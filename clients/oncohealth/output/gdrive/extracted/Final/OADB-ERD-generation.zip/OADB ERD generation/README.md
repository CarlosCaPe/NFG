This script references a SQL file. Please update the sql_file path to the correct one.
Then run command in terminal -> python generate_table_dependencies.py <tablename> (e.g. Patients instead of <tablename>)
List of tables in database_table_names.json.
It should generate a dbdiagram and json files.
