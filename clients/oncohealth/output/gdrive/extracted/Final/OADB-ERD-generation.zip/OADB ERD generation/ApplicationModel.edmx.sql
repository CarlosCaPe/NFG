
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 09/30/2025 19:29:56
-- Generated from EDMX file: C:\Users\bohdan.chachun\source\repos onch\MATIS\MATIS\src\Data\OncologyAnalytics.DB\ApplicationModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [OADB-DEV];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK__PatientAs__Docum__0A54486F]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientAssessment] DROP CONSTRAINT [FK__PatientAs__Docum__0A54486F];
GO
IF OBJECT_ID(N'[dbo].[FK__PatientProtocolAssignment_ProtocolDiagnosis__LookupElement__PerformanceStatus]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDiagnosis] DROP CONSTRAINT [FK__PatientProtocolAssignment_ProtocolDiagnosis__LookupElement__PerformanceStatus];
GO
IF OBJECT_ID(N'[dbo].[FK_ActiveSurveillanceLifeExpectancy_ActiveSruveillanceLifeExpectancyDescription]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ActiveSurveillanceLifeExpectancy] DROP CONSTRAINT [FK_ActiveSurveillanceLifeExpectancy_ActiveSruveillanceLifeExpectancyDescription];
GO
IF OBJECT_ID(N'[dbo].[FK_ActiveSurveillanceLifeExpectancy_AssessmentQuestionPossibleAnswer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ActiveSurveillanceLifeExpectancy] DROP CONSTRAINT [FK_ActiveSurveillanceLifeExpectancy_AssessmentQuestionPossibleAnswer];
GO
IF OBJECT_ID(N'[dbo].[FK_Address_State]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Address] DROP CONSTRAINT [FK_Address_State];
GO
IF OBJECT_ID(N'[dbo].[FK_Aggregation_AggregationRule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Aggregation] DROP CONSTRAINT [FK_Aggregation_AggregationRule];
GO
IF OBJECT_ID(N'[dbo].[FK_Aggregation_LookupElement_ApprovalReason]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Aggregation] DROP CONSTRAINT [FK_Aggregation_LookupElement_ApprovalReason];
GO
IF OBJECT_ID(N'[dbo].[FK_Aggregation_LookupElement_ApprovalRule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Aggregation] DROP CONSTRAINT [FK_Aggregation_LookupElement_ApprovalRule];
GO
IF OBJECT_ID(N'[dbo].[FK_Aggregation_LookupElement_AutoProcess]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Aggregation] DROP CONSTRAINT [FK_Aggregation_LookupElement_AutoProcess];
GO
IF OBJECT_ID(N'[dbo].[FK_AggregationResolution_AggregationRule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AggregationResolution] DROP CONSTRAINT [FK_AggregationResolution_AggregationRule];
GO
IF OBJECT_ID(N'[dbo].[FK_AggregationResulution_LookupElement_AutoProcess]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AggregationResolution] DROP CONSTRAINT [FK_AggregationResulution_LookupElement_AutoProcess];
GO
IF OBJECT_ID(N'[dbo].[FK_AggregationRule_Rule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AggregationRule] DROP CONSTRAINT [FK_AggregationRule_Rule];
GO
IF OBJECT_ID(N'[dbo].[FK_ApprovedDrugsOverturnList_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ApprovedDrugsOverturnList] DROP CONSTRAINT [FK_ApprovedDrugsOverturnList_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_AssessmentDiagnosis_AssessmentType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssessmentDiagnosis] DROP CONSTRAINT [FK_AssessmentDiagnosis_AssessmentType];
GO
IF OBJECT_ID(N'[dbo].[FK_AssessmentDiagnosis_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssessmentDiagnosis] DROP CONSTRAINT [FK_AssessmentDiagnosis_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_AssessmentDiagnosis_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssessmentDiagnosis] DROP CONSTRAINT [FK_AssessmentDiagnosis_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_AssessmentDiagnosis_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssessmentDiagnosis] DROP CONSTRAINT [FK_AssessmentDiagnosis_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_AssessmentQuestion_AssessmentQuestion]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssessmentQuestion] DROP CONSTRAINT [FK_AssessmentQuestion_AssessmentQuestion];
GO
IF OBJECT_ID(N'[dbo].[FK_AssessmentQuestionPossibleAnswer_AssessmentQuestion]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssessmentQuestionPossibleAnswer] DROP CONSTRAINT [FK_AssessmentQuestionPossibleAnswer_AssessmentQuestion];
GO
IF OBJECT_ID(N'[dbo].[FK_AssessmentType_AssessmentQuestion_AssessmentQuestion]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssessmentType_AssessmentQuestion] DROP CONSTRAINT [FK_AssessmentType_AssessmentQuestion_AssessmentQuestion];
GO
IF OBJECT_ID(N'[dbo].[FK_AssessmentType_AssessmentQuestion_AssessmentType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssessmentType_AssessmentQuestion] DROP CONSTRAINT [FK_AssessmentType_AssessmentQuestion_AssessmentType];
GO
IF OBJECT_ID(N'[dbo].[FK_AssignmentAction_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssignmentAction] DROP CONSTRAINT [FK_AssignmentAction_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_AssignmentAction_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssignmentAction] DROP CONSTRAINT [FK_AssignmentAction_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_AssignmentAction_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssignmentAction] DROP CONSTRAINT [FK_AssignmentAction_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID];
GO
IF OBJECT_ID(N'[dbo].[FK_AssignmentLockByUser_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssignmentLockByUser] DROP CONSTRAINT [FK_AssignmentLockByUser_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_AssignmentLockByUser_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssignmentLockByUser] DROP CONSTRAINT [FK_AssignmentLockByUser_User];
GO
IF OBJECT_ID(N'[dbo].[FK_AssignmentProvider_Contact]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssignmentProvider] DROP CONSTRAINT [FK_AssignmentProvider_Contact];
GO
IF OBJECT_ID(N'[dbo].[FK_AssignmentProvider_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssignmentProvider] DROP CONSTRAINT [FK_AssignmentProvider_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_AssignmentProvider_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssignmentProvider] DROP CONSTRAINT [FK_AssignmentProvider_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_AssignmentTimeZone_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssignmentTimeZone] DROP CONSTRAINT [FK_AssignmentTimeZone_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_AssignmentWorkflowStatusLog_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssignmentWorkflowStatusLog] DROP CONSTRAINT [FK_AssignmentWorkflowStatusLog_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_AssignmentWorkflowStatusLog_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssignmentWorkflowStatusLog] DROP CONSTRAINT [FK_AssignmentWorkflowStatusLog_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID];
GO
IF OBJECT_ID(N'[dbo].[FK_AssignmentWorkflowStatusLog_WorkQueue]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AssignmentWorkflowStatusLog] DROP CONSTRAINT [FK_AssignmentWorkflowStatusLog_WorkQueue];
GO
IF OBJECT_ID(N'[dbo].[FK_Attachment_DocumentRepository]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Attachment] DROP CONSTRAINT [FK_Attachment_DocumentRepository];
GO
IF OBJECT_ID(N'[dbo].[FK_Attachment_Patient]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Attachment] DROP CONSTRAINT [FK_Attachment_Patient];
GO
IF OBJECT_ID(N'[dbo].[FK_Attachment_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Attachment] DROP CONSTRAINT [FK_Attachment_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_Attachment_PatientProtocolAssignment_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Attachment] DROP CONSTRAINT [FK_Attachment_PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_Attachment_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Attachment] DROP CONSTRAINT [FK_Attachment_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID];
GO
IF OBJECT_ID(N'[dbo].[FK_Attachment_User_CurrentMD]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Attachment] DROP CONSTRAINT [FK_Attachment_User_CurrentMD];
GO
IF OBJECT_ID(N'[dbo].[FK_AuditTrailField_AuditTrailObjectType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AuditTrailField] DROP CONSTRAINT [FK_AuditTrailField_AuditTrailObjectType];
GO
IF OBJECT_ID(N'[dbo].[FK_AuditTrailTransaction_AuditTrailObjectType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AuditTrailTransaction] DROP CONSTRAINT [FK_AuditTrailTransaction_AuditTrailObjectType];
GO
IF OBJECT_ID(N'[dbo].[FK_AuditTrailTransactionDetail_AuditTrailField]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AuditTrailTransactionDetail] DROP CONSTRAINT [FK_AuditTrailTransactionDetail_AuditTrailField];
GO
IF OBJECT_ID(N'[dbo].[FK_AuditTrailTransactionDetail_AuditTrailTransaction]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AuditTrailTransactionDetail] DROP CONSTRAINT [FK_AuditTrailTransactionDetail_AuditTrailTransaction];
GO
IF OBJECT_ID(N'[dbo].[FK_AutoProtocolConfiguration_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AutoProtocolConfiguration] DROP CONSTRAINT [FK_AutoProtocolConfiguration_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_AutoProtocolConfiguration_Lookup]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AutoProtocolConfiguration] DROP CONSTRAINT [FK_AutoProtocolConfiguration_Lookup];
GO
IF OBJECT_ID(N'[dbo].[FK_AutoProtocolConfiguration_LookupElement_AssignmentCategory]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AutoProtocolConfiguration] DROP CONSTRAINT [FK_AutoProtocolConfiguration_LookupElement_AssignmentCategory];
GO
IF OBJECT_ID(N'[dbo].[FK_AutoProtocolConfiguration_LookupElement_ConfigurationSubID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AutoProtocolConfiguration] DROP CONSTRAINT [FK_AutoProtocolConfiguration_LookupElement_ConfigurationSubID];
GO
IF OBJECT_ID(N'[dbo].[FK_AutoProtocolConfiguration_LookupElement_Gender]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AutoProtocolConfiguration] DROP CONSTRAINT [FK_AutoProtocolConfiguration_LookupElement_Gender];
GO
IF OBJECT_ID(N'[dbo].[FK_AutoProtocolConfiguration_LookupElement_TurnToAutoReason]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AutoProtocolConfiguration] DROP CONSTRAINT [FK_AutoProtocolConfiguration_LookupElement_TurnToAutoReason];
GO
IF OBJECT_ID(N'[dbo].[FK_BrandDrug_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[BrandDrug] DROP CONSTRAINT [FK_BrandDrug_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_BrandDrugCode_BrandDrug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[BrandDrugCode] DROP CONSTRAINT [FK_BrandDrugCode_BrandDrug];
GO
IF OBJECT_ID(N'[dbo].[FK_CallerContactDetail_LookupElement_CallMethod]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CallerContactDetail] DROP CONSTRAINT [FK_CallerContactDetail_LookupElement_CallMethod];
GO
IF OBJECT_ID(N'[dbo].[FK_CallerContactDetail_LookupElement_CallSubject]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CallerContactDetail] DROP CONSTRAINT [FK_CallerContactDetail_LookupElement_CallSubject];
GO
IF OBJECT_ID(N'[dbo].[FK_CallerContactDetail_LookupElement_CallType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CallerContactDetail] DROP CONSTRAINT [FK_CallerContactDetail_LookupElement_CallType];
GO
IF OBJECT_ID(N'[dbo].[FK_CallerContactDetail_LookupElement_ContactTitle]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CallerContactDetail] DROP CONSTRAINT [FK_CallerContactDetail_LookupElement_ContactTitle];
GO
IF OBJECT_ID(N'[dbo].[FK_CallerContactDetail_LookupElement_MessageType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CallerContactDetail] DROP CONSTRAINT [FK_CallerContactDetail_LookupElement_MessageType];
GO
IF OBJECT_ID(N'[dbo].[FK_CallerContactDetail_LookupElement_Outcome]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CallerContactDetail] DROP CONSTRAINT [FK_CallerContactDetail_LookupElement_Outcome];
GO
IF OBJECT_ID(N'[dbo].[FK_CallerContactDetail_LookupElement_UnsuccessfulContactMethod]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CallerContactDetail] DROP CONSTRAINT [FK_CallerContactDetail_LookupElement_UnsuccessfulContactMethod];
GO
IF OBJECT_ID(N'[dbo].[FK_CallerContactDetail_PatientProtocolAssignment_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CallerContactDetail] DROP CONSTRAINT [FK_CallerContactDetail_PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_CallerContactDetail_PatientProtocolAssignment1]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CallerContactDetail] DROP CONSTRAINT [FK_CallerContactDetail_PatientProtocolAssignment1];
GO
IF OBJECT_ID(N'[dbo].[FK_ChangeReasonID_LookupElementID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_ChangeReasonID_LookupElementID];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalObservation_LookupElement_CodingSystem]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalObservation] DROP CONSTRAINT [FK_ClinicalObservation_LookupElement_CodingSystem];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalObservation_LookupElement_Type]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalObservation] DROP CONSTRAINT [FK_ClinicalObservation_LookupElement_Type];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalObservation_LookupElement_UnitsOfMeasure]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalObservation] DROP CONSTRAINT [FK_ClinicalObservation_LookupElement_UnitsOfMeasure];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalObservation_LookupElement_ValueType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalObservation] DROP CONSTRAINT [FK_ClinicalObservation_LookupElement_ValueType];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalObservationLabResult_ClinicalObservation]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalObservationLabResult] DROP CONSTRAINT [FK_ClinicalObservationLabResult_ClinicalObservation];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalObservationLabResult_LookupElement_Source]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalObservationLabResult] DROP CONSTRAINT [FK_ClinicalObservationLabResult_LookupElement_Source];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalObservationLabResult_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalObservationLabResult] DROP CONSTRAINT [FK_ClinicalObservationLabResult_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalQuestion_LookupElement_QuestionStatus]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalQuestion] DROP CONSTRAINT [FK_ClinicalQuestion_LookupElement_QuestionStatus];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalQuestion_LookupElement_QuestionTypeId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalQuestion] DROP CONSTRAINT [FK_ClinicalQuestion_LookupElement_QuestionTypeId];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalQuestionAnswer_LookupElement_AnswerStatus]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalQuestionAnswer] DROP CONSTRAINT [FK_ClinicalQuestionAnswer_LookupElement_AnswerStatus];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalQuestionAnswer_LookupElement_AnswerTypeId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalQuestionAnswer] DROP CONSTRAINT [FK_ClinicalQuestionAnswer_LookupElement_AnswerTypeId];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalQuestionDiagnosisId_ClinicalQuestionId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalQuestionDiagnosis] DROP CONSTRAINT [FK_ClinicalQuestionDiagnosisId_ClinicalQuestionId];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalQuestionDiagnosisId_DiagnosisId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalQuestionDiagnosis] DROP CONSTRAINT [FK_ClinicalQuestionDiagnosisId_DiagnosisId];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalQuestionId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalQuestionAnswer] DROP CONSTRAINT [FK_ClinicalQuestionId];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalValuesRule_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalValuesRule] DROP CONSTRAINT [FK_ClinicalValuesRule_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalValuesRule_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalValuesRule] DROP CONSTRAINT [FK_ClinicalValuesRule_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalValuesRule_Rule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalValuesRule] DROP CONSTRAINT [FK_ClinicalValuesRule_Rule];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalValuesRuleDiagnosisExcluded_ClinicalValuesRule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalValuesRuleDiagnosisExcluded] DROP CONSTRAINT [FK_ClinicalValuesRuleDiagnosisExcluded_ClinicalValuesRule];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalValuesRuleDiagnosisExcluded_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalValuesRuleDiagnosisExcluded] DROP CONSTRAINT [FK_ClinicalValuesRuleDiagnosisExcluded_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalValuesRuleLabResult_ClinicalObservation]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalValuesRuleLabResult] DROP CONSTRAINT [FK_ClinicalValuesRuleLabResult_ClinicalObservation];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalValuesRuleLabResult_ClinicalValuesRule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalValuesRuleLabResult] DROP CONSTRAINT [FK_ClinicalValuesRuleLabResult_ClinicalValuesRule];
GO
IF OBJECT_ID(N'[dbo].[FK_ClinicalValuesRuleLabResult_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ClinicalValuesRuleLabResult] DROP CONSTRAINT [FK_ClinicalValuesRuleLabResult_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_County_State]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[County] DROP CONSTRAINT [FK_County_State];
GO
IF OBJECT_ID(N'[dbo].[FK_CPTCodeXRT_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CPTCodeXRT] DROP CONSTRAINT [FK_CPTCodeXRT_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_DecisionReason_DecisionReasonElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DecisionReasonElement] DROP CONSTRAINT [FK_DecisionReason_DecisionReasonElement];
GO
IF OBJECT_ID(N'[dbo].[FK_DecisionReasonElementRequestType_DecisionReasonElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DecisionReasonElementRequestType] DROP CONSTRAINT [FK_DecisionReasonElementRequestType_DecisionReasonElement];
GO
IF OBJECT_ID(N'[dbo].[FK_DecisionReasonElementRequestType_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DecisionReasonElementRequestType] DROP CONSTRAINT [FK_DecisionReasonElementRequestType_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_Diagnosis_MetastaticSite_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Diagnosis_MetastaticSite] DROP CONSTRAINT [FK_Diagnosis_MetastaticSite_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_Diagnosis_MetastaticSite_MetastaticSite]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Diagnosis_MetastaticSite] DROP CONSTRAINT [FK_Diagnosis_MetastaticSite_MetastaticSite];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisClinicalNarrative_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisClinicalNarrative] DROP CONSTRAINT [FK_DiagnosisClinicalNarrative_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisClinicalTrialLink_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisClinicalTrialLink] DROP CONSTRAINT [FK_DiagnosisClinicalTrialLink_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisClinicalTrialLink_LookupElement_StageID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisClinicalTrialLink] DROP CONSTRAINT [FK_DiagnosisClinicalTrialLink_LookupElement_StageID];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisConfiguration_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisConfiguration] DROP CONSTRAINT [FK_DiagnosisConfiguration_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisConfiguration_LookupElement_ProtocolType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisConfiguration] DROP CONSTRAINT [FK_DiagnosisConfiguration_LookupElement_ProtocolType];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisDistantMetaStasis_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisDistantMetaStasis] DROP CONSTRAINT [FK_DiagnosisDistantMetaStasis_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisDistantMetaStasis_LookupElement_Stage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisDistantMetaStasis] DROP CONSTRAINT [FK_DiagnosisDistantMetaStasis_LookupElement_Stage];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisDistantMetaStasiss_LookupElement_Stage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisDistantMetaStasis] DROP CONSTRAINT [FK_DiagnosisDistantMetaStasiss_LookupElement_Stage];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisICDCode_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisICDCode] DROP CONSTRAINT [FK_DiagnosisICDCode_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisICDCode_ICDCode]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisICDCode] DROP CONSTRAINT [FK_DiagnosisICDCode_ICDCode];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisLineOfTherapy_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisLineOfTherapy] DROP CONSTRAINT [FK_DiagnosisLineOfTherapy_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisLineOfTherapy_LookupElement_Stage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisLineOfTherapy] DROP CONSTRAINT [FK_DiagnosisLineOfTherapy_LookupElement_Stage];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisLocalizedDisease_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisLocalizedDisease] DROP CONSTRAINT [FK_DiagnosisLocalizedDisease_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisLocalizedDiseaseStage_DiagnosisLocalizedDisease]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisLocalizedDiseaseStage] DROP CONSTRAINT [FK_DiagnosisLocalizedDiseaseStage_DiagnosisLocalizedDisease];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisLocalizedDiseaseStage_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisLocalizedDiseaseStage] DROP CONSTRAINT [FK_DiagnosisLocalizedDiseaseStage_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisMolecularMarker_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisMolecularMarker] DROP CONSTRAINT [FK_DiagnosisMolecularMarker_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisMolecularMarker_LookupElement_Stage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisMolecularMarker] DROP CONSTRAINT [FK_DiagnosisMolecularMarker_LookupElement_Stage];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisNodalStatus_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisNodalStatus] DROP CONSTRAINT [FK_DiagnosisNodalStatus_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisNodalStatus_LookupElement_Stage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisNodalStatus] DROP CONSTRAINT [FK_DiagnosisNodalStatus_LookupElement_Stage];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisNodalStatuss_LookupElement_Stage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisNodalStatus] DROP CONSTRAINT [FK_DiagnosisNodalStatuss_LookupElement_Stage];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisPhase_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisPhase] DROP CONSTRAINT [FK_DiagnosisPhase_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisPhases_LookupElement_Phase]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisPhase] DROP CONSTRAINT [FK_DiagnosisPhases_LookupElement_Phase];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisSettingOfTherapy_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisSettingOfTherapy] DROP CONSTRAINT [FK_DiagnosisSettingOfTherapy_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisSettingOfTherapy_LookupElement_Stage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisSettingOfTherapy] DROP CONSTRAINT [FK_DiagnosisSettingOfTherapy_LookupElement_Stage];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisStage_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisStage] DROP CONSTRAINT [FK_DiagnosisStage_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisStage_LookupElement_Stage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisStage] DROP CONSTRAINT [FK_DiagnosisStage_LookupElement_Stage];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisStages_LookupElement_Stage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisStage] DROP CONSTRAINT [FK_DiagnosisStages_LookupElement_Stage];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisTumorSize_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisTumorSize] DROP CONSTRAINT [FK_DiagnosisTumorSize_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisTumorSize_LookupElement_Stage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisTumorSize] DROP CONSTRAINT [FK_DiagnosisTumorSize_LookupElement_Stage];
GO
IF OBJECT_ID(N'[dbo].[FK_DiagnosisTumorSizes_LookupElement_Stage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiagnosisTumorSize] DROP CONSTRAINT [FK_DiagnosisTumorSizes_LookupElement_Stage];
GO
IF OBJECT_ID(N'[dbo].[FK_DimPayer_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DimPayer] DROP CONSTRAINT [FK_DimPayer_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_DimPayer_LineofBusiness]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DimPayer] DROP CONSTRAINT [FK_DimPayer_LineofBusiness];
GO
IF OBJECT_ID(N'[dbo].[FK_DimPayer_LookupElement_MajorLineOfBusiness]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DimPayer] DROP CONSTRAINT [FK_DimPayer_LookupElement_MajorLineOfBusiness];
GO
IF OBJECT_ID(N'[dbo].[FK_DimPayer_ProductLine]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DimPayer] DROP CONSTRAINT [FK_DimPayer_ProductLine];
GO
IF OBJECT_ID(N'[dbo].[FK_DimPayer_StateCode]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DimPayer] DROP CONSTRAINT [FK_DimPayer_StateCode];
GO
IF OBJECT_ID(N'[dbo].[FK_DimPayer_StateOfPlanIssue]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DimPayer] DROP CONSTRAINT [FK_DimPayer_StateOfPlanIssue];
GO
IF OBJECT_ID(N'[dbo].[FK_DimPayerPreferredProtocolProgram_DimPayer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DimPayerPreferredProtocolProgram] DROP CONSTRAINT [FK_DimPayerPreferredProtocolProgram_DimPayer];
GO
IF OBJECT_ID(N'[dbo].[FK_DimPayerPreferredProtocolProgram_LookupElement_PreferredProgram]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DimPayerPreferredProtocolProgram] DROP CONSTRAINT [FK_DimPayerPreferredProtocolProgram_LookupElement_PreferredProgram];
GO
IF OBJECT_ID(N'[dbo].[FK_DimPayerPreferredProtocolProgram_LookupElement_PreferredStatus]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DimPayerPreferredProtocolProgram] DROP CONSTRAINT [FK_DimPayerPreferredProtocolProgram_LookupElement_PreferredStatus];
GO
IF OBJECT_ID(N'[dbo].[FK_DimPayerPreferredProtocolProgram_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DimPayerPreferredProtocolProgram] DROP CONSTRAINT [FK_DimPayerPreferredProtocolProgram_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_DimPayerPreferredProtocolProgramPatientDiagnosis_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DimPayerPreferredProtocolProgram_PatientDiagnosis] DROP CONSTRAINT [FK_DimPayerPreferredProtocolProgramPatientDiagnosis_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_DimPayerPreferredProtocolProgramPatientDiagnosis_DimPayerPreferredProtocolProgram]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DimPayerPreferredProtocolProgram_PatientDiagnosis] DROP CONSTRAINT [FK_DimPayerPreferredProtocolProgramPatientDiagnosis_DimPayerPreferredProtocolProgram];
GO
IF OBJECT_ID(N'[dbo].[FK_DimPayerRule_DimPayer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DimPayerRule] DROP CONSTRAINT [FK_DimPayerRule_DimPayer];
GO
IF OBJECT_ID(N'[dbo].[FK_DimPayerRule_LookupElement_ApprovalRuleMode]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DimPayerRule] DROP CONSTRAINT [FK_DimPayerRule_LookupElement_ApprovalRuleMode];
GO
IF OBJECT_ID(N'[dbo].[FK_DimPayerRule_Rule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DimPayerRule] DROP CONSTRAINT [FK_DimPayerRule_Rule];
GO
IF OBJECT_ID(N'[dbo].[FK_DiscontiueAuthorizationAssignment_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiscontiueAuthorizationAssignment] DROP CONSTRAINT [FK_DiscontiueAuthorizationAssignment_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_DiscontiueAuthorizationLinkedAssignment_DiscontiueAuthorizationAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiscontiueAuthorizationLinkedAssignment] DROP CONSTRAINT [FK_DiscontiueAuthorizationLinkedAssignment_DiscontiueAuthorizationAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_DiscontiueAuthorizationLinkedAssignment_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DiscontiueAuthorizationLinkedAssignment] DROP CONSTRAINT [FK_DiscontiueAuthorizationLinkedAssignment_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_DocumentDeletionReason_DocumentRepository]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DocumentDeletionReason] DROP CONSTRAINT [FK_DocumentDeletionReason_DocumentRepository];
GO
IF OBJECT_ID(N'[dbo].[FK_DocumentDeletionReason_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DocumentDeletionReason] DROP CONSTRAINT [FK_DocumentDeletionReason_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_DocumentDownloadHistory_DocumentRepository]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DocumentDownloadHistory] DROP CONSTRAINT [FK_DocumentDownloadHistory_DocumentRepository];
GO
IF OBJECT_ID(N'[dbo].[FK_DocumentExtraInfo_DocumentRepository]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DocumentExtraInfo] DROP CONSTRAINT [FK_DocumentExtraInfo_DocumentRepository];
GO
IF OBJECT_ID(N'[dbo].[FK_DocumentExtraInfo_Priority]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DocumentExtraInfo] DROP CONSTRAINT [FK_DocumentExtraInfo_Priority];
GO
IF OBJECT_ID(N'[dbo].[FK_DocumentRepository_FileExtension]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DocumentRepository] DROP CONSTRAINT [FK_DocumentRepository_FileExtension];
GO
IF OBJECT_ID(N'[dbo].[FK_DocumentRepository_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DocumentRepository] DROP CONSTRAINT [FK_DocumentRepository_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_DocumentRepository_LookupElement_DocumentType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DocumentRepository] DROP CONSTRAINT [FK_DocumentRepository_LookupElement_DocumentType];
GO
IF OBJECT_ID(N'[dbo].[FK_DocumentTextBlock_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DocumentTextBlock] DROP CONSTRAINT [FK_DocumentTextBlock_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_DocumentTextBlock_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DocumentTextBlock] DROP CONSTRAINT [FK_DocumentTextBlock_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_Drug_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Drug] DROP CONSTRAINT [FK_Drug_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_Drug_LookupElement_DrugClass]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Drug] DROP CONSTRAINT [FK_Drug_LookupElement_DrugClass];
GO
IF OBJECT_ID(N'[dbo].[FK_Drug_LookupElement_DrugSubClass]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Drug] DROP CONSTRAINT [FK_Drug_LookupElement_DrugSubClass];
GO
IF OBJECT_ID(N'[dbo].[FK_Drug_LookupElement_GCSFType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Drug] DROP CONSTRAINT [FK_Drug_LookupElement_GCSFType];
GO
IF OBJECT_ID(N'[dbo].[FK_Drug_LookupElement_RxNormTermType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Drug] DROP CONSTRAINT [FK_Drug_LookupElement_RxNormTermType];
GO
IF OBJECT_ID(N'[dbo].[FK_Drug_SideEffect_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Drug_SideEffect] DROP CONSTRAINT [FK_Drug_SideEffect_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_Drug_SideEffect_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Drug_SideEffect] DROP CONSTRAINT [FK_Drug_SideEffect_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_DrugBiosimilarity_BiosimilarDrug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DrugBiosimilarity] DROP CONSTRAINT [FK_DrugBiosimilarity_BiosimilarDrug];
GO
IF OBJECT_ID(N'[dbo].[FK_DrugBiosimilarity_OriginalDrug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DrugBiosimilarity] DROP CONSTRAINT [FK_DrugBiosimilarity_OriginalDrug];
GO
IF OBJECT_ID(N'[dbo].[FK_DrugCode_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DrugCode] DROP CONSTRAINT [FK_DrugCode_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_DrugPolicy_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DrugPolicy] DROP CONSTRAINT [FK_DrugPolicy_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_DrugPolicy_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DrugPolicy] DROP CONSTRAINT [FK_DrugPolicy_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_DrugPolicyCriteria_DrugPolicy]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DrugPolicyCriteria] DROP CONSTRAINT [FK_DrugPolicyCriteria_DrugPolicy];
GO
IF OBJECT_ID(N'[dbo].[FK_DrugPolicyCriteriaDiagnosis_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DrugPolicyCriteriaDiagnosis] DROP CONSTRAINT [FK_DrugPolicyCriteriaDiagnosis_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_DrugPolicyCriteriaDiagnosis_DrugPolicyCriteria]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DrugPolicyCriteriaDiagnosis] DROP CONSTRAINT [FK_DrugPolicyCriteriaDiagnosis_DrugPolicyCriteria];
GO
IF OBJECT_ID(N'[dbo].[FK_DrugPolicyCriteriaDiagnosis_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DrugPolicyCriteriaDiagnosis] DROP CONSTRAINT [FK_DrugPolicyCriteriaDiagnosis_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_DrugPolicyLOB_DrugPolicy]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DrugPolicyLOB] DROP CONSTRAINT [FK_DrugPolicyLOB_DrugPolicy];
GO
IF OBJECT_ID(N'[dbo].[FK_DrugPolicyLOB_LineofBusiness]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DrugPolicyLOB] DROP CONSTRAINT [FK_DrugPolicyLOB_LineofBusiness];
GO
IF OBJECT_ID(N'[dbo].[FK_DrugProtocolTotalBillingUnits_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DrugProtocolTotalBillingUnits] DROP CONSTRAINT [FK_DrugProtocolTotalBillingUnits_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_DrugProtocolTotalBillingUnits_LookupElement_BillingMethod]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DrugProtocolTotalBillingUnits] DROP CONSTRAINT [FK_DrugProtocolTotalBillingUnits_LookupElement_BillingMethod];
GO
IF OBJECT_ID(N'[dbo].[FK_DrugProtocolTotalBillingUnits_LookupElement_CodeType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DrugProtocolTotalBillingUnits] DROP CONSTRAINT [FK_DrugProtocolTotalBillingUnits_LookupElement_CodeType];
GO
IF OBJECT_ID(N'[dbo].[FK_DrugProtocolTotalBillingUnits_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DrugProtocolTotalBillingUnits] DROP CONSTRAINT [FK_DrugProtocolTotalBillingUnits_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_DynamicFaxContent_AppealLanguage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DynamicFaxContent] DROP CONSTRAINT [FK_DynamicFaxContent_AppealLanguage];
GO
IF OBJECT_ID(N'[dbo].[FK_DynamicFaxContent_DocumentTextBlock_DenialHealthcareAdvocateInfo]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DynamicFaxContent] DROP CONSTRAINT [FK_DynamicFaxContent_DocumentTextBlock_DenialHealthcareAdvocateInfo];
GO
IF OBJECT_ID(N'[dbo].[FK_DynamicFaxContent_DocumentTextBlock_HelpInfo]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DynamicFaxContent] DROP CONSTRAINT [FK_DynamicFaxContent_DocumentTextBlock_HelpInfo];
GO
IF OBJECT_ID(N'[dbo].[FK_DynamicFaxContent_Image]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DynamicFaxContent] DROP CONSTRAINT [FK_DynamicFaxContent_Image];
GO
IF OBJECT_ID(N'[dbo].[FK_DynamicFaxContent_NotificationEnclosure_Application]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DynamicFaxContent] DROP CONSTRAINT [FK_DynamicFaxContent_NotificationEnclosure_Application];
GO
IF OBJECT_ID(N'[dbo].[FK_DynamicFaxContent_NotificationEnclosure_Guide]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DynamicFaxContent] DROP CONSTRAINT [FK_DynamicFaxContent_NotificationEnclosure_Guide];
GO
IF OBJECT_ID(N'[dbo].[FK_Eligibility_DualEligibilityStatus]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Eligibility] DROP CONSTRAINT [FK_Eligibility_DualEligibilityStatus];
GO
IF OBJECT_ID(N'[dbo].[FK_Eligibility_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Eligibility] DROP CONSTRAINT [FK_Eligibility_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_Eligibility_LineofBusiness]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Eligibility] DROP CONSTRAINT [FK_Eligibility_LineofBusiness];
GO
IF OBJECT_ID(N'[dbo].[FK_Eligibility_Patient]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Eligibility] DROP CONSTRAINT [FK_Eligibility_Patient];
GO
IF OBJECT_ID(N'[dbo].[FK_Eligibility_ProductLine]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Eligibility] DROP CONSTRAINT [FK_Eligibility_ProductLine];
GO
IF OBJECT_ID(N'[dbo].[FK_EmailArchive_Patient]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[EmailArchive] DROP CONSTRAINT [FK_EmailArchive_Patient];
GO
IF OBJECT_ID(N'[dbo].[FK_EmailArchive_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[EmailArchive] DROP CONSTRAINT [FK_EmailArchive_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_EmailArchiveDetail_EmailArchive]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[EmailArchiveDetail] DROP CONSTRAINT [FK_EmailArchiveDetail_EmailArchive];
GO
IF OBJECT_ID(N'[dbo].[FK_EmailArchiveDocument_DocumentRepository]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[EmailArchiveDocument] DROP CONSTRAINT [FK_EmailArchiveDocument_DocumentRepository];
GO
IF OBJECT_ID(N'[dbo].[FK_EmailArchiveDocument_EmailArchive]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[EmailArchiveDocument] DROP CONSTRAINT [FK_EmailArchiveDocument_EmailArchive];
GO
IF OBJECT_ID(N'[dbo].[FK_EODFile_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[EODFile] DROP CONSTRAINT [FK_EODFile_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_EODFileProtocolAssignment_EODFile]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[EODFileProtocolAssignment] DROP CONSTRAINT [FK_EODFileProtocolAssignment_EODFile];
GO
IF OBJECT_ID(N'[dbo].[FK_EODFileProtocolAssignment_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[EODFileProtocolAssignment] DROP CONSTRAINT [FK_EODFileProtocolAssignment_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_ExcludedPCP_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ExcludedPCP] DROP CONSTRAINT [FK_ExcludedPCP_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_ExplicitQuestionAnswer_ExplicitQuestion]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ExplicitQuestionAnswer] DROP CONSTRAINT [FK_ExplicitQuestionAnswer_ExplicitQuestion];
GO
IF OBJECT_ID(N'[dbo].[FK_ExplicitQuestionAnswer_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ExplicitQuestionAnswer] DROP CONSTRAINT [FK_ExplicitQuestionAnswer_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_ExplicitQuestionAnswerXRT_ExplicitQuestionXRT]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ExplicitAnswerXRT] DROP CONSTRAINT [FK_ExplicitQuestionAnswerXRT_ExplicitQuestionXRT];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxArchive_Patient]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxArchive] DROP CONSTRAINT [FK_FaxArchive_Patient];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxArchive_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxArchive] DROP CONSTRAINT [FK_FaxArchive_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxArchiveDocument_DocumentRepository]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxArchiveDocument] DROP CONSTRAINT [FK_FaxArchiveDocument_DocumentRepository];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxArchiveDocument_FaxArchive]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxArchiveDocument] DROP CONSTRAINT [FK_FaxArchiveDocument_FaxArchive];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxCatalog_InsuranceProviderFaxTemplate]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxCatalog] DROP CONSTRAINT [FK_FaxCatalog_InsuranceProviderFaxTemplate];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxDetails_DocumentRepository]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxDetails] DROP CONSTRAINT [FK_FaxDetails_DocumentRepository];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxDetails_FaxAddress]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxDetails] DROP CONSTRAINT [FK_FaxDetails_FaxAddress];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxDocumentAssignment_DocumentRepository]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxDocumentAssignment] DROP CONSTRAINT [FK_FaxDocumentAssignment_DocumentRepository];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxDocumentAssignment_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxDocumentAssignment] DROP CONSTRAINT [FK_FaxDocumentAssignment_User];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxParameter_FaxCatalog]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxParameter] DROP CONSTRAINT [FK_FaxParameter_FaxCatalog];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxRecipient_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxRecipient] DROP CONSTRAINT [FK_FaxRecipient_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxRecipient_LineofBusiness]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxRecipient] DROP CONSTRAINT [FK_FaxRecipient_LineofBusiness];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxRecipient_LookupElement_FaxRecipientType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxRecipient] DROP CONSTRAINT [FK_FaxRecipient_LookupElement_FaxRecipientType];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxRecipient_LookupElement_FaxTemplatetType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxRecipient] DROP CONSTRAINT [FK_FaxRecipient_LookupElement_FaxTemplatetType];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxRecipient_State]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxRecipient] DROP CONSTRAINT [FK_FaxRecipient_State];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxRecipientConfiguration_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxRecipientConfiguration] DROP CONSTRAINT [FK_FaxRecipientConfiguration_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxRecipientConfiguration_LineofBusiness]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxRecipientConfiguration] DROP CONSTRAINT [FK_FaxRecipientConfiguration_LineofBusiness];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxRecipientConfiguration_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxRecipientConfiguration] DROP CONSTRAINT [FK_FaxRecipientConfiguration_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxRecipientConfiguration_ProductLine]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxRecipientConfiguration] DROP CONSTRAINT [FK_FaxRecipientConfiguration_ProductLine];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxRecipientConfigurationFaxRecipientType_FaxRecipientConfiguration]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxRecipientConfigurationFaxRecipientType] DROP CONSTRAINT [FK_FaxRecipientConfigurationFaxRecipientType_FaxRecipientConfiguration];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxRecipientConfigurationFaxRecipientType_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxRecipientConfigurationFaxRecipientType] DROP CONSTRAINT [FK_FaxRecipientConfigurationFaxRecipientType_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_FaxRecipientState_FaxRecipientConfiguration]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FaxRecipientConfigurationState] DROP CONSTRAINT [FK_FaxRecipientState_FaxRecipientConfiguration];
GO
IF OBJECT_ID(N'[dbo].[FK_FebrileNeutropeniaClinicalValuesRule_ClinicalValuesRule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FebrileNeutropeniaClinicalValuesRule] DROP CONSTRAINT [FK_FebrileNeutropeniaClinicalValuesRule_ClinicalValuesRule];
GO
IF OBJECT_ID(N'[dbo].[FK_FebrileNeutropeniaClinicalValuesRule_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FebrileNeutropeniaClinicalValuesRule] DROP CONSTRAINT [FK_FebrileNeutropeniaClinicalValuesRule_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_FormularyException_AlternativeCode_FormularyException]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FormularyException_AlternativeCode] DROP CONSTRAINT [FK_FormularyException_AlternativeCode_FormularyException];
GO
IF OBJECT_ID(N'[dbo].[FK_FormularyException_AlternativeCode_LookupElement_CodeType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FormularyException_AlternativeCode] DROP CONSTRAINT [FK_FormularyException_AlternativeCode_LookupElement_CodeType];
GO
IF OBJECT_ID(N'[dbo].[FK_FormularyException_ExceptionType_FormularyException]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FormularyException_ExceptionType] DROP CONSTRAINT [FK_FormularyException_ExceptionType_FormularyException];
GO
IF OBJECT_ID(N'[dbo].[FK_FormularyException_ExceptionType_LookupElement_ExceptionType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FormularyException_ExceptionType] DROP CONSTRAINT [FK_FormularyException_ExceptionType_LookupElement_ExceptionType];
GO
IF OBJECT_ID(N'[dbo].[FK_FormularyException_LookupElement_ExceptionReason]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FormularyException] DROP CONSTRAINT [FK_FormularyException_LookupElement_ExceptionReason];
GO
IF OBJECT_ID(N'[dbo].[FK_FormularyException_LookupElement_ExceptionResolution]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FormularyException] DROP CONSTRAINT [FK_FormularyException_LookupElement_ExceptionResolution];
GO
IF OBJECT_ID(N'[dbo].[FK_FormularyException_ProtocolElementCode]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FormularyException] DROP CONSTRAINT [FK_FormularyException_ProtocolElementCode];
GO
IF OBJECT_ID(N'[dbo].[FK_FTNConfiguration_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FtnConfiguration] DROP CONSTRAINT [FK_FTNConfiguration_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_FTNConfiguration_LineOfBusiness]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FtnConfiguration] DROP CONSTRAINT [FK_FTNConfiguration_LineOfBusiness];
GO
IF OBJECT_ID(N'[dbo].[FK_GrandfatherRule_Rule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[GrandfatherRule] DROP CONSTRAINT [FK_GrandfatherRule_Rule];
GO
IF OBJECT_ID(N'[dbo].[FK_GrandfatherRuleDrug_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[GrandfatherRuleDrug] DROP CONSTRAINT [FK_GrandfatherRuleDrug_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_GrandfatherRuleDrug_GrandfatherRule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[GrandfatherRuleDrug] DROP CONSTRAINT [FK_GrandfatherRuleDrug_GrandfatherRule];
GO
IF OBJECT_ID(N'[dbo].[FK_GrandfatherRuleDrug_LookupElement_Frequency]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[GrandfatherRuleDrug] DROP CONSTRAINT [FK_GrandfatherRuleDrug_LookupElement_Frequency];
GO
IF OBJECT_ID(N'[dbo].[FK_HelpfulLink_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[HelpfulLink] DROP CONSTRAINT [FK_HelpfulLink_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_Image_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Image] DROP CONSTRAINT [FK_Image_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InScopeState_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InScopeState] DROP CONSTRAINT [FK_InScopeState_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InScopeState_ProductLine]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InScopeState] DROP CONSTRAINT [FK_InScopeState_ProductLine];
GO
IF OBJECT_ID(N'[dbo].[FK_InScopeState_State]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InScopeState] DROP CONSTRAINT [FK_InScopeState_State];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProvider_Address_Address]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProvider_Address] DROP CONSTRAINT [FK_InsuranceProvider_Address_Address];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProvider_Address_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProvider_Address] DROP CONSTRAINT [FK_InsuranceProvider_Address_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProvider_LookupElement_EligibilityPrimarySource]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProvider] DROP CONSTRAINT [FK_InsuranceProvider_LookupElement_EligibilityPrimarySource];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProvider_LookupElement_EligibilitySecondarySource]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProvider] DROP CONSTRAINT [FK_InsuranceProvider_LookupElement_EligibilitySecondarySource];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProvider_LookupElement_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProvider_LookupElement] DROP CONSTRAINT [FK_InsuranceProvider_LookupElement_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProvider_LookupElement_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProvider_LookupElement] DROP CONSTRAINT [FK_InsuranceProvider_LookupElement_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderAttributeValue_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderAttributeValue] DROP CONSTRAINT [FK_InsuranceProviderAttributeValue_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderAttributeValue_InsuranceProviderAttributeKey]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderAttributeValue] DROP CONSTRAINT [FK_InsuranceProviderAttributeValue_InsuranceProviderAttributeKey];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderConfiguration_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderConfiguration] DROP CONSTRAINT [FK_InsuranceProviderConfiguration_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderContactDetail_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderContactDetail] DROP CONSTRAINT [FK_InsuranceProviderContactDetail_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderDaylightSavingSetting_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderDaylightSavingSetting] DROP CONSTRAINT [FK_InsuranceProviderDaylightSavingSetting_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderDrug_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderDrug] DROP CONSTRAINT [FK_InsuranceProviderDrug_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderDrug_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderDrug] DROP CONSTRAINT [FK_InsuranceProviderDrug_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderDrugConfiguration_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderDrugConfiguration] DROP CONSTRAINT [FK_InsuranceProviderDrugConfiguration_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderDrugConfiguration_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderDrugConfiguration] DROP CONSTRAINT [FK_InsuranceProviderDrugConfiguration_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderDrugConfiguration_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderDrugConfiguration] DROP CONSTRAINT [FK_InsuranceProviderDrugConfiguration_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderDrugConfiguration_LOB_InsuranceProviderDrugConfiguration]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderDrugConfiguration_LOB] DROP CONSTRAINT [FK_InsuranceProviderDrugConfiguration_LOB_InsuranceProviderDrugConfiguration];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderDrugConfiguration_LOB_LineofBusiness]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderDrugConfiguration_LOB] DROP CONSTRAINT [FK_InsuranceProviderDrugConfiguration_LOB_LineofBusiness];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderDrugConfiguration_Stage_InsuranceProviderDrugConfiguration]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderDrugConfiguration_Stage] DROP CONSTRAINT [FK_InsuranceProviderDrugConfiguration_Stage_InsuranceProviderDrugConfiguration];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderDrugConfiguration_Stage_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderDrugConfiguration_Stage] DROP CONSTRAINT [FK_InsuranceProviderDrugConfiguration_Stage_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderEODFileRecipient_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderEODFileRecipient] DROP CONSTRAINT [FK_InsuranceProviderEODFileRecipient_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderEODStatusOverride_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderEODStatusOverride] DROP CONSTRAINT [FK_InsuranceProviderEODStatusOverride_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderEODStatusOverride_LineOfBusiness]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderEODStatusOverride] DROP CONSTRAINT [FK_InsuranceProviderEODStatusOverride_LineOfBusiness];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderEODStatusOverride_LookupElement_ProtocolStatus]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderEODStatusOverride] DROP CONSTRAINT [FK_InsuranceProviderEODStatusOverride_LookupElement_ProtocolStatus];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderEODStatusOverride_StatusOverrideType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderEODStatusOverride] DROP CONSTRAINT [FK_InsuranceProviderEODStatusOverride_StatusOverrideType];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderFaxTemplate_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderFaxTemplate] DROP CONSTRAINT [FK_InsuranceProviderFaxTemplate_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderFaxTemplate_LookupElement_BenefitType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderFaxTemplate] DROP CONSTRAINT [FK_InsuranceProviderFaxTemplate_LookupElement_BenefitType];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderFaxTemplate_LookupElement_FaxTemplateType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderFaxTemplate] DROP CONSTRAINT [FK_InsuranceProviderFaxTemplate_LookupElement_FaxTemplateType];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderFaxTemplate_ProductLine_InsuranceProviderFaxTemplate]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderFaxTemplate_ProductLine] DROP CONSTRAINT [FK_InsuranceProviderFaxTemplate_ProductLine_InsuranceProviderFaxTemplate];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderFaxTemplate_ProductLine_ProductLine]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderFaxTemplate_ProductLine] DROP CONSTRAINT [FK_InsuranceProviderFaxTemplate_ProductLine_ProductLine];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderFaxTemplate_Rule_DimPayer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderFaxTemplate_Rule] DROP CONSTRAINT [FK_InsuranceProviderFaxTemplate_Rule_DimPayer];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderFaxTemplate_Rule_LookupElement_BenefitType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderFaxTemplate_Rule] DROP CONSTRAINT [FK_InsuranceProviderFaxTemplate_Rule_LookupElement_BenefitType];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderFaxTemplate_Rule_LookupElement_FaxTemplateType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderFaxTemplate_Rule] DROP CONSTRAINT [FK_InsuranceProviderFaxTemplate_Rule_LookupElement_FaxTemplateType];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderFaxTemplate_State]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderFaxTemplate] DROP CONSTRAINT [FK_InsuranceProviderFaxTemplate_State];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderGlobalFaxParameter_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderGlobalFaxParameter] DROP CONSTRAINT [FK_InsuranceProviderGlobalFaxParameter_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderGlobalFaxParameter_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderGlobalFaxParameter] DROP CONSTRAINT [FK_InsuranceProviderGlobalFaxParameter_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderHomePage_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderHomePage] DROP CONSTRAINT [FK_InsuranceProviderHomePage_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderSpecialtyCode_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderSpecialtyCode] DROP CONSTRAINT [FK_InsuranceProviderSpecialtyCode_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderTreatmentType_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderTreatmentType] DROP CONSTRAINT [FK_InsuranceProviderTreatmentType_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_InsuranceProviderTreatmentType_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[InsuranceProviderTreatmentType] DROP CONSTRAINT [FK_InsuranceProviderTreatmentType_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_LabResult_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LabResult] DROP CONSTRAINT [FK_LabResult_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_LineofBusiness_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LineofBusiness] DROP CONSTRAINT [FK_LineofBusiness_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_LineofBusiness_LookupElement_MajorLineOfBusiness]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LineofBusiness] DROP CONSTRAINT [FK_LineofBusiness_LookupElement_MajorLineOfBusiness];
GO
IF OBJECT_ID(N'[dbo].[FK_LineofBusiness_LookupElement_MedicalBenefitDrugsSetting]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LineofBusiness] DROP CONSTRAINT [FK_LineofBusiness_LookupElement_MedicalBenefitDrugsSetting];
GO
IF OBJECT_ID(N'[dbo].[FK_LineofBusiness_LookupElement_PharmacyBenefitDrugsSetting]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LineofBusiness] DROP CONSTRAINT [FK_LineofBusiness_LookupElement_PharmacyBenefitDrugsSetting];
GO
IF OBJECT_ID(N'[dbo].[FK_LineOfBusiness_LookupElement_ProcedureUnitsReplacementApproach]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LineofBusiness] DROP CONSTRAINT [FK_LineOfBusiness_LookupElement_ProcedureUnitsReplacementApproach];
GO
IF OBJECT_ID(N'[dbo].[FK_LobCagSetting_LineOfBusinessID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LineOfBusiness_CAGSetting] DROP CONSTRAINT [FK_LobCagSetting_LineOfBusinessID];
GO
IF OBJECT_ID(N'[dbo].[FK_Lookup_LookupName_ParentLookupName]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Lookup] DROP CONSTRAINT [FK_Lookup_LookupName_ParentLookupName];
GO
IF OBJECT_ID(N'[dbo].[FK_LookupElement_Lookup]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LookupElement] DROP CONSTRAINT [FK_LookupElement_Lookup];
GO
IF OBJECT_ID(N'[dbo].[FK_LookupElement_LookupElementID_ParentLookupElementID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LookupElement] DROP CONSTRAINT [FK_LookupElement_LookupElementID_ParentLookupElementID];
GO
IF OBJECT_ID(N'[dbo].[FK_LookupElement_SecurityGroup_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LookupElement_SecurityGroup] DROP CONSTRAINT [FK_LookupElement_SecurityGroup_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_LookupElement_SecurityGroup_SecurityGroup]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LookupElement_SecurityGroup] DROP CONSTRAINT [FK_LookupElement_SecurityGroup_SecurityGroup];
GO
IF OBJECT_ID(N'[dbo].[FK_LookupElementID_Protocol_TreatmentTypeID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Protocol] DROP CONSTRAINT [FK_LookupElementID_Protocol_TreatmentTypeID];
GO
IF OBJECT_ID(N'[dbo].[FK_LookupElementMapping_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LookupElementMapping] DROP CONSTRAINT [FK_LookupElementMapping_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_LookupElementMapping_LookupElement1]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LookupElementMapping] DROP CONSTRAINT [FK_LookupElementMapping_LookupElement1];
GO
IF OBJECT_ID(N'[dbo].[FK_MailArchive_LookupElement_MailStatus]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MailArchiveLog] DROP CONSTRAINT [FK_MailArchive_LookupElement_MailStatus];
GO
IF OBJECT_ID(N'[dbo].[FK_MailArchive_Patient]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MailArchive] DROP CONSTRAINT [FK_MailArchive_Patient];
GO
IF OBJECT_ID(N'[dbo].[FK_MailArchive_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MailArchive] DROP CONSTRAINT [FK_MailArchive_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_MailArchive_State]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MailArchive] DROP CONSTRAINT [FK_MailArchive_State];
GO
IF OBJECT_ID(N'[dbo].[FK_MailArchiveDocument_DocumentRepository]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MailArchiveDocument] DROP CONSTRAINT [FK_MailArchiveDocument_DocumentRepository];
GO
IF OBJECT_ID(N'[dbo].[FK_MailArchiveDocument_MailArchive]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MailArchiveDocument] DROP CONSTRAINT [FK_MailArchiveDocument_MailArchive];
GO
IF OBJECT_ID(N'[dbo].[FK_MailArchiveDocumentID_MailArchiveTracking_MailArchiveDocumentID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MailArchiveTracking] DROP CONSTRAINT [FK_MailArchiveDocumentID_MailArchiveTracking_MailArchiveDocumentID];
GO
IF OBJECT_ID(N'[dbo].[FK_MailArchiveLog_MailArchive]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MailArchiveLog] DROP CONSTRAINT [FK_MailArchiveLog_MailArchive];
GO
IF OBJECT_ID(N'[dbo].[FK_MailingCutoffCalculationLog_PatientProtocolAssignmentTimeCountdown]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MailingCutoffCalculationLog] DROP CONSTRAINT [FK_MailingCutoffCalculationLog_PatientProtocolAssignmentTimeCountdown];
GO
IF OBJECT_ID(N'[dbo].[FK_MailingCutoffConfiguration_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MailingCutoffConfiguration] DROP CONSTRAINT [FK_MailingCutoffConfiguration_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_MailingCutoffConfiguration_LineOfBusiness]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MailingCutoffConfiguration] DROP CONSTRAINT [FK_MailingCutoffConfiguration_LineOfBusiness];
GO
IF OBJECT_ID(N'[dbo].[FK_MailingOptionID_LookupElement_MailingOptionID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MailArchiveTracking] DROP CONSTRAINT [FK_MailingOptionID_LookupElement_MailingOptionID];
GO
IF OBJECT_ID(N'[dbo].[FK_MailingPriorityID_LookupElement_MailingPriorityID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MailArchiveTracking] DROP CONSTRAINT [FK_MailingPriorityID_LookupElement_MailingPriorityID];
GO
IF OBJECT_ID(N'[dbo].[FK_MemberContactLog_LookupElement_CallStatusType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MemberContactLog] DROP CONSTRAINT [FK_MemberContactLog_LookupElement_CallStatusType];
GO
IF OBJECT_ID(N'[dbo].[FK_MemberContactLog_Patient]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MemberContactLog] DROP CONSTRAINT [FK_MemberContactLog_Patient];
GO
IF OBJECT_ID(N'[dbo].[FK_MemberContactLog_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MemberContactLog] DROP CONSTRAINT [FK_MemberContactLog_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_MemberContactLog_Requester]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MemberContactLog] DROP CONSTRAINT [FK_MemberContactLog_Requester];
GO
IF OBJECT_ID(N'[dbo].[FK_MetastaticSite_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MetastaticSite] DROP CONSTRAINT [FK_MetastaticSite_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_MultilingualData_MultilingualObjectField]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MultilingualData] DROP CONSTRAINT [FK_MultilingualData_MultilingualObjectField];
GO
IF OBJECT_ID(N'[dbo].[FK_MultilingualObjectField_MultilingualObject]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MultilingualObjectField] DROP CONSTRAINT [FK_MultilingualObjectField_MultilingualObject];
GO
IF OBJECT_ID(N'[dbo].[FK_NCCNRecurrenceRiskFormula_AssessmentQuestion]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[NCCNRecurrenceRiskFormula] DROP CONSTRAINT [FK_NCCNRecurrenceRiskFormula_AssessmentQuestion];
GO
IF OBJECT_ID(N'[dbo].[FK_NCCNRecurrenceRiskFormula_NCCNRecurrenceRiskGroup]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[NCCNRecurrenceRiskFormula] DROP CONSTRAINT [FK_NCCNRecurrenceRiskFormula_NCCNRecurrenceRiskGroup];
GO
IF OBJECT_ID(N'[dbo].[FK_NeutropeniaOverTurnDrug_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[NeutropeniaOverTurnDrug] DROP CONSTRAINT [FK_NeutropeniaOverTurnDrug_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_Note_AssignmentAction]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Note] DROP CONSTRAINT [FK_Note_AssignmentAction];
GO
IF OBJECT_ID(N'[dbo].[FK_Note_Patient]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Note] DROP CONSTRAINT [FK_Note_Patient];
GO
IF OBJECT_ID(N'[dbo].[FK_Note_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Note] DROP CONSTRAINT [FK_Note_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_Note_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Note] DROP CONSTRAINT [FK_Note_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID];
GO
IF OBJECT_ID(N'[dbo].[FK_Note_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Note] DROP CONSTRAINT [FK_Note_User];
GO
IF OBJECT_ID(N'[dbo].[FK_NoteID_Note_NoteID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MailArchiveTracking] DROP CONSTRAINT [FK_NoteID_Note_NoteID];
GO
IF OBJECT_ID(N'[dbo].[FK_NotificationEnclosureImage_Image]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[NotificationEnclosureImage] DROP CONSTRAINT [FK_NotificationEnclosureImage_Image];
GO
IF OBJECT_ID(N'[dbo].[FK_NotificationEnclosureImage_NotificationEnclosure]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[NotificationEnclosureImage] DROP CONSTRAINT [FK_NotificationEnclosureImage_NotificationEnclosure];
GO
IF OBJECT_ID(N'[dbo].[FK_Patient_LookupElement_PatientSource]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Patient] DROP CONSTRAINT [FK_Patient_LookupElement_PatientSource];
GO
IF OBJECT_ID(N'[dbo].[FK_Patient_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Patient] DROP CONSTRAINT [FK_Patient_User];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientAssessment_AssessmentType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientAssessment] DROP CONSTRAINT [FK_PatientAssessment_AssessmentType];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientAssessment_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientAssessment] DROP CONSTRAINT [FK_PatientAssessment_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientAssessment_LookupElement_Stage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientAssessment] DROP CONSTRAINT [FK_PatientAssessment_LookupElement_Stage];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientAssessment_Patient]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientAssessment] DROP CONSTRAINT [FK_PatientAssessment_Patient];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientAssessment_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientAssessment] DROP CONSTRAINT [FK_PatientAssessment_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientAssessment_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientAssessment] DROP CONSTRAINT [FK_PatientAssessment_User];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientAssessmentAnswer_AssessmentQuestion]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientAssessmentAnswer] DROP CONSTRAINT [FK_PatientAssessmentAnswer_AssessmentQuestion];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientAssessmentAnswer_AssessmentQuestionPossibleAnswer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientAssessmentAnswer] DROP CONSTRAINT [FK_PatientAssessmentAnswer_AssessmentQuestionPossibleAnswer];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientAssessmentAnswer_PatientAssessment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientAssessmentAnswer] DROP CONSTRAINT [FK_PatientAssessmentAnswer_PatientAssessment];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientClinicalDecisionSupport_Patient]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientClinicalDecisionSupport] DROP CONSTRAINT [FK_PatientClinicalDecisionSupport_Patient];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientClinicalDecisionSupport_Protocol_PatientClinicalDecisionSupport]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientClinicalDecisionSupport_Protocol] DROP CONSTRAINT [FK_PatientClinicalDecisionSupport_Protocol_PatientClinicalDecisionSupport];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientClinicalDecisionSupport_Protocol_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientClinicalDecisionSupport_Protocol] DROP CONSTRAINT [FK_PatientClinicalDecisionSupport_Protocol_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientDiagnosis_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientDiagnosis] DROP CONSTRAINT [FK_PatientDiagnosis_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientDiagnosis_LookupElement_DiagnosisStage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientDiagnosis] DROP CONSTRAINT [FK_PatientDiagnosis_LookupElement_DiagnosisStage];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientDiagnosis_LookupElement_PerformanceStatus]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientDiagnosis] DROP CONSTRAINT [FK_PatientDiagnosis_LookupElement_PerformanceStatus];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientDiagnosis_Patient]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientDiagnosis] DROP CONSTRAINT [FK_PatientDiagnosis_Patient];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientICDCode_ICDCode]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientICDCode] DROP CONSTRAINT [FK_PatientICDCode_ICDCode];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientICDCode_Patient]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientICDCode] DROP CONSTRAINT [FK_PatientICDCode_Patient];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientICDCode_PatientDiagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientICDCode] DROP CONSTRAINT [FK_PatientICDCode_PatientDiagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Eligibility]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment] DROP CONSTRAINT [FK_PatientProtocolAssignment_Eligibility];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_History_LookupElement_ProtocolStatusID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentHistory] DROP CONSTRAINT [FK_PatientProtocolAssignment_History_LookupElement_ProtocolStatusID];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_History_PatientProtocolAssignment_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentHistory] DROP CONSTRAINT [FK_PatientProtocolAssignment_History_PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Labresult_Patient]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Labresult] DROP CONSTRAINT [FK_PatientProtocolAssignment_Labresult_Patient];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Labresult_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Labresult] DROP CONSTRAINT [FK_PatientProtocolAssignment_Labresult_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment] DROP CONSTRAINT [FK_PatientProtocolAssignment_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_LookupElement_BoundaryCaseTypeId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment] DROP CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_BoundaryCaseTypeId];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_LookupElement_LegacyStatusId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment] DROP CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_LegacyStatusId];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_LookupElement_LineOfTherapyID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment] DROP CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_LineOfTherapyID];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_LookupElement_MedicationsReceivingMethodId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment] DROP CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_MedicationsReceivingMethodId];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_LookupElement_ProtocolAssignmentOriginId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment] DROP CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_ProtocolAssignmentOriginId];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_LookupElement_ProtocolAssignmentSourceId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment] DROP CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_ProtocolAssignmentSourceId];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_LookupElement_ProtocolAssignmentTypeId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment] DROP CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_ProtocolAssignmentTypeId];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_LookupElement_ReviewStageId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment] DROP CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_ReviewStageId];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_LookupElement_SpecialtyPharmacyId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment] DROP CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_SpecialtyPharmacyId];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Patient]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment] DROP CONSTRAINT [FK_PatientProtocolAssignment_Patient];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_LookupElement_ExternalReviewer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_LookupElement_ExternalReviewer];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_LookupElement_InternalReviewer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_LookupElement_InternalReviewer];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_LookupElement_LineOfTherapyID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_LookupElement_LineOfTherapyID];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_LookupElement_ProtocolType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_LookupElement_ProtocolType];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_LookupElement_RadiotherapyTechnique]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_LookupElement_RadiotherapyTechnique];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_LookupElement_TreatmentIntentID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_LookupElement_TreatmentIntentID];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_DrugCode]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_DrugCode];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_PatientProtocolAssignment_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_ProtocolElementID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_ProtocolElementID];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_User_InitialPharmDReviewerID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_User_InitialPharmDReviewerID];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_User_Reviewer1]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_User_Reviewer1];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_User_Reviewer2]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_User_Reviewer2];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_Protocol_User_TranslatorID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PatientProtocolAssignment_Protocol_User_TranslatorID];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_CPTCodeXRT]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_CPTCodeXRT];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_LookupElement_QuantityModifyReasonID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_LookupElement_QuantityModifyReasonID];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_LookupElement_Type]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_LookupElement_Type];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_PatientProtocolAssignment_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolDiagnosis_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDiagnosis] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDiagnosis_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolDiagnosis_LookupElement_StageId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDiagnosis] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDiagnosis_LookupElement_StageId];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolDiagnosis_PatientProtocolAssignment_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDiagnosis] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDiagnosis_PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolDosing_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDosing_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_AdministrationMethod]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_AdministrationMethod];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_BillingUnitQuantityUnit]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_BillingUnitQuantityUnit];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_DoseUnit]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_DoseUnit];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_Frequency]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_Frequency];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_PatientSpecificDoseUnit]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_PatientSpecificDoseUnit];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolDosing_PatientProtocolAssignment_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDosing_PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolExtraInfo_LookupElement_ProtocolApprovalReason]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolExtraInfo] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolExtraInfo_LookupElement_ProtocolApprovalReason];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolExtraInfo_PatientProtocolAssignment_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolExtraInfo] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolExtraInfo_PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolHCPCSCodeGMT_PatientProtocolAssignment_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolHCPCSCodeGMT] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolHCPCSCodeGMT_PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolICDCode_ICDCode]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolICDCode] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolICDCode_ICDCode];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolICDCode_PatientProtocolAssignment_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolICDCode] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolICDCode_PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolQuestionAnswer_ExplicitQuestion]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolQuestionAnswer] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolQuestionAnswer_ExplicitQuestion];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolQuestionAnswer_LookupElement_Answer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolQuestionAnswer] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolQuestionAnswer_LookupElement_Answer];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_ProtocolQuestionAnswer_PatientProtocolAssignment_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolQuestionAnswer] DROP CONSTRAINT [FK_PatientProtocolAssignment_ProtocolQuestionAnswer_PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_QuestionAnswerXRT_ExplicitAnswerXRT]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_QuestionAnswerXRT] DROP CONSTRAINT [FK_PatientProtocolAssignment_QuestionAnswerXRT_ExplicitAnswerXRT];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_QuestionAnswerXRT_ExplicitQuestionXRT]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_QuestionAnswerXRT] DROP CONSTRAINT [FK_PatientProtocolAssignment_QuestionAnswerXRT_ExplicitQuestionXRT];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_QuestionAnswerXRT_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_QuestionAnswerXRT] DROP CONSTRAINT [FK_PatientProtocolAssignment_QuestionAnswerXRT_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_User_CSRId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment] DROP CONSTRAINT [FK_PatientProtocolAssignment_User_CSRId];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_User_CurrentMD]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment] DROP CONSTRAINT [FK_PatientProtocolAssignment_User_CurrentMD];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignment_VitalSigns_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_VitalSign] DROP CONSTRAINT [FK_PatientProtocolAssignment_VitalSigns_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentEffectuationDate_PatientProtocolAssignmentId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentEffectuationDate] DROP CONSTRAINT [FK_PatientProtocolAssignmentEffectuationDate_PatientProtocolAssignmentId];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentInfo_LookupElement_DecisionDelegation]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentInfo] DROP CONSTRAINT [FK_PatientProtocolAssignmentInfo_LookupElement_DecisionDelegation];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentPostDenial_InsuranceProvider_Address]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenial] DROP CONSTRAINT [FK_PatientProtocolAssignmentPostDenial_InsuranceProvider_Address];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentPostDenial_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenial] DROP CONSTRAINT [FK_PatientProtocolAssignmentPostDenial_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentPostDenial_LookupElement1]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenial] DROP CONSTRAINT [FK_PatientProtocolAssignmentPostDenial_LookupElement1];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentPostDenial_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenial] DROP CONSTRAINT [FK_PatientProtocolAssignmentPostDenial_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentPostDenial_PostDenialRequestType_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenial] DROP CONSTRAINT [FK_PatientProtocolAssignmentPostDenial_PostDenialRequestType_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentPostDenialInfo_InsuranceProvider_Address]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialInfo] DROP CONSTRAINT [FK_PatientProtocolAssignmentPostDenialInfo_InsuranceProvider_Address];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentPostDenialInfo_LookupElement_RequestInitiator]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialInfo] DROP CONSTRAINT [FK_PatientProtocolAssignmentPostDenialInfo_LookupElement_RequestInitiator];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentPostDenialInfo_LookupElement_RequestSource]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialInfo] DROP CONSTRAINT [FK_PatientProtocolAssignmentPostDenialInfo_LookupElement_RequestSource];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentPostDenialInfo_PatientProtocolAssignmentPostDenial]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialInfo] DROP CONSTRAINT [FK_PatientProtocolAssignmentPostDenialInfo_PatientProtocolAssignmentPostDenial];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentPostDenialProtocol_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialProtocol] DROP CONSTRAINT [FK_PatientProtocolAssignmentPostDenialProtocol_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentPostDenialProtocol_PatientProtocolAssignment_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialProtocol] DROP CONSTRAINT [FK_PatientProtocolAssignmentPostDenialProtocol_PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentPostDenialProtocol_PatientProtocolAssignmentPostDenial]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialProtocol] DROP CONSTRAINT [FK_PatientProtocolAssignmentPostDenialProtocol_PatientProtocolAssignmentPostDenial];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentPostDenialProtocol_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialProtocol] DROP CONSTRAINT [FK_PatientProtocolAssignmentPostDenialProtocol_User];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentPostDenialProtocol_User1]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialProtocol] DROP CONSTRAINT [FK_PatientProtocolAssignmentPostDenialProtocol_User1];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentPostDenialProtocol_User2]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialProtocol] DROP CONSTRAINT [FK_PatientProtocolAssignmentPostDenialProtocol_User2];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentProtocolElementAlias_LookupElement_DrugCodeType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentProtocolElementAlias] DROP CONSTRAINT [FK_PatientProtocolAssignmentProtocolElementAlias_LookupElement_DrugCodeType];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentProtocolElementAlias_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentProtocolElementAlias] DROP CONSTRAINT [FK_PatientProtocolAssignmentProtocolElementAlias_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentProtocolElementAlias_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentProtocolElementAlias] DROP CONSTRAINT [FK_PatientProtocolAssignmentProtocolElementAlias_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentProtocolElementAlias_ProtocolElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentProtocolElementAlias] DROP CONSTRAINT [FK_PatientProtocolAssignmentProtocolElementAlias_ProtocolElement];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentTimeCountdown_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentTimeCountdown] DROP CONSTRAINT [FK_PatientProtocolAssignmentTimeCountdown_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentTimeCountdown_PatientProtocolAssignmentPostDenial]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignmentTimeCountdown] DROP CONSTRAINT [FK_PatientProtocolAssignmentTimeCountdown_PatientProtocolAssignmentPostDenial];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentTimer_LookupElement_DurationUnit]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Timer] DROP CONSTRAINT [FK_PatientProtocolAssignmentTimer_LookupElement_DurationUnit];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentTimer_LookupElement_TimerStatus]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Timer] DROP CONSTRAINT [FK_PatientProtocolAssignmentTimer_LookupElement_TimerStatus];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentTimer_LookupElement_TimerType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Timer] DROP CONSTRAINT [FK_PatientProtocolAssignmentTimer_LookupElement_TimerType];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentTimer_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Timer] DROP CONSTRAINT [FK_PatientProtocolAssignmentTimer_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolAssignmentTimer_PayerTimerConfiguration]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolAssignment_Timer] DROP CONSTRAINT [FK_PatientProtocolAssignmentTimer_PayerTimerConfiguration];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolRulesTrail_patientprotocolassignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolRulesTrail] DROP CONSTRAINT [FK_PatientProtocolRulesTrail_patientprotocolassignment];
GO
IF OBJECT_ID(N'[dbo].[FK_PatientProtocolRulesTrail_protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PatientProtocolRulesTrail] DROP CONSTRAINT [FK_PatientProtocolRulesTrail_protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerBusinessDayConfig_DimPayer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerBusinessDayConfig] DROP CONSTRAINT [FK_PayerBusinessDayConfig_DimPayer];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerContactDetail_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerContactDetail] DROP CONSTRAINT [FK_PayerContactDetail_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerFormulary_DimPayer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerFormulary] DROP CONSTRAINT [FK_PayerFormulary_DimPayer];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerFormulary_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerFormulary] DROP CONSTRAINT [FK_PayerFormulary_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerFormulary_LookupElement_BenefitType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerFormulary] DROP CONSTRAINT [FK_PayerFormulary_LookupElement_BenefitType];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerOrganization_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerOrganization] DROP CONSTRAINT [FK_PayerOrganization_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerOrganization_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerOrganization] DROP CONSTRAINT [FK_PayerOrganization_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerPrimaryTimer_DimPayer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerPrimaryTimer] DROP CONSTRAINT [FK_PayerPrimaryTimer_DimPayer];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerPrimaryTimer_DimPayer_LookupElement_TimerTypeID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerPrimaryTimer] DROP CONSTRAINT [FK_PayerPrimaryTimer_DimPayer_LookupElement_TimerTypeID];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerTimerConfiguration_DimPayer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerTimerConfiguration] DROP CONSTRAINT [FK_PayerTimerConfiguration_DimPayer];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerTimerConfiguration_LookupElement_DurationUnits]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerTimerConfiguration] DROP CONSTRAINT [FK_PayerTimerConfiguration_LookupElement_DurationUnits];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerTimerConfiguration_LookupElement_DurationUnits2]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerTimerConfiguration] DROP CONSTRAINT [FK_PayerTimerConfiguration_LookupElement_DurationUnits2];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerTimerConfiguration_LookupElement_RequestType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerTimerConfiguration] DROP CONSTRAINT [FK_PayerTimerConfiguration_LookupElement_RequestType];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerTimerConfiguration_LookupElement_ReviewStage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerTimerConfiguration] DROP CONSTRAINT [FK_PayerTimerConfiguration_LookupElement_ReviewStage];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerTimerConfigurationState_PayerTimerConfiguration]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerTimerConfiguration_State] DROP CONSTRAINT [FK_PayerTimerConfigurationState_PayerTimerConfiguration];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerTimerConfigurationState_State]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerTimerConfiguration_State] DROP CONSTRAINT [FK_PayerTimerConfigurationState_State];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerXrtCode_CPTCodeXRT]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerXrtCode] DROP CONSTRAINT [FK_PayerXrtCode_CPTCodeXRT];
GO
IF OBJECT_ID(N'[dbo].[FK_PayerXrtCode_DimPayer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PayerXrtCode] DROP CONSTRAINT [FK_PayerXrtCode_DimPayer];
GO
IF OBJECT_ID(N'[dbo].[FK_PostDenialConfiguration_LineOfBusiness]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PostDenialConfiguration] DROP CONSTRAINT [FK_PostDenialConfiguration_LineOfBusiness];
GO
IF OBJECT_ID(N'[dbo].[FK_PracticeGroup_LookupElement_AccountTypeID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PracticeGroup] DROP CONSTRAINT [FK_PracticeGroup_LookupElement_AccountTypeID];
GO
IF OBJECT_ID(N'[dbo].[FK_PracticeGroup_LookupElement_EHRSoftwareID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PracticeGroup] DROP CONSTRAINT [FK_PracticeGroup_LookupElement_EHRSoftwareID];
GO
IF OBJECT_ID(N'[dbo].[FK_PracticeGroup_LookupElement_PermissionGroupID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PracticeGroup] DROP CONSTRAINT [FK_PracticeGroup_LookupElement_PermissionGroupID];
GO
IF OBJECT_ID(N'[dbo].[FK_PracticeGroup_LookupElement_TaxonomyTypeID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PracticeGroup] DROP CONSTRAINT [FK_PracticeGroup_LookupElement_TaxonomyTypeID];
GO
IF OBJECT_ID(N'[dbo].[FK_PracticeGroup_PracticeGroup_ParentID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PracticeGroup] DROP CONSTRAINT [FK_PracticeGroup_PracticeGroup_ParentID];
GO
IF OBJECT_ID(N'[dbo].[FK_PracticeGroupAddress_Address_AddressID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PracticeGroupAddress] DROP CONSTRAINT [FK_PracticeGroupAddress_Address_AddressID];
GO
IF OBJECT_ID(N'[dbo].[FK_PracticeGroupAddress_LookupElement_AddressTypeID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PracticeGroupAddress] DROP CONSTRAINT [FK_PracticeGroupAddress_LookupElement_AddressTypeID];
GO
IF OBJECT_ID(N'[dbo].[FK_PracticeGroupAddress_PracticeGroup_PracticeGroupID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PracticeGroupAddress] DROP CONSTRAINT [FK_PracticeGroupAddress_PracticeGroup_PracticeGroupID];
GO
IF OBJECT_ID(N'[dbo].[FK_PracticeGroupPayer_InsuranceProvider_InsuranceProviderID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PracticeGroupPayer] DROP CONSTRAINT [FK_PracticeGroupPayer_InsuranceProvider_InsuranceProviderID];
GO
IF OBJECT_ID(N'[dbo].[FK_PracticeGroupPayer_PracticeGroupPayer_PracticeGroupPayerID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PracticeGroupPayer] DROP CONSTRAINT [FK_PracticeGroupPayer_PracticeGroupPayer_PracticeGroupPayerID];
GO
IF OBJECT_ID(N'[dbo].[FK_PracticeGroupUser_PracticeGroup_PracticeGroupID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PracticeGroupUser] DROP CONSTRAINT [FK_PracticeGroupUser_PracticeGroup_PracticeGroupID];
GO
IF OBJECT_ID(N'[dbo].[FK_PracticeGroupUser_User_UserID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PracticeGroupUser] DROP CONSTRAINT [FK_PracticeGroupUser_User_UserID];
GO
IF OBJECT_ID(N'[dbo].[FK_PreferredDrugRule_DrugID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PreferredDrugRule] DROP CONSTRAINT [FK_PreferredDrugRule_DrugID];
GO
IF OBJECT_ID(N'[dbo].[FK_PreferredDrugRule_PreferredBrandID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PreferredDrugRule] DROP CONSTRAINT [FK_PreferredDrugRule_PreferredBrandID];
GO
IF OBJECT_ID(N'[dbo].[FK_PreferredDrugRule_PreferredGenericDrugID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PreferredDrugRule] DROP CONSTRAINT [FK_PreferredDrugRule_PreferredGenericDrugID];
GO
IF OBJECT_ID(N'[dbo].[FK_PreferredDrugRule_RuleID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PreferredDrugRule] DROP CONSTRAINT [FK_PreferredDrugRule_RuleID];
GO
IF OBJECT_ID(N'[dbo].[FK_PreferredDrugRule_RuleLevelID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PreferredDrugRule] DROP CONSTRAINT [FK_PreferredDrugRule_RuleLevelID];
GO
IF OBJECT_ID(N'[dbo].[FK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_LookupElement_Program]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PreferredProtocolProgram_PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_LookupElement_Program];
GO
IF OBJECT_ID(N'[dbo].[FK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_LookupElement_Status]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PreferredProtocolProgram_PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_LookupElement_Status];
GO
IF OBJECT_ID(N'[dbo].[FK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PreferredProtocolProgram_PatientProtocolAssignment_Protocol] DROP CONSTRAINT [FK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_PrerequisiteDrug_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PrerequisiteDrug] DROP CONSTRAINT [FK_PrerequisiteDrug_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_PrerequisiteDrug_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[PrerequisiteDrug] DROP CONSTRAINT [FK_PrerequisiteDrug_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_ProcedureCodeSimpleDescription_LookupElement_ProcedureCodeCategory]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProcedureCodeSimpleDescription] DROP CONSTRAINT [FK_ProcedureCodeSimpleDescription_LookupElement_ProcedureCodeCategory];
GO
IF OBJECT_ID(N'[dbo].[FK_ProductLine_LineofBusiness]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProductLine] DROP CONSTRAINT [FK_ProductLine_LineofBusiness];
GO
IF OBJECT_ID(N'[dbo].[FK_ProductLine_PlanType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProductLine] DROP CONSTRAINT [FK_ProductLine_PlanType];
GO
IF OBJECT_ID(N'[dbo].[FK_ProductLine_ProviderNetworkRule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProductLine] DROP CONSTRAINT [FK_ProductLine_ProviderNetworkRule];
GO
IF OBJECT_ID(N'[dbo].[FK_Protocol_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Protocol] DROP CONSTRAINT [FK_Protocol_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_Protocol_Diagnosis_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Protocol_Diagnosis] DROP CONSTRAINT [FK_Protocol_Diagnosis_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_Protocol_Diagnosis_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Protocol_Diagnosis] DROP CONSTRAINT [FK_Protocol_Diagnosis_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_Protocol_LookupElement_DiagnosisStage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Protocol] DROP CONSTRAINT [FK_Protocol_LookupElement_DiagnosisStage];
GO
IF OBJECT_ID(N'[dbo].[FK_Protocol_LookupElement_EfficacyRating]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Protocol] DROP CONSTRAINT [FK_Protocol_LookupElement_EfficacyRating];
GO
IF OBJECT_ID(N'[dbo].[FK_Protocol_LookupElement_EmetogenicPotential]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Protocol] DROP CONSTRAINT [FK_Protocol_LookupElement_EmetogenicPotential];
GO
IF OBJECT_ID(N'[dbo].[FK_Protocol_LookupElement_FebrileNeutropenia]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Protocol] DROP CONSTRAINT [FK_Protocol_LookupElement_FebrileNeutropenia];
GO
IF OBJECT_ID(N'[dbo].[FK_Protocol_LookupElement_FinancialToxicity]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Protocol] DROP CONSTRAINT [FK_Protocol_LookupElement_FinancialToxicity];
GO
IF OBJECT_ID(N'[dbo].[FK_Protocol_LookupElement_Gender]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Protocol] DROP CONSTRAINT [FK_Protocol_LookupElement_Gender];
GO
IF OBJECT_ID(N'[dbo].[FK_Protocol_LookupElement_ToxicityRating]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Protocol] DROP CONSTRAINT [FK_Protocol_LookupElement_ToxicityRating];
GO
IF OBJECT_ID(N'[dbo].[FK_Protocol_Protocol_ParentProtocolID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Protocol] DROP CONSTRAINT [FK_Protocol_Protocol_ParentProtocolID];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolApprovalLog_LookupElement_ProcessedID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolApprovalLog] DROP CONSTRAINT [FK_ProtocolApprovalLog_LookupElement_ProcessedID];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolApprovalLog_LookupElement_ProtocolStatusID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolApprovalLog] DROP CONSTRAINT [FK_ProtocolApprovalLog_LookupElement_ProtocolStatusID];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolApprovalLog_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolApprovalLog] DROP CONSTRAINT [FK_ProtocolApprovalLog_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolApprovalLog_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolApprovalLog] DROP CONSTRAINT [FK_ProtocolApprovalLog_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolApprovalLogRule_ApprovalReason]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolApprovalLogRule] DROP CONSTRAINT [FK_ProtocolApprovalLogRule_ApprovalReason];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolApprovalLogRule_LookupRule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolApprovalLogRule] DROP CONSTRAINT [FK_ProtocolApprovalLogRule_LookupRule];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolApprovalLogRule_ProcessedAs]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolApprovalLogRule] DROP CONSTRAINT [FK_ProtocolApprovalLogRule_ProcessedAs];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolApprovalLogRule_ProtocolApprovalLog]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolApprovalLogRule] DROP CONSTRAINT [FK_ProtocolApprovalLogRule_ProtocolApprovalLog];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolApprovalLogRule_RuleMode]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolApprovalLogRule] DROP CONSTRAINT [FK_ProtocolApprovalLogRule_RuleMode];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolAuthorizationTip_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolAuthorizationTip] DROP CONSTRAINT [FK_ProtocolAuthorizationTip_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElement_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElement] DROP CONSTRAINT [FK_ProtocolElement_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElement_LookupElement_AdminMethod]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElement] DROP CONSTRAINT [FK_ProtocolElement_LookupElement_AdminMethod];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElement_LookupElement_DoseUnit]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElement] DROP CONSTRAINT [FK_ProtocolElement_LookupElement_DoseUnit];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElement_LookupElement_Frequency]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElement] DROP CONSTRAINT [FK_ProtocolElement_LookupElement_Frequency];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElement_LookupElement_FrequencyPerDay]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElement] DROP CONSTRAINT [FK_ProtocolElement_LookupElement_FrequencyPerDay];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElement_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElement] DROP CONSTRAINT [FK_ProtocolElement_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElementBillingUnits_LookupElement_BillingUnitsQuantityUnit]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElementBillingUnits] DROP CONSTRAINT [FK_ProtocolElementBillingUnits_LookupElement_BillingUnitsQuantityUnit];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElementBillingUnits_ProtocolElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElementBillingUnits] DROP CONSTRAINT [FK_ProtocolElementBillingUnits_ProtocolElement];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElementCode_LookupElement_BillingMethod]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElementCode] DROP CONSTRAINT [FK_ProtocolElementCode_LookupElement_BillingMethod];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElementCode_LookupElement_CodeType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElementCode] DROP CONSTRAINT [FK_ProtocolElementCode_LookupElement_CodeType];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElementCode_LookupElement_PatientSpecificDoseUnit]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElementCode] DROP CONSTRAINT [FK_ProtocolElementCode_LookupElement_PatientSpecificDoseUnit];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElementCode_ProtocolElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElementCode] DROP CONSTRAINT [FK_ProtocolElementCode_ProtocolElement];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElementCodeFormularyDataID_ProtocolElementCode]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElementCodeFormularyData] DROP CONSTRAINT [FK_ProtocolElementCodeFormularyDataID_ProtocolElementCode];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElementDosing_OptimalPatientSpecificDoseUnitID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElementDosing] DROP CONSTRAINT [FK_ProtocolElementDosing_OptimalPatientSpecificDoseUnitID];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElementDosing_OriginalPatientSpecificDoseUnitID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElementDosing] DROP CONSTRAINT [FK_ProtocolElementDosing_OriginalPatientSpecificDoseUnitID];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElementDosing_ProtocolElementID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElementDosing] DROP CONSTRAINT [FK_ProtocolElementDosing_ProtocolElementID];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElement_RxNavDenormID_ProtocolElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElement_RxNavDenorm] DROP CONSTRAINT [FK_ProtocolElement_RxNavDenormID_ProtocolElement];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElementDosing_ReducedDoseUnitID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElementDosing] DROP CONSTRAINT [FK_ProtocolElementDosing_ReducedDoseUnitID];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElementDosingVial_ProtocolElementDosingID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElementDosingVial] DROP CONSTRAINT [FK_ProtocolElementDosingVial_ProtocolElementDosingID];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElementDosingVial_VialUnitID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElementDosingVial] DROP CONSTRAINT [FK_ProtocolElementDosingVial_VialUnitID];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElementXRT_CPTCodeXRT]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElementXRT] DROP CONSTRAINT [FK_ProtocolElementXRT_CPTCodeXRT];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolElementXRT_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolElementXRT] DROP CONSTRAINT [FK_ProtocolElementXRT_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolEvidenceLink_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolEvidenceLink] DROP CONSTRAINT [FK_ProtocolEvidenceLink_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolIntentOfTherapy_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolIntentOfTherapy] DROP CONSTRAINT [FK_ProtocolIntentOfTherapy_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolIntentOfTherapy_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolIntentOfTherapy] DROP CONSTRAINT [FK_ProtocolIntentOfTherapy_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolLineOfTherapy_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolLineOfTherapy] DROP CONSTRAINT [FK_ProtocolLineOfTherapy_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolLineOfTherapy_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolLineOfTherapy] DROP CONSTRAINT [FK_ProtocolLineOfTherapy_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolMGT_LookupElement_TestType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolMGT] DROP CONSTRAINT [FK_ProtocolMGT_LookupElement_TestType];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolMGT_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolMGT] DROP CONSTRAINT [FK_ProtocolMGT_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolMolecularMarker_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolMolecularMarker] DROP CONSTRAINT [FK_ProtocolMolecularMarker_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolMolecularMarker_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolMolecularMarker] DROP CONSTRAINT [FK_ProtocolMolecularMarker_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolNCCNCategory_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolNCCNCategory] DROP CONSTRAINT [FK_ProtocolNCCNCategory_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolNCCNCategory_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolNCCNCategory] DROP CONSTRAINT [FK_ProtocolNCCNCategory_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolPerformaceStatus_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolPerformaceStatus] DROP CONSTRAINT [FK_ProtocolPerformaceStatus_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolPerformaceStatus_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolPerformaceStatus] DROP CONSTRAINT [FK_ProtocolPerformaceStatus_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolQuestion_ExplicitQuestion]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolQuestion] DROP CONSTRAINT [FK_ProtocolQuestion_ExplicitQuestion];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolQuestion_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolQuestion] DROP CONSTRAINT [FK_ProtocolQuestion_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolRequest_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolRequest] DROP CONSTRAINT [FK_ProtocolRequest_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolRequest_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolRequest] DROP CONSTRAINT [FK_ProtocolRequest_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolRequest_LookupElement_Status]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolRequest] DROP CONSTRAINT [FK_ProtocolRequest_LookupElement_Status];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolRequestDrug_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolRequestDrug] DROP CONSTRAINT [FK_ProtocolRequestDrug_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolRequestDrug_ProtocolRequest]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolRequestDrug] DROP CONSTRAINT [FK_ProtocolRequestDrug_ProtocolRequest];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolSettingOfTherapy_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolSettingOfTherapy] DROP CONSTRAINT [FK_ProtocolSettingOfTherapy_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolSettingOfTherapy_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolSettingOfTherapy] DROP CONSTRAINT [FK_ProtocolSettingOfTherapy_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolXRT_LookupElement_AdministrationMethod]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolXRT] DROP CONSTRAINT [FK_ProtocolXRT_LookupElement_AdministrationMethod];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolXRT_LookupElement_Frequency]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolXRT] DROP CONSTRAINT [FK_ProtocolXRT_LookupElement_Frequency];
GO
IF OBJECT_ID(N'[dbo].[FK_ProtocolXRT_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProtocolXRT] DROP CONSTRAINT [FK_ProtocolXRT_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_ProviderID_UserAccessList]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserAccessList_Provider] DROP CONSTRAINT [FK_ProviderID_UserAccessList];
GO
IF OBJECT_ID(N'[dbo].[FK_ProviderInfoData_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ProviderInfoData] DROP CONSTRAINT [FK_ProviderInfoData_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_QppAttestationReportResult_LookupElement_Status]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[QppAttestationReportResult] DROP CONSTRAINT [FK_QppAttestationReportResult_LookupElement_Status];
GO
IF OBJECT_ID(N'[dbo].[FK_QppAttestationReportResult_LookupElement_UserGroupID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[QppAttestationReportResult] DROP CONSTRAINT [FK_QppAttestationReportResult_LookupElement_UserGroupID];
GO
IF OBJECT_ID(N'[dbo].[FK_QppAttestationReportResult_QppReportSettings_ID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[QppAttestationReportResult] DROP CONSTRAINT [FK_QppAttestationReportResult_QppReportSettings_ID];
GO
IF OBJECT_ID(N'[dbo].[FK_QppAttestationReportResult_User_AttestatedBy]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[QppAttestationReportResult] DROP CONSTRAINT [FK_QppAttestationReportResult_User_AttestatedBy];
GO
IF OBJECT_ID(N'[dbo].[FK_QppReportSetting_LookupElement_Status]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[QppReportSetting] DROP CONSTRAINT [FK_QppReportSetting_LookupElement_Status];
GO
IF OBJECT_ID(N'[dbo].[FK_Rule_LookupElement_RuleType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Rule] DROP CONSTRAINT [FK_Rule_LookupElement_RuleType];
GO
IF OBJECT_ID(N'[dbo].[FK_Rule_LookupElement_Stage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Rule] DROP CONSTRAINT [FK_Rule_LookupElement_Stage];
GO
IF OBJECT_ID(N'[dbo].[FK_Rule_PatientDiagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Rule] DROP CONSTRAINT [FK_Rule_PatientDiagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_Rule_ProtocolDiagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Rule] DROP CONSTRAINT [FK_Rule_ProtocolDiagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_SecurityGroup_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[SecurityGroup] DROP CONSTRAINT [FK_SecurityGroup_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_SecurityGroup_MenuOption_MenuOption]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[SecurityGroup_MenuOption] DROP CONSTRAINT [FK_SecurityGroup_MenuOption_MenuOption];
GO
IF OBJECT_ID(N'[dbo].[FK_SecurityGroup_MenuOption_SecurityGroup]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[SecurityGroup_MenuOption] DROP CONSTRAINT [FK_SecurityGroup_MenuOption_SecurityGroup];
GO
IF OBJECT_ID(N'[dbo].[FK_SfOriginAccount_SfOriginAccount]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[SfOriginAccount] DROP CONSTRAINT [FK_SfOriginAccount_SfOriginAccount];
GO
IF OBJECT_ID(N'[dbo].[FK_SfOriginContact_SfOriginAccount]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[SfOriginContact] DROP CONSTRAINT [FK_SfOriginContact_SfOriginAccount];
GO
IF OBJECT_ID(N'[dbo].[FK_SfOriginContact_SfOriginContact]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[SfOriginContact] DROP CONSTRAINT [FK_SfOriginContact_SfOriginContact];
GO
IF OBJECT_ID(N'[dbo].[FK_SideEffect_Drug_SideEffect]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Drug_SideEffect] DROP CONSTRAINT [FK_SideEffect_Drug_SideEffect];
GO
IF OBJECT_ID(N'[dbo].[FK_SideEffect_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[SideEffect] DROP CONSTRAINT [FK_SideEffect_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_SpecialtyDrugCodes_DimPayer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[SpecialtyDrugCode] DROP CONSTRAINT [FK_SpecialtyDrugCodes_DimPayer];
GO
IF OBJECT_ID(N'[dbo].[FK_SpecialtyDrugCodes_DrugCode]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[SpecialtyDrugCode] DROP CONSTRAINT [FK_SpecialtyDrugCodes_DrugCode];
GO
IF OBJECT_ID(N'[dbo].[FK_SStepTherapyRulePriorDrug_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StepTherapyRulePriorDrug] DROP CONSTRAINT [FK_SStepTherapyRulePriorDrug_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_SStepTherapyRulePriorDrug_Rule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StepTherapyRulePriorDrug] DROP CONSTRAINT [FK_SStepTherapyRulePriorDrug_Rule];
GO
IF OBJECT_ID(N'[dbo].[FK_StateOutofScopeRule_LookupElement_EligibilityStateFieldType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StateOutofScopeRule] DROP CONSTRAINT [FK_StateOutofScopeRule_LookupElement_EligibilityStateFieldType];
GO
IF OBJECT_ID(N'[dbo].[FK_StepTherapyRule_Drug]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StepTherapyRule] DROP CONSTRAINT [FK_StepTherapyRule_Drug];
GO
IF OBJECT_ID(N'[dbo].[FK_StepTherapyRule_LookupElement_RuleCondition]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StepTherapyRule] DROP CONSTRAINT [FK_StepTherapyRule_LookupElement_RuleCondition];
GO
IF OBJECT_ID(N'[dbo].[FK_StepTherapyRule_Rule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StepTherapyRule] DROP CONSTRAINT [FK_StepTherapyRule_Rule];
GO
IF OBJECT_ID(N'[dbo].[FK_StepTherapyRuleDiagnosisExcluded_Diagnosis]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StepTherapyRuleDiagnosisExcluded] DROP CONSTRAINT [FK_StepTherapyRuleDiagnosisExcluded_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[FK_StepTherapyRuleDiagnosisExcluded_StepTherapyRule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StepTherapyRuleDiagnosisExcluded] DROP CONSTRAINT [FK_StepTherapyRuleDiagnosisExcluded_StepTherapyRule];
GO
IF OBJECT_ID(N'[dbo].[FK_StepTherapyRulePatientCancerStageExcluded_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StepTherapyRulePatientCancerStageExcluded] DROP CONSTRAINT [FK_StepTherapyRulePatientCancerStageExcluded_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_StepTherapyRulePatientCancerStageExcluded_StepTherapyRule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StepTherapyRulePatientCancerStageExcluded] DROP CONSTRAINT [FK_StepTherapyRulePatientCancerStageExcluded_StepTherapyRule];
GO
IF OBJECT_ID(N'[dbo].[FK_StepTherapyStateExcluded_State]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StepTherapyStateExcluded] DROP CONSTRAINT [FK_StepTherapyStateExcluded_State];
GO
IF OBJECT_ID(N'[dbo].[FK_StepTherapyStateExcluded_StepTherapyRule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StepTherapyStateExcluded] DROP CONSTRAINT [FK_StepTherapyStateExcluded_StepTherapyRule];
GO
IF OBJECT_ID(N'[dbo].[FK_StepTherapyStateOfPlanIssueExcluded_State]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StepTherapyStateOfPlanIssueExcluded] DROP CONSTRAINT [FK_StepTherapyStateOfPlanIssueExcluded_State];
GO
IF OBJECT_ID(N'[dbo].[FK_StepTherapyStateOfPlanIssueExcluded_StepTherapyRule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StepTherapyStateOfPlanIssueExcluded] DROP CONSTRAINT [FK_StepTherapyStateOfPlanIssueExcluded_StepTherapyRule];
GO
IF OBJECT_ID(N'[dbo].[FK_StopLossRule_BrandDrugID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StopLossRule] DROP CONSTRAINT [FK_StopLossRule_BrandDrugID];
GO
IF OBJECT_ID(N'[dbo].[FK_StopLossRule_CountyID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StopLossRule] DROP CONSTRAINT [FK_StopLossRule_CountyID];
GO
IF OBJECT_ID(N'[dbo].[FK_StopLossRule_DrugID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StopLossRule] DROP CONSTRAINT [FK_StopLossRule_DrugID];
GO
IF OBJECT_ID(N'[dbo].[FK_StopLossRule_RuleID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StopLossRule] DROP CONSTRAINT [FK_StopLossRule_RuleID];
GO
IF OBJECT_ID(N'[dbo].[FK_StopLossRule_StopLossDrugID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StopLossRule] DROP CONSTRAINT [FK_StopLossRule_StopLossDrugID];
GO
IF OBJECT_ID(N'[dbo].[FK_SupportedProtocolConfiguration_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[SupportedProtocolConfiguration] DROP CONSTRAINT [FK_SupportedProtocolConfiguration_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_SupportedProtocolConfiguration_LookupElement1]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[SupportedProtocolConfiguration] DROP CONSTRAINT [FK_SupportedProtocolConfiguration_LookupElement1];
GO
IF OBJECT_ID(N'[dbo].[FK_SupportedProtocolConfiguration_Protocol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[SupportedProtocolConfiguration] DROP CONSTRAINT [FK_SupportedProtocolConfiguration_Protocol];
GO
IF OBJECT_ID(N'[dbo].[FK_TATConfiguration_LookupElement_RequestType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TATConfiguration] DROP CONSTRAINT [FK_TATConfiguration_LookupElement_RequestType];
GO
IF OBJECT_ID(N'[dbo].[FK_TATConfiguration_LookupElement_TreatmentType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TATConfiguration] DROP CONSTRAINT [FK_TATConfiguration_LookupElement_TreatmentType];
GO
IF OBJECT_ID(N'[dbo].[FK_TATConfigurations_LineofBusiness]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TATConfiguration] DROP CONSTRAINT [FK_TATConfigurations_LineofBusiness];
GO
IF OBJECT_ID(N'[dbo].[FK_TATConfigurations_TATConfigurations]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TATConfiguration] DROP CONSTRAINT [FK_TATConfigurations_TATConfigurations];
GO
IF OBJECT_ID(N'[dbo].[FK_TatEvent_LookupElement_EventType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TatEvent] DROP CONSTRAINT [FK_TatEvent_LookupElement_EventType];
GO
IF OBJECT_ID(N'[dbo].[FK_TatEvent_LookupElement_ReviewStageId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TatEvent] DROP CONSTRAINT [FK_TatEvent_LookupElement_ReviewStageId];
GO
IF OBJECT_ID(N'[dbo].[FK_TatEvent_PatientProtocolAssignment]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TatEvent] DROP CONSTRAINT [FK_TatEvent_PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[FK_TatExtensionConfiguration_State]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TatExtensionConfiguration] DROP CONSTRAINT [FK_TatExtensionConfiguration_State];
GO
IF OBJECT_ID(N'[dbo].[FK_TatExtensionConfiguration_TypeOfDetermination]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TatExtensionConfiguration] DROP CONSTRAINT [FK_TatExtensionConfiguration_TypeOfDetermination];
GO
IF OBJECT_ID(N'[dbo].[FK_User_LookupElement_Status]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[User] DROP CONSTRAINT [FK_User_LookupElement_Status];
GO
IF OBJECT_ID(N'[dbo].[FK_User_LookupElement_UserGroup]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[User] DROP CONSTRAINT [FK_User_LookupElement_UserGroup];
GO
IF OBJECT_ID(N'[dbo].[FK_User_MemberAssociation_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[User_MemberAssociation] DROP CONSTRAINT [FK_User_MemberAssociation_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_User_MemberAssociation_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[User_MemberAssociation] DROP CONSTRAINT [FK_User_MemberAssociation_User];
GO
IF OBJECT_ID(N'[dbo].[FK_User_SecurityGroup_SecurityGroup]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[User_SecurityGroup] DROP CONSTRAINT [FK_User_SecurityGroup_SecurityGroup];
GO
IF OBJECT_ID(N'[dbo].[FK_User_SecurityGroup_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[User_SecurityGroup] DROP CONSTRAINT [FK_User_SecurityGroup_User];
GO
IF OBJECT_ID(N'[dbo].[FK_User_SfOriginAccount]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[User] DROP CONSTRAINT [FK_User_SfOriginAccount];
GO
IF OBJECT_ID(N'[dbo].[FK_User_SfOriginContact]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[User] DROP CONSTRAINT [FK_User_SfOriginContact];
GO
IF OBJECT_ID(N'[dbo].[FK_UserAccessList_InsuranceProvider]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserAccessList] DROP CONSTRAINT [FK_UserAccessList_InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[FK_UserAccessList_ProviderID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserAccessList_Provider] DROP CONSTRAINT [FK_UserAccessList_ProviderID];
GO
IF OBJECT_ID(N'[dbo].[FK_UserAddress_County]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserAddress] DROP CONSTRAINT [FK_UserAddress_County];
GO
IF OBJECT_ID(N'[dbo].[FK_UserAddress_LookupElement_AddressType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserAddress] DROP CONSTRAINT [FK_UserAddress_LookupElement_AddressType];
GO
IF OBJECT_ID(N'[dbo].[FK_UserAddress_State]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserAddress] DROP CONSTRAINT [FK_UserAddress_State];
GO
IF OBJECT_ID(N'[dbo].[FK_UserAddress_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserAddress] DROP CONSTRAINT [FK_UserAddress_User];
GO
IF OBJECT_ID(N'[dbo].[FK_UserAreaCode_AreaCodeLookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserAreaCode] DROP CONSTRAINT [FK_UserAreaCode_AreaCodeLookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_UserAreaCode_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserAreaCode] DROP CONSTRAINT [FK_UserAreaCode_User];
GO
IF OBJECT_ID(N'[dbo].[FK_UserCaseAcceptanceTime_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserCaseAcceptanceTime] DROP CONSTRAINT [FK_UserCaseAcceptanceTime_User];
GO
IF OBJECT_ID(N'[dbo].[FK_UserContact_LookupElement_ContactType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserContact] DROP CONSTRAINT [FK_UserContact_LookupElement_ContactType];
GO
IF OBJECT_ID(N'[dbo].[FK_UserContact_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserContact] DROP CONSTRAINT [FK_UserContact_User];
GO
IF OBJECT_ID(N'[dbo].[FK_UserLicense_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserLicense] DROP CONSTRAINT [FK_UserLicense_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_UserLicense_State_StateCode]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserLicense] DROP CONSTRAINT [FK_UserLicense_State_StateCode];
GO
IF OBJECT_ID(N'[dbo].[FK_UserLicense_User_UserID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserLicense] DROP CONSTRAINT [FK_UserLicense_User_UserID];
GO
IF OBJECT_ID(N'[dbo].[FK_UserLoginActivity_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserLoginActivity] DROP CONSTRAINT [FK_UserLoginActivity_User];
GO
IF OBJECT_ID(N'[dbo].[FK_UserProfileSetting_ProfileSetting]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserProfileSetting] DROP CONSTRAINT [FK_UserProfileSetting_ProfileSetting];
GO
IF OBJECT_ID(N'[dbo].[FK_UserProfileSetting_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserProfileSetting] DROP CONSTRAINT [FK_UserProfileSetting_User];
GO
IF OBJECT_ID(N'[dbo].[FK_VerificationCodeActivity_LookupElement_Reason]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[VerificationCodeActivity] DROP CONSTRAINT [FK_VerificationCodeActivity_LookupElement_Reason];
GO
IF OBJECT_ID(N'[dbo].[FK_WorkFlowQueueConfiguration_LookupElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[WorkFlowQueueConfiguration] DROP CONSTRAINT [FK_WorkFlowQueueConfiguration_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[FK_WorkFlowQueueConfiguration_WorkQueue]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[WorkFlowQueueConfiguration] DROP CONSTRAINT [FK_WorkFlowQueueConfiguration_WorkQueue];
GO
IF OBJECT_ID(N'[dbo].[FK_WorkQueue_SecurityGroup_SecurityGroup]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[WorkQueue_SecurityGroup] DROP CONSTRAINT [FK_WorkQueue_SecurityGroup_SecurityGroup];
GO
IF OBJECT_ID(N'[dbo].[FK_WorkQueue_SecurityGroup_WorkQueue]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[WorkQueue_SecurityGroup] DROP CONSTRAINT [FK_WorkQueue_SecurityGroup_WorkQueue];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[__RefactorLog]', 'U') IS NOT NULL
    DROP TABLE [dbo].[__RefactorLog];
GO
IF OBJECT_ID(N'[dbo].[ActiveSruveillanceLifeExpectancyDescription]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ActiveSruveillanceLifeExpectancyDescription];
GO
IF OBJECT_ID(N'[dbo].[ActiveSurveillanceLifeExpectancy]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ActiveSurveillanceLifeExpectancy];
GO
IF OBJECT_ID(N'[dbo].[Address]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Address];
GO
IF OBJECT_ID(N'[dbo].[Aggregation]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Aggregation];
GO
IF OBJECT_ID(N'[dbo].[AggregationResolution]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AggregationResolution];
GO
IF OBJECT_ID(N'[dbo].[AggregationRule]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AggregationRule];
GO
IF OBJECT_ID(N'[dbo].[ApprovedDrugsOverturnList]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ApprovedDrugsOverturnList];
GO
IF OBJECT_ID(N'[dbo].[AreaCodeLookupElement]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AreaCodeLookupElement];
GO
IF OBJECT_ID(N'[dbo].[AssessmentDiagnosis]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AssessmentDiagnosis];
GO
IF OBJECT_ID(N'[dbo].[AssessmentQuestion]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AssessmentQuestion];
GO
IF OBJECT_ID(N'[dbo].[AssessmentQuestionPossibleAnswer]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AssessmentQuestionPossibleAnswer];
GO
IF OBJECT_ID(N'[dbo].[AssessmentType]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AssessmentType];
GO
IF OBJECT_ID(N'[dbo].[AssessmentType_AssessmentQuestion]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AssessmentType_AssessmentQuestion];
GO
IF OBJECT_ID(N'[dbo].[AssignmentAction]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AssignmentAction];
GO
IF OBJECT_ID(N'[dbo].[AssignmentLockByUser]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AssignmentLockByUser];
GO
IF OBJECT_ID(N'[dbo].[AssignmentProvider]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AssignmentProvider];
GO
IF OBJECT_ID(N'[dbo].[AssignmentResponce]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AssignmentResponce];
GO
IF OBJECT_ID(N'[dbo].[AssignmentTimeZone]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AssignmentTimeZone];
GO
IF OBJECT_ID(N'[dbo].[AssignmentWorkflowStatusLog]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AssignmentWorkflowStatusLog];
GO
IF OBJECT_ID(N'[dbo].[Attachment]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Attachment];
GO
IF OBJECT_ID(N'[dbo].[AuditTrailField]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AuditTrailField];
GO
IF OBJECT_ID(N'[dbo].[AuditTrailObjectType]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AuditTrailObjectType];
GO
IF OBJECT_ID(N'[dbo].[AuditTrailTransaction]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AuditTrailTransaction];
GO
IF OBJECT_ID(N'[dbo].[AuditTrailTransactionDetail]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AuditTrailTransactionDetail];
GO
IF OBJECT_ID(N'[dbo].[AutoProtocolConfiguration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AutoProtocolConfiguration];
GO
IF OBJECT_ID(N'[dbo].[BrandDrug]', 'U') IS NOT NULL
    DROP TABLE [dbo].[BrandDrug];
GO
IF OBJECT_ID(N'[dbo].[BrandDrugCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[BrandDrugCode];
GO
IF OBJECT_ID(N'[dbo].[CallerContactDetail]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CallerContactDetail];
GO
IF OBJECT_ID(N'[dbo].[ClaimServiceLog]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ClaimServiceLog];
GO
IF OBJECT_ID(N'[dbo].[ClinicalObservation]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ClinicalObservation];
GO
IF OBJECT_ID(N'[dbo].[ClinicalObservationLabResult]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ClinicalObservationLabResult];
GO
IF OBJECT_ID(N'[dbo].[ClinicalQuestion]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ClinicalQuestion];
GO
IF OBJECT_ID(N'[dbo].[ClinicalQuestionAnswer]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ClinicalQuestionAnswer];
GO
IF OBJECT_ID(N'[dbo].[ClinicalQuestionDiagnosis]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ClinicalQuestionDiagnosis];
GO
IF OBJECT_ID(N'[dbo].[ClinicalValuesRule]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ClinicalValuesRule];
GO
IF OBJECT_ID(N'[dbo].[ClinicalValuesRuleDiagnosisExcluded]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ClinicalValuesRuleDiagnosisExcluded];
GO
IF OBJECT_ID(N'[dbo].[ClinicalValuesRuleLabResult]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ClinicalValuesRuleLabResult];
GO
IF OBJECT_ID(N'[dbo].[CMSProviderRRContact]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CMSProviderRRContact];
GO
IF OBJECT_ID(N'[dbo].[Contact]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Contact];
GO
IF OBJECT_ID(N'[dbo].[County]', 'U') IS NOT NULL
    DROP TABLE [dbo].[County];
GO
IF OBJECT_ID(N'[dbo].[CPTCodeXRT]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CPTCodeXRT];
GO
IF OBJECT_ID(N'[dbo].[DayLightSavingChangeDate]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DayLightSavingChangeDate];
GO
IF OBJECT_ID(N'[dbo].[DecisionReason]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DecisionReason];
GO
IF OBJECT_ID(N'[dbo].[DecisionReasonElement]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DecisionReasonElement];
GO
IF OBJECT_ID(N'[dbo].[DecisionReasonElementRequestType]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DecisionReasonElementRequestType];
GO
IF OBJECT_ID(N'[dbo].[Diagnosis]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[Diagnosis_MetastaticSite]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Diagnosis_MetastaticSite];
GO
IF OBJECT_ID(N'[dbo].[DiagnosisClinicalNarrative]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiagnosisClinicalNarrative];
GO
IF OBJECT_ID(N'[dbo].[DiagnosisClinicalTrialLink]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiagnosisClinicalTrialLink];
GO
IF OBJECT_ID(N'[dbo].[DiagnosisConfiguration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiagnosisConfiguration];
GO
IF OBJECT_ID(N'[dbo].[DiagnosisDistantMetaStasis]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiagnosisDistantMetaStasis];
GO
IF OBJECT_ID(N'[dbo].[DiagnosisICDCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiagnosisICDCode];
GO
IF OBJECT_ID(N'[dbo].[DiagnosisLineOfTherapy]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiagnosisLineOfTherapy];
GO
IF OBJECT_ID(N'[dbo].[DiagnosisLocalizedDisease]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiagnosisLocalizedDisease];
GO
IF OBJECT_ID(N'[dbo].[DiagnosisLocalizedDiseaseStage]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiagnosisLocalizedDiseaseStage];
GO
IF OBJECT_ID(N'[dbo].[DiagnosisMolecularMarker]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiagnosisMolecularMarker];
GO
IF OBJECT_ID(N'[dbo].[DiagnosisNodalStatus]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiagnosisNodalStatus];
GO
IF OBJECT_ID(N'[dbo].[DiagnosisOption]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiagnosisOption];
GO
IF OBJECT_ID(N'[dbo].[DiagnosisPhase]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiagnosisPhase];
GO
IF OBJECT_ID(N'[dbo].[DiagnosisSettingOfTherapy]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiagnosisSettingOfTherapy];
GO
IF OBJECT_ID(N'[dbo].[DiagnosisStage]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiagnosisStage];
GO
IF OBJECT_ID(N'[dbo].[DiagnosisTumorSize]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiagnosisTumorSize];
GO
IF OBJECT_ID(N'[dbo].[DimPayer]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DimPayer];
GO
IF OBJECT_ID(N'[dbo].[DimPayerPreferredProtocolProgram]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DimPayerPreferredProtocolProgram];
GO
IF OBJECT_ID(N'[dbo].[DimPayerPreferredProtocolProgram_PatientDiagnosis]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DimPayerPreferredProtocolProgram_PatientDiagnosis];
GO
IF OBJECT_ID(N'[dbo].[DimPayerRule]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DimPayerRule];
GO
IF OBJECT_ID(N'[dbo].[DiscontiueAuthorizationAssignment]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiscontiueAuthorizationAssignment];
GO
IF OBJECT_ID(N'[dbo].[DiscontiueAuthorizationLinkedAssignment]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DiscontiueAuthorizationLinkedAssignment];
GO
IF OBJECT_ID(N'[dbo].[DocumentDeletionReason]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DocumentDeletionReason];
GO
IF OBJECT_ID(N'[dbo].[DocumentDownloadHistory]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DocumentDownloadHistory];
GO
IF OBJECT_ID(N'[dbo].[DocumentExtraInfo]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DocumentExtraInfo];
GO
IF OBJECT_ID(N'[dbo].[DocumentRepository]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DocumentRepository];
GO
IF OBJECT_ID(N'[dbo].[DocumentTextBlock]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DocumentTextBlock];
GO
IF OBJECT_ID(N'[dbo].[Drug]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Drug];
GO
IF OBJECT_ID(N'[dbo].[Drug_SideEffect]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Drug_SideEffect];
GO
IF OBJECT_ID(N'[dbo].[DrugBiosimilarity]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DrugBiosimilarity];
GO
IF OBJECT_ID(N'[dbo].[DrugCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DrugCode];
GO
IF OBJECT_ID(N'[dbo].[DrugPolicy]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DrugPolicy];
GO
IF OBJECT_ID(N'[dbo].[DrugPolicyCriteria]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DrugPolicyCriteria];
GO
IF OBJECT_ID(N'[dbo].[DrugPolicyCriteriaDiagnosis]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DrugPolicyCriteriaDiagnosis];
GO
IF OBJECT_ID(N'[dbo].[DrugPolicyLOB]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DrugPolicyLOB];
GO
IF OBJECT_ID(N'[dbo].[DrugProtocolTotalBillingUnits]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DrugProtocolTotalBillingUnits];
GO
IF OBJECT_ID(N'[dbo].[DynamicFaxContent]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DynamicFaxContent];
GO
IF OBJECT_ID(N'[dbo].[Eligibility]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Eligibility];
GO
IF OBJECT_ID(N'[dbo].[EligiblityServiceLog]', 'U') IS NOT NULL
    DROP TABLE [dbo].[EligiblityServiceLog];
GO
IF OBJECT_ID(N'[dbo].[EmailArchive]', 'U') IS NOT NULL
    DROP TABLE [dbo].[EmailArchive];
GO
IF OBJECT_ID(N'[dbo].[EmailArchiveDetail]', 'U') IS NOT NULL
    DROP TABLE [dbo].[EmailArchiveDetail];
GO
IF OBJECT_ID(N'[dbo].[EmailArchiveDocument]', 'U') IS NOT NULL
    DROP TABLE [dbo].[EmailArchiveDocument];
GO
IF OBJECT_ID(N'[dbo].[EODFile]', 'U') IS NOT NULL
    DROP TABLE [dbo].[EODFile];
GO
IF OBJECT_ID(N'[dbo].[EODFileProtocolAssignment]', 'U') IS NOT NULL
    DROP TABLE [dbo].[EODFileProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[ExceptionsLog]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ExceptionsLog];
GO
IF OBJECT_ID(N'[dbo].[ExcludedPCP]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ExcludedPCP];
GO
IF OBJECT_ID(N'[dbo].[ExecutionLog]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ExecutionLog];
GO
IF OBJECT_ID(N'[dbo].[ExplicitAnswerXRT]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ExplicitAnswerXRT];
GO
IF OBJECT_ID(N'[dbo].[ExplicitQuestion]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ExplicitQuestion];
GO
IF OBJECT_ID(N'[dbo].[ExplicitQuestionAnswer]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ExplicitQuestionAnswer];
GO
IF OBJECT_ID(N'[dbo].[ExplicitQuestionXRT]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ExplicitQuestionXRT];
GO
IF OBJECT_ID(N'[dbo].[ExtractionDetail]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ExtractionDetail];
GO
IF OBJECT_ID(N'[dbo].[FaxAddress]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FaxAddress];
GO
IF OBJECT_ID(N'[dbo].[FaxArchive]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FaxArchive];
GO
IF OBJECT_ID(N'[dbo].[FaxArchiveDocument]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FaxArchiveDocument];
GO
IF OBJECT_ID(N'[dbo].[FaxCatalog]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FaxCatalog];
GO
IF OBJECT_ID(N'[dbo].[FaxDetails]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FaxDetails];
GO
IF OBJECT_ID(N'[dbo].[FaxDocumentAssignment]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FaxDocumentAssignment];
GO
IF OBJECT_ID(N'[dbo].[FaxParameter]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FaxParameter];
GO
IF OBJECT_ID(N'[dbo].[FaxRecipient]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FaxRecipient];
GO
IF OBJECT_ID(N'[dbo].[FaxRecipientConfiguration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FaxRecipientConfiguration];
GO
IF OBJECT_ID(N'[dbo].[FaxRecipientConfigurationFaxRecipientType]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FaxRecipientConfigurationFaxRecipientType];
GO
IF OBJECT_ID(N'[dbo].[FaxRecipientConfigurationState]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FaxRecipientConfigurationState];
GO
IF OBJECT_ID(N'[dbo].[FebrileNeutropeniaClinicalValuesRule]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FebrileNeutropeniaClinicalValuesRule];
GO
IF OBJECT_ID(N'[dbo].[FileExtension]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FileExtension];
GO
IF OBJECT_ID(N'[dbo].[FormularyException]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FormularyException];
GO
IF OBJECT_ID(N'[dbo].[FormularyException_AlternativeCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FormularyException_AlternativeCode];
GO
IF OBJECT_ID(N'[dbo].[FormularyException_ExceptionType]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FormularyException_ExceptionType];
GO
IF OBJECT_ID(N'[dbo].[FtnConfiguration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FtnConfiguration];
GO
IF OBJECT_ID(N'[dbo].[GrandfatherRule]', 'U') IS NOT NULL
    DROP TABLE [dbo].[GrandfatherRule];
GO
IF OBJECT_ID(N'[dbo].[GrandfatherRuleDrug]', 'U') IS NOT NULL
    DROP TABLE [dbo].[GrandfatherRuleDrug];
GO
IF OBJECT_ID(N'[dbo].[HelpfulLink]', 'U') IS NOT NULL
    DROP TABLE [dbo].[HelpfulLink];
GO
IF OBJECT_ID(N'[dbo].[ICDCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ICDCode];
GO
IF OBJECT_ID(N'[dbo].[Image]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Image];
GO
IF OBJECT_ID(N'[dbo].[InScopeICDCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InScopeICDCode];
GO
IF OBJECT_ID(N'[dbo].[InScopeInsuranceGroup]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InScopeInsuranceGroup];
GO
IF OBJECT_ID(N'[dbo].[InScopeJCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InScopeJCode];
GO
IF OBJECT_ID(N'[dbo].[InScopePCPCenter]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InScopePCPCenter];
GO
IF OBJECT_ID(N'[dbo].[InScopeState]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InScopeState];
GO
IF OBJECT_ID(N'[dbo].[InScopeZipCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InScopeZipCode];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProvider]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProvider];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProvider_Address]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProvider_Address];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProvider_LookupElement]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProvider_LookupElement];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderAttributeKey]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderAttributeKey];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderAttributeValue]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderAttributeValue];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderConfiguration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderConfiguration];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderContactDetail]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderContactDetail];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderDaylightSavingSetting]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderDaylightSavingSetting];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderDrug]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderDrug];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderDrugConfiguration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderDrugConfiguration];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderDrugConfiguration_LOB]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderDrugConfiguration_LOB];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderDrugConfiguration_Stage]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderDrugConfiguration_Stage];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderEODFileRecipient]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderEODFileRecipient];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderEODStatusOverride]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderEODStatusOverride];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderFaxTemplate]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderFaxTemplate];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderFaxTemplate_ProductLine]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderFaxTemplate_ProductLine];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderFaxTemplate_Rule]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderFaxTemplate_Rule];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderGlobalFaxParameter]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderGlobalFaxParameter];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderHomePage]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderHomePage];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderSpecialtyCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderSpecialtyCode];
GO
IF OBJECT_ID(N'[dbo].[InsuranceProviderTreatmentType]', 'U') IS NOT NULL
    DROP TABLE [dbo].[InsuranceProviderTreatmentType];
GO
IF OBJECT_ID(N'[dbo].[LabResult]', 'U') IS NOT NULL
    DROP TABLE [dbo].[LabResult];
GO
IF OBJECT_ID(N'[dbo].[LineofBusiness]', 'U') IS NOT NULL
    DROP TABLE [dbo].[LineofBusiness];
GO
IF OBJECT_ID(N'[dbo].[LineOfBusiness_CAGSetting]', 'U') IS NOT NULL
    DROP TABLE [dbo].[LineOfBusiness_CAGSetting];
GO
IF OBJECT_ID(N'[dbo].[Lookup]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Lookup];
GO
IF OBJECT_ID(N'[dbo].[LookupElement]', 'U') IS NOT NULL
    DROP TABLE [dbo].[LookupElement];
GO
IF OBJECT_ID(N'[dbo].[LookupElement_SecurityGroup]', 'U') IS NOT NULL
    DROP TABLE [dbo].[LookupElement_SecurityGroup];
GO
IF OBJECT_ID(N'[dbo].[LookupElementMapping]', 'U') IS NOT NULL
    DROP TABLE [dbo].[LookupElementMapping];
GO
IF OBJECT_ID(N'[dbo].[MailArchive]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MailArchive];
GO
IF OBJECT_ID(N'[dbo].[MailArchiveDocument]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MailArchiveDocument];
GO
IF OBJECT_ID(N'[dbo].[MailArchiveLog]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MailArchiveLog];
GO
IF OBJECT_ID(N'[dbo].[MailArchiveTracking]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MailArchiveTracking];
GO
IF OBJECT_ID(N'[dbo].[MailingCutoffCalculationLog]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MailingCutoffCalculationLog];
GO
IF OBJECT_ID(N'[dbo].[MailingCutoffConfiguration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MailingCutoffConfiguration];
GO
IF OBJECT_ID(N'[dbo].[MemberContactLog]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MemberContactLog];
GO
IF OBJECT_ID(N'[dbo].[MenuOption]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MenuOption];
GO
IF OBJECT_ID(N'[dbo].[MetastaticSite]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MetastaticSite];
GO
IF OBJECT_ID(N'[dbo].[MimicEligibilityServiceResponse]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MimicEligibilityServiceResponse];
GO
IF OBJECT_ID(N'[dbo].[MultilingualData]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MultilingualData];
GO
IF OBJECT_ID(N'[dbo].[MultilingualObject]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MultilingualObject];
GO
IF OBJECT_ID(N'[dbo].[MultilingualObjectField]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MultilingualObjectField];
GO
IF OBJECT_ID(N'[dbo].[NCCNRecurrenceRiskFormula]', 'U') IS NOT NULL
    DROP TABLE [dbo].[NCCNRecurrenceRiskFormula];
GO
IF OBJECT_ID(N'[dbo].[NCCNRecurrenceRiskGroup]', 'U') IS NOT NULL
    DROP TABLE [dbo].[NCCNRecurrenceRiskGroup];
GO
IF OBJECT_ID(N'[dbo].[NeutropeniaOverTurnDrug]', 'U') IS NOT NULL
    DROP TABLE [dbo].[NeutropeniaOverTurnDrug];
GO
IF OBJECT_ID(N'[dbo].[Note]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Note];
GO
IF OBJECT_ID(N'[dbo].[NotificationEnclosure]', 'U') IS NOT NULL
    DROP TABLE [dbo].[NotificationEnclosure];
GO
IF OBJECT_ID(N'[dbo].[NotificationEnclosureImage]', 'U') IS NOT NULL
    DROP TABLE [dbo].[NotificationEnclosureImage];
GO
IF OBJECT_ID(N'[dbo].[Patient]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Patient];
GO
IF OBJECT_ID(N'[dbo].[PatientAssessment]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientAssessment];
GO
IF OBJECT_ID(N'[dbo].[PatientAssessmentAnswer]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientAssessmentAnswer];
GO
IF OBJECT_ID(N'[dbo].[PatientClinicalDecisionSupport]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientClinicalDecisionSupport];
GO
IF OBJECT_ID(N'[dbo].[PatientClinicalDecisionSupport_Protocol]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientClinicalDecisionSupport_Protocol];
GO
IF OBJECT_ID(N'[dbo].[PatientDiagnosis]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientDiagnosis];
GO
IF OBJECT_ID(N'[dbo].[PatientICDCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientICDCode];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignment]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignment];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignment_Labresult]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignment_Labresult];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignment_Protocol]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignment_ProtocolDiagnosis]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignment_ProtocolDiagnosis];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignment_ProtocolDosing]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignment_ProtocolExtraInfo]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignment_ProtocolExtraInfo];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignment_ProtocolHCPCSCodeGMT]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignment_ProtocolHCPCSCodeGMT];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignment_ProtocolICDCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignment_ProtocolICDCode];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignment_ProtocolQuestionAnswer]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignment_ProtocolQuestionAnswer];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignment_QuestionAnswerXRT]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignment_QuestionAnswerXRT];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignment_Timer]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignment_Timer];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignment_VitalSign]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignment_VitalSign];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignmentEffectuationDate]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignmentEffectuationDate];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignmentHistory]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignmentHistory];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignmentInfo]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignmentInfo];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignmentPostDenial]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignmentPostDenial];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignmentPostDenialInfo]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignmentPostDenialInfo];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignmentPostDenialProtocol]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignmentPostDenialProtocol];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignmentProtocolElementAlias]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignmentProtocolElementAlias];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolAssignmentTimeCountdown]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolAssignmentTimeCountdown];
GO
IF OBJECT_ID(N'[dbo].[PatientProtocolRulesTrail]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PatientProtocolRulesTrail];
GO
IF OBJECT_ID(N'[dbo].[PayerBusinessDayConfig]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PayerBusinessDayConfig];
GO
IF OBJECT_ID(N'[dbo].[PayerContactDetail]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PayerContactDetail];
GO
IF OBJECT_ID(N'[dbo].[PayerFormulary]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PayerFormulary];
GO
IF OBJECT_ID(N'[dbo].[PayerOrganization]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PayerOrganization];
GO
IF OBJECT_ID(N'[dbo].[PayerPrimaryTimer]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PayerPrimaryTimer];
GO
IF OBJECT_ID(N'[dbo].[PayerTimerConfiguration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PayerTimerConfiguration];
GO
IF OBJECT_ID(N'[dbo].[PayerTimerConfiguration_State]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PayerTimerConfiguration_State];
GO
IF OBJECT_ID(N'[dbo].[PayerXrtCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PayerXrtCode];
GO
IF OBJECT_ID(N'[dbo].[PostDenialConfiguration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PostDenialConfiguration];
GO
IF OBJECT_ID(N'[dbo].[PracticeGroup]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PracticeGroup];
GO
IF OBJECT_ID(N'[dbo].[PracticeGroupAddress]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PracticeGroupAddress];
GO
IF OBJECT_ID(N'[dbo].[PracticeGroupPayer]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PracticeGroupPayer];
GO
IF OBJECT_ID(N'[dbo].[PracticeGroupUser]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PracticeGroupUser];
GO
IF OBJECT_ID(N'[dbo].[PreferredDrugRule]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PreferredDrugRule];
GO
IF OBJECT_ID(N'[dbo].[PreferredProtocolProgram_PatientProtocolAssignment_Protocol]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PreferredProtocolProgram_PatientProtocolAssignment_Protocol];
GO
IF OBJECT_ID(N'[dbo].[PreferredRegimenDrugBag]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PreferredRegimenDrugBag];
GO
IF OBJECT_ID(N'[dbo].[PreferredRegimenEvaluation]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PreferredRegimenEvaluation];
GO
IF OBJECT_ID(N'[dbo].[PreferredRegimenRules]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PreferredRegimenRules];
GO
IF OBJECT_ID(N'[dbo].[PrerequisiteDrug]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PrerequisiteDrug];
GO
IF OBJECT_ID(N'[dbo].[ProcedureCodeSimpleDescription]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProcedureCodeSimpleDescription];
GO
IF OBJECT_ID(N'[dbo].[ProductLine]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProductLine];
GO
IF OBJECT_ID(N'[dbo].[ProfileSetting]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProfileSetting];
GO
IF OBJECT_ID(N'[dbo].[Protocol]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Protocol];
GO
IF OBJECT_ID(N'[dbo].[Protocol_Diagnosis]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Protocol_Diagnosis];
GO
IF OBJECT_ID(N'[dbo].[ProtocolApprovalLog]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolApprovalLog];
GO
IF OBJECT_ID(N'[dbo].[ProtocolApprovalLogRule]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolApprovalLogRule];
GO
IF OBJECT_ID(N'[dbo].[ProtocolAuthorizationTip]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolAuthorizationTip];
GO
IF OBJECT_ID(N'[dbo].[ProtocolElement]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolElement];
GO
IF OBJECT_ID(N'[dbo].[ProtocolElement_RxNavDenorm]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolElement_RxNavDenorm];
GO
IF OBJECT_ID(N'[dbo].[ProtocolElementBillingUnits]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolElementBillingUnits];
GO
IF OBJECT_ID(N'[dbo].[ProtocolElementCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolElementCode];
GO
IF OBJECT_ID(N'[dbo].[ProtocolElementCodeFormularyData]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolElementCodeFormularyData];
GO
IF OBJECT_ID(N'[dbo].[ProtocolElementDosing]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolElementDosing];
GO
IF OBJECT_ID(N'[dbo].[ProtocolElementDosingVial]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolElementDosingVial];
GO
IF OBJECT_ID(N'[dbo].[ProtocolElementXRT]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolElementXRT];
GO
IF OBJECT_ID(N'[dbo].[ProtocolEvidenceLink]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolEvidenceLink];
GO
IF OBJECT_ID(N'[dbo].[ProtocolIntentOfTherapy]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolIntentOfTherapy];
GO
IF OBJECT_ID(N'[dbo].[ProtocolLineOfTherapy]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolLineOfTherapy];
GO
IF OBJECT_ID(N'[dbo].[ProtocolMGT]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolMGT];
GO
IF OBJECT_ID(N'[dbo].[ProtocolMolecularMarker]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolMolecularMarker];
GO
IF OBJECT_ID(N'[dbo].[ProtocolNCCNCategory]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolNCCNCategory];
GO
IF OBJECT_ID(N'[dbo].[ProtocolPerformaceStatus]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolPerformaceStatus];
GO
IF OBJECT_ID(N'[dbo].[ProtocolQuestion]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolQuestion];
GO
IF OBJECT_ID(N'[dbo].[ProtocolRequest]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolRequest];
GO
IF OBJECT_ID(N'[dbo].[ProtocolRequestDrug]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolRequestDrug];
GO
IF OBJECT_ID(N'[dbo].[ProtocolSettingOfTherapy]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolSettingOfTherapy];
GO
IF OBJECT_ID(N'[dbo].[ProtocolXRT]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProtocolXRT];
GO
IF OBJECT_ID(N'[dbo].[Provider]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Provider];
GO
IF OBJECT_ID(N'[dbo].[ProviderInfoData]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProviderInfoData];
GO
IF OBJECT_ID(N'[dbo].[QppAttestationReportResult]', 'U') IS NOT NULL
    DROP TABLE [dbo].[QppAttestationReportResult];
GO
IF OBJECT_ID(N'[dbo].[QppReportSetting]', 'U') IS NOT NULL
    DROP TABLE [dbo].[QppReportSetting];
GO
IF OBJECT_ID(N'[dbo].[ReferenceNumber]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ReferenceNumber];
GO
IF OBJECT_ID(N'[dbo].[Rule]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Rule];
GO
IF OBJECT_ID(N'[dbo].[RxNavDenorm]', 'U') IS NOT NULL
    DROP TABLE [dbo].[RxNavDenorm];
GO
IF OBJECT_ID(N'[dbo].[SalesforceStagingLoad]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SalesforceStagingLoad];
GO
IF OBJECT_ID(N'[dbo].[SecurityGroup]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SecurityGroup];
GO
IF OBJECT_ID(N'[dbo].[SecurityGroup_MenuOption]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SecurityGroup_MenuOption];
GO
IF OBJECT_ID(N'[dbo].[SfOriginAccount]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SfOriginAccount];
GO
IF OBJECT_ID(N'[dbo].[SfOriginAccountStaging]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SfOriginAccountStaging];
GO
IF OBJECT_ID(N'[dbo].[SfOriginContact]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SfOriginContact];
GO
IF OBJECT_ID(N'[dbo].[SfOriginContactStaging]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SfOriginContactStaging];
GO
IF OBJECT_ID(N'[dbo].[SideEffect]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SideEffect];
GO
IF OBJECT_ID(N'[dbo].[SpecialtyDrugCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SpecialtyDrugCode];
GO
IF OBJECT_ID(N'[dbo].[State]', 'U') IS NOT NULL
    DROP TABLE [dbo].[State];
GO
IF OBJECT_ID(N'[dbo].[StateOutofScopeRule]', 'U') IS NOT NULL
    DROP TABLE [dbo].[StateOutofScopeRule];
GO
IF OBJECT_ID(N'[dbo].[StepTherapyRule]', 'U') IS NOT NULL
    DROP TABLE [dbo].[StepTherapyRule];
GO
IF OBJECT_ID(N'[dbo].[StepTherapyRuleDiagnosisExcluded]', 'U') IS NOT NULL
    DROP TABLE [dbo].[StepTherapyRuleDiagnosisExcluded];
GO
IF OBJECT_ID(N'[dbo].[StepTherapyRulePatientCancerStageExcluded]', 'U') IS NOT NULL
    DROP TABLE [dbo].[StepTherapyRulePatientCancerStageExcluded];
GO
IF OBJECT_ID(N'[dbo].[StepTherapyRulePriorDrug]', 'U') IS NOT NULL
    DROP TABLE [dbo].[StepTherapyRulePriorDrug];
GO
IF OBJECT_ID(N'[dbo].[StepTherapyStateExcluded]', 'U') IS NOT NULL
    DROP TABLE [dbo].[StepTherapyStateExcluded];
GO
IF OBJECT_ID(N'[dbo].[StepTherapyStateOfPlanIssueExcluded]', 'U') IS NOT NULL
    DROP TABLE [dbo].[StepTherapyStateOfPlanIssueExcluded];
GO
IF OBJECT_ID(N'[dbo].[StopLossRule]', 'U') IS NOT NULL
    DROP TABLE [dbo].[StopLossRule];
GO
IF OBJECT_ID(N'[dbo].[SupportedProtocolConfiguration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SupportedProtocolConfiguration];
GO
IF OBJECT_ID(N'[dbo].[sysdiagrams]', 'U') IS NOT NULL
    DROP TABLE [dbo].[sysdiagrams];
GO
IF OBJECT_ID(N'[dbo].[sysssislog]', 'U') IS NOT NULL
    DROP TABLE [dbo].[sysssislog];
GO
IF OBJECT_ID(N'[dbo].[SystemConfiguration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SystemConfiguration];
GO
IF OBJECT_ID(N'[dbo].[TATConfiguration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TATConfiguration];
GO
IF OBJECT_ID(N'[dbo].[TatEvent]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TatEvent];
GO
IF OBJECT_ID(N'[dbo].[TatExtensionConfiguration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TatExtensionConfiguration];
GO
IF OBJECT_ID(N'[dbo].[TATNotification]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TATNotification];
GO
IF OBJECT_ID(N'[dbo].[User]', 'U') IS NOT NULL
    DROP TABLE [dbo].[User];
GO
IF OBJECT_ID(N'[dbo].[User_MemberAssociation]', 'U') IS NOT NULL
    DROP TABLE [dbo].[User_MemberAssociation];
GO
IF OBJECT_ID(N'[dbo].[User_SecurityGroup]', 'U') IS NOT NULL
    DROP TABLE [dbo].[User_SecurityGroup];
GO
IF OBJECT_ID(N'[dbo].[UserAccessList]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserAccessList];
GO
IF OBJECT_ID(N'[dbo].[UserAccessList_Provider]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserAccessList_Provider];
GO
IF OBJECT_ID(N'[dbo].[UserAddress]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserAddress];
GO
IF OBJECT_ID(N'[dbo].[UserAreaCode]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserAreaCode];
GO
IF OBJECT_ID(N'[dbo].[UserCaseAcceptanceTime]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserCaseAcceptanceTime];
GO
IF OBJECT_ID(N'[dbo].[UserContact]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserContact];
GO
IF OBJECT_ID(N'[dbo].[UserFeedback]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserFeedback];
GO
IF OBJECT_ID(N'[dbo].[UserLicense]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserLicense];
GO
IF OBJECT_ID(N'[dbo].[UserLoginActivity]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserLoginActivity];
GO
IF OBJECT_ID(N'[dbo].[UserProfileSetting]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserProfileSetting];
GO
IF OBJECT_ID(N'[dbo].[VerificationCodeActivity]', 'U') IS NOT NULL
    DROP TABLE [dbo].[VerificationCodeActivity];
GO
IF OBJECT_ID(N'[dbo].[WorkFlowQueueConfiguration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[WorkFlowQueueConfiguration];
GO
IF OBJECT_ID(N'[dbo].[WorkQueue]', 'U') IS NOT NULL
    DROP TABLE [dbo].[WorkQueue];
GO
IF OBJECT_ID(N'[dbo].[WorkQueue_SecurityGroup]', 'U') IS NOT NULL
    DROP TABLE [dbo].[WorkQueue_SecurityGroup];
GO
IF OBJECT_ID(N'[ApplicationModelStoreContainer].[DMSSTAT_RSTATS]', 'U') IS NOT NULL
    DROP TABLE [ApplicationModelStoreContainer].[DMSSTAT_RSTATS];
GO
IF OBJECT_ID(N'[ApplicationModelStoreContainer].[DMSSTAT_TSTATS]', 'U') IS NOT NULL
    DROP TABLE [ApplicationModelStoreContainer].[DMSSTAT_TSTATS];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'PatientProtocolAssignment_ProtocolExtraInfo'
CREATE TABLE [dbo].[PatientProtocolAssignment_ProtocolExtraInfo] (
    [PatientProtocolAssignmentProtocolID] int  NOT NULL,
    [ProtocolApprovalReasonID] smallint  NULL,
    [ProtocolApprovalReasonText] varchar(3000)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [ProtocolDecisionReasonID] smallint  NULL,
    [ProtocolDecisionDate] datetime  NULL,
    [WithdrawnRequestDateTime] datetime  NULL
);
GO

-- Creating table 'C__RefactorLog'
CREATE TABLE [dbo].[C__RefactorLog] (
    [OperationKey] uniqueidentifier  NOT NULL
);
GO

-- Creating table 'ActiveSruveillanceLifeExpectancyDescriptions'
CREATE TABLE [dbo].[ActiveSruveillanceLifeExpectancyDescriptions] (
    [LifeExpectancyDescriptionID] int IDENTITY(1,1) NOT NULL,
    [Description] nvarchar(500)  NOT NULL,
    [DescriptionSymbol] nvarchar(2)  NOT NULL,
    [Active] bit  NOT NULL
);
GO

-- Creating table 'ActiveSurveillanceLifeExpectancies'
CREATE TABLE [dbo].[ActiveSurveillanceLifeExpectancies] (
    [LifeExpectancyID] int IDENTITY(1,1) NOT NULL,
    [Age] int  NOT NULL,
    [RemainingLifeExpectancy] int  NOT NULL,
    [AssessmentQuestionPossibleAnswerID] int  NOT NULL,
    [LifeExpectancyDescriptionID] int  NOT NULL,
    [Active] bit  NOT NULL
);
GO

-- Creating table 'Addresses'
CREATE TABLE [dbo].[Addresses] (
    [AddressID] smallint IDENTITY(1,1) NOT NULL,
    [AddressLine1] varchar(100)  NOT NULL,
    [AddressLine2] varchar(100)  NULL,
    [City] varchar(32)  NOT NULL,
    [StateCode] varchar(2)  NOT NULL,
    [Zip] varchar(10)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'Aggregations'
CREATE TABLE [dbo].[Aggregations] (
    [AggregationID] int IDENTITY(1,1) NOT NULL,
    [AggregationRuleID] int  NOT NULL,
    [ApprovalRuleID] smallint  NOT NULL,
    [AutoProcessID] smallint  NULL,
    [ApprovalReasonID] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'AggregationResolutions'
CREATE TABLE [dbo].[AggregationResolutions] (
    [AggregationResolutionID] int IDENTITY(1,1) NOT NULL,
    [AggregationRuleID] int  NOT NULL,
    [AutoProcessID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'AggregationRules'
CREATE TABLE [dbo].[AggregationRules] (
    [AggregationRuleID] int IDENTITY(1,1) NOT NULL,
    [RuleID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ApprovedDrugsOverturnLists'
CREATE TABLE [dbo].[ApprovedDrugsOverturnLists] (
    [ApprovedDrugsOverturnListID] int IDENTITY(1,1) NOT NULL,
    [DrugID] int  NOT NULL
);
GO

-- Creating table 'AreaCodeLookupElements'
CREATE TABLE [dbo].[AreaCodeLookupElements] (
    [AreaCodeID] int IDENTITY(1,1) NOT NULL,
    [AreaCode] nvarchar(20)  NOT NULL,
    [State] varchar(20)  NULL,
    [ServiceAreaDescription] varchar(200)  NULL,
    [OAServiceArea] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [Active] bit  NULL
);
GO

-- Creating table 'AssessmentDiagnosis'
CREATE TABLE [dbo].[AssessmentDiagnosis] (
    [AssessmentDiagnosisID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NULL,
    [StageID] smallint  NULL,
    [ProtocolID] int  NULL,
    [ActiveSurveillanceFormID] int  NULL,
    [CreatedBy] int  NULL,
    [CreatedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'AssessmentQuestions'
CREATE TABLE [dbo].[AssessmentQuestions] (
    [AssessmentQuestionID] int IDENTITY(1,1) NOT NULL,
    [QuestionText] varchar(500)  NULL,
    [ControlType] varchar(128)  NULL,
    [ParentQuestionID] int  NULL,
    [Active] bit  NOT NULL,
    [SortOrder] int  NULL,
    [DisplayTabPosition] tinyint  NULL,
    [IsHeading] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [IsMandatory] bit  NOT NULL,
    [IsVisible] bit  NOT NULL,
    [HasFormula] bit  NOT NULL,
    [AnswerIDGroup] int  NULL
);
GO

-- Creating table 'AssessmentQuestionPossibleAnswers'
CREATE TABLE [dbo].[AssessmentQuestionPossibleAnswers] (
    [AssessmentQuestionPossibleAnswerID] int IDENTITY(1,1) NOT NULL,
    [AssessmentQuestionID] int  NOT NULL,
    [AnswerText] varchar(500)  NULL,
    [DefaultChecked] bit  NULL,
    [SortOrder] smallint  NULL,
    [HardStopValue] varchar(255)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [HardStopped] bit  NOT NULL,
    [AnswerValueType] nvarchar(20)  NULL
);
GO

-- Creating table 'AssessmentTypes'
CREATE TABLE [dbo].[AssessmentTypes] (
    [AssessmentTypeID] int IDENTITY(1,1) NOT NULL,
    [FormName] varchar(128)  NOT NULL,
    [Active] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'AssessmentType_AssessmentQuestion'
CREATE TABLE [dbo].[AssessmentType_AssessmentQuestion] (
    [AssessmentTypeAssessmentQuestionID] int IDENTITY(1,1) NOT NULL,
    [AssessmentTypeID] int  NULL,
    [AssessmentQuestionID] int  NULL,
    [CreatedBy] int  NULL,
    [CreatedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'AssignmentActions'
CREATE TABLE [dbo].[AssignmentActions] (
    [AssignmentActionID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [ActionID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [PatientProtocolAssignmentPostDenialID] int  NULL
);
GO

-- Creating table 'AssignmentLockByUsers'
CREATE TABLE [dbo].[AssignmentLockByUsers] (
    [AssignmentLockByUserID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [LockedBy] int  NOT NULL
);
GO

-- Creating table 'AssignmentProviders'
CREATE TABLE [dbo].[AssignmentProviders] (
    [AssignmentProviderID] int IDENTITY(1,1) NOT NULL,
    [ProtocolAssignmentID] int  NOT NULL,
    [TypeID] smallint  NOT NULL,
    [ProviderNPI] varchar(15)  NOT NULL,
    [ProviderTaxID] varchar(15)  NOT NULL,
    [IsOrganization] bit  NOT NULL,
    [PrimaryContactID] int  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [PrimaryPayerProviderID] varchar(24)  NULL,
    [SecondaryPayerProviderID] varchar(24)  NULL
);
GO

-- Creating table 'AssignmentResponces'
CREATE TABLE [dbo].[AssignmentResponces] (
    [AssignmentResponceID] int IDENTITY(1,1) NOT NULL,
    [OAReferenceNumber] varchar(50)  NULL,
    [PayerReferenceNumber] varchar(50)  NULL,
    [Status] varchar(50)  NULL,
    [ResponceDate] datetime  NULL
);
GO

-- Creating table 'AssignmentTimeZones'
CREATE TABLE [dbo].[AssignmentTimeZones] (
    [AssignmentTimeZoneID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [TimeZoneVariance] smallint  NULL,
    [CreatedOn] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL
);
GO

-- Creating table 'AssignmentWorkflowStatusLogs'
CREATE TABLE [dbo].[AssignmentWorkflowStatusLogs] (
    [AssignmentWorkflowStatusLogID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [WorkFlowStatusID] smallint  NULL,
    [WorkQueueID] tinyint  NOT NULL,
    [Description] nvarchar(100)  NULL,
    [AssignedBy] int  NOT NULL,
    [AssignedTo] int  NULL,
    [CreatedOn] datetime  NOT NULL,
    [Active] bit  NOT NULL,
    [Processed] bit  NOT NULL,
    [Locked] bit  NOT NULL,
    [AssignmentProcess] varchar(50)  NULL,
    [PatientProtocolAssignmentPostDenialID] int  NULL
);
GO

-- Creating table 'Attachments'
CREATE TABLE [dbo].[Attachments] (
    [DocumentRepositoryID] int  NOT NULL,
    [PatientID] int  NOT NULL,
    [PatientProtocolAssignmentID] int  NULL,
    [PatientProtocolAssignmentProtocolID] int  NULL,
    [CurrentMDID] int  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [OncologistOrganization] smallint  NULL,
    [SalesforceAccountID] varchar(100)  NULL,
    [PatientProtocolAssignmentPostDenialID] int  NULL
);
GO

-- Creating table 'AuditTrailFields'
CREATE TABLE [dbo].[AuditTrailFields] (
    [FieldID] smallint IDENTITY(1,1) NOT NULL,
    [FieldName] varchar(50)  NOT NULL,
    [ObjectTypeID] smallint  NOT NULL,
    [FieldDataType] nvarchar(50)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'AuditTrailObjectTypes'
CREATE TABLE [dbo].[AuditTrailObjectTypes] (
    [ObjectTypeID] smallint IDENTITY(1,1) NOT NULL,
    [ObjectName] varchar(50)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'AuditTrailTransactions'
CREATE TABLE [dbo].[AuditTrailTransactions] (
    [AuditTrailTransactionID] bigint IDENTITY(1,1) NOT NULL,
    [ObjectTypeID] smallint  NOT NULL,
    [ObjectID] int  NULL,
    [UserID] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL
);
GO

-- Creating table 'AuditTrailTransactionDetails'
CREATE TABLE [dbo].[AuditTrailTransactionDetails] (
    [AuditTrailTransactionDetailID] bigint IDENTITY(1,1) NOT NULL,
    [AuditTrailTransactionID] bigint  NOT NULL,
    [FieldID] smallint  NOT NULL,
    [OldValue] nvarchar(1000)  NULL,
    [NewValue] nvarchar(1000)  NULL
);
GO

-- Creating table 'AutoProtocolConfigurations'
CREATE TABLE [dbo].[AutoProtocolConfigurations] (
    [AutoProtocolConfigurationID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NULL,
    [ConfigurationType] varchar(128)  NULL,
    [ConfigurationSubID] smallint  NULL,
    [AssignmentCategoryID] smallint  NULL,
    [TurnToAutoReasonID] smallint  NULL,
    [ApplicableAge] smallint  NULL,
    [Gender] smallint  NULL,
    [Active] bit  NULL,
    [CreatedOn] datetime  NULL,
    [TurntoAuto] bit  NULL
);
GO

-- Creating table 'BrandDrugs'
CREATE TABLE [dbo].[BrandDrugs] (
    [BrandDrugID] int IDENTITY(1,1) NOT NULL,
    [BrandName] nvarchar(50)  NOT NULL,
    [DrugID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'BrandDrugCodes'
CREATE TABLE [dbo].[BrandDrugCodes] (
    [BrandDrugCodeID] int IDENTITY(1,1) NOT NULL,
    [HCPCSCode] char(5)  NOT NULL,
    [BrandDrugID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'CallerContactDetails'
CREATE TABLE [dbo].[CallerContactDetails] (
    [CallerContactDetailID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [PatientProtocolAssignmentProtocolID] int  NULL,
    [CallType] smallint  NOT NULL,
    [CallMethod] smallint  NOT NULL,
    [Outcome] smallint  NOT NULL,
    [ContactNumber] varchar(50)  NULL,
    [TimeOfContact] datetime  NOT NULL,
    [AttempNumber] varchar(50)  NULL,
    [ContactFirstName] varchar(50)  NULL,
    [ContactLastName] varchar(50)  NULL,
    [Notes] varchar(3000)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [ContactTitle] smallint  NULL,
    [CallSubjectID] smallint  NULL,
    [MessageType] smallint  NULL,
    [UnsuccessfulContactMethod] smallint  NULL
);
GO

-- Creating table 'ClaimServiceLogs'
CREATE TABLE [dbo].[ClaimServiceLogs] (
    [ClaimServiceLogID] int IDENTITY(1,1) NOT NULL,
    [Request] varchar(255)  NULL,
    [Response] varchar(1000)  NULL,
    [RequestDateTime] datetime  NULL,
    [ResponseDateTime] datetime  NULL
);
GO

-- Creating table 'ClinicalObservations'
CREATE TABLE [dbo].[ClinicalObservations] (
    [ClinicalObservationId] int IDENTITY(1,1) NOT NULL,
    [TypeId] smallint  NULL,
    [Name] varchar(50)  NOT NULL,
    [UnitsOfMeasureId] smallint  NULL,
    [ValueTypeId] smallint  NOT NULL,
    [RangeMin] smallint  NULL,
    [RangeMax] int  NULL,
    [CodingSystemId] smallint  NULL,
    [Code] varchar(50)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ClinicalObservationLabResults'
CREATE TABLE [dbo].[ClinicalObservationLabResults] (
    [ClinicalObservationLabResultID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [Value] varchar(50)  NOT NULL,
    [Date] datetime  NOT NULL,
    [ClinicalObservationID] int  NOT NULL,
    [SourceID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ClinicalQuestions'
CREATE TABLE [dbo].[ClinicalQuestions] (
    [ClinicalQuestionId] int IDENTITY(1,1) NOT NULL,
    [QuestionText] nvarchar(256)  NOT NULL,
    [QuestionHelpText] nvarchar(320)  NULL,
    [QuestionCode] nvarchar(50)  NOT NULL,
    [QuestionTypeId] smallint  NOT NULL,
    [Sequence] int  NOT NULL,
    [StatusId] smallint  NULL,
    [IsRequired] bit  NOT NULL,
    [EffectiveStartDate] datetime  NULL,
    [EffectiveEndDate] datetime  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ClinicalQuestionAnswers'
CREATE TABLE [dbo].[ClinicalQuestionAnswers] (
    [ClinicalQuestionAnswerId] int IDENTITY(1,1) NOT NULL,
    [ClinicalQuestionId] int  NOT NULL,
    [AnswerText] nvarchar(200)  NULL,
    [AnswerValue] nvarchar(200)  NULL,
    [AnswerTypeId] smallint  NULL,
    [PostText] nvarchar(50)  NULL,
    [Sequence] int  NOT NULL,
    [StatusId] smallint  NULL,
    [EffectiveStartDate] datetime  NULL,
    [EffectiveEndDate] datetime  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ClinicalQuestionDiagnosis'
CREATE TABLE [dbo].[ClinicalQuestionDiagnosis] (
    [ClinicalQuestionDiagnosisId] int IDENTITY(1,1) NOT NULL,
    [DiagnosisId] int  NOT NULL,
    [ClinicalQuestionId] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ClinicalValuesRules'
CREATE TABLE [dbo].[ClinicalValuesRules] (
    [ClinicalValuesRuleID] int IDENTITY(1,1) NOT NULL,
    [RuleID] int  NOT NULL,
    [DrugID] int  NOT NULL,
    [TreatmentID] smallint  NULL,
    [MinPatientAge] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ClinicalValuesRuleDiagnosisExcludeds'
CREATE TABLE [dbo].[ClinicalValuesRuleDiagnosisExcludeds] (
    [ClinicalValuesRuleDiagnosisExcludedID] int IDENTITY(1,1) NOT NULL,
    [ClinicalValuesRuleID] int  NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ClinicalValuesRuleLabResults'
CREATE TABLE [dbo].[ClinicalValuesRuleLabResults] (
    [ClinicalValuesRuleLabResultID] int IDENTITY(1,1) NOT NULL,
    [Value] varchar(50)  NOT NULL,
    [Period] smallint  NOT NULL,
    [ConditionID] smallint  NOT NULL,
    [ClinicalValuesRuleID] int  NOT NULL,
    [ClinicalObservationID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'CMSProviderRRContacts'
CREATE TABLE [dbo].[CMSProviderRRContacts] (
    [ID] int IDENTITY(1,1) NOT NULL,
    [SFAID] varchar(100)  NOT NULL,
    [RepFirstName] varchar(50)  NOT NULL,
    [RepLastName] varchar(50)  NOT NULL,
    [RepPhone] varchar(45)  NOT NULL,
    [RepEmail] varchar(255)  NOT NULL,
    [RepDefault] bit  NOT NULL,
    [RepForPortoRico] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL
);
GO

-- Creating table 'Contacts'
CREATE TABLE [dbo].[Contacts] (
    [ContactID] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(100)  NOT NULL,
    [Phone] varchar(15)  NULL,
    [Fax] varchar(15)  NULL,
    [Email] nvarchar(255)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'Counties'
CREATE TABLE [dbo].[Counties] (
    [CountyID] smallint IDENTITY(1,1) NOT NULL,
    [StateCode] varchar(2)  NOT NULL,
    [CountyName] varchar(50)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'CPTCodeXRTs'
CREATE TABLE [dbo].[CPTCodeXRTs] (
    [CPTCodeXRTID] int IDENTITY(1,1) NOT NULL,
    [CPTCode] nvarchar(50)  NOT NULL,
    [Description] nvarchar(500)  NOT NULL,
    [NumberOfRVU] varchar(50)  NOT NULL,
    [MCAPerRVU] varchar(50)  NOT NULL,
    [CostPerUnit] varchar(50)  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [ModifiedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [Deleted] bit  NULL,
    [DeletedOn] datetime  NULL,
    [DeletedBy] int  NULL,
    [AddendumBOPPSPaymentRate] decimal(14,4)  NULL,
    [CalculationMethodID] smallint  NULL
);
GO

-- Creating table 'DayLightSavingChangeDates'
CREATE TABLE [dbo].[DayLightSavingChangeDates] (
    [DayLightSavingChangeDateID] int IDENTITY(1,1) NOT NULL,
    [DayLightSavingDate] datetime  NOT NULL,
    [IsDayLightSavingOn] bit  NOT NULL
);
GO

-- Creating table 'DecisionReasons'
CREATE TABLE [dbo].[DecisionReasons] (
    [DecisionReasonID] int IDENTITY(1,1) NOT NULL,
    [Description] varchar(255)  NOT NULL,
    [Code] varchar(10)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DecisionReasonElements'
CREATE TABLE [dbo].[DecisionReasonElements] (
    [DecisionReasonElementID] int IDENTITY(1,1) NOT NULL,
    [DecisionReasonID] int  NOT NULL,
    [Text] varchar(5000)  NOT NULL,
    [Other] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DecisionReasonElementRequestTypes'
CREATE TABLE [dbo].[DecisionReasonElementRequestTypes] (
    [DecisionReasonElementRequestTypeID] smallint IDENTITY(1,1) NOT NULL,
    [DecisionReasonElementID] int  NOT NULL,
    [TreatmentTypeID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'Diagnosis'
CREATE TABLE [dbo].[Diagnosis] (
    [DiagnosisID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisName] varchar(128)  NOT NULL,
    [DiagnosisCode] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [Active] bit  NULL,
    [Susceptibility] bit  NULL
);
GO

-- Creating table 'Diagnosis_MetastaticSite'
CREATE TABLE [dbo].[Diagnosis_MetastaticSite] (
    [DiagnosisMetastaticSiteID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [MetastaticSiteID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiagnosisClinicalNarratives'
CREATE TABLE [dbo].[DiagnosisClinicalNarratives] (
    [DiagnosisClinicalNarrativeID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [ClinicalNarrative] nvarchar(max)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiagnosisClinicalTrialLinks'
CREATE TABLE [dbo].[DiagnosisClinicalTrialLinks] (
    [DiagnosisClinicalTrialLinkID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [StageID] smallint  NOT NULL,
    [LinkURL] varchar(2083)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiagnosisConfigurations'
CREATE TABLE [dbo].[DiagnosisConfigurations] (
    [DiagnosisConfigurationID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [Title] varchar(50)  NULL,
    [ProtocolTypeID] smallint  NOT NULL,
    [SortOrder] tinyint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [MainProtocol] bit  NOT NULL
);
GO

-- Creating table 'DiagnosisDistantMetaStasis'
CREATE TABLE [dbo].[DiagnosisDistantMetaStasis] (
    [DiagnosisDistantMetaStasisID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [DistantMetaStasisID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiagnosisICDCodes'
CREATE TABLE [dbo].[DiagnosisICDCodes] (
    [DiagnosisICDCodeID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [ICDCode] varchar(13)  NOT NULL,
    [ICDversion] tinyint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiagnosisLineOfTherapies'
CREATE TABLE [dbo].[DiagnosisLineOfTherapies] (
    [DiagnosisLineOfTherapyID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [LineOfTherapyID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiagnosisLocalizedDiseases'
CREATE TABLE [dbo].[DiagnosisLocalizedDiseases] (
    [DiagnosisLocalizedDiseaseID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [Description] nvarchar(max)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiagnosisLocalizedDiseaseStages'
CREATE TABLE [dbo].[DiagnosisLocalizedDiseaseStages] (
    [DiagnosisLocalizedDiseaseStageID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisLocalizedDiseaseID] int  NOT NULL,
    [StageID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiagnosisMolecularMarkers'
CREATE TABLE [dbo].[DiagnosisMolecularMarkers] (
    [DiagnosisMolecularMarkerID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [MolecularMarkerID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiagnosisNodalStatus'
CREATE TABLE [dbo].[DiagnosisNodalStatus] (
    [DiagnosisNodalStatusID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [NodalStatusID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiagnosisOptions'
CREATE TABLE [dbo].[DiagnosisOptions] (
    [DiagnosisOptionID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [LookupElementID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiagnosisPhases'
CREATE TABLE [dbo].[DiagnosisPhases] (
    [DiagnosisPhaseID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [PhaseID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiagnosisSettingOfTherapies'
CREATE TABLE [dbo].[DiagnosisSettingOfTherapies] (
    [DiagnosisSettingOfTherapyID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [SettingOfTherapyID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiagnosisStages'
CREATE TABLE [dbo].[DiagnosisStages] (
    [DiagnosisStageID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [StageID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiagnosisTumorSizes'
CREATE TABLE [dbo].[DiagnosisTumorSizes] (
    [DiagnosisTumorSizeID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [TumorSizeID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DimPayers'
CREATE TABLE [dbo].[DimPayers] (
    [DimPayerID] int IDENTITY(1,1) NOT NULL,
    [OA] bit  NULL,
    [InsuranceProviderID] smallint  NULL,
    [Market] varchar(50)  NULL,
    [MajorLineOfBusinessID] smallint  NULL,
    [StateOfPlanIssue] varchar(2)  NULL,
    [StateCode] varchar(2)  NULL,
    [LineOfBusinessID] smallint  NULL,
    [ProductLineID] smallint  NULL,
    [BenefitPlan] varchar(300)  NULL,
    [PlanYear] smallint  NULL,
    [Group] varchar(50)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DimPayerPreferredProtocolPrograms'
CREATE TABLE [dbo].[DimPayerPreferredProtocolPrograms] (
    [DimPayerPreferredProtocolProgramID] int IDENTITY(1,1) NOT NULL,
    [ProtocolID] int  NOT NULL,
    [DimPayerID] int  NOT NULL,
    [ProgramID] smallint  NOT NULL,
    [StatusID] smallint  NOT NULL,
    [EffectiveDate] datetime  NOT NULL,
    [EffectiveEndDate] datetime  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DimPayerPreferredProtocolProgram_PatientDiagnosis'
CREATE TABLE [dbo].[DimPayerPreferredProtocolProgram_PatientDiagnosis] (
    [DimPayerPreferredProtocolProgramPatientDiagnosisID] int IDENTITY(1,1) NOT NULL,
    [DimPayerPreferredProtocolProgramID] int  NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DimPayerRules'
CREATE TABLE [dbo].[DimPayerRules] (
    [DimPayerRuleID] int IDENTITY(1,1) NOT NULL,
    [RuleID] int  NOT NULL,
    [DimPayerID] int  NOT NULL,
    [ApprovalRuleModeID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiscontiueAuthorizationAssignments'
CREATE TABLE [dbo].[DiscontiueAuthorizationAssignments] (
    [DiscontinueAuthorizationAssignmentID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DiscontiueAuthorizationLinkedAssignments'
CREATE TABLE [dbo].[DiscontiueAuthorizationLinkedAssignments] (
    [DiscontiueAuthorizationLinkedAssignmentID] int IDENTITY(1,1) NOT NULL,
    [DiscontinueAuthorizationAssignmentID] int  NOT NULL,
    [PatientProtocolLinkedAssignmentID] int  NOT NULL,
    [Discontinued] bit  NULL,
    [DiscontinuedBy] int  NULL,
    [DiscontinuedOn] datetime  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [DiscontinueEmailSentDate] datetime  NULL
);
GO

-- Creating table 'DocumentDeletionReasons'
CREATE TABLE [dbo].[DocumentDeletionReasons] (
    [DocumentDeletionReasonID] int IDENTITY(1,1) NOT NULL,
    [DocumentDeletionID] smallint  NOT NULL,
    [DocumentRepositoryID] int  NOT NULL,
    [DeletionNotes] varchar(350)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DocumentDownloadHistories'
CREATE TABLE [dbo].[DocumentDownloadHistories] (
    [DocumentDownloadHistoryID] int IDENTITY(1,1) NOT NULL,
    [DocumentID] int  NOT NULL,
    [IPNumber] varchar(20)  NOT NULL,
    [DownloadedBy] int  NOT NULL,
    [DownloadedOn] datetime  NOT NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DocumentExtraInfoes'
CREATE TABLE [dbo].[DocumentExtraInfoes] (
    [DocumentRepositoryID] int  NOT NULL,
    [PriorityID] smallint  NULL,
    [Notes] varchar(5000)  NULL
);
GO

-- Creating table 'DocumentRepositories'
CREATE TABLE [dbo].[DocumentRepositories] (
    [DocumentRepositoryID] int IDENTITY(1,1) NOT NULL,
    [DocumentName] varchar(200)  NOT NULL,
    [DocumentDescription] varchar(256)  NULL,
    [DocumentData] varbinary(max)  NULL,
    [DocumentType] smallint  NULL,
    [Compressed] bit  NOT NULL,
    [FileExtension] varchar(10)  NULL,
    [DocumentVersion] smallint  NOT NULL,
    [ParentDocumentID] bigint  NULL,
    [OriginalSize] int  NOT NULL,
    [CompressedSize] int  NULL,
    [Active] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [InsuranceProviderID] smallint  NULL,
    [DocumentHash] varchar(64)  NULL
);
GO

-- Creating table 'DocumentTextBlocks'
CREATE TABLE [dbo].[DocumentTextBlocks] (
    [DocumentTextBlockID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NULL,
    [ShortText] varchar(500)  NOT NULL,
    [LongText] varchar(max)  NOT NULL,
    [DocumentTextBlockTypeID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'Drugs'
CREATE TABLE [dbo].[Drugs] (
    [DrugID] int IDENTITY(1,1) NOT NULL,
    [DrugName] varchar(64)  NOT NULL,
    [PhysicianCostPerUnitOfMeasure] real  NOT NULL,
    [MCACostPerUnitOfMeasure] real  NOT NULL,
    [UnitOfMeasureID] smallint  NOT NULL,
    [HFSBasePrice] real  NULL,
    [C98PercentMCAFloorPrice] real  NULL,
    [C100PercentMCAFloorPrice] real  NULL,
    [C103PercentMCAFloorPrice] real  NULL,
    [C105PercentMCAFloorPrice] real  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [NeverOverturnToAuto] bit  NULL,
    [GCSFTypeID] smallint  NULL,
    [DrugClassID] smallint  NULL,
    [DrugSubClassID] smallint  NULL,
    [RxNormTermTypeID] smallint  NULL,
    [RxNormCode] varchar(8)  NULL,
    [DrugIsCarT] bit  NULL,
    [IsLegacyProtocolAdapterData] bit  NULL
);
GO

-- Creating table 'Drug_SideEffect'
CREATE TABLE [dbo].[Drug_SideEffect] (
    [DrugSideEffectID] int IDENTITY(1,1) NOT NULL,
    [DrugID] int  NOT NULL,
    [SideEffectID] int  NOT NULL,
    [SideEffectFrequencyID] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DrugBiosimilarities'
CREATE TABLE [dbo].[DrugBiosimilarities] (
    [DrugBiosimilarityID] int IDENTITY(1,1) NOT NULL,
    [OriginalDrugID] int  NOT NULL,
    [BiosimilarDrugID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DrugCodes'
CREATE TABLE [dbo].[DrugCodes] (
    [DrugCodeID] int IDENTITY(1,1) NOT NULL,
    [DrugID] int  NOT NULL,
    [HCPCSCode] char(5)  NOT NULL,
    [Description] varchar(255)  NULL,
    [BillingUnitQuantity] real  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [IsLegacyProtocolAdapterData] bit  NULL
);
GO

-- Creating table 'DrugPolicies'
CREATE TABLE [dbo].[DrugPolicies] (
    [DrugPolicyID] int IDENTITY(1,1) NOT NULL,
    [DrugID] int  NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [PolicyName] varchar(500)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DrugPolicyCriterias'
CREATE TABLE [dbo].[DrugPolicyCriterias] (
    [DrugPolicyCriteriaID] int IDENTITY(1,1) NOT NULL,
    [DrugPolicyID] int  NOT NULL,
    [PolicyCriteria] varchar(max)  NOT NULL,
    [SortOrder] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DrugPolicyCriteriaDiagnosis'
CREATE TABLE [dbo].[DrugPolicyCriteriaDiagnosis] (
    [DrugPolicyCriteriaDiagnosisID] int IDENTITY(1,1) NOT NULL,
    [DrugPolicyCriteriaID] int  NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [StageID] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DrugPolicyLOBs'
CREATE TABLE [dbo].[DrugPolicyLOBs] (
    [DrugPolicyLOBID] int IDENTITY(1,1) NOT NULL,
    [DrugPolicyID] int  NOT NULL,
    [LineOfBusinessID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DrugProtocolTotalBillingUnits'
CREATE TABLE [dbo].[DrugProtocolTotalBillingUnits] (
    [DrugProtocolTotalBillingUnitsID] int IDENTITY(1,1) NOT NULL,
    [ProtocolID] int  NOT NULL,
    [DrugID] int  NOT NULL,
    [Code] varchar(50)  NOT NULL,
    [CodeTypeID] smallint  NOT NULL,
    [BillingMethodID] smallint  NOT NULL,
    [TotalBillingUnitsPerAuth] real  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'Eligibilities'
CREATE TABLE [dbo].[Eligibilities] (
    [EligibilityID] int IDENTITY(1,1) NOT NULL,
    [PatientID] int  NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [ProductLineID] smallint  NULL,
    [MemberID] varchar(20)  NOT NULL,
    [MedicareContractNumber] varchar(15)  NULL,
    [PatientFirstName] nvarchar(50)  NULL,
    [PatientLastName] nvarchar(50)  NOT NULL,
    [DOB] datetime  NOT NULL,
    [CenterNo] varchar(16)  NULL,
    [PCPGrouperNumber] varchar(15)  NULL,
    [ReferringPCP] nvarchar(255)  NULL,
    [InsuranceGroupID] varchar(50)  NULL,
    [InsuranceEffectiveDate] datetime  NULL,
    [InsuranceTerminationDate] datetime  NULL,
    [SecondaryInsurance] bit  NOT NULL,
    [VerificationDate] datetime  NULL,
    [Re_VerificationDate] datetime  NULL,
    [VerificationSource] nvarchar(50)  NULL,
    [MemberRiskIndicator] bit  NOT NULL,
    [MemberASOIndicator] bit  NOT NULL,
    [LineOfBusinessID] smallint  NOT NULL,
    [Retrospective] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [Eligible] bit  NULL,
    [StateOfPlanIssue] varchar(50)  NULL,
    [ODSMemberGeneratedKey] varchar(55)  NULL,
    [NumOneIndicator] bit  NULL,
    [FinProdCd] varchar(50)  NULL,
    [Phone] varchar(10)  NULL,
    [City] varchar(32)  NULL,
    [State] varchar(2)  NULL,
    [ZipCode] varchar(10)  NULL,
    [AddressLine1] varchar(100)  NULL,
    [AddressLine2] varchar(100)  NULL,
    [WorkPhone] varchar(10)  NULL,
    [WorkPhoneExtension] varchar(5)  NULL,
    [MobilePhone] varchar(10)  NULL,
    [AppointmentOfRepresentative] bit  NULL,
    [RepresentativeFirstName] varchar(50)  NULL,
    [RepresentativeLastName] varchar(50)  NULL,
    [RepresentativeAddressLine1] varchar(100)  NULL,
    [RepresentativeAddressLine2] varchar(100)  NULL,
    [RepresentativeCity] varchar(32)  NULL,
    [RepresentativeState] varchar(2)  NULL,
    [RepresentativeZipCode] varchar(10)  NULL,
    [RepresentativeZipPlusCode] varchar(4)  NULL,
    [RepresentativeRelationshipCodeID] varchar(50)  NULL,
    [RepresentativeHomePhone] varchar(10)  NULL,
    [RepresentativeWorkPhone] varchar(10)  NULL,
    [RepresentativeWorkPhoneExtension] varchar(5)  NULL,
    [RepresentativeMobilePhone] varchar(10)  NULL,
    [PreferredLanguageIso639Code] nvarchar(50)  NULL,
    [PreferredLanguageIso639Name] nvarchar(100)  NULL,
    [OONBenefit] bit  NULL,
    [CarrierID] nvarchar(10)  NULL,
    [AccountID] nvarchar(20)  NULL,
    [PharmacyGroupID] nvarchar(30)  NULL,
    [ProductOfferCode] varchar(200)  NULL,
    [LegalEntity] varchar(10)  NULL,
    [OutOfArea] bit  NULL,
    [DualEligibilityStatusID] smallint  NULL,
    [IsErisa] bit  NULL,
    [InsuranceGroupName] nvarchar(60)  NULL,
    [IsFEHB] bit  NULL,
    [IsASOSWHP] bit  NULL,
    [IsASOICSW] bit  NULL,
    [HasMedicalBenefits] bit  NULL,
    [HasPharmacyBenefits] bit  NULL,
    [FormularyName] varchar(100)  NULL,
    [PlanDescription] varchar(30)  NULL,
    [MedicaidNumber] varchar(15)  NULL,
    [OutOfAreaCategory] char(1)  NULL,
    [ContractNumber] nvarchar(10)  NULL,
    [PBPID] nvarchar(3)  NULL,
    [LegacySystemSourceProdPlanKey] nvarchar(30)  NULL
);
GO

-- Creating table 'EligiblityServiceLogs'
CREATE TABLE [dbo].[EligiblityServiceLogs] (
    [LogID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NULL,
    [Request] varchar(500)  NULL,
    [Response] varchar(max)  NULL,
    [RequestDateTime] datetime  NULL,
    [ResponseDateTime] datetime  NULL,
    [ErrorCode] varchar(10)  NULL,
    [ErrorDescription] varchar(255)  NULL
);
GO

-- Creating table 'EmailArchives'
CREATE TABLE [dbo].[EmailArchives] (
    [EmailArchiveID] int IDENTITY(1,1) NOT NULL,
    [PatientID] int  NULL,
    [PatientProtocolAssignmentID] int  NULL,
    [From] nvarchar(128)  NOT NULL,
    [To] nvarchar(512)  NOT NULL,
    [Subject] varchar(300)  NULL,
    [Body] varchar(1000)  NULL,
    [Sent] bit  NULL,
    [SentTries] tinyint  NULL,
    [ResponseMessage] nvarchar(512)  NULL,
    [SentOn] datetime  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [IsAdditionalText] bit  NULL,
    [AdditionalBodyText] varchar(max)  NULL,
    [BccEmail] varchar(128)  NULL,
    [EmailCode] varchar(50)  NULL
);
GO

-- Creating table 'EmailArchiveDetails'
CREATE TABLE [dbo].[EmailArchiveDetails] (
    [EmailArchiveDetailID] int IDENTITY(1,1) NOT NULL,
    [EmailArchiveID] int  NOT NULL,
    [To] nvarchar(128)  NOT NULL,
    [IsSent] bit  NOT NULL,
    [SentTries] tinyint  NOT NULL,
    [ResponseMessage] nvarchar(512)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'EmailArchiveDocuments'
CREATE TABLE [dbo].[EmailArchiveDocuments] (
    [EmailArchiveDocumentID] int IDENTITY(1,1) NOT NULL,
    [EmailArchiveID] int  NOT NULL,
    [DocumentRepositoryID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'EODFiles'
CREATE TABLE [dbo].[EODFiles] (
    [EODFileID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [EODFileName] varchar(128)  NOT NULL,
    [SentDateTime] datetime  NULL,
    [LastProcessedAssignment] datetime  NULL
);
GO

-- Creating table 'EODFileProtocolAssignments'
CREATE TABLE [dbo].[EODFileProtocolAssignments] (
    [EODFileProtocolAssignmentID] int IDENTITY(1,1) NOT NULL,
    [EODFileID] int  NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [OAReferenceNumber] varchar(50)  NOT NULL
);
GO

-- Creating table 'ExceptionsLogs'
CREATE TABLE [dbo].[ExceptionsLogs] (
    [ID] int IDENTITY(1,1) NOT NULL,
    [MachineName] nvarchar(200)  NULL,
    [SiteName] nvarchar(200)  NOT NULL,
    [Logged] datetime  NOT NULL,
    [Level] varchar(5)  NOT NULL,
    [UserName] nvarchar(200)  NULL,
    [Message] nvarchar(max)  NOT NULL,
    [Logger] nvarchar(300)  NULL,
    [Properties] nvarchar(max)  NULL,
    [ServerName] nvarchar(200)  NULL,
    [Port] nvarchar(100)  NULL,
    [Url] nvarchar(2000)  NULL,
    [Https] bit  NULL,
    [ServerAddress] nvarchar(100)  NULL,
    [RemoteAddress] nvarchar(100)  NULL,
    [Callsite] nvarchar(300)  NULL,
    [Exception] nvarchar(max)  NULL
);
GO

-- Creating table 'ExecutionLogs'
CREATE TABLE [dbo].[ExecutionLogs] (
    [ExecutionLogID] bigint IDENTITY(1,1) NOT NULL,
    [ExecutionID] uniqueidentifier  NOT NULL,
    [HealthPlan] nvarchar(50)  NOT NULL,
    [StartExecDateTime] datetime  NOT NULL,
    [EndExecDateTime] datetime  NULL,
    [FileName] nvarchar(120)  NULL,
    [Result] nvarchar(16)  NULL,
    [ResultReason] nvarchar(4000)  NULL,
    [ReceivedRecords] int  NULL,
    [UploadRecords] int  NULL,
    [RejectedRecords] int  NULL,
    [FailOnTask] nvarchar(60)  NULL
);
GO

-- Creating table 'ExplicitAnswerXRTs'
CREATE TABLE [dbo].[ExplicitAnswerXRTs] (
    [ExplicitAnswerXRTID] int IDENTITY(1,1) NOT NULL,
    [ExplicitQuestionXRTID] int  NOT NULL,
    [AnswerText] nvarchar(200)  NOT NULL,
    [SortOrder] int  NULL,
    [ToolTip] nvarchar(500)  NULL,
    [Active] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ExplicitQuestions'
CREATE TABLE [dbo].[ExplicitQuestions] (
    [QuestionID] int IDENTITY(1,1) NOT NULL,
    [QuestionText] varchar(255)  NULL,
    [Active] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ExplicitQuestionAnswers'
CREATE TABLE [dbo].[ExplicitQuestionAnswers] (
    [QuestionAnswerID] int IDENTITY(1,1) NOT NULL,
    [QuestionID] int  NOT NULL,
    [AnswerID] smallint  NOT NULL,
    [DefaultChecked] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ExplicitQuestionXRTs'
CREATE TABLE [dbo].[ExplicitQuestionXRTs] (
    [ExplicitQuestionXRTID] int IDENTITY(1,1) NOT NULL,
    [QuestionText] varchar(250)  NOT NULL,
    [SortOrder] int  NULL,
    [Active] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [Version] tinyint  NULL
);
GO

-- Creating table 'ExtractionDetails'
CREATE TABLE [dbo].[ExtractionDetails] (
    [ExractionDetailID] int IDENTITY(1,1) NOT NULL,
    [Object] varchar(50)  NOT NULL,
    [ExractionStartDate] datetime  NOT NULL,
    [ExractionEndDate] datetime  NULL,
    [TimeConsumedInExtraction] varchar(10)  NULL,
    [TotalCount] int  NULL,
    [UpdatedCount] int  NULL,
    [InsertedCount] int  NULL,
    [HardDeletedCount] int  NULL,
    [SoftDeletedCount] int  NULL
);
GO

-- Creating table 'FaxAddresses'
CREATE TABLE [dbo].[FaxAddresses] (
    [FaxAddressID] int IDENTITY(1,1) NOT NULL,
    [Address] varchar(100)  NOT NULL,
    [Description] varchar(100)  NULL,
    [UseOnLinkDocumentsToPatient] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'FaxArchives'
CREATE TABLE [dbo].[FaxArchives] (
    [FaxArchiveID] int IDENTITY(1,1) NOT NULL,
    [PatientID] int  NULL,
    [PatientProtocolAssignmentID] int  NULL,
    [FaxRequest] nvarchar(max)  NULL,
    [FaxResult] nvarchar(max)  NULL,
    [FaxResponse] nvarchar(max)  NULL,
    [JobId] varchar(100)  NULL,
    [JobStatus] varchar(100)  NULL,
    [JobStatusCode] varchar(10)  NULL,
    [RequestSubmissionTime] datetime  NULL,
    [RequestCompletionTime] datetime  NULL,
    [FailureMessage] varchar(100)  NULL,
    [TryCount] int  NULL,
    [CreatedBy] int  NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [PageCount] int  NULL
);
GO

-- Creating table 'FaxArchiveDocuments'
CREATE TABLE [dbo].[FaxArchiveDocuments] (
    [FaxArchiveDocumentID] int IDENTITY(1,1) NOT NULL,
    [FaxArchiveID] int  NOT NULL,
    [DocumentID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'FaxCatalogs'
CREATE TABLE [dbo].[FaxCatalogs] (
    [FaxCatalogID] smallint IDENTITY(1,1) NOT NULL,
    [InsuranceProviderFaxTemplateID] smallint  NOT NULL,
    [TemplateName] varchar(250)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'FaxDetails'
CREATE TABLE [dbo].[FaxDetails] (
    [FaxDetailsID] int IDENTITY(1,1) NOT NULL,
    [DocumentRepositoryID] int  NOT NULL,
    [FaxAddressID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'FaxDocumentAssignments'
CREATE TABLE [dbo].[FaxDocumentAssignments] (
    [DocumentRepositoryID] int  NOT NULL,
    [AssignedTo] int  NULL,
    [Processed] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [SendToSmartUM] bit  NULL,
    [SendToSmartUMOn] datetime  NULL
);
GO

-- Creating table 'FaxParameters'
CREATE TABLE [dbo].[FaxParameters] (
    [FaxParameterID] smallint IDENTITY(1,1) NOT NULL,
    [FaxCatalogID] smallint  NOT NULL,
    [ParameterName] varchar(30)  NOT NULL,
    [ParameterText] nvarchar(max)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'FaxRecipients'
CREATE TABLE [dbo].[FaxRecipients] (
    [FaxRecipientID] smallint IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [LOBID] smallint  NULL,
    [StateCode] varchar(2)  NULL,
    [RiskMember] bit  NULL,
    [FaxTemplateType] smallint  NOT NULL,
    [SendBy] varchar(10)  NOT NULL,
    [FaxRecipientType] smallint  NOT NULL,
    [RecipientValue] varchar(50)  NULL
);
GO

-- Creating table 'FaxRecipientConfigurations'
CREATE TABLE [dbo].[FaxRecipientConfigurations] (
    [FaxRecipientConfigurationID] smallint IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [MajorLineofBusinessID] smallint  NULL,
    [ProductLineID] smallint  NULL,
    [FaxTemplateType] smallint  NOT NULL,
    [RiskMember] bit  NULL,
    [Expedite] bit  NULL,
    [FaxRecipientValue] nvarchar(200)  NULL,
    [EmailRecipientValue] nvarchar(500)  NULL,
    [Activ] bit  NOT NULL,
    [CreatedOn] datetime  NULL,
    [CreatedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [Deleted] bit  NULL,
    [DeletedOn] datetime  NULL,
    [DeletedBy] int  NULL
);
GO

-- Creating table 'FaxRecipientConfigurationFaxRecipientTypes'
CREATE TABLE [dbo].[FaxRecipientConfigurationFaxRecipientTypes] (
    [FaxRecipientConfigurationFaxRecipientTypeID] smallint IDENTITY(1,1) NOT NULL,
    [FaxRecipientConfigurationID] smallint  NOT NULL,
    [FaxRecipientType] smallint  NOT NULL,
    [CreatedOn] datetime  NULL,
    [CreatedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [Deleted] bit  NULL,
    [DeletedOn] datetime  NULL,
    [DeletedBy] int  NULL
);
GO

-- Creating table 'FaxRecipientConfigurationStates'
CREATE TABLE [dbo].[FaxRecipientConfigurationStates] (
    [FaxRecipientConfigurationStateID] smallint IDENTITY(1,1) NOT NULL,
    [FaxRecipientConfigurationID] smallint  NOT NULL,
    [StateCode] varchar(2)  NOT NULL,
    [Exclude] bit  NOT NULL,
    [CreatedOn] datetime  NULL,
    [CreatedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [Deleted] bit  NULL,
    [DeletedOn] datetime  NULL,
    [DeletedBy] int  NULL
);
GO

-- Creating table 'FebrileNeutropeniaClinicalValuesRules'
CREATE TABLE [dbo].[FebrileNeutropeniaClinicalValuesRules] (
    [FebrileNeutropeniaClinicalValuesRuleID] int IDENTITY(1,1) NOT NULL,
    [FebrileNeutropeniaID] smallint  NOT NULL,
    [ClinicalValuesRuleID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'FileExtensions'
CREATE TABLE [dbo].[FileExtensions] (
    [FileExtension1] varchar(10)  NOT NULL,
    [MIMEType] varchar(128)  NOT NULL,
    [Description] varchar(128)  NULL,
    [CompressionRequired] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'FormularyExceptions'
CREATE TABLE [dbo].[FormularyExceptions] (
    [FormularyExceptionID] int IDENTITY(1,1) NOT NULL,
    [ProtocolElementCodeID] int  NOT NULL,
    [ExceptionReasonID] smallint  NULL,
    [ExceptionResolutionID] smallint  NOT NULL,
    [Reasoning] varchar(3000)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'FormularyException_AlternativeCode'
CREATE TABLE [dbo].[FormularyException_AlternativeCode] (
    [FormularyException_AlternativeCodeID] int IDENTITY(1,1) NOT NULL,
    [FormularyExceptionID] int  NOT NULL,
    [Code] varchar(50)  NOT NULL,
    [CodeTypeID] smallint  NOT NULL,
    [Description] varchar(255)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'FormularyException_ExceptionType'
CREATE TABLE [dbo].[FormularyException_ExceptionType] (
    [FormularyException_ExceptionTypeID] int IDENTITY(1,1) NOT NULL,
    [FormularyExceptionID] int  NOT NULL,
    [ExceptionTypeID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'FtnConfigurations'
CREATE TABLE [dbo].[FtnConfigurations] (
    [FtnConfigurationID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [LineOfBusinessID] smallint  NOT NULL,
    [EnableFailureToNotify] bit  NOT NULL,
    [Message] nvarchar(1000)  NULL,
    [Deleted] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'GrandfatherRules'
CREATE TABLE [dbo].[GrandfatherRules] (
    [GrandfatherRuleID] int IDENTITY(1,1) NOT NULL,
    [RuleID] int  NOT NULL,
    [GrandfatherPeriodInDays] int  NULL,
    [ContinuationLimitInDays] int  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'GrandfatherRuleDrugs'
CREATE TABLE [dbo].[GrandfatherRuleDrugs] (
    [GrandfatherRuleDrugID] int IDENTITY(1,1) NOT NULL,
    [GrandfatherRuleID] int  NOT NULL,
    [DrugID] int  NOT NULL,
    [DoseAmount] decimal(14,4)  NULL,
    [FrequencyID] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'HelpfulLinks'
CREATE TABLE [dbo].[HelpfulLinks] (
    [HelpfulLinkID] int IDENTITY(1,1) NOT NULL,
    [LinkCaption] varchar(300)  NULL,
    [Url] varchar(500)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [Category] varchar(100)  NULL,
    [InsuranceProviderID] smallint  NULL,
    [VisibleToOA] bit  NULL
);
GO

-- Creating table 'ICDCodes'
CREATE TABLE [dbo].[ICDCodes] (
    [Code] varchar(13)  NOT NULL,
    [CodeVersion] tinyint  NOT NULL,
    [ShortDescription] varchar(128)  NULL,
    [FullDescription] varchar(255)  NULL,
    [Active] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'Images'
CREATE TABLE [dbo].[Images] (
    [ImageID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NULL,
    [Name] varchar(200)  NOT NULL,
    [Extension] varchar(5)  NOT NULL,
    [Content] varbinary(max)  NOT NULL,
    [Deleted] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'InScopeICDCodes'
CREATE TABLE [dbo].[InScopeICDCodes] (
    [InScopeICDCodeID] int IDENTITY(1,1) NOT NULL,
    [ICD10Code] varchar(13)  NOT NULL,
    [ICD9Code] varchar(13)  NOT NULL
);
GO

-- Creating table 'InScopeInsuranceGroups'
CREATE TABLE [dbo].[InScopeInsuranceGroups] (
    [InsuranceGroupID] varchar(50)  NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL
);
GO

-- Creating table 'InScopeJCodes'
CREATE TABLE [dbo].[InScopeJCodes] (
    [InScopeJCodeID] int IDENTITY(1,1) NOT NULL,
    [JCode] varchar(10)  NOT NULL
);
GO

-- Creating table 'InScopePCPCenters'
CREATE TABLE [dbo].[InScopePCPCenters] (
    [MCCIId] int IDENTITY(1,1) NOT NULL,
    [MCCICenterNumbers] nvarchar(50)  NULL,
    [GrouperNumber] nvarchar(50)  NULL,
    [MSO] nvarchar(50)  NULL,
    [Active] bit  NULL,
    [DeActivationDate] datetime  NULL
);
GO

-- Creating table 'InScopeStates'
CREATE TABLE [dbo].[InScopeStates] (
    [InScopeStateID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [ProductLineID] smallint  NOT NULL,
    [StateCode] varchar(2)  NOT NULL
);
GO

-- Creating table 'InScopeZipCodes'
CREATE TABLE [dbo].[InScopeZipCodes] (
    [InScopeZipCodeID] int IDENTITY(1,1) NOT NULL,
    [ZipCode] varchar(20)  NOT NULL
);
GO

-- Creating table 'InsuranceProviders'
CREATE TABLE [dbo].[InsuranceProviders] (
    [InsuranceProviderID] smallint IDENTITY(1,1) NOT NULL,
    [Name] varchar(128)  NOT NULL,
    [Description] varchar(255)  NULL,
    [StateID] smallint  NULL,
    [RequiredEligibilityVerification] bit  NULL,
    [MemberIDLength] tinyint  NOT NULL,
    [EligibilityPrimarySourceID] smallint  NULL,
    [EligibilitySecondarySourceID] smallint  NULL,
    [GenerateEODFile] bit  NULL,
    [Active] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [DisplayName] varchar(128)  NULL,
    [WhiteListDomains] varchar(256)  NULL,
    [AllowPartialApprovalFax] bit  NULL,
    [RequiredPayerReceiptDate] bit  NULL,
    [RequiredDisAuth] bit  NULL
);
GO

-- Creating table 'InsuranceProvider_Address'
CREATE TABLE [dbo].[InsuranceProvider_Address] (
    [InsuranceProviderAddressID] smallint IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [AddressID] smallint  NOT NULL,
    [OfficeName] varchar(50)  NOT NULL,
    [TimeZoneID] varchar(50)  NOT NULL,
    [Active] bit  NOT NULL,
    [Default] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [UseOnFax] bit  NULL
);
GO

-- Creating table 'InsuranceProvider_LookupElement'
CREATE TABLE [dbo].[InsuranceProvider_LookupElement] (
    [InsuranceProviderLookupElementID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [LookupElementID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'InsuranceProviderAttributeKeys'
CREATE TABLE [dbo].[InsuranceProviderAttributeKeys] (
    [InsuranceProviderAttributeKeyID] smallint IDENTITY(1,1) NOT NULL,
    [AttributeKey] nvarchar(80)  NOT NULL,
    [AttributeCaption] nvarchar(100)  NOT NULL,
    [ControlType] nvarchar(10)  NOT NULL,
    [Require] bit  NOT NULL,
    [MaxLength] int  NOT NULL,
    [Active] bit  NOT NULL,
    [SortOrder] smallint  NULL,
    [CreatedOn] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [ModifiedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [Deleted] bit  NULL,
    [DeletedOn] datetime  NULL,
    [DeletedBy] int  NULL
);
GO

-- Creating table 'InsuranceProviderAttributeValues'
CREATE TABLE [dbo].[InsuranceProviderAttributeValues] (
    [InsuranceProviderAttributeValueID] smallint IDENTITY(1,1) NOT NULL,
    [InsuranceProviderAttributeKeyID] smallint  NOT NULL,
    [InsurancProviderID] smallint  NOT NULL,
    [AttributeValue] nvarchar(256)  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [ModifiedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [Deleted] bit  NULL,
    [DeletedOn] datetime  NULL,
    [DeletedBy] int  NULL
);
GO

-- Creating table 'InsuranceProviderConfigurations'
CREATE TABLE [dbo].[InsuranceProviderConfigurations] (
    [InsuranceProviderConfigurationID] smallint IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [FieldName] varchar(64)  NOT NULL,
    [Visible] bit  NOT NULL,
    [Required] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'InsuranceProviderContactDetails'
CREATE TABLE [dbo].[InsuranceProviderContactDetails] (
    [InsuranceProviderContactDetailID] smallint IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [AddressLine1] varchar(64)  NOT NULL,
    [AddressLine2] varchar(64)  NOT NULL,
    [Phone] varchar(64)  NOT NULL,
    [Fax] varchar(64)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'InsuranceProviderDaylightSavingSettings'
CREATE TABLE [dbo].[InsuranceProviderDaylightSavingSettings] (
    [InsuranceProviderDayLightSavingSettingID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [TimeZone] varchar(100)  NOT NULL,
    [TimeVarianceDuringDST] int  NOT NULL,
    [TimeVarianceAfterDST] int  NOT NULL
);
GO

-- Creating table 'InsuranceProviderDrugs'
CREATE TABLE [dbo].[InsuranceProviderDrugs] (
    [InsuranceProviderDrugID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [DrugID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'InsuranceProviderDrugConfigurations'
CREATE TABLE [dbo].[InsuranceProviderDrugConfigurations] (
    [InsuranceProviderDrugConfigurationID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [DrugID] int  NOT NULL,
    [DiagnosisID] int  NULL,
    [InternalMessage] varchar(5000)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'InsuranceProviderDrugConfiguration_LOB'
CREATE TABLE [dbo].[InsuranceProviderDrugConfiguration_LOB] (
    [InsuranceProviderDrugConfigurationLOBID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderDrugConfigurationID] int  NOT NULL,
    [LineOfBusinessID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'InsuranceProviderDrugConfiguration_Stage'
CREATE TABLE [dbo].[InsuranceProviderDrugConfiguration_Stage] (
    [InsuranceProviderDrugConfigurationStageID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderDrugConfigurationID] int  NOT NULL,
    [StageID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'InsuranceProviderEODFileRecipients'
CREATE TABLE [dbo].[InsuranceProviderEODFileRecipients] (
    [InsuranceProviderEODFileRecipientID] smallint IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [EmailAddress] varchar(512)  NOT NULL,
    [FileSharedLocation] varchar(256)  NULL
);
GO

-- Creating table 'InsuranceProviderEODStatusOverrides'
CREATE TABLE [dbo].[InsuranceProviderEODStatusOverrides] (
    [InsuranceProviderEODStatusOverrideID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [ProtocolStatusID] smallint  NULL,
    [IncludeInEOD] bit  NOT NULL,
    [TextOverride] varchar(255)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [StatusReasonOverride] varchar(50)  NULL,
    [LineOfBusinessID] smallint  NULL,
    [StatusOverrideTypeID] smallint  NULL,
    [StatusAlias1] varchar(255)  NULL,
    [StatusAlias2] varchar(255)  NULL
);
GO

-- Creating table 'InsuranceProviderFaxTemplates'
CREATE TABLE [dbo].[InsuranceProviderFaxTemplates] (
    [InsuranceProviderFaxTemplateID] smallint IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [LOBID] smallint  NULL,
    [StateCode] varchar(2)  NULL,
    [RiskMember] bit  NULL,
    [FaxTemplateType] smallint  NOT NULL,
    [TemplateDocument] varbinary(max)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [Active] bit  NOT NULL,
    [BenefitTypeID] smallint  NULL
);
GO

-- Creating table 'InsuranceProviderFaxTemplate_ProductLine'
CREATE TABLE [dbo].[InsuranceProviderFaxTemplate_ProductLine] (
    [InsuranceProviderFaxTemplate_ProductLineID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderFaxTemplateID] smallint  NOT NULL,
    [ProductLineID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'InsuranceProviderFaxTemplate_Rule'
CREATE TABLE [dbo].[InsuranceProviderFaxTemplate_Rule] (
    [InsuranceProviderFaxTemplateRuleID] int IDENTITY(1,1) NOT NULL,
    [DimPayerID] int  NOT NULL,
    [FaxTemplateID] smallint  NOT NULL,
    [FaxTemplateType] nvarchar(100)  NOT NULL,
    [EntityName] nvarchar(100)  NOT NULL,
    [PropertyName] nvarchar(100)  NOT NULL,
    [Comparison] nvarchar(2)  NOT NULL,
    [Value] nvarchar(100)  NULL,
    [PredicateType] nvarchar(3)  NULL,
    [LogicalOperator] nvarchar(3)  NULL,
    [BenefitTypeID] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [Filter] nvarchar(256)  NULL
);
GO

-- Creating table 'InsuranceProviderGlobalFaxParameters'
CREATE TABLE [dbo].[InsuranceProviderGlobalFaxParameters] (
    [InsuranceProviderGlobalFaxParameterID] smallint IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [GlobalFaxParameterID] smallint  NOT NULL,
    [ParameterText] nvarchar(max)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'InsuranceProviderHomePages'
CREATE TABLE [dbo].[InsuranceProviderHomePages] (
    [InsuranceProviderHomePageID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NULL,
    [VisibleToOA] bit  NULL,
    [Content] varchar(5000)  NULL,
    [SortOrder] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'InsuranceProviderSpecialtyCodes'
CREATE TABLE [dbo].[InsuranceProviderSpecialtyCodes] (
    [InsuranceProviderSpecialtyCodeId] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [SpecialtyCode] varchar(10)  NOT NULL,
    [SpecialtyDesc] varchar(100)  NULL,
    [AutoCreateUser] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'InsuranceProviderTreatmentTypes'
CREATE TABLE [dbo].[InsuranceProviderTreatmentTypes] (
    [InsuranceProviderTreatmentTypeID] smallint IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [TreatmentTypeID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'LabResults'
CREATE TABLE [dbo].[LabResults] (
    [LabResultID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [TestName] varchar(300)  NOT NULL,
    [TestDate] datetime  NOT NULL,
    [Result] varchar(512)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'LineofBusinesses'
CREATE TABLE [dbo].[LineofBusinesses] (
    [LineOfBusinessID] smallint IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [LOBName] varchar(100)  NOT NULL,
    [Active] bit  NOT NULL,
    [IncludeInEODFile] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [MajorLineOfBusinessID] smallint  NULL,
    [MedicalBenefitDrugsSettingID] smallint  NULL,
    [PharmacyBenefitDrugsSettingID] smallint  NULL,
    [RetrospectiveMessage] varchar(255)  NULL,
    [PriorAuthIsNotRequiredMessage] varchar(300)  NULL,
    [IsPediatricProgramEnabled] bit  NOT NULL,
    [AllowCaseCreationWithAllPaExemptDrugs] bit  NOT NULL,
    [AgeOfMajority] smallint  NULL,
    [EnableMemberReceivingActiveCare] bit  NOT NULL,
    [EnableTreatingProviderReasonableDistance] bit  NOT NULL,
    [EnablePatientHaveReferralForTreatingProvider] bit  NOT NULL,
    [IncludeMemberCopyInProviderFax] bit  NOT NULL,
    [SendPreferredLanguageNotificationToMember] bit  NOT NULL,
    [ProcedureUnitsReplacementApproachID] smallint  NULL,
    [ProcedureUnitsReplacementText] nvarchar(256)  NULL,
    [NewReconsiderationWorkflow] bit  NOT NULL,
    [DoNotRequireCagFieldsForCompletingCaseWithPharmacyDrugs] bit  NOT NULL,
    [IsPharmacyOutOfScope] bit  NOT NULL,
    [RequireGapReviewBeforeCaseCanBeClosed] bit  NOT NULL
);
GO

-- Creating table 'Lookups'
CREATE TABLE [dbo].[Lookups] (
    [LookupName] varchar(128)  NOT NULL,
    [Description] varchar(255)  NULL,
    [LegacyID] tinyint  NULL,
    [RegExpression] varchar(255)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [SortBy] varchar(20)  NULL,
    [ParentLookupName] varchar(128)  NULL
);
GO

-- Creating table 'LookupElements'
CREATE TABLE [dbo].[LookupElements] (
    [LookupElementID] smallint IDENTITY(1,1) NOT NULL,
    [LookupName] varchar(128)  NOT NULL,
    [Text] varchar(255)  NOT NULL,
    [Code] varchar(10)  NOT NULL,
    [SortOrder] smallint  NULL,
    [Active] bit  NOT NULL,
    [UsedInBusinessProcess] bit  NULL,
    [HideFromExternalOffice] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [Description] nvarchar(500)  NULL,
    [ParentLookupElementID] smallint  NULL
);
GO

-- Creating table 'LookupElement_SecurityGroup'
CREATE TABLE [dbo].[LookupElement_SecurityGroup] (
    [LookupElementSecurityGroupID] int IDENTITY(1,1) NOT NULL,
    [SecurityGroupID] smallint  NOT NULL,
    [LookupElementID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'LookupElementMappings'
CREATE TABLE [dbo].[LookupElementMappings] (
    [LookupElementMappingID] int IDENTITY(1,1) NOT NULL,
    [ParentLookupElementID] smallint  NOT NULL,
    [ChildLookupElementID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'MailArchives'
CREATE TABLE [dbo].[MailArchives] (
    [MailArchiveID] int IDENTITY(1,1) NOT NULL,
    [PatientID] int  NOT NULL,
    [PatientProtocolAssignmentID] int  NULL,
    [AddressLine1] nvarchar(100)  NOT NULL,
    [AddressLine2] nvarchar(100)  NULL,
    [City] nvarchar(32)  NOT NULL,
    [StateCode] varchar(2)  NOT NULL,
    [Zip] varchar(10)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'MailArchiveDocuments'
CREATE TABLE [dbo].[MailArchiveDocuments] (
    [MailArchiveDocumentID] int IDENTITY(1,1) NOT NULL,
    [MailArchiveID] int  NOT NULL,
    [DocumentRepositoryID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'MailArchiveLogs'
CREATE TABLE [dbo].[MailArchiveLogs] (
    [MailArchiveLogID] int IDENTITY(1,1) NOT NULL,
    [MailArchiveID] int  NOT NULL,
    [MailStatusID] smallint  NOT NULL,
    [StatusReason] nvarchar(200)  NULL,
    [MailStatusOn] datetime  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'MailArchiveTrackings'
CREATE TABLE [dbo].[MailArchiveTrackings] (
    [MailArchiveTrackingID] int IDENTITY(1,1) NOT NULL,
    [MailArchiveDocumentID] int  NOT NULL,
    [DateLabelCreated] datetime  NOT NULL,
    [TrackingNumber] varchar(35)  NULL,
    [MailingOptionID] smallint  NULL,
    [MailingPriorityID] smallint  NULL,
    [NoteID] int  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'MailingCutoffCalculationLogs'
CREATE TABLE [dbo].[MailingCutoffCalculationLogs] (
    [MailingCutoffCalculationLogID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentTimeCountdownID] int  NOT NULL,
    [RequestDate] datetime  NOT NULL,
    [BasicDueDate] datetime  NOT NULL,
    [DeductedDueDate] datetime  NULL,
    [CutoffDueDate] datetime  NULL,
    [FinalDueDate] datetime  NOT NULL
);
GO

-- Creating table 'MailingCutoffConfigurations'
CREATE TABLE [dbo].[MailingCutoffConfigurations] (
    [MailingCutoffConfigurationID] smallint IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [LineOfBusinessID] smallint  NULL,
    [DayOfWeek] tinyint  NOT NULL,
    [Time] time  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'MemberContactLogs'
CREATE TABLE [dbo].[MemberContactLogs] (
    [MemberContactLogID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [PatientID] int  NOT NULL,
    [RequesterID] int  NOT NULL,
    [StatusID] smallint  NOT NULL,
    [Attempt] smallint  NOT NULL,
    [ActionTime] datetime  NOT NULL,
    [Note] varchar(100)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'MenuOptions'
CREATE TABLE [dbo].[MenuOptions] (
    [MenuOptionID] smallint IDENTITY(1,1) NOT NULL,
    [Code] varchar(50)  NOT NULL,
    [Title] varchar(50)  NOT NULL,
    [Tooltip] varchar(100)  NULL,
    [URL] varchar(500)  NULL,
    [ParentMenuOptionsID] smallint  NULL,
    [MenuLocation] varchar(50)  NULL,
    [MenuCss] varchar(50)  NULL,
    [DefaultSelected] bit  NULL,
    [SortOrder] smallint  NULL,
    [Active] bit  NOT NULL,
    [CanHaveRights] bit  NOT NULL,
    [VisibleToEveryone] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'MetastaticSites'
CREATE TABLE [dbo].[MetastaticSites] (
    [MetastaticSiteID] int IDENTITY(1,1) NOT NULL,
    [FaxParamMetastaticSiteID] smallint  NOT NULL,
    [Description] nvarchar(max)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'MimicEligibilityServiceResponses'
CREATE TABLE [dbo].[MimicEligibilityServiceResponses] (
    [MimicEligibilityServiceResponseID] int IDENTITY(1,1) NOT NULL,
    [MemberID] varchar(255)  NULL,
    [FirstName] varchar(255)  NULL,
    [LastName] varchar(255)  NULL,
    [BirthDate] varchar(255)  NULL,
    [Gender] varchar(255)  NULL,
    [GroupID] varchar(255)  NULL,
    [MajorLineOfBusiness] varchar(255)  NULL,
    [CoverageEffectiveDate] varchar(255)  NULL,
    [CoverageEndDate] varchar(255)  NULL
);
GO

-- Creating table 'MultilingualDatas'
CREATE TABLE [dbo].[MultilingualDatas] (
    [MultilingualDataID] int IDENTITY(1,1) NOT NULL,
    [MultilingualObjectFieldID] smallint  NOT NULL,
    [ReferenceObjectID] int  NOT NULL,
    [LanguageCode] varchar(5)  NOT NULL,
    [MultilingualText] nvarchar(max)  NOT NULL,
    [ReviewedBy] int  NULL,
    [ReviewedOn] datetime  NULL,
    [Active] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'MultilingualObjects'
CREATE TABLE [dbo].[MultilingualObjects] (
    [MultilingualObjectID] smallint IDENTITY(1,1) NOT NULL,
    [ObjectName] varchar(50)  NOT NULL,
    [Active] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'MultilingualObjectFields'
CREATE TABLE [dbo].[MultilingualObjectFields] (
    [MultilingualObjectFieldID] smallint IDENTITY(1,1) NOT NULL,
    [MultilingualObjectID] smallint  NOT NULL,
    [FieldName] varchar(50)  NOT NULL,
    [Active] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'NCCNRecurrenceRiskFormulas'
CREATE TABLE [dbo].[NCCNRecurrenceRiskFormulas] (
    [NCCNRecurrenceRiskFormulaID] int IDENTITY(1,1) NOT NULL,
    [NCCNRecurrenceRiskGroupID] int  NOT NULL,
    [AssessmentQuestionID] int  NULL,
    [AnswerValueID] int  NOT NULL,
    [ComparingOperator] nvarchar(2)  NOT NULL
);
GO

-- Creating table 'NCCNRecurrenceRiskGroups'
CREATE TABLE [dbo].[NCCNRecurrenceRiskGroups] (
    [NCCNRecurrenceRiskGroupID] int IDENTITY(1,1) NOT NULL,
    [Description] nvarchar(150)  NOT NULL,
    [Active] bit  NOT NULL,
    [RecurrenceRiskGroupCode] nvarchar(4)  NOT NULL
);
GO

-- Creating table 'NeutropeniaOverTurnDrugs'
CREATE TABLE [dbo].[NeutropeniaOverTurnDrugs] (
    [DrugID] int  NOT NULL,
    [StartDate] datetime  NULL,
    [EndDate] datetime  NULL
);
GO

-- Creating table 'Notes'
CREATE TABLE [dbo].[Notes] (
    [NoteID] int IDENTITY(1,1) NOT NULL,
    [PatientID] int  NOT NULL,
    [PatientProtocolAssignmentID] int  NULL,
    [NoteTypeID] smallint  NOT NULL,
    [UserID] int  NOT NULL,
    [NoteText] varchar(3000)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [AdditionalNoteText] varchar(max)  NULL,
    [HasAdditionalNote] bit  NULL,
    [IsApprovalNote] bit  NULL,
    [PatientProtocolAssignmentPostDenialID] int  NULL,
    [AssignmentActionID] int  NULL
);
GO

-- Creating table 'NotificationEnclosures'
CREATE TABLE [dbo].[NotificationEnclosures] (
    [NotificationEnclosureID] int IDENTITY(1,1) NOT NULL,
    [NotificationEnclosureText] varchar(100)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'NotificationEnclosureImages'
CREATE TABLE [dbo].[NotificationEnclosureImages] (
    [NotificationEnclosureImageID] int IDENTITY(1,1) NOT NULL,
    [NotificationEnclosureID] int  NOT NULL,
    [ImageID] int  NOT NULL,
    [ImageOrder] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'Patients'
CREATE TABLE [dbo].[Patients] (
    [PatientID] int IDENTITY(1,1) NOT NULL,
    [FirstName] nvarchar(50)  NOT NULL,
    [LastName] nvarchar(50)  NOT NULL,
    [DOB] datetime  NOT NULL,
    [Gender] smallint  NOT NULL,
    [Height] float  NULL,
    [Weight] int  NULL,
    [PatientSourceID] smallint  NULL,
    [CurrentMDID] int  NOT NULL,
    [LegacyPatientID] int  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PatientAssessments'
CREATE TABLE [dbo].[PatientAssessments] (
    [PatientAssessmentID] int IDENTITY(1,1) NOT NULL,
    [AssessmentTypeID] int  NULL,
    [PatientID] int  NULL,
    [MemberID] varchar(15)  NULL,
    [PatientProtocolAssignmentID] int  NULL,
    [CurrentMD] int  NULL,
    [CreatedBy] int  NULL,
    [CreatedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [DocumentrepositoryID] int  NULL,
    [DiagnosisID] int  NULL,
    [StageID] smallint  NULL
);
GO

-- Creating table 'PatientAssessmentAnswers'
CREATE TABLE [dbo].[PatientAssessmentAnswers] (
    [PatientAssessmentAnswerID] int IDENTITY(1,1) NOT NULL,
    [PatientAssessmentID] int  NULL,
    [AssessmentQuestionID] int  NULL,
    [AssessmentQuestionText] nvarchar(500)  NULL,
    [AssessmentQuestionPossibleAnswerID] int  NULL,
    [AnswerValue] nvarchar(500)  NULL,
    [AnswerText] varchar(255)  NULL,
    [AnswerDateTime] datetime  NULL,
    [CreatedBy] int  NULL,
    [CreatedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PatientClinicalDecisionSupports'
CREATE TABLE [dbo].[PatientClinicalDecisionSupports] (
    [PatientClinicalDecisionSupportID] int IDENTITY(1,1) NOT NULL,
    [PatientID] int  NULL,
    [PatientProtocolAssignmentID] int  NULL,
    [Processed] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [FirstName] nvarchar(50)  NULL,
    [LastName] nvarchar(50)  NULL,
    [DOB] datetime  NULL
);
GO

-- Creating table 'PatientClinicalDecisionSupport_Protocol'
CREATE TABLE [dbo].[PatientClinicalDecisionSupport_Protocol] (
    [PatientClinicalDecisionSupportProtocolID] int IDENTITY(1,1) NOT NULL,
    [PatientClinicalDecisionSupportID] int  NOT NULL,
    [ProtocolID] int  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PatientDiagnosis'
CREATE TABLE [dbo].[PatientDiagnosis] (
    [PatientDiagnosisID] int IDENTITY(1,1) NOT NULL,
    [PatientID] int  NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [StageID] smallint  NULL,
    [PerformanceStatusID] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [TumorSizeID] smallint  NULL,
    [NodalStatusID] smallint  NULL,
    [DistantMetaStasisID] smallint  NULL
);
GO

-- Creating table 'PatientICDCodes'
CREATE TABLE [dbo].[PatientICDCodes] (
    [PatientICDCodeID] int IDENTITY(1,1) NOT NULL,
    [PatientID] int  NOT NULL,
    [PatientDiagnosisID] int  NOT NULL,
    [Code] varchar(13)  NOT NULL,
    [CodeVersion] tinyint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PatientProtocolAssignments'
CREATE TABLE [dbo].[PatientProtocolAssignments] (
    [PatientProtocolAssignmentID] int IDENTITY(1,1) NOT NULL,
    [PatientID] int  NOT NULL,
    [EligibilityID] int  NOT NULL,
    [EligibilityVerificationDate] datetime  NULL,
    [OAReferenceNumber] varchar(50)  NOT NULL,
    [PayerAuthorizationNumber] varchar(50)  NULL,
    [ProtocolAssignmentTypeID] smallint  NOT NULL,
    [ProcessedWithinTime] bit  NOT NULL,
    [UrgentExpedited] bit  NULL,
    [StandardTimeFrameRisk] bit  NULL,
    [RecvPrescForAntiCancerMedi] bit  NOT NULL,
    [WrittenPrescription] bit  NOT NULL,
    [ClinicalTrial] bit  NULL,
    [FacilityID] int  NULL,
    [CareSite] nvarchar(128)  NULL,
    [ProtocolAssignmentSourceID] smallint  NULL,
    [ProtocolAssignmentOriginID] smallint  NULL,
    [MedicationsOrderingMethodID] smallint  NOT NULL,
    [SpecialtyPharmacyID] smallint  NULL,
    [ReportingNPI] varchar(15)  NULL,
    [ReportingTaxID] varchar(15)  NULL,
    [BoundaryCaseTypeID] smallint  NOT NULL,
    [RequestInitiationDate] datetime  NULL,
    [ScheduledTreatmentStartDate] datetime  NOT NULL,
    [AnticipatedTreatmentEndDate] datetime  NOT NULL,
    [DecisionDateTime] datetime  NULL,
    [NotificationDateTime] datetime  NULL,
    [PayerReceiptDate] datetime  NULL,
    [Completed] bit  NULL,
    [AssignmentStatusID] smallint  NULL,
    [AssignmentProcessedAsID] smallint  NULL,
    [CRSID] int  NULL,
    [CurrentMDID] int  NOT NULL,
    [LegacyStatusID] smallint  NULL,
    [LegacyID] int  NULL,
    [TurnaroundTime] datetime  NULL,
    [Version] tinyint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [DirectFaxNumber] varchar(15)  NULL,
    [LineOfTherapyID] smallint  NULL,
    [AssignmentPriority] varchar(15)  NULL,
    [RequesterName] varchar(50)  NULL,
    [RequesterPhoneNumber] varchar(15)  NULL,
    [OncologistOrganization] smallint  NULL,
    [SalesforceAccountID] varchar(100)  NULL,
    [Locked] int  NULL,
    [LockedBy] int  NULL,
    [IsTherapyTreatment] bit  NOT NULL,
    [PartD] bit  NULL,
    [TreatmentTypeID] smallint  NULL,
    [PlaceOfTreatmentOtherthanProvider] bit  NULL,
    [InsuranceProviderAddressID] smallint  NULL,
    [ActualPayerReceiptDate] datetime  NULL,
    [NCTNumber] varchar(15)  NULL,
    [IsPatientInOffice] bit  NULL,
    [IsInNetwork] bit  NULL,
    [EnterpriseNetworkCode] varchar(8)  NULL,
    [PatientNotificationDateTime] datetime  NULL,
    [PatientRepresentativeNotificationDateTime] datetime  NULL,
    [PreferToFaxRecords] bit  NOT NULL,
    [IsPediatric] bit  NOT NULL,
    [IsCurrentlyBeingTreated] bit  NULL,
    [ReviewStageID] smallint  NULL,
    [LastModifiedByOperationID] uniqueidentifier  NULL,
    [IsPayerOwnedProvider] bit  NULL
);
GO

-- Creating table 'PatientProtocolAssignment_Labresult'
CREATE TABLE [dbo].[PatientProtocolAssignment_Labresult] (
    [PatientProtocolAssignmentLabResultID] int IDENTITY(1,1) NOT NULL,
    [PatientID] int  NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [ResultDate] datetime  NULL,
    [HgbID] int  NULL,
    [HctID] int  NULL,
    [TIBCID] int  NULL,
    [PercentSatID] int  NULL,
    [FerritinID] int  NULL,
    [AnemiaSymptomID] int  NULL,
    [WBCID] int  NULL,
    [PercentageNeutrophilsID] int  NULL,
    [ANCID] int  NULL,
    [IsActive] bit  NULL,
    [CreatedBy] int  NULL,
    [CreatedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL
);
GO

-- Creating table 'PatientProtocolAssignment_Protocol'
CREATE TABLE [dbo].[PatientProtocolAssignment_Protocol] (
    [PatientProtocolAssignmentProtocolID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [ProtocolID] int  NOT NULL,
    [ProtocolTypeID] smallint  NOT NULL,
    [InternalReviewContactID] smallint  NULL,
    [ExternalReviewContactID] smallint  NULL,
    [Reviewer1] int  NULL,
    [Reviewer2] int  NULL,
    [TreatmentStartDate] datetime  NOT NULL,
    [TreatmentEndDate] datetime  NOT NULL,
    [ProtocolStatusID] smallint  NULL,
    [AutoProcessedID] smallint  NULL,
    [CreatedBy] int  NULL,
    [CreatedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [ChangeReasonID] smallint  NULL,
    [RadiotherapyTechniqueID] smallint  NULL,
    [NumberOfFraction] varchar(50)  NULL,
    [TotalDoseInGY] varchar(50)  NULL,
    [TranslatorID] int  NULL,
    [InitialPharmDReviewerID] int  NULL,
    [IsBoost] bit  NULL,
    [TreatmentIntentID] smallint  NULL,
    [LineOfTherapyID] smallint  NULL,
    [FromProtocolID] int  NULL,
    [IsDSNPMedicareApproved] bit  NULL,
    [IsDSNPMedicaidApproved] bit  NULL,
    [WithdrawalReasonID] smallint  NULL,
    [ProtocolStatusReasonID] smallint  NULL
);
GO

-- Creating table 'PatientProtocolAssignment_Protocol_ProtocolElementCode'
CREATE TABLE [dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode] (
    [PatientProtocolAssignment_Protocol_ProtocolElementCodeID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentProtocolID] int  NOT NULL,
    [ProtocolElementID] int  NOT NULL,
    [DrugID] int  NOT NULL,
    [DrugCodeID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PatientProtocolAssignment_ProtocolCPTCodeXRT'
CREATE TABLE [dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT] (
    [PatientProtocolAssignmentProtocolCPTCodeXRTID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentProtocolID] int  NOT NULL,
    [CPTCodeXRTID] int  NOT NULL,
    [QuantityRequested] smallint  NULL,
    [TypeId] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [QuantityApproved] smallint  NULL,
    [QuantityModifyReasonID] smallint  NULL
);
GO

-- Creating table 'PatientProtocolAssignment_ProtocolDiagnosis'
CREATE TABLE [dbo].[PatientProtocolAssignment_ProtocolDiagnosis] (
    [PatientProtocolAssignmentProtocolDiagnosisID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentProtocolID] int  NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [StageID] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [PerformanceStatusID] smallint  NULL
);
GO

-- Creating table 'PatientProtocolAssignment_ProtocolDosing'
CREATE TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing] (
    [PatientProtocolAssignment_ProtocolDosingID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentProtocolID] int  NOT NULL,
    [DrugID] int  NOT NULL,
    [HCPCSCode] char(5)  NULL,
    [DoseAmount] decimal(14,4)  NOT NULL,
    [DoseUnitID] smallint  NOT NULL,
    [Schedule] varchar(255)  NOT NULL,
    [FrequencyID] smallint  NOT NULL,
    [Cycles] real  NULL,
    [OverrideDynamicCycles] bit  NOT NULL,
    [AdministrationMethodID] smallint  NOT NULL,
    [BSA] decimal(4,2)  NOT NULL,
    [PatientSpecificDoseAmount] decimal(14,4)  NOT NULL,
    [PatientSpecificDoseUnitID] smallint  NOT NULL,
    [BillingUnitQuantity] real  NOT NULL,
    [BillingUnitQuantityUnitID] smallint  NOT NULL,
    [TotalBUsPerAuth] real  NOT NULL,
    [TotalBUsPerCycle] real  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PatientProtocolAssignment_ProtocolHCPCSCodeGMT'
CREATE TABLE [dbo].[PatientProtocolAssignment_ProtocolHCPCSCodeGMT] (
    [PatientProtocolAssignment_ProtocolHCPCSCodeGMTID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentProtocolID] int  NOT NULL,
    [HCPCSCode] varchar(10)  NOT NULL,
    [HCPCSCodeDescription] varchar(255)  NOT NULL,
    [Quantity] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PatientProtocolAssignment_ProtocolICDCode'
CREATE TABLE [dbo].[PatientProtocolAssignment_ProtocolICDCode] (
    [PatientProtocolAssignmentProtocolICDCodeID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentProtocolID] int  NOT NULL,
    [Code] varchar(13)  NOT NULL,
    [CodeVersion] tinyint  NOT NULL,
    [CreatedBy] int  NULL,
    [CreatedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PatientProtocolAssignment_ProtocolQuestionAnswer'
CREATE TABLE [dbo].[PatientProtocolAssignment_ProtocolQuestionAnswer] (
    [PatientProtocolAssignmentProtocolQuestionAnswerID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentProtocolID] int  NOT NULL,
    [QuestionID] int  NOT NULL,
    [Answer] smallint  NOT NULL,
    [OtherAnswer] varchar(255)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PatientProtocolAssignment_QuestionAnswerXRT'
CREATE TABLE [dbo].[PatientProtocolAssignment_QuestionAnswerXRT] (
    [PatientProtocolAssignmentQuestionAnswerXRTID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [ExplicitQuestionXRTID] int  NOT NULL,
    [ExplicitAnswerXRTID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL
);
GO

-- Creating table 'PatientProtocolAssignment_Timer'
CREATE TABLE [dbo].[PatientProtocolAssignment_Timer] (
    [PatientProtocolAssignmentTimerID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [PayerTimerConfigurationID] int  NOT NULL,
    [TimerTypeID] smallint  NOT NULL,
    [DurationUnitID] smallint  NULL,
    [Duration] int  NULL,
    [InitiatingEventID] int  NULL,
    [ReevaluatingEventID] int  NULL,
    [CompletingEventID] int  NULL,
    [CancelingEventID] int  NULL,
    [StartDate] datetime  NOT NULL,
    [DeadlineDate] datetime  NOT NULL,
    [CompletionDate] datetime  NULL,
    [EffectiveStart] datetime  NOT NULL,
    [EffectiveEnd] datetime  NOT NULL,
    [StatusID] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PatientProtocolAssignmentEffectuationDates'
CREATE TABLE [dbo].[PatientProtocolAssignmentEffectuationDates] (
    [PatientProtocolAssignmentEffectuationDateID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentId] int  NOT NULL,
    [EffectuationReference] varchar(50)  NOT NULL,
    [EffectuationOn] varchar(30)  NOT NULL,
    [AuthFileName] varchar(400)  NULL,
    [ResponseFileName] varchar(400)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PatientProtocolAssignmentHistories'
CREATE TABLE [dbo].[PatientProtocolAssignmentHistories] (
    [PatientProtocolAssignmentHistoryID] bigint IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentProtocolID] int  NULL,
    [ProtocolStatusID] smallint  NULL,
    [ChangedOn] datetime  NULL,
    [ChangedBy] int  NULL,
    [CreatedBy] int  NULL,
    [CreatedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PatientProtocolAssignmentInfoes'
CREATE TABLE [dbo].[PatientProtocolAssignmentInfoes] (
    [PatientProtocolAssignmentID] int  NOT NULL,
    [SendMemberLetter] bit  NOT NULL,
    [AuthDuration] smallint  NULL,
    [ParentAuthDuration] smallint  NULL,
    [AuthDurationOnSubmit] smallint  NULL,
    [DecisionDelegationLevel] smallint  NULL,
    [DismissalReasonID] smallint  NULL,
    [DismissalRequestDate] datetime  NULL,
    [DismissalDecisionDate] datetime  NULL,
    [DismissalReviewerID] int  NULL,
    [WithdrawnProviderNotificationDate] datetime  NULL,
    [WithdrawnPatientNotificationDate] datetime  NULL,
    [EmptyClinicalTrial] bit  NOT NULL,
    [ReconsiderationCase] bit  NOT NULL,
    [ReconsiderationCaseOriginalRef] varchar(50)  NULL,
    [AssignmentIsInpatientCarT] bit  NOT NULL,
    [PlaceOfService] smallint  NULL,
    [AlternativeInNetworkProvidersFound] bit  NULL
);
GO

-- Creating table 'PatientProtocolAssignmentPostDenials'
CREATE TABLE [dbo].[PatientProtocolAssignmentPostDenials] (
    [PatientProtocolAssignmentPostDenialID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [PostDenialReferenceNumber] varchar(50)  NOT NULL,
    [PostDenialInitiationDate] datetime  NOT NULL,
    [PostDenialReceiptDate] datetime  NOT NULL,
    [PostDenialPriorityID] smallint  NOT NULL,
    [PostDenialReasonID] smallint  NOT NULL,
    [OtherPostDenialReason] varchar(1000)  NULL,
    [PostDenialDecisionDate] datetime  NULL,
    [PostDenialNotificationDate] datetime  NULL,
    [Completed] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [InsuranceProviderAddressID] smallint  NULL,
    [ActualPostDenialReceiptDate] datetime  NULL,
    [CompletedOn] datetime  NULL,
    [EffectuationDateTime] datetime  NULL,
    [PostDenialRequestTypeId] smallint  NULL,
    [PatientNotificationDateTime] datetime  NULL,
    [PatientRepresentativeNotificationDateTime] datetime  NULL
);
GO

-- Creating table 'PatientProtocolAssignmentPostDenialInfoes'
CREATE TABLE [dbo].[PatientProtocolAssignmentPostDenialInfoes] (
    [PatientProtocolAssignmentPostDenialID] int  NOT NULL,
    [HealthPlanLocationId] smallint  NOT NULL,
    [RequestInitiatorId] smallint  NOT NULL,
    [RequestSourceId] smallint  NOT NULL,
    [UpdatedTreatmentStartDate] datetime  NULL,
    [UpdatedTreatmentEndDate] datetime  NULL
);
GO

-- Creating table 'PatientProtocolAssignmentPostDenialProtocols'
CREATE TABLE [dbo].[PatientProtocolAssignmentPostDenialProtocols] (
    [PatientProtocolAssignmentPostDenialProtocolID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentProtocolID] int  NOT NULL,
    [PatientProtocolAssignmentPostDenialID] int  NOT NULL,
    [PostDenialStatusID] smallint  NULL,
    [PostDenialReviewerID] int  NULL,
    [PostDenialTranslatorID] int  NULL,
    [PostDenialPharmDReviewerID] int  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [WithdrawnReasonId] smallint  NULL
);
GO

-- Creating table 'PatientProtocolAssignmentProtocolElementAlias'
CREATE TABLE [dbo].[PatientProtocolAssignmentProtocolElementAlias] (
    [PatientProtocolAssignmentProtocolElementAliasID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [ProtocolID] int  NOT NULL,
    [ProtocolElementID] int  NOT NULL,
    [DrugCodeTypeID] smallint  NOT NULL,
    [DrugCode] varchar(50)  NOT NULL,
    [DrugCodeAlias] varchar(50)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PatientProtocolAssignmentTimeCountdowns'
CREATE TABLE [dbo].[PatientProtocolAssignmentTimeCountdowns] (
    [PatientProtocolAssignmentTimeCountdownID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [TurnaroundTime] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [PriorityChangeDate] datetime  NULL,
    [PartDChangeDate] datetime  NULL,
    [ContractualTAT] smallint  NULL,
    [TATCalculationMethodID] smallint  NULL,
    [PatientProtocolAssignmentPostDenialID] int  NULL,
    [TatExtensionDays] int  NULL
);
GO

-- Creating table 'PatientProtocolRulesTrails'
CREATE TABLE [dbo].[PatientProtocolRulesTrails] (
    [PatientProtocolRulesTrailID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [ProtocolID] int  NOT NULL,
    [ProtocolMsgText] varchar(1000)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL
);
GO

-- Creating table 'PayerBusinessDayConfigs'
CREATE TABLE [dbo].[PayerBusinessDayConfigs] (
    [PayerBusinessDayConfigID] int IDENTITY(1,1) NOT NULL,
    [DimPayerID] int  NOT NULL,
    [StartTime] time  NOT NULL,
    [EndTime] time  NOT NULL,
    [Timezone] varchar(256)  NOT NULL,
    [IncludeWeekend] bit  NOT NULL,
    [IncludeObservedHolidays] bit  NOT NULL,
    [EffectiveStartDate] datetime  NOT NULL,
    [EffectiveEndDate] datetime  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PayerContactDetails'
CREATE TABLE [dbo].[PayerContactDetails] (
    [PayerContactDetailId] int IDENTITY(1,1) NOT NULL,
    [PayerId] smallint  NOT NULL,
    [PointOfContact] varchar(128)  NOT NULL,
    [PhoneNumber] varchar(16)  NOT NULL,
    [AutomatedAttendantInstructions] varchar(128)  NULL,
    [Email] varchar(64)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PayerFormularies'
CREATE TABLE [dbo].[PayerFormularies] (
    [PayerFormularyID] int IDENTITY(1,1) NOT NULL,
    [DimPayerID] int  NOT NULL,
    [DrugID] int  NOT NULL,
    [BenefitTypeID] smallint  NULL,
    [PriorAuthRequired] bit  NULL,
    [EffectiveFrom] datetime  NULL,
    [EffectiveTo] datetime  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [VialRounding] bit  NOT NULL,
    [OutOfScope] bit  NOT NULL,
    [PriorAuthRequiredCrossoverPharmacy] bit  NULL,
    [OOSCrossoverPharmacy] bit  NULL
);
GO

-- Creating table 'PayerOrganizations'
CREATE TABLE [dbo].[PayerOrganizations] (
    [PayerOrganizationID] int IDENTITY(1,1) NOT NULL,
    [OrganizationID] smallint  NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PayerPrimaryTimers'
CREATE TABLE [dbo].[PayerPrimaryTimers] (
    [PayerPrimaryTimerID] int IDENTITY(1,1) NOT NULL,
    [DimPayerID] int  NOT NULL,
    [TimerTypeID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [SequenceNumber] tinyint  NULL,
    [SendMemberLetter] bit  NULL
);
GO

-- Creating table 'PayerTimerConfigurations'
CREATE TABLE [dbo].[PayerTimerConfigurations] (
    [PayerTimerConfigurationID] int IDENTITY(1,1) NOT NULL,
    [DimPayerID] int  NOT NULL,
    [RequestTypeID] smallint  NULL,
    [ReviewStageID] smallint  NULL,
    [PriorityType] varchar(10)  NULL,
    [Resolution] varchar(10)  NULL,
    [TimerName] varchar(255)  NULL,
    [DurationUnitsID] smallint  NULL,
    [Duration] int  NULL,
    [DurationUnitsID2] smallint  NULL,
    [Duration2] int  NULL,
    [Required] bit  NULL,
    [EffectiveStartDate] datetime  NOT NULL,
    [EffectiveEndDate] datetime  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [IsTimerHidden] bit  NULL,
    [IsAso] bit  NULL,
    [IsErisa] bit  NULL,
    [IsStepTherapy] bit  NULL,
    [SendMemberLetter] bit  NULL
);
GO

-- Creating table 'PayerTimerConfiguration_State'
CREATE TABLE [dbo].[PayerTimerConfiguration_State] (
    [PayerTimerConfigurationStateID] int IDENTITY(1,1) NOT NULL,
    [PayerTimerConfigurationID] int  NULL,
    [StateCode] varchar(2)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PayerXrtCodes'
CREATE TABLE [dbo].[PayerXrtCodes] (
    [PayerXrtCodeID] int IDENTITY(1,1) NOT NULL,
    [DimPayerID] int  NOT NULL,
    [CPTCodeXRTID] int  NOT NULL,
    [PaRequired] bit  NOT NULL,
    [EffectiveFrom] datetime  NOT NULL,
    [EffectiveTo] datetime  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PostDenialConfigurations'
CREATE TABLE [dbo].[PostDenialConfigurations] (
    [PostDenialConfigurationID] int IDENTITY(1,1) NOT NULL,
    [LineOfBusinessID] smallint  NOT NULL,
    [IsAppealEnabled] bit  NOT NULL,
    [IsReconsiderationEnabled] bit  NOT NULL,
    [IsReopenEnabled] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PracticeGroups'
CREATE TABLE [dbo].[PracticeGroups] (
    [PracticeGroupID] int IDENTITY(1,1) NOT NULL,
    [ParentID] int  NULL,
    [Name] varchar(255)  NOT NULL,
    [DBA] varchar(255)  NULL,
    [AccountTypeID] smallint  NOT NULL,
    [PhoneNumber] varchar(15)  NULL,
    [NPI] varchar(50)  NOT NULL,
    [TIN] varchar(50)  NOT NULL,
    [PermissionGroupID] smallint  NOT NULL,
    [TaxonomyTypeID] smallint  NULL,
    [EHRSoftwareID] smallint  NULL,
    [PrimaryTaxonomyType] varchar(50)  NULL,
    [TaxonomyCode] varchar(50)  NULL,
    [Active] bit  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [ModifiedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [Deleted] bit  NOT NULL
);
GO

-- Creating table 'PracticeGroupAddresses'
CREATE TABLE [dbo].[PracticeGroupAddresses] (
    [PracticeGroupAddressID] int IDENTITY(1,1) NOT NULL,
    [PracticeGroupID] int  NOT NULL,
    [AddressTypeID] smallint  NOT NULL,
    [AddressID] smallint  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [ModifiedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [Deleted] bit  NOT NULL
);
GO

-- Creating table 'PracticeGroupPayers'
CREATE TABLE [dbo].[PracticeGroupPayers] (
    [PracticeGroupPayerID] int IDENTITY(1,1) NOT NULL,
    [PracticeGroupID] int  NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [ModifiedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [Deleted] bit  NOT NULL
);
GO

-- Creating table 'PracticeGroupUsers'
CREATE TABLE [dbo].[PracticeGroupUsers] (
    [PracticeGroupUserID] int IDENTITY(1,1) NOT NULL,
    [PracticeGroupID] int  NOT NULL,
    [UserID] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [ModifiedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [Deleted] bit  NOT NULL
);
GO

-- Creating table 'PreferredDrugRules'
CREATE TABLE [dbo].[PreferredDrugRules] (
    [PreferredDrugRuleID] int IDENTITY(1,1) NOT NULL,
    [RuleID] int  NOT NULL,
    [DrugID] int  NOT NULL,
    [PreferredBrandID] int  NULL,
    [PreferredGenericDrugID] int  NULL,
    [RuleLevelID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PreferredProtocolProgram_PatientProtocolAssignment_Protocol'
CREATE TABLE [dbo].[PreferredProtocolProgram_PatientProtocolAssignment_Protocol] (
    [PreferredProtocolProgram_PatientProtocolAssignment_ProtocolID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignment_ProtocolID] int  NOT NULL,
    [ProgramID] smallint  NOT NULL,
    [StatusID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'PreferredRegimenDrugBags'
CREATE TABLE [dbo].[PreferredRegimenDrugBags] (
    [PreferredRegimenDrugBagId] int IDENTITY(1,1) NOT NULL,
    [BagGroupReference] int  NULL,
    [DrugId] int  NOT NULL
);
GO

-- Creating table 'PreferredRegimenEvaluations'
CREATE TABLE [dbo].[PreferredRegimenEvaluations] (
    [PreferredRegimenEvaluationId] int IDENTITY(1,1) NOT NULL,
    [PreferredRegimenRuleId] int  NULL,
    [ClinicalQuestionId] int  NOT NULL,
    [ClinicalQuestionAnswerId] int  NULL,
    [Operator] nchar(10)  NOT NULL,
    [Predicate] nvarchar(10)  NOT NULL,
    [Value] varchar(500)  NULL,
    [ValueOperator] nchar(10)  NULL,
    [ValueType] varchar(50)  NULL
);
GO

-- Creating table 'PreferredRegimenRules'
CREATE TABLE [dbo].[PreferredRegimenRules] (
    [PreferredRegimenRuleId] int IDENTITY(1,1) NOT NULL,
    [DiagnosisId] int  NOT NULL,
    [PreferredRegimenDrugBagId] int  NOT NULL,
    [PreferredStatus] varchar(1)  NOT NULL
);
GO

-- Creating table 'PrerequisiteDrugs'
CREATE TABLE [dbo].[PrerequisiteDrugs] (
    [PrerequisiteDrugID] int IDENTITY(1,1) NOT NULL,
    [ProtocolID] int  NOT NULL,
    [DrugID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProcedureCodeSimpleDescriptions'
CREATE TABLE [dbo].[ProcedureCodeSimpleDescriptions] (
    [ProcedureCodeSimpleDescriptionID] int IDENTITY(1,1) NOT NULL,
    [ProcedureCode] nvarchar(50)  NOT NULL,
    [ProcedureCodeCategoryID] smallint  NOT NULL,
    [SimpleDescription] nvarchar(256)  NOT NULL,
    [SimpleDescriptionSpanish] nvarchar(256)  NULL,
    [SimpleDescriptionChinese] nvarchar(256)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProductLines'
CREATE TABLE [dbo].[ProductLines] (
    [ProductLineID] smallint IDENTITY(1,1) NOT NULL,
    [LineOfBusinessID] smallint  NOT NULL,
    [ProductLineName] varchar(100)  NOT NULL,
    [MemberIdFormat] varchar(200)  NULL,
    [MinCharMemberID] tinyint  NULL,
    [MaxCharMemberID] tinyint  NULL,
    [ASO] bit  NOT NULL,
    [PlanTypeID] smallint  NULL,
    [ProviderNetworkRuleID] smallint  NULL,
    [Active] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProfileSettings'
CREATE TABLE [dbo].[ProfileSettings] (
    [ProfileSettingID] int IDENTITY(1,1) NOT NULL,
    [Description] varchar(100)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'Protocols'
CREATE TABLE [dbo].[Protocols] (
    [ProtocolID] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(255)  NOT NULL,
    [NCTNumber] varchar(15)  NULL,
    [AutoAuthorization] bit  NOT NULL,
    [EstimatedCycles] smallint  NULL,
    [EstimatedDurationInMonth] real  NOT NULL,
    [NormalizationFee] int  NOT NULL,
    [RecommendationEvidenceLink] varchar(255)  NULL,
    [DiagnosisID] int  NOT NULL,
    [StageID] smallint  NULL,
    [EmetogenicPotentialID] smallint  NULL,
    [FebrileNeutropeniaRiskID] smallint  NOT NULL,
    [ToxicityRatingID] smallint  NOT NULL,
    [EfficacyRatingID] smallint  NOT NULL,
    [FinancialToxicityID] smallint  NOT NULL,
    [ApplicableGenderID] smallint  NULL,
    [Compendia] smallint  NULL,
    [MinPatientAge] tinyint  NULL,
    [MaxPatientAge] tinyint  NULL,
    [CheckAge] bit  NULL,
    [CheckPrerequisiteDrugs] bit  NULL,
    [LegacyID] bigint  NULL,
    [ProtocolPopupMessage] varchar(1000)  NULL,
    [TreatmentTypeID] smallint  NULL,
    [ParentProtocolID] int  NULL,
    [Active] bit  NOT NULL,
    [ReadyForExternalUsage] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [IsLegacyProtocolAdapterData] bit  NULL
);
GO

-- Creating table 'Protocol_Diagnosis'
CREATE TABLE [dbo].[Protocol_Diagnosis] (
    [ProtocolDiagnosisID] int IDENTITY(1,1) NOT NULL,
    [ProtocolID] int  NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolApprovalLogs'
CREATE TABLE [dbo].[ProtocolApprovalLogs] (
    [ProtocolApprovalLogID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [ProtocolID] int  NOT NULL,
    [ProtocolStatusID] smallint  NOT NULL,
    [ProcessedID] smallint  NOT NULL,
    [Reason] nvarchar(500)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolApprovalLogRules'
CREATE TABLE [dbo].[ProtocolApprovalLogRules] (
    [ProtocolApprovalLogRuleID] int IDENTITY(1,1) NOT NULL,
    [ProtocolApprovalLogID] int  NOT NULL,
    [PayerRuleID] int  NULL,
    [LookupRuleID] smallint  NULL,
    [ProcessedAsID] smallint  NOT NULL,
    [RuleModeID] smallint  NULL,
    [ApprovalReasonID] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolAuthorizationTips'
CREATE TABLE [dbo].[ProtocolAuthorizationTips] (
    [ProtocolAuthorizationTipID] int IDENTITY(1,1) NOT NULL,
    [ProtocolID] int  NOT NULL,
    [AuthorizationTip] varchar(1000)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [SortOrder] smallint  NULL
);
GO

-- Creating table 'ProtocolElements'
CREATE TABLE [dbo].[ProtocolElements] (
    [ProtocolElementID] int IDENTITY(1,1) NOT NULL,
    [ProtocolID] int  NOT NULL,
    [ParentProtocolElementID] int  NULL,
    [DrugID] int  NOT NULL,
    [DoseAmount] decimal(14,4)  NOT NULL,
    [DosePerAdministration] decimal(14,4)  NULL,
    [DoseUnitID] smallint  NOT NULL,
    [AverageDose] decimal(14,4)  NULL,
    [BSA] decimal(4,2)  NOT NULL,
    [AdministrationMethodID] smallint  NULL,
    [Cycles] real  NULL,
    [OverrideDynamicCycles] bit  NOT NULL,
    [Schedule] varchar(255)  NOT NULL,
    [FrequencyID] smallint  NOT NULL,
    [LegacyID] int  NULL,
    [FrequencyPerDayID] smallint  NULL,
    [AdministrationPerCycle] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [FinalPA] bit  NULL,
    [FinalOOS] bit  NULL
);
GO

-- Creating table 'ProtocolElement_RxNavDenorms'
CREATE TABLE [dbo].[ProtocolElement_RxNavDenorms] (
    [ProtocolElement_RxNavDenormID] int  NOT NULL,
    [ProtocolElementID] int  NOT NULL,
    [RxNav_DenormId] int  NOT NULL,
    [Ingredient_RXCUI] nvarchar(8)  NULL,
    [Ingredient] nvarchar(3000)  NULL,
    [Precise_Ingredient_RXCUI] nvarchar(8)  NULL,
    [Precise_Ingredient] nvarchar(3000)  NULL,
    [Brand_Name_RXCUI] nvarchar(8)  NULL,
    [Brand_Name] nvarchar(3000)  NULL,
    [Clinical_Drug_Component_RXCUI] nvarchar(8)  NULL,
    [Clinical_Drug_Component] nvarchar(3000)  NULL,
    [Clinical_Drug_or_Pack_RXCUI] nvarchar(8)  NULL,
    [Clinical_Drug_or_Pack] nvarchar(3000)  NULL,
    [Branded_Drug_Component_RXCUI] nvarchar(8)  NULL,
    [Branded_Drug_Component] nvarchar(3000)  NULL,
    [Branded_Drug_or_Pack_RXCUI] nvarchar(8)  NULL,
    [Branded_Drug_or_Pack] nvarchar(3000)  NULL,
    [Prescribable_Name] nvarchar(3000)  NULL,
    [DDI] int  NULL,
    [RXCUI_Tied_To_NDC] nvarchar(8)  NULL,
    [NDC] nvarchar(15)  NULL,
    [GPI] nvarchar(20)  NULL,
    [RxNav_HCPCS] nvarchar(10)  NULL,
    [RxNav_HCPCS_Description] nvarchar(3000)  NULL,
    [PDAC_HCPCS] nvarchar(10)  NULL,
    [PDAC_HCPCS_Description] nvarchar(3000)  NULL,
    [HCPCSCodes_HCPCS] nvarchar(10)  NULL,
    [HCPCSCodes_HCPCS_Description] nvarchar(3000)  NULL,
    [Available_HCPCS] nvarchar(30)  NULL,
    [Numerator_Value] nvarchar(20)  NULL,
    [Numerator_Unit] nvarchar(20)  NULL,
    [Denominator_Value] nvarchar(20)  NULL,
    [Denominator_Unit] nvarchar(20)  NULL,
    [RXN_Dose_Form] nvarchar(50)  NULL,
    [Generic_Name] nvarchar(3000)  NULL,
    [Route] nvarchar(50)  NULL,
    [New_Dose_Form] nvarchar(50)  NULL,
    [Strength] nvarchar(150)  NULL,
    [BrandOrGeneric] nvarchar(20)  NULL,
    [HashValue] nvarchar(100)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolElementBillingUnits'
CREATE TABLE [dbo].[ProtocolElementBillingUnits] (
    [ProtocolElementBillingUnitsID] int IDENTITY(1,1) NOT NULL,
    [ProtocolElementID] int  NOT NULL,
    [BillingUnitsQuantity] real  NOT NULL,
    [BillingUnitsQuantityUnitID] smallint  NOT NULL,
    [BillingUnitsPerCycle] real  NULL,
    [BillingUnitsPerAuth] real  NULL,
    [IsLegacyProtocolAdapterData] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolElementCodes'
CREATE TABLE [dbo].[ProtocolElementCodes] (
    [ProtocolElementCodeID] int IDENTITY(1,1) NOT NULL,
    [ProtocolElementID] int  NOT NULL,
    [Code] varchar(50)  NOT NULL,
    [CodeTypeID] smallint  NOT NULL,
    [Description] varchar(255)  NULL,
    [BillingMethodID] smallint  NOT NULL,
    [StrengthDescription] varchar(255)  NULL,
    [DoseForm] varchar(50)  NULL,
    [Route] varchar(50)  NULL,
    [PatientSpecificDoseAmount] decimal(14,4)  NULL,
    [PatientSpecificDoseUnitID] smallint  NULL,
    [QuantityPerCycle] smallint  NULL,
    [QuantityPerAuth] int  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [FormularyOutOfScope] bit  NULL,
    [BrandGenericInfoId] smallint  NULL,
    [NDC] varchar(50)  NULL
);
GO

-- Creating table 'ProtocolElementCodeFormularyDatas'
CREATE TABLE [dbo].[ProtocolElementCodeFormularyDatas] (
    [ProtocolElementCodeFormularyDataID] int IDENTITY(1,1) NOT NULL,
    [ProtocolElementCodeID] int  NOT NULL,
    [FormularyDrugStatus] bit  NOT NULL,
    [PriorAuthorizationRequired] bit  NOT NULL,
    [QuantityLimitStatus] bit  NOT NULL,
    [QuantityLimitAmount] decimal(18,0)  NULL,
    [QuantityLimitDays] smallint  NULL,
    [StepTherapyStatus] bit  NOT NULL,
    [StepTherapyDescription] nvarchar(4000)  NULL,
    [StepOrder] tinyint  NULL,
    [PreferredDrugStatus] bit  NOT NULL,
    [PreferredDrugGroupID] nvarchar(10)  NULL,
    [PreferredDrugGroupIDDescription] nvarchar(100)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [CoverageDuration] smallint  NULL,
    [FormularyDataId] int  NULL
);
GO

-- Creating table 'ProtocolElementDosings'
CREATE TABLE [dbo].[ProtocolElementDosings] (
    [ProtocolElementDosingID] int IDENTITY(1,1) NOT NULL,
    [ProtocolElementID] int  NOT NULL,
    [OriginalPatientSpecificDoseAmount] decimal(14,4)  NOT NULL,
    [OriginalPatientSpecificDoseUnitID] smallint  NOT NULL,
    [OptimalPatientSpecificDoseAmount] decimal(14,4)  NOT NULL,
    [OptimalPatientSpecificDoseUnitID] smallint  NOT NULL,
    [ReducedDoseAmount] decimal(14,4)  NOT NULL,
    [ReducedDoseUnitID] smallint  NOT NULL,
    [DoseRoundingAccepted] bit  NOT NULL,
    [DoseRoundingApplicable] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolElementDosingVials'
CREATE TABLE [dbo].[ProtocolElementDosingVials] (
    [ProtocolElementDosingVialID] int IDENTITY(1,1) NOT NULL,
    [ProtocolElementDosingID] int  NOT NULL,
    [VialSize] decimal(10,2)  NOT NULL,
    [VialUnitID] smallint  NOT NULL,
    [NumberOfVials] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolElementXRTs'
CREATE TABLE [dbo].[ProtocolElementXRTs] (
    [ProtocolElementXRTID] int IDENTITY(1,1) NOT NULL,
    [ProtocolID] int  NOT NULL,
    [CPTCodeXRTID] int  NOT NULL,
    [NumberofUnitsFractions] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolEvidenceLinks'
CREATE TABLE [dbo].[ProtocolEvidenceLinks] (
    [ProtocolEvidenceLinkID] int IDENTITY(1,1) NOT NULL,
    [ProtocolID] int  NOT NULL,
    [EvidenceLink] varchar(500)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [EvidenceLinkDescription] varchar(200)  NULL
);
GO

-- Creating table 'ProtocolIntentOfTherapies'
CREATE TABLE [dbo].[ProtocolIntentOfTherapies] (
    [ProtocolIntentOfTherapyID] int IDENTITY(1,1) NOT NULL,
    [IntentOfTherapyID] smallint  NULL,
    [ProtocolID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolLineOfTherapies'
CREATE TABLE [dbo].[ProtocolLineOfTherapies] (
    [ProtocolLineOfTherapyID] int IDENTITY(1,1) NOT NULL,
    [LineOfTherapyID] smallint  NULL,
    [ProtocolID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolMGTs'
CREATE TABLE [dbo].[ProtocolMGTs] (
    [ProtocolID] int  NOT NULL,
    [BrandName] varchar(200)  NULL,
    [Description] varchar(200)  NULL,
    [TestType] smallint  NULL,
    [MCACost] real  NULL,
    [HCPCSCode] varchar(10)  NULL,
    [HCPCSDescription] varchar(255)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolMolecularMarkers'
CREATE TABLE [dbo].[ProtocolMolecularMarkers] (
    [ProtocolMolecularMarkerID] int IDENTITY(1,1) NOT NULL,
    [MolecularMarkerID] smallint  NULL,
    [ProtocolID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolNCCNCategories'
CREATE TABLE [dbo].[ProtocolNCCNCategories] (
    [ProtocolNCCNCategoryID] int IDENTITY(1,1) NOT NULL,
    [NCCNCategoryID] smallint  NULL,
    [ProtocolID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolPerformaceStatus'
CREATE TABLE [dbo].[ProtocolPerformaceStatus] (
    [ProtocolPerformaceStatusID] int IDENTITY(1,1) NOT NULL,
    [PerformanceStatusID] smallint  NULL,
    [ProtocolID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolQuestions'
CREATE TABLE [dbo].[ProtocolQuestions] (
    [ProtocolQuestionID] int IDENTITY(1,1) NOT NULL,
    [ProtocolID] int  NOT NULL,
    [QuestionID] int  NOT NULL,
    [Compulsory] bit  NOT NULL,
    [ProtocolApprovalAnswerValue] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [SortOrder] smallint  NULL,
    [DisplayTabPosition] tinyint  NOT NULL,
    [IsHeading] bit  NOT NULL
);
GO

-- Creating table 'ProtocolRequests'
CREATE TABLE [dbo].[ProtocolRequests] (
    [ProtocolRequestID] int IDENTITY(1,1) NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [StageID] smallint  NOT NULL,
    [ClinicalTrial] bit  NULL,
    [NCTNumber] varchar(15)  NULL,
    [StatusID] smallint  NULL,
    [StatusReason] varchar(200)  NULL,
    [Note] varchar(500)  NULL,
    [CreatedBy] int  NULL,
    [CreatedOn] datetime  NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [PatientID] int  NULL,
    [PatientProtocolAssignmentID] int  NULL
);
GO

-- Creating table 'ProtocolRequestDrugs'
CREATE TABLE [dbo].[ProtocolRequestDrugs] (
    [ProtocolRequestDrugID] int IDENTITY(1,1) NOT NULL,
    [ProtocolRequestID] int  NOT NULL,
    [DrugID] int  NULL,
    [DrugName] varchar(64)  NULL,
    [SuppliedByStudy] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolSettingOfTherapies'
CREATE TABLE [dbo].[ProtocolSettingOfTherapies] (
    [ProtocolSettingOfTherapyID] int IDENTITY(1,1) NOT NULL,
    [SettingOfTherapyID] smallint  NULL,
    [ProtocolID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ProtocolXRTs'
CREATE TABLE [dbo].[ProtocolXRTs] (
    [ProtocolID] int  NOT NULL,
    [NumberOfFraction] varchar(50)  NOT NULL,
    [DosePerFraction] varchar(50)  NOT NULL,
    [TotalDoseInGY] varchar(50)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [SOC] bit  NULL,
    [FrequencyID] smallint  NULL,
    [AdministrationMethodID] smallint  NOT NULL,
    [IsBoost] bit  NULL
);
GO

-- Creating table 'Providers'
CREATE TABLE [dbo].[Providers] (
    [ProviderID] int IDENTITY(1,1) NOT NULL,
    [ProviderNPI] varchar(15)  NULL,
    [ProviderTaxID] varchar(15)  NULL,
    [Deleted] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [PayerProviderId] varchar(24)  NULL
);
GO

-- Creating table 'ProviderInfoDatas'
CREATE TABLE [dbo].[ProviderInfoDatas] (
    [ProviderInfoDataID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [RecordType] int  NOT NULL,
    [IsSoleProprietor] bit  NOT NULL,
    [FirstName] nvarchar(55)  NULL,
    [LastName] nvarchar(55)  NULL,
    [Title] nvarchar(128)  NULL,
    [PhysicianNPI] nvarchar(24)  NULL,
    [ParticipatingLinesOfBusiness] nvarchar(128)  NOT NULL,
    [NonParticipatingLinesOfBusiness] nvarchar(128)  NOT NULL,
    [Phone] nvarchar(24)  NOT NULL,
    [Fax] nvarchar(24)  NOT NULL,
    [Email] nvarchar(100)  NULL,
    [PracticeName] nvarchar(128)  NOT NULL,
    [DoingBusinessAs] nvarchar(128)  NOT NULL,
    [PracticeNPI] nvarchar(24)  NOT NULL,
    [PracticeTaxID] nvarchar(24)  NOT NULL,
    [BusinessPracticeLocationStreet] nvarchar(128)  NOT NULL,
    [BusinessPracticeLocationCity] nvarchar(99)  NOT NULL,
    [BusinessPracticeLocationState] nvarchar(5)  NOT NULL,
    [BusinessPracticeLocationZip] nvarchar(5)  NOT NULL,
    [BusinessPracticeLocationZipPlusCode] nvarchar(4)  NULL,
    [BusinessPracticeLocationCounty] nvarchar(99)  NULL,
    [BusinessMailingAddressStreet] nvarchar(128)  NULL,
    [BusinessMailingAddressCity] nvarchar(99)  NULL,
    [BusinessMailingAddressState] nvarchar(5)  NULL,
    [BusinessMailingAddressZip] nvarchar(5)  NULL,
    [BusinessMailingAddressZipPlusCode] nvarchar(4)  NULL,
    [ProviderSpecialty] nvarchar(100)  NULL,
    [CreatedOn] datetime  NOT NULL,
    [CreatedBy] nvarchar(50)  NULL,
    [ModifiedOn] datetime  NULL,
    [ModifiedBy] nvarchar(50)  NULL
);
GO

-- Creating table 'QppAttestationReportResults'
CREATE TABLE [dbo].[QppAttestationReportResults] (
    [QppAttestationReportResultID] int IDENTITY(1,1) NOT NULL,
    [QppReportSettingID] int  NOT NULL,
    [UserGroupID] smallint  NOT NULL,
    [AttestedDate] datetime  NULL,
    [AttestedBy] int  NULL,
    [StatusID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'QppReportSettings'
CREATE TABLE [dbo].[QppReportSettings] (
    [QppReportSettingId] int IDENTITY(1,1) NOT NULL,
    [StartDate] datetime  NOT NULL,
    [EndDate] datetime  NOT NULL,
    [DateCode] varchar(10)  NOT NULL,
    [AttestationStartDate] datetime  NOT NULL,
    [AttestationEndDate] datetime  NOT NULL,
    [StatusID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'ReferenceNumbers'
CREATE TABLE [dbo].[ReferenceNumbers] (
    [ReferenceNumberID] int IDENTITY(1,1) NOT NULL,
    [OAReferenceNumber] varchar(50)  NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL
);
GO

-- Creating table 'Rules'
CREATE TABLE [dbo].[Rules] (
    [RuleID] int IDENTITY(1,1) NOT NULL,
    [RuleTypeID] smallint  NOT NULL,
    [PatientDiagnosisID] int  NULL,
    [StageID] smallint  NULL,
    [ProtocolDiagnosisID] int  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'RxNavDenorms'
CREATE TABLE [dbo].[RxNavDenorms] (
    [RxNavDenormId] int IDENTITY(1,1) NOT NULL,
    [IngredientRXCUI] varchar(8)  NULL,
    [Ingredient] varchar(3000)  NULL,
    [PreciseIngredientRXCUI] varchar(8)  NULL,
    [PreciseIngredient] varchar(3000)  NULL,
    [BrandNameRXCUI] varchar(8)  NULL,
    [BrandName] varchar(3000)  NULL,
    [ClinicalDrugComponentRXCUI] varchar(8)  NULL,
    [ClinicalDrugComponent] varchar(3000)  NULL,
    [ClinicalDrugorPackRXCUI] varchar(8)  NULL,
    [ClinicalDrugOrPack] varchar(3000)  NULL,
    [BrandedDrugComponentRXCUI] varchar(8)  NULL,
    [BrandedDrugComponent] varchar(3000)  NULL,
    [BrandedDrugOrPackRXCUI] varchar(8)  NULL,
    [BrandedDrugorPack] varchar(3000)  NULL,
    [PrescribableName] varchar(3000)  NULL,
    [DDI] int  NULL,
    [RXCUITiedToNDC] varchar(8)  NULL,
    [NDC] varchar(15)  NULL,
    [GPI] varchar(20)  NULL,
    [RxNavHCPCS] varchar(10)  NULL,
    [RxNavHCPCSDescription] varchar(3000)  NULL,
    [PdacHCPCS] varchar(10)  NULL,
    [PdacHCPCSDescription] varchar(3000)  NULL,
    [HCPCSCodesHCPCS] varchar(10)  NULL,
    [HCPCSCodesHCPCSDescription] varchar(3000)  NULL,
    [AvailableHCPCS] varchar(30)  NULL,
    [NumeratorValue] decimal(20,6)  NULL,
    [NumeratorUnit] varchar(20)  NULL,
    [DenominatorValue] decimal(20,6)  NULL,
    [DenominatorUnit] varchar(20)  NULL,
    [RXNDoseForm] varchar(50)  NULL,
    [GenericName] varchar(3000)  NULL,
    [Route] varchar(50)  NULL,
    [NewDoseForm] varchar(50)  NULL,
    [Strength] varchar(150)  NULL,
    [IsProtectedClass] varchar(3)  NULL,
    [CreatedOnCDR] datetime  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'SalesforceStagingLoads'
CREATE TABLE [dbo].[SalesforceStagingLoads] (
    [SalesforceStagingLoadID] int IDENTITY(1,1) NOT NULL,
    [StagingLoadDate] datetime  NOT NULL,
    [Processed] bit  NOT NULL,
    [AccountTransfered] int  NOT NULL,
    [ContactTransfered] int  NOT NULL
);
GO

-- Creating table 'SecurityGroups'
CREATE TABLE [dbo].[SecurityGroups] (
    [SecurityGroupID] smallint IDENTITY(1,1) NOT NULL,
    [UserGroupID] smallint  NOT NULL,
    [SecurityGroupName] varchar(255)  NOT NULL,
    [Description] varchar(255)  NULL,
    [Active] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'SecurityGroup_MenuOption'
CREATE TABLE [dbo].[SecurityGroup_MenuOption] (
    [SecurityGroupMenuOptionID] int IDENTITY(1,1) NOT NULL,
    [SecurityGroupID] smallint  NOT NULL,
    [MenuOptionID] smallint  NOT NULL,
    [CanCreate] bit  NULL,
    [CanRead] bit  NULL,
    [CanModify] bit  NULL,
    [CanDelete] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'SfOriginAccounts'
CREATE TABLE [dbo].[SfOriginAccounts] (
    [sfId] varchar(100)  NOT NULL,
    [IsDeleted] bit  NULL,
    [MasterRecordId] varchar(100)  NULL,
    [Name] varchar(255)  NULL,
    [Type] varchar(40)  NULL,
    [ParentId] varchar(18)  NULL,
    [BillingStreet] varchar(255)  NULL,
    [BillingCity] varchar(40)  NULL,
    [BillingState] varchar(20)  NULL,
    [BillingPostalCode] varchar(20)  NULL,
    [BillingCountry] varchar(40)  NULL,
    [BillingLatitude] decimal(14,4)  NULL,
    [BillingLongitude] decimal(14,4)  NULL,
    [ShippingStreet] varchar(255)  NULL,
    [ShippingCity] varchar(40)  NULL,
    [ShippingState] varchar(20)  NULL,
    [ShippingPostalCode] varchar(20)  NULL,
    [ShippingCountry] varchar(40)  NULL,
    [ShippingLatitude] decimal(14,4)  NULL,
    [ShippingLongitude] decimal(14,4)  NULL,
    [Phone] varchar(45)  NULL,
    [Fax] varchar(45)  NULL,
    [Website] nvarchar(256)  NULL,
    [PhotoUrl] varchar(45)  NULL,
    [Industry] varchar(45)  NULL,
    [AnnualRevenue] decimal(14,4)  NULL,
    [NumberOfEmployees] int  NULL,
    [Description] nvarchar(600)  NULL,
    [OwnerId] varchar(45)  NULL,
    [CreatedDate] datetime  NULL,
    [CreatedById] varchar(45)  NULL,
    [LastModifiedDate] datetime  NULL,
    [LastModifiedById] varchar(45)  NULL,
    [SystemModstamp] datetime  NULL,
    [LastActivityDate] datetime  NULL,
    [LastViewedDate] datetime  NULL,
    [LastReferencedDate] datetime  NULL,
    [JigsawCompanyId] varchar(45)  NULL,
    [First_Name__c] varchar(45)  NULL,
    [Last_Name__c] varchar(45)  NULL,
    [Back_Phone__c] varchar(45)  NULL,
    [Back_Fax__c] varchar(45)  NULL,
    [Notes__c] nvarchar(600)  NULL,
    [County__c] varchar(45)  NULL,
    [Tax_ID__c] varchar(45)  NULL,
    [MSO_or_Center_ID__c] varchar(45)  NULL,
    [Provider_Name_Prefix_Text__c] varchar(45)  NULL,
    [NPI__c] varchar(45)  NULL,
    [User_Name__c] varchar(45)  NULL,
    [Contracted_Plans__c] varchar(45)  NULL,
    [Title__c] varchar(255)  NULL,
    [Professional_Designation__c] varchar(45)  NULL,
    [Shipping_suite__c] varchar(45)  NULL,
    [Billing_Phone__c] varchar(45)  NULL,
    [Billing_Fax__c] varchar(45)  NULL,
    [Provider_Enumeration_Date__c] datetime  NULL,
    [Last_Update_Date__c] datetime  NULL,
    [Provider_Gender__c] varchar(45)  NULL,
    [Middle_Name__c] varchar(45)  NULL,
    [Authorized_Official_Telephone_Number__c] varchar(45)  NULL,
    [Healthcare_Provider_Taxonomy_Code_1__c] varchar(45)  NULL,
    [Authorized_Official_Name_Prefix_Text__c] varchar(45)  NULL,
    [Authorized_Official_Name_Suffix_Text__c] varchar(45)  NULL,
    [Authorized_Official_Credential_Text__c] varchar(45)  NULL,
    [Healthcare_Provider_Taxonomy_Group_2__c] varchar(255)  NULL,
    [Authorized_Official_First_Name__c] varchar(45)  NULL,
    [Authorized_Official_Last_Name__c] varchar(45)  NULL,
    [Authorized_Official_Middle_Name__c] varchar(45)  NULL,
    [Provider_OA_Effective_Date__c] datetime  NULL,
    [QPP_Street_Address__c] varchar(45)  NULL,
    [QPP_City__c] varchar(45)  NULL,
    [QPP_State__c] varchar(45)  NULL,
    [QPP_Zip_Code__c] varchar(45)  NULL,
    [Doing_Business_As__c] varchar(255)  NULL,
    [Tier__c] varchar(45)  NULL,
    [QPP_Official__c] varchar(255)  NULL,
    [Participating_LOB__c] varchar(255)  NULL,
    [AccountCheckSum] varchar(50)  NULL,
    [BillingGeocodeAccuracy] varchar(255)  NULL,
    [CHEMO_FEE_SCHEDULE__c] varchar(255)  NULL,
    [Provider_Update_Form_Date__c] datetime  NULL,
    [ShippingGeocodeAccuracy] varchar(255)  NULL,
    [Account_Synchronization__c] varchar(250)  NULL,
    [CreatedInMATIS] bit  NULL,
    [RAD_Fax_1__c] varchar(255)  NULL,
    [RAD_Contact_1__c] varchar(255)  NULL,
    [RAD_Fax_2__c] varchar(255)  NULL,
    [RAD_Contact_2__c] varchar(255)  NULL,
    [RAD_Fax_Determinator__c] varchar(255)  NULL,
    [Approval_Fax_Determinator__c] varchar(255)  NULL,
    [Account_Type__c] varchar(255)  NULL,
    [Full_Facility_ID__c] varchar(255)  NULL,
    [RAD_Email__c] varchar(255)  NULL,
    [Approval_Email__c] varchar(255)  NULL,
    [Acnt_User_group__c] varchar(255)  NULL,
    [MSO_Market__c] varchar(255)  NULL,
    [MSO_Region__c] varchar(255)  NULL,
    [QPP_Official_Contact_NEW__c] varchar(255)  NULL,
    [QPP_Status__c] varchar(255)  NULL,
    [PrimaryPayerProviderID] varchar(24)  NULL,
    [SecondaryPayerProviderID] varchar(24)  NULL,
    [Source] char(1)  NULL,
    [SpecialtyCode] varchar(10)  NULL,
    [RefSfId] varchar(100)  NULL
);
GO

-- Creating table 'SfOriginAccountStagings'
CREATE TABLE [dbo].[SfOriginAccountStagings] (
    [sfId] varchar(100)  NOT NULL,
    [IsDeleted] varchar(45)  NULL,
    [MasterRecordId] varchar(100)  NULL,
    [Name] varchar(255)  NULL,
    [Type] varchar(40)  NULL,
    [ParentId] varchar(18)  NULL,
    [BillingStreet] varchar(255)  NULL,
    [BillingCity] varchar(40)  NULL,
    [BillingState] varchar(20)  NULL,
    [BillingPostalCode] varchar(20)  NULL,
    [BillingCountry] varchar(40)  NULL,
    [BillingLatitude] varchar(45)  NULL,
    [BillingLongitude] varchar(45)  NULL,
    [ShippingStreet] varchar(255)  NULL,
    [ShippingCity] varchar(40)  NULL,
    [ShippingState] varchar(20)  NULL,
    [ShippingPostalCode] varchar(20)  NULL,
    [ShippingCountry] varchar(40)  NULL,
    [ShippingLatitude] varchar(45)  NULL,
    [ShippingLongitude] varchar(45)  NULL,
    [Phone] varchar(45)  NULL,
    [Fax] varchar(45)  NULL,
    [Website] nvarchar(256)  NULL,
    [PhotoUrl] varchar(45)  NULL,
    [Industry] varchar(45)  NULL,
    [AnnualRevenue] varchar(45)  NULL,
    [NumberOfEmployees] varchar(45)  NULL,
    [Description] nvarchar(600)  NULL,
    [OwnerId] varchar(45)  NULL,
    [CreatedDate] varchar(255)  NULL,
    [CreatedById] varchar(45)  NULL,
    [LastModifiedDate] varchar(255)  NULL,
    [LastModifiedById] varchar(45)  NULL,
    [SystemModstamp] varchar(255)  NULL,
    [LastActivityDate] varchar(255)  NULL,
    [LastViewedDate] varchar(255)  NULL,
    [LastReferencedDate] varchar(255)  NULL,
    [JigsawCompanyId] varchar(45)  NULL,
    [First_Name__c] varchar(45)  NULL,
    [Last_Name__c] varchar(45)  NULL,
    [Back_Phone__c] varchar(45)  NULL,
    [Back_Fax__c] varchar(45)  NULL,
    [Notes__c] nvarchar(600)  NULL,
    [County__c] varchar(45)  NULL,
    [Tax_ID__c] varchar(45)  NULL,
    [MSO_or_Center_ID__c] varchar(45)  NULL,
    [Provider_Name_Prefix_Text__c] varchar(45)  NULL,
    [NPI__c] varchar(45)  NULL,
    [User_Name__c] varchar(45)  NULL,
    [Contracted_Plans__c] varchar(45)  NULL,
    [Title__c] varchar(255)  NULL,
    [Professional_Designation__c] varchar(45)  NULL,
    [Shipping_suite__c] varchar(45)  NULL,
    [Billing_Phone__c] varchar(45)  NULL,
    [Billing_Fax__c] varchar(45)  NULL,
    [Provider_Enumeration_Date__c] varchar(255)  NULL,
    [Last_Update_Date__c] varchar(255)  NULL,
    [Provider_Gender__c] varchar(45)  NULL,
    [Middle_Name__c] varchar(45)  NULL,
    [Authorized_Official_Telephone_Number__c] varchar(45)  NULL,
    [Healthcare_Provider_Taxonomy_Code_1__c] varchar(45)  NULL,
    [Authorized_Official_Name_Prefix_Text__c] varchar(45)  NULL,
    [Authorized_Official_Name_Suffix_Text__c] varchar(45)  NULL,
    [Authorized_Official_Credential_Text__c] varchar(45)  NULL,
    [Healthcare_Provider_Taxonomy_Group_2__c] varchar(255)  NULL,
    [Authorized_Official_First_Name__c] varchar(45)  NULL,
    [Authorized_Official_Last_Name__c] varchar(45)  NULL,
    [Authorized_Official_Middle_Name__c] varchar(45)  NULL,
    [Provider_OA_Effective_Date__c] varchar(255)  NULL,
    [QPP_Street_Address__c] varchar(45)  NULL,
    [QPP_City__c] varchar(45)  NULL,
    [QPP_State__c] varchar(45)  NULL,
    [QPP_Zip_Code__c] varchar(45)  NULL,
    [Doing_Business_As__c] varchar(255)  NULL,
    [Tier__c] varchar(45)  NULL,
    [QPP_Official__c] varchar(255)  NULL,
    [Participating_LOB__c] varchar(255)  NULL,
    [BillingGeocodeAccuracy] varchar(255)  NULL,
    [CHEMO_FEE_SCHEDULE__c] varchar(255)  NULL,
    [Provider_Update_Form_Date__c] varchar(255)  NULL,
    [ShippingGeocodeAccuracy] varchar(255)  NULL,
    [Account_Synchronization__c] varchar(250)  NULL,
    [RAD_Fax_1__c] varchar(255)  NULL,
    [RAD_Contact_1__c] varchar(255)  NULL,
    [RAD_Fax_2__c] varchar(255)  NULL,
    [RAD_Contact_2__c] varchar(255)  NULL,
    [RAD_Fax_Determinator__c] varchar(255)  NULL,
    [Approval_Fax_Determinator__c] varchar(255)  NULL,
    [Account_Type__c] varchar(255)  NULL,
    [Full_Facility_ID__c] varchar(255)  NULL,
    [RAD_Email__c] varchar(255)  NULL,
    [Approval_Email__c] varchar(255)  NULL,
    [Acnt_User_group__c] varchar(255)  NULL,
    [MSO_Market__c] varchar(255)  NULL,
    [MSO_Region__c] varchar(255)  NULL,
    [QPP_Official_Contact_NEW__c] varchar(255)  NULL,
    [QPP_Status__c] varchar(255)  NULL
);
GO

-- Creating table 'SfOriginContacts'
CREATE TABLE [dbo].[SfOriginContacts] (
    [sfId] varchar(100)  NOT NULL,
    [IsDeleted] bit  NULL,
    [MasterRecordId] varchar(100)  NULL,
    [AccountId] varchar(100)  NULL,
    [LastName] varchar(55)  NULL,
    [FirstName] varchar(55)  NULL,
    [Salutation] varchar(45)  NULL,
    [Name] varchar(255)  NULL,
    [OtherStreet] varchar(255)  NULL,
    [OtherCity] varchar(255)  NULL,
    [OtherPostalCode] varchar(12)  NULL,
    [OtherCountry] varchar(45)  NULL,
    [OtherLatitude] decimal(14,4)  NULL,
    [OtherLongitude] decimal(14,4)  NULL,
    [MailingStreet] nvarchar(128)  NULL,
    [MailingCity] varchar(255)  NULL,
    [MailingState] varchar(100)  NULL,
    [MailingPostalCode] varchar(12)  NULL,
    [MailingCountry] varchar(45)  NULL,
    [MailingLatitude] decimal(14,4)  NULL,
    [MailingLongitude] decimal(14,4)  NULL,
    [Phone] varchar(45)  NULL,
    [Fax] varchar(45)  NULL,
    [MobilePhone] varchar(45)  NULL,
    [HomePhone] varchar(45)  NULL,
    [OtherPhone] varchar(45)  NULL,
    [AssistantPhone] varchar(45)  NULL,
    [Email] varchar(255)  NULL,
    [Title] varchar(255)  NULL,
    [Department] varchar(55)  NULL,
    [AssistantName] varchar(255)  NULL,
    [LeadSource] varchar(255)  NULL,
    [BirthDate] datetime  NULL,
    [Description] nvarchar(600)  NULL,
    [OwnerId] varchar(55)  NULL,
    [HasOptedOutOfEmail] varchar(45)  NULL,
    [HasOptedOutOfFax] varchar(45)  NULL,
    [DoNotCall] varchar(45)  NULL,
    [CreatedDate] datetime  NULL,
    [CreatedById] varchar(45)  NULL,
    [LastModifiedDate] datetime  NULL,
    [LastModifiedById] varchar(45)  NULL,
    [SystemModstamp] datetime  NULL,
    [LastActivityDate] datetime  NULL,
    [LastCURequestDate] datetime  NULL,
    [LastCUUpdateDate] datetime  NULL,
    [LastViewedDate] datetime  NULL,
    [LastReferencedDate] datetime  NULL,
    [EmailBouncedReason] varchar(255)  NULL,
    [EmailBouncedDate] datetime  NULL,
    [IsEmailBounced] varchar(45)  NULL,
    [PhotoUrl] varchar(45)  NULL,
    [JigsawContactId] varchar(45)  NULL,
    [First_Name__c] varchar(55)  NULL,
    [Last_Name__c] varchar(55)  NULL,
    [User_Name__c] varchar(55)  NULL,
    [User_Group__c] varchar(255)  NULL,
    [Back_Office_Phone__c] varchar(50)  NULL,
    [Back_Office_Fax__c] varchar(50)  NULL,
    [Notes__c] nvarchar(600)  NULL,
    [County__c] varchar(255)  NULL,
    [Tax_ID__c] varchar(12)  NULL,
    [NPI__c] varchar(20)  NULL,
    [Provider_Effective_Date__c] datetime  NULL,
    [Suffix__c] varchar(45)  NULL,
    [Type__c] varchar(45)  NULL,
    [Contracted_Payers__c] varchar(255)  NULL,
    [QPP_Street_Address__c] varchar(255)  NULL,
    [QPP_City__c] varchar(255)  NULL,
    [QPP_State__c] varchar(255)  NULL,
    [QPP_Zip_Code__c] varchar(12)  NULL,
    [Tier__c] varchar(45)  NULL,
    [Participating_LOB__c] varchar(255)  NULL,
    [Doing_Business_As__c] varchar(255)  NULL,
    [OA_User_ID__c] varchar(20)  NULL,
    [ContactCheckSum] varchar(50)  NULL,
    [CHEMO_FEE_SCHEDULE__c] varchar(255)  NULL,
    [For_Deletion__c] varchar(255)  NULL,
    [Healthcare_Provider_Taxonomy_Code_2__c] varchar(255)  NULL,
    [MailingGeocodeAccuracy] varchar(255)  NULL,
    [OtherGeocodeAccuracy] varchar(255)  NULL,
    [OtherState] varchar(255)  NULL,
    [Provider_Update_Form_Recevied__c] datetime  NULL,
    [Quarterly_QPP__c] varchar(255)  NULL,
    [ReportsToId] varchar(255)  NULL,
    [Taxonomy_Text__c] varchar(255)  NULL,
    [QPp_Opt_Out__c] varchar(255)  NULL,
    [Contact_Synchronization__c] varchar(250)  NULL,
    [CreatedInMATIS] bit  NULL,
    [PrimaryPayerProviderID] varchar(24)  NULL,
    [SecondaryPayerProviderID] varchar(24)  NULL,
    [Source] char(1)  NULL,
    [SpecialtyCode] varchar(10)  NULL,
    [RefSfId] varchar(100)  NULL
);
GO

-- Creating table 'SfOriginContactStagings'
CREATE TABLE [dbo].[SfOriginContactStagings] (
    [sfId] varchar(100)  NOT NULL,
    [IsDeleted] varchar(10)  NULL,
    [MasterRecordId] varchar(100)  NULL,
    [AccountId] varchar(100)  NULL,
    [LastName] varchar(55)  NULL,
    [FirstName] varchar(55)  NULL,
    [Salutation] varchar(45)  NULL,
    [Name] varchar(255)  NULL,
    [OtherStreet] varchar(255)  NULL,
    [OtherCity] varchar(255)  NULL,
    [OtherPostalCode] varchar(12)  NULL,
    [OtherCountry] varchar(45)  NULL,
    [OtherLatitude] varchar(45)  NULL,
    [OtherLongitude] varchar(45)  NULL,
    [MailingStreet] nvarchar(128)  NULL,
    [MailingCity] varchar(255)  NULL,
    [MailingState] varchar(100)  NULL,
    [MailingPostalCode] varchar(12)  NULL,
    [MailingCountry] varchar(45)  NULL,
    [MailingLatitude] varchar(45)  NULL,
    [MailingLongitude] varchar(45)  NULL,
    [Phone] varchar(45)  NULL,
    [Fax] varchar(45)  NULL,
    [MobilePhone] varchar(45)  NULL,
    [HomePhone] varchar(45)  NULL,
    [OtherPhone] varchar(45)  NULL,
    [AssistantPhone] varchar(45)  NULL,
    [Email] varchar(255)  NULL,
    [Title] varchar(255)  NULL,
    [Department] varchar(55)  NULL,
    [AssistantName] varchar(255)  NULL,
    [LeadSource] varchar(255)  NULL,
    [BirthDate] varchar(255)  NULL,
    [Description] nvarchar(600)  NULL,
    [OwnerId] varchar(55)  NULL,
    [HasOptedOutOfEmail] varchar(45)  NULL,
    [HasOptedOutOfFax] varchar(45)  NULL,
    [DoNotCall] varchar(45)  NULL,
    [CreatedDate] varchar(255)  NULL,
    [CreatedById] varchar(45)  NULL,
    [LastModifiedDate] varchar(255)  NULL,
    [LastModifiedById] varchar(45)  NULL,
    [SystemModstamp] varchar(255)  NULL,
    [LastActivityDate] varchar(255)  NULL,
    [LastCURequestDate] varchar(255)  NULL,
    [LastCUUpdateDate] varchar(255)  NULL,
    [LastViewedDate] varchar(255)  NULL,
    [LastReferencedDate] varchar(255)  NULL,
    [EmailBouncedReason] varchar(255)  NULL,
    [EmailBouncedDate] varchar(255)  NULL,
    [IsEmailBounced] varchar(45)  NULL,
    [PhotoUrl] varchar(45)  NULL,
    [JigsawContactId] varchar(45)  NULL,
    [First_Name__c] varchar(55)  NULL,
    [Last_Name__c] varchar(55)  NULL,
    [User_Name__c] varchar(55)  NULL,
    [User_Group__c] varchar(255)  NULL,
    [Back_Office_Phone__c] varchar(50)  NULL,
    [Back_Office_Fax__c] varchar(50)  NULL,
    [Notes__c] nvarchar(600)  NULL,
    [County__c] varchar(255)  NULL,
    [Tax_ID__c] varchar(12)  NULL,
    [NPI__c] varchar(20)  NULL,
    [Provider_Effective_Date__c] varchar(255)  NULL,
    [Suffix__c] varchar(45)  NULL,
    [Type__c] varchar(45)  NULL,
    [Contracted_Payers__c] varchar(255)  NULL,
    [QPP_Street_Address__c] varchar(255)  NULL,
    [QPP_City__c] varchar(255)  NULL,
    [QPP_State__c] varchar(255)  NULL,
    [QPP_Zip_Code__c] varchar(12)  NULL,
    [Tier__c] varchar(45)  NULL,
    [Participating_LOB__c] varchar(255)  NULL,
    [Doing_Business_As__c] varchar(255)  NULL,
    [OA_User_ID__c] varchar(20)  NULL,
    [CHEMO_FEE_SCHEDULE__c] varchar(255)  NULL,
    [For_Deletion__c] varchar(255)  NULL,
    [Healthcare_Provider_Taxonomy_Code_2__c] varchar(255)  NULL,
    [MailingGeocodeAccuracy] varchar(255)  NULL,
    [OtherGeocodeAccuracy] varchar(255)  NULL,
    [OtherState] varchar(255)  NULL,
    [Provider_Update_Form_Recevied__c] varchar(255)  NULL,
    [Quarterly_QPP__c] varchar(255)  NULL,
    [ReportsToId] varchar(255)  NULL,
    [Taxonomy_Text__c] varchar(255)  NULL,
    [QPp_Opt_Out__c] varchar(255)  NULL,
    [Contact_Synchronization__c] varchar(250)  NULL
);
GO

-- Creating table 'SideEffects'
CREATE TABLE [dbo].[SideEffects] (
    [SideEffectID] int IDENTITY(1,1) NOT NULL,
    [FaxParamSideEffectID] smallint  NOT NULL,
    [AttentionLevel] bit  NOT NULL,
    [Description] nvarchar(max)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'States'
CREATE TABLE [dbo].[States] (
    [StateCode] varchar(2)  NOT NULL,
    [StateName] varchar(50)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'StateOutofScopeRules'
CREATE TABLE [dbo].[StateOutofScopeRules] (
    [StateOutofScopeRuleID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] int  NOT NULL,
    [StateCode] varchar(10)  NULL,
    [EligibilityStateFieldTypeID] smallint  NULL,
    [Active] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'StepTherapyRules'
CREATE TABLE [dbo].[StepTherapyRules] (
    [StepTherapyRuleID] int IDENTITY(1,1) NOT NULL,
    [RuleID] int  NOT NULL,
    [DrugID] int  NOT NULL,
    [RuleConditionID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'StepTherapyRuleDiagnosisExcludeds'
CREATE TABLE [dbo].[StepTherapyRuleDiagnosisExcludeds] (
    [StepTherapyRuleDiagnosisExcludedID] int IDENTITY(1,1) NOT NULL,
    [StepTherapyRuleID] int  NOT NULL,
    [DiagnosisID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'StepTherapyRulePatientCancerStageExcludeds'
CREATE TABLE [dbo].[StepTherapyRulePatientCancerStageExcludeds] (
    [StepTherapyRulePatientCancerStageExcludedID] int IDENTITY(1,1) NOT NULL,
    [StepTherapyRuleID] int  NOT NULL,
    [CancerStageID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'StepTherapyRulePriorDrugs'
CREATE TABLE [dbo].[StepTherapyRulePriorDrugs] (
    [StepTherapyRulePriorDrugID] int IDENTITY(1,1) NOT NULL,
    [StepTherapyRuleID] int  NOT NULL,
    [PriorDrugID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'StepTherapyStateExcludeds'
CREATE TABLE [dbo].[StepTherapyStateExcludeds] (
    [StepTherapyStateExcludedID] int IDENTITY(1,1) NOT NULL,
    [StepTherapyRuleID] int  NOT NULL,
    [StateCode] varchar(2)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'StepTherapyStateOfPlanIssueExcludeds'
CREATE TABLE [dbo].[StepTherapyStateOfPlanIssueExcludeds] (
    [StepTherapyStateOfPlanIssueExcludedID] int IDENTITY(1,1) NOT NULL,
    [StepTherapyRuleID] int  NOT NULL,
    [StateCode] varchar(2)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'StopLossRules'
CREATE TABLE [dbo].[StopLossRules] (
    [StopLossRuleID] int IDENTITY(1,1) NOT NULL,
    [RuleID] int  NOT NULL,
    [DrugID] int  NOT NULL,
    [BrandDrugID] int  NULL,
    [StopLossDrugID] int  NULL,
    [CountyID] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'SupportedProtocolConfigurations'
CREATE TABLE [dbo].[SupportedProtocolConfigurations] (
    [SupportedProtocolConfigurationID] int IDENTITY(1,1) NOT NULL,
    [ProtocolID] int  NOT NULL,
    [EmetogenicPotentialID] smallint  NULL,
    [FebrileNeutropeniaRiskID] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'sysdiagrams'
CREATE TABLE [dbo].[sysdiagrams] (
    [name] nvarchar(128)  NOT NULL,
    [principal_id] int  NOT NULL,
    [diagram_id] int IDENTITY(1,1) NOT NULL,
    [version] int  NULL,
    [definition] varbinary(max)  NULL
);
GO

-- Creating table 'sysssislogs'
CREATE TABLE [dbo].[sysssislogs] (
    [id] int IDENTITY(1,1) NOT NULL,
    [event] nvarchar(128)  NOT NULL,
    [computer] nvarchar(128)  NOT NULL,
    [operator] nvarchar(128)  NOT NULL,
    [source] nvarchar(1024)  NOT NULL,
    [sourceid] uniqueidentifier  NOT NULL,
    [executionid] uniqueidentifier  NOT NULL,
    [starttime] datetime  NOT NULL,
    [endtime] datetime  NOT NULL,
    [datacode] int  NOT NULL,
    [databytes] varbinary(max)  NULL,
    [message] nvarchar(2048)  NOT NULL
);
GO

-- Creating table 'SystemConfigurations'
CREATE TABLE [dbo].[SystemConfigurations] (
    [UniqueName] varchar(50)  NOT NULL,
    [Value] varchar(1000)  NOT NULL,
    [RegExpression] varchar(255)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'TATConfigurations'
CREATE TABLE [dbo].[TATConfigurations] (
    [TATConfigurationID] smallint IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [LineOfBusinessID] smallint  NULL,
    [StateCode] varchar(2)  NULL,
    [NonUrgent] smallint  NOT NULL,
    [Urgent] smallint  NOT NULL,
    [Retrospective] smallint  NOT NULL,
    [TATForPartD_Deprecated] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [TreatmentTypeID] smallint  NULL,
    [RequestTypeID] smallint  NULL
);
GO

-- Creating table 'TatEvents'
CREATE TABLE [dbo].[TatEvents] (
    [TatEventId] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentId] int  NOT NULL,
    [EventTypeId] smallint  NOT NULL,
    [Source] varchar(50)  NOT NULL,
    [EventTimeStamp] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [Priority] nvarchar(20)  NULL,
    [ReviewStageId] smallint  NULL,
    [IsStepTherapyApplicable] bit  NULL
);
GO

-- Creating table 'TatExtensionConfigurations'
CREATE TABLE [dbo].[TatExtensionConfigurations] (
    [TatExtensionConfigurationID] smallint IDENTITY(1,1) NOT NULL,
    [State] varchar(2)  NULL,
    [LineOfBusiness] varchar(100)  NULL,
    [AssignmentPriority] varchar(100)  NULL,
    [TypeOfDeterminationID] smallint  NULL,
    [PartD] bit  NULL,
    [Priority] smallint  NOT NULL,
    [ExtensionDays] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'TATNotifications'
CREATE TABLE [dbo].[TATNotifications] (
    [AssignmentNotificationConfigurationID] int IDENTITY(1,1) NOT NULL,
    [Title] varchar(128)  NOT NULL,
    [DurationFrom] int  NOT NULL,
    [DurationTo] int  NOT NULL,
    [Selected] bit  NOT NULL,
    [SelectedColor] varchar(50)  NOT NULL,
    [SortOrder] int  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'Users'
CREATE TABLE [dbo].[Users] (
    [UserID] int IDENTITY(1,1) NOT NULL,
    [FirstName] nvarchar(50)  NOT NULL,
    [LastName] nvarchar(50)  NOT NULL,
    [Username] varchar(128)  NOT NULL,
    [Password] varchar(255)  NOT NULL,
    [PasswordSalt] varchar(255)  NULL,
    [PasswordResetToken] varchar(255)  NULL,
    [ResetPassword] bit  NULL,
    [StatusID] smallint  NOT NULL,
    [UserGroupID] smallint  NOT NULL,
    [PracticeName] varchar(100)  NULL,
    [Specialty] varchar(50)  NULL,
    [UserTaxID] varchar(15)  NULL,
    [LastUsedTaxID] varchar(15)  NULL,
    [UserNPI] varchar(15)  NULL,
    [LastUsedNPI] varchar(15)  NULL,
    [LegacyID] int  NULL,
    [SalesforceContactID] varchar(100)  NULL,
    [SalesforceAccountID] varchar(100)  NULL,
    [PasswordMigratedToNewSystem] bit  NOT NULL,
    [PasswordResetTokenExpiration] datetime  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [Title] nvarchar(255)  NULL,
    [LoginAttempts] smallint  NULL,
    [OAUserSpecialty] varchar(255)  NULL,
    [MigrateUser] bit  NULL,
    [UserEmail] nvarchar(255)  NULL,
    [LanguageTranslator] bit  NULL,
    [EmailValidated] bit  NOT NULL,
    [IsEmailLegitimate] bit  NOT NULL,
    [PayerID] smallint  NULL
);
GO

-- Creating table 'User_MemberAssociation'
CREATE TABLE [dbo].[User_MemberAssociation] (
    [UserMemberAssociationID] int IDENTITY(1,1) NOT NULL,
    [UserID] int  NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'User_SecurityGroup'
CREATE TABLE [dbo].[User_SecurityGroup] (
    [UserSecurityGroupID] int IDENTITY(1,1) NOT NULL,
    [SecurityGroupID] smallint  NOT NULL,
    [UserID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'UserAccessLists'
CREATE TABLE [dbo].[UserAccessLists] (
    [UserAccessListID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NULL,
    [AccessID] int  NOT NULL,
    [Deleted] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'UserAccessList_Provider'
CREATE TABLE [dbo].[UserAccessList_Provider] (
    [UserAccessList_ProviderID] int IDENTITY(1,1) NOT NULL,
    [ProviderID] int  NOT NULL,
    [UserAccessListID] int  NOT NULL,
    [Deleted] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'UserAddresses'
CREATE TABLE [dbo].[UserAddresses] (
    [UserAddressID] smallint IDENTITY(1,1) NOT NULL,
    [UserID] int  NOT NULL,
    [AddressType] smallint  NOT NULL,
    [AddressLine1] varchar(100)  NOT NULL,
    [AddressLine2] varchar(100)  NULL,
    [City] varchar(32)  NOT NULL,
    [StateCode] varchar(2)  NOT NULL,
    [Zip] varchar(10)  NOT NULL,
    [CountyID] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'UserAreaCodes'
CREATE TABLE [dbo].[UserAreaCodes] (
    [UserAreaCodeID] int IDENTITY(1,1) NOT NULL,
    [AreaCodeID] int  NOT NULL,
    [UserID] int  NOT NULL,
    [AreaCode] nvarchar(10)  NULL,
    [Active] bit  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [StartDate] datetime  NULL,
    [EndDate] datetime  NULL,
    [CreatedBy] int  NOT NULL
);
GO

-- Creating table 'UserCaseAcceptanceTimes'
CREATE TABLE [dbo].[UserCaseAcceptanceTimes] (
    [UserCaseAcceptanceTimeID] int IDENTITY(1,1) NOT NULL,
    [UserID] int  NOT NULL,
    [CaseAcceptanceDate] datetime  NOT NULL,
    [StartTime] time  NOT NULL,
    [EndTime] time  NULL,
    [Active] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'UserContacts'
CREATE TABLE [dbo].[UserContacts] (
    [UserContactID] smallint IDENTITY(1,1) NOT NULL,
    [UserID] int  NOT NULL,
    [ContactType] smallint  NOT NULL,
    [ContactNumber] varchar(100)  NOT NULL,
    [Extension] varchar(6)  NULL,
    [PrimaryContact] bit  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'UserFeedbacks'
CREATE TABLE [dbo].[UserFeedbacks] (
    [UserFeedbackID] int IDENTITY(1,1) NOT NULL,
    [UserEmail] varchar(320)  NOT NULL,
    [Comments] varchar(2000)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [Name] nvarchar(200)  NULL,
    [Phone] nvarchar(100)  NULL,
    [SubjectID] smallint  NULL,
    [SubjectText] nvarchar(100)  NULL,
    [StatusID] smallint  NULL,
    [OAComments] nvarchar(2000)  NULL
);
GO

-- Creating table 'UserLicenses'
CREATE TABLE [dbo].[UserLicenses] (
    [UserLicenseID] int IDENTITY(1,1) NOT NULL,
    [UserID] int  NOT NULL,
    [StateCode] varchar(2)  NOT NULL,
    [LicenseID] varchar(50)  NULL,
    [LicenseTypeID] smallint  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'UserLoginActivities'
CREATE TABLE [dbo].[UserLoginActivities] (
    [UserLoginActivityID] int IDENTITY(1,1) NOT NULL,
    [UserID] int  NULL,
    [UserName] nvarchar(128)  NOT NULL,
    [IPAddress] varchar(50)  NOT NULL,
    [Browser] varchar(50)  NOT NULL,
    [SessionID] nvarchar(255)  NOT NULL,
    [LoginStatus] bit  NOT NULL,
    [LoggedinDateTime] datetime  NOT NULL,
    [LogoutDateTime] datetime  NULL,
    [UserEmail] nvarchar(255)  NULL
);
GO

-- Creating table 'UserProfileSettings'
CREATE TABLE [dbo].[UserProfileSettings] (
    [UserProfileSettingID] int IDENTITY(1,1) NOT NULL,
    [UserID] int  NOT NULL,
    [ProfileSettingID] int  NOT NULL,
    [Value] varchar(50)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'VerificationCodeActivities'
CREATE TABLE [dbo].[VerificationCodeActivities] (
    [VerificationCodeActivityID] int IDENTITY(1,1) NOT NULL,
    [UserEmail] nvarchar(255)  NOT NULL,
    [VerificationCode] varchar(6)  NOT NULL,
    [VerificationCodeExpiration] datetime  NOT NULL,
    [CodeVerified] bit  NOT NULL,
    [EmailVerificationSkipped] bit  NOT NULL,
    [ReasonID] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'WorkFlowQueueConfigurations'
CREATE TABLE [dbo].[WorkFlowQueueConfigurations] (
    [WorkFlowQueueConfigurationID] int IDENTITY(1,1) NOT NULL,
    [WorkFlowStatusID] smallint  NOT NULL,
    [WorkQueueID] tinyint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL
);
GO

-- Creating table 'WorkQueues'
CREATE TABLE [dbo].[WorkQueues] (
    [WorkQueueID] tinyint IDENTITY(1,1) NOT NULL,
    [QueueName] varchar(128)  NOT NULL,
    [Description] varchar(512)  NULL,
    [Active] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'WorkQueue_SecurityGroup'
CREATE TABLE [dbo].[WorkQueue_SecurityGroup] (
    [WorkQueueSecurityGroupID] int IDENTITY(1,1) NOT NULL,
    [SecurityGroupID] smallint  NOT NULL,
    [WorkQueueID] tinyint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DMSSTAT_RSTATS'
CREATE TABLE [dbo].[DMSSTAT_RSTATS] (
    [runid] varchar(250)  NOT NULL,
    [ruleid] varchar(50)  NOT NULL,
    [ruleblock] int  NOT NULL,
    [rulenum] int  NOT NULL,
    [rulesubscript] int  NOT NULL,
    [ruletype] varchar(50)  NOT NULL,
    [rulecreated] datetime  NOT NULL,
    [ruleupdated] datetime  NOT NULL,
    [secondsactive] int  NOT NULL,
    [rulestatus] char(1)  NOT NULL,
    [rulesource] varchar(250)  NULL,
    [ruletarget] varchar(250)  NULL,
    [rowoperations] bigint  NULL,
    [coloperations] bigint  NULL,
    [rulePrevRPN] int  NULL,
    [ruleRPN] int  NULL
);
GO

-- Creating table 'DMSSTAT_TSTATS'
CREATE TABLE [dbo].[DMSSTAT_TSTATS] (
    [runid] varchar(250)  NOT NULL,
    [ruleid] varchar(50)  NOT NULL,
    [statscreated] datetime  NOT NULL,
    [statsupdated] datetime  NOT NULL,
    [ruletype] varchar(50)  NOT NULL,
    [ruleblock] int  NOT NULL,
    [rulenum] int  NOT NULL,
    [rulesubscript] int  NOT NULL,
    [controllerid] varchar(50)  NULL,
    [tabledatabase] varchar(250)  NOT NULL,
    [tableschema] varchar(250)  NOT NULL,
    [tablename] varchar(250)  NOT NULL,
    [tablecolumn] varchar(250)  NULL,
    [rowoperations] bigint  NULL,
    [coloperations] bigint  NULL
);
GO

-- Creating table 'PatientProtocolAssignment_VitalSign'
CREATE TABLE [dbo].[PatientProtocolAssignment_VitalSign] (
    [PatientProtocolAssignmentVitalSignID] int IDENTITY(1,1) NOT NULL,
    [PatientProtocolAssignmentID] int  NOT NULL,
    [Weight] decimal(14,10)  NULL,
    [Height] decimal(14,10)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'DynamicFaxContents'
CREATE TABLE [dbo].[DynamicFaxContents] (
    [DynamicFaxContentID] int  NOT NULL,
    [ParLanguage] varchar(1500)  NULL,
    [Footer] varchar(1000)  NULL,
    [CompanyReferenceLong] varchar(1000)  NULL,
    [CompanyReferenceShort] varchar(100)  NULL,
    [AppealLanguageID] int  NULL,
    [LogoImageID] int  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL,
    [ProviderNetworkCheck] varchar(100)  NULL,
    [PeerToPeerLanguage] varchar(1000)  NULL,
    [GuideToAppealingInsuranceDenialsID] int  NULL,
    [ExternalAppealsApplicationID] int  NULL,
    [PartialDenialCoverageLanguage] varchar(1500)  NULL,
    [DenialTypeLanguage1] varchar(100)  NULL,
    [DenialTypeLanguage2] varchar(100)  NULL,
    [HelpInfoID] int  NULL,
    [HMOSpecificLanguage] nvarchar(256)  NULL,
    [LetterTitle] varchar(128)  NULL,
    [CompanyNameLabel] varchar(64)  NULL,
    [OAAddress] varchar(256)  NULL,
    [OAPhone] varchar(32)  NULL,
    [OAFax] varchar(32)  NULL,
    [OAEmail] varchar(64)  NULL,
    [OAName] varchar(64)  NULL,
    [PriorityLanguage] nvarchar(500)  NULL,
    [HealthPlanMailingAddress] nvarchar(256)  NULL,
    [DenialHealthcareAdvocateInfoID] int  NULL,
    [AppealContactLanguage] varchar(1500)  NULL,
    [WhiteBaggingPayerMessage] nvarchar(500)  NULL,
    [CustomerServiceNumber] varchar(15)  NULL,
    [CustomerServiceHours] nvarchar(500)  NULL,
    [CustomerServiceWebsite] varchar(256)  NULL
);
GO

-- Creating table 'ExcludedPCPs'
CREATE TABLE [dbo].[ExcludedPCPs] (
    [ExcludedPCPID] int IDENTITY(1,1) NOT NULL,
    [InsuranceProviderID] smallint  NOT NULL,
    [PCP_NPI] varchar(16)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'SpecialtyDrugCodes'
CREATE TABLE [dbo].[SpecialtyDrugCodes] (
    [SpecialtyDrugCodeID] int IDENTITY(1,1) NOT NULL,
    [DimPayerID] int  NOT NULL,
    [DrugCodeID] int  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- Creating table 'LineOfBusiness_CAGSetting'
CREATE TABLE [dbo].[LineOfBusiness_CAGSetting] (
    [LineOfBusiness_CAGSettingId] smallint IDENTITY(1,1) NOT NULL,
    [LineOfBusinessId] smallint  NOT NULL,
    [IsCarrierIdOptional] bit  NOT NULL,
    [IsAccountIdOptional] bit  NOT NULL,
    [IsGroupIdOptional] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedOn] datetime  NOT NULL,
    [ModifiedBy] int  NULL,
    [ModifiedOn] datetime  NULL,
    [Deleted] bit  NOT NULL,
    [DeletedBy] int  NULL,
    [DeletedOn] datetime  NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [PatientProtocolAssignmentProtocolID] in table 'PatientProtocolAssignment_ProtocolExtraInfo'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolExtraInfo]
ADD CONSTRAINT [PK_PatientProtocolAssignment_ProtocolExtraInfo]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentProtocolID] ASC);
GO

-- Creating primary key on [OperationKey] in table 'C__RefactorLog'
ALTER TABLE [dbo].[C__RefactorLog]
ADD CONSTRAINT [PK_C__RefactorLog]
    PRIMARY KEY CLUSTERED ([OperationKey] ASC);
GO

-- Creating primary key on [LifeExpectancyDescriptionID] in table 'ActiveSruveillanceLifeExpectancyDescriptions'
ALTER TABLE [dbo].[ActiveSruveillanceLifeExpectancyDescriptions]
ADD CONSTRAINT [PK_ActiveSruveillanceLifeExpectancyDescriptions]
    PRIMARY KEY CLUSTERED ([LifeExpectancyDescriptionID] ASC);
GO

-- Creating primary key on [LifeExpectancyID] in table 'ActiveSurveillanceLifeExpectancies'
ALTER TABLE [dbo].[ActiveSurveillanceLifeExpectancies]
ADD CONSTRAINT [PK_ActiveSurveillanceLifeExpectancies]
    PRIMARY KEY CLUSTERED ([LifeExpectancyID] ASC);
GO

-- Creating primary key on [AddressID] in table 'Addresses'
ALTER TABLE [dbo].[Addresses]
ADD CONSTRAINT [PK_Addresses]
    PRIMARY KEY CLUSTERED ([AddressID] ASC);
GO

-- Creating primary key on [AggregationID] in table 'Aggregations'
ALTER TABLE [dbo].[Aggregations]
ADD CONSTRAINT [PK_Aggregations]
    PRIMARY KEY CLUSTERED ([AggregationID] ASC);
GO

-- Creating primary key on [AggregationResolutionID] in table 'AggregationResolutions'
ALTER TABLE [dbo].[AggregationResolutions]
ADD CONSTRAINT [PK_AggregationResolutions]
    PRIMARY KEY CLUSTERED ([AggregationResolutionID] ASC);
GO

-- Creating primary key on [AggregationRuleID] in table 'AggregationRules'
ALTER TABLE [dbo].[AggregationRules]
ADD CONSTRAINT [PK_AggregationRules]
    PRIMARY KEY CLUSTERED ([AggregationRuleID] ASC);
GO

-- Creating primary key on [ApprovedDrugsOverturnListID] in table 'ApprovedDrugsOverturnLists'
ALTER TABLE [dbo].[ApprovedDrugsOverturnLists]
ADD CONSTRAINT [PK_ApprovedDrugsOverturnLists]
    PRIMARY KEY CLUSTERED ([ApprovedDrugsOverturnListID] ASC);
GO

-- Creating primary key on [AreaCodeID] in table 'AreaCodeLookupElements'
ALTER TABLE [dbo].[AreaCodeLookupElements]
ADD CONSTRAINT [PK_AreaCodeLookupElements]
    PRIMARY KEY CLUSTERED ([AreaCodeID] ASC);
GO

-- Creating primary key on [AssessmentDiagnosisID] in table 'AssessmentDiagnosis'
ALTER TABLE [dbo].[AssessmentDiagnosis]
ADD CONSTRAINT [PK_AssessmentDiagnosis]
    PRIMARY KEY CLUSTERED ([AssessmentDiagnosisID] ASC);
GO

-- Creating primary key on [AssessmentQuestionID] in table 'AssessmentQuestions'
ALTER TABLE [dbo].[AssessmentQuestions]
ADD CONSTRAINT [PK_AssessmentQuestions]
    PRIMARY KEY CLUSTERED ([AssessmentQuestionID] ASC);
GO

-- Creating primary key on [AssessmentQuestionPossibleAnswerID] in table 'AssessmentQuestionPossibleAnswers'
ALTER TABLE [dbo].[AssessmentQuestionPossibleAnswers]
ADD CONSTRAINT [PK_AssessmentQuestionPossibleAnswers]
    PRIMARY KEY CLUSTERED ([AssessmentQuestionPossibleAnswerID] ASC);
GO

-- Creating primary key on [AssessmentTypeID] in table 'AssessmentTypes'
ALTER TABLE [dbo].[AssessmentTypes]
ADD CONSTRAINT [PK_AssessmentTypes]
    PRIMARY KEY CLUSTERED ([AssessmentTypeID] ASC);
GO

-- Creating primary key on [AssessmentTypeAssessmentQuestionID] in table 'AssessmentType_AssessmentQuestion'
ALTER TABLE [dbo].[AssessmentType_AssessmentQuestion]
ADD CONSTRAINT [PK_AssessmentType_AssessmentQuestion]
    PRIMARY KEY CLUSTERED ([AssessmentTypeAssessmentQuestionID] ASC);
GO

-- Creating primary key on [AssignmentActionID] in table 'AssignmentActions'
ALTER TABLE [dbo].[AssignmentActions]
ADD CONSTRAINT [PK_AssignmentActions]
    PRIMARY KEY CLUSTERED ([AssignmentActionID] ASC);
GO

-- Creating primary key on [AssignmentLockByUserID] in table 'AssignmentLockByUsers'
ALTER TABLE [dbo].[AssignmentLockByUsers]
ADD CONSTRAINT [PK_AssignmentLockByUsers]
    PRIMARY KEY CLUSTERED ([AssignmentLockByUserID] ASC);
GO

-- Creating primary key on [AssignmentProviderID] in table 'AssignmentProviders'
ALTER TABLE [dbo].[AssignmentProviders]
ADD CONSTRAINT [PK_AssignmentProviders]
    PRIMARY KEY CLUSTERED ([AssignmentProviderID] ASC);
GO

-- Creating primary key on [AssignmentResponceID] in table 'AssignmentResponces'
ALTER TABLE [dbo].[AssignmentResponces]
ADD CONSTRAINT [PK_AssignmentResponces]
    PRIMARY KEY CLUSTERED ([AssignmentResponceID] ASC);
GO

-- Creating primary key on [AssignmentTimeZoneID] in table 'AssignmentTimeZones'
ALTER TABLE [dbo].[AssignmentTimeZones]
ADD CONSTRAINT [PK_AssignmentTimeZones]
    PRIMARY KEY CLUSTERED ([AssignmentTimeZoneID] ASC);
GO

-- Creating primary key on [AssignmentWorkflowStatusLogID] in table 'AssignmentWorkflowStatusLogs'
ALTER TABLE [dbo].[AssignmentWorkflowStatusLogs]
ADD CONSTRAINT [PK_AssignmentWorkflowStatusLogs]
    PRIMARY KEY CLUSTERED ([AssignmentWorkflowStatusLogID] ASC);
GO

-- Creating primary key on [DocumentRepositoryID] in table 'Attachments'
ALTER TABLE [dbo].[Attachments]
ADD CONSTRAINT [PK_Attachments]
    PRIMARY KEY CLUSTERED ([DocumentRepositoryID] ASC);
GO

-- Creating primary key on [FieldID] in table 'AuditTrailFields'
ALTER TABLE [dbo].[AuditTrailFields]
ADD CONSTRAINT [PK_AuditTrailFields]
    PRIMARY KEY CLUSTERED ([FieldID] ASC);
GO

-- Creating primary key on [ObjectTypeID] in table 'AuditTrailObjectTypes'
ALTER TABLE [dbo].[AuditTrailObjectTypes]
ADD CONSTRAINT [PK_AuditTrailObjectTypes]
    PRIMARY KEY CLUSTERED ([ObjectTypeID] ASC);
GO

-- Creating primary key on [AuditTrailTransactionID] in table 'AuditTrailTransactions'
ALTER TABLE [dbo].[AuditTrailTransactions]
ADD CONSTRAINT [PK_AuditTrailTransactions]
    PRIMARY KEY CLUSTERED ([AuditTrailTransactionID] ASC);
GO

-- Creating primary key on [AuditTrailTransactionDetailID] in table 'AuditTrailTransactionDetails'
ALTER TABLE [dbo].[AuditTrailTransactionDetails]
ADD CONSTRAINT [PK_AuditTrailTransactionDetails]
    PRIMARY KEY CLUSTERED ([AuditTrailTransactionDetailID] ASC);
GO

-- Creating primary key on [AutoProtocolConfigurationID] in table 'AutoProtocolConfigurations'
ALTER TABLE [dbo].[AutoProtocolConfigurations]
ADD CONSTRAINT [PK_AutoProtocolConfigurations]
    PRIMARY KEY CLUSTERED ([AutoProtocolConfigurationID] ASC);
GO

-- Creating primary key on [BrandDrugID] in table 'BrandDrugs'
ALTER TABLE [dbo].[BrandDrugs]
ADD CONSTRAINT [PK_BrandDrugs]
    PRIMARY KEY CLUSTERED ([BrandDrugID] ASC);
GO

-- Creating primary key on [BrandDrugCodeID] in table 'BrandDrugCodes'
ALTER TABLE [dbo].[BrandDrugCodes]
ADD CONSTRAINT [PK_BrandDrugCodes]
    PRIMARY KEY CLUSTERED ([BrandDrugCodeID] ASC);
GO

-- Creating primary key on [CallerContactDetailID] in table 'CallerContactDetails'
ALTER TABLE [dbo].[CallerContactDetails]
ADD CONSTRAINT [PK_CallerContactDetails]
    PRIMARY KEY CLUSTERED ([CallerContactDetailID] ASC);
GO

-- Creating primary key on [ClaimServiceLogID] in table 'ClaimServiceLogs'
ALTER TABLE [dbo].[ClaimServiceLogs]
ADD CONSTRAINT [PK_ClaimServiceLogs]
    PRIMARY KEY CLUSTERED ([ClaimServiceLogID] ASC);
GO

-- Creating primary key on [ClinicalObservationId] in table 'ClinicalObservations'
ALTER TABLE [dbo].[ClinicalObservations]
ADD CONSTRAINT [PK_ClinicalObservations]
    PRIMARY KEY CLUSTERED ([ClinicalObservationId] ASC);
GO

-- Creating primary key on [ClinicalObservationLabResultID] in table 'ClinicalObservationLabResults'
ALTER TABLE [dbo].[ClinicalObservationLabResults]
ADD CONSTRAINT [PK_ClinicalObservationLabResults]
    PRIMARY KEY CLUSTERED ([ClinicalObservationLabResultID] ASC);
GO

-- Creating primary key on [ClinicalQuestionId] in table 'ClinicalQuestions'
ALTER TABLE [dbo].[ClinicalQuestions]
ADD CONSTRAINT [PK_ClinicalQuestions]
    PRIMARY KEY CLUSTERED ([ClinicalQuestionId] ASC);
GO

-- Creating primary key on [ClinicalQuestionAnswerId] in table 'ClinicalQuestionAnswers'
ALTER TABLE [dbo].[ClinicalQuestionAnswers]
ADD CONSTRAINT [PK_ClinicalQuestionAnswers]
    PRIMARY KEY CLUSTERED ([ClinicalQuestionAnswerId] ASC);
GO

-- Creating primary key on [ClinicalQuestionDiagnosisId] in table 'ClinicalQuestionDiagnosis'
ALTER TABLE [dbo].[ClinicalQuestionDiagnosis]
ADD CONSTRAINT [PK_ClinicalQuestionDiagnosis]
    PRIMARY KEY CLUSTERED ([ClinicalQuestionDiagnosisId] ASC);
GO

-- Creating primary key on [ClinicalValuesRuleID] in table 'ClinicalValuesRules'
ALTER TABLE [dbo].[ClinicalValuesRules]
ADD CONSTRAINT [PK_ClinicalValuesRules]
    PRIMARY KEY CLUSTERED ([ClinicalValuesRuleID] ASC);
GO

-- Creating primary key on [ClinicalValuesRuleDiagnosisExcludedID] in table 'ClinicalValuesRuleDiagnosisExcludeds'
ALTER TABLE [dbo].[ClinicalValuesRuleDiagnosisExcludeds]
ADD CONSTRAINT [PK_ClinicalValuesRuleDiagnosisExcludeds]
    PRIMARY KEY CLUSTERED ([ClinicalValuesRuleDiagnosisExcludedID] ASC);
GO

-- Creating primary key on [ClinicalValuesRuleLabResultID] in table 'ClinicalValuesRuleLabResults'
ALTER TABLE [dbo].[ClinicalValuesRuleLabResults]
ADD CONSTRAINT [PK_ClinicalValuesRuleLabResults]
    PRIMARY KEY CLUSTERED ([ClinicalValuesRuleLabResultID] ASC);
GO

-- Creating primary key on [ID] in table 'CMSProviderRRContacts'
ALTER TABLE [dbo].[CMSProviderRRContacts]
ADD CONSTRAINT [PK_CMSProviderRRContacts]
    PRIMARY KEY CLUSTERED ([ID] ASC);
GO

-- Creating primary key on [ContactID] in table 'Contacts'
ALTER TABLE [dbo].[Contacts]
ADD CONSTRAINT [PK_Contacts]
    PRIMARY KEY CLUSTERED ([ContactID] ASC);
GO

-- Creating primary key on [CountyID] in table 'Counties'
ALTER TABLE [dbo].[Counties]
ADD CONSTRAINT [PK_Counties]
    PRIMARY KEY CLUSTERED ([CountyID] ASC);
GO

-- Creating primary key on [CPTCodeXRTID] in table 'CPTCodeXRTs'
ALTER TABLE [dbo].[CPTCodeXRTs]
ADD CONSTRAINT [PK_CPTCodeXRTs]
    PRIMARY KEY CLUSTERED ([CPTCodeXRTID] ASC);
GO

-- Creating primary key on [DayLightSavingChangeDateID] in table 'DayLightSavingChangeDates'
ALTER TABLE [dbo].[DayLightSavingChangeDates]
ADD CONSTRAINT [PK_DayLightSavingChangeDates]
    PRIMARY KEY CLUSTERED ([DayLightSavingChangeDateID] ASC);
GO

-- Creating primary key on [DecisionReasonID] in table 'DecisionReasons'
ALTER TABLE [dbo].[DecisionReasons]
ADD CONSTRAINT [PK_DecisionReasons]
    PRIMARY KEY CLUSTERED ([DecisionReasonID] ASC);
GO

-- Creating primary key on [DecisionReasonElementID] in table 'DecisionReasonElements'
ALTER TABLE [dbo].[DecisionReasonElements]
ADD CONSTRAINT [PK_DecisionReasonElements]
    PRIMARY KEY CLUSTERED ([DecisionReasonElementID] ASC);
GO

-- Creating primary key on [DecisionReasonElementRequestTypeID] in table 'DecisionReasonElementRequestTypes'
ALTER TABLE [dbo].[DecisionReasonElementRequestTypes]
ADD CONSTRAINT [PK_DecisionReasonElementRequestTypes]
    PRIMARY KEY CLUSTERED ([DecisionReasonElementRequestTypeID] ASC);
GO

-- Creating primary key on [DiagnosisID] in table 'Diagnosis'
ALTER TABLE [dbo].[Diagnosis]
ADD CONSTRAINT [PK_Diagnosis]
    PRIMARY KEY CLUSTERED ([DiagnosisID] ASC);
GO

-- Creating primary key on [DiagnosisMetastaticSiteID] in table 'Diagnosis_MetastaticSite'
ALTER TABLE [dbo].[Diagnosis_MetastaticSite]
ADD CONSTRAINT [PK_Diagnosis_MetastaticSite]
    PRIMARY KEY CLUSTERED ([DiagnosisMetastaticSiteID] ASC);
GO

-- Creating primary key on [DiagnosisClinicalNarrativeID] in table 'DiagnosisClinicalNarratives'
ALTER TABLE [dbo].[DiagnosisClinicalNarratives]
ADD CONSTRAINT [PK_DiagnosisClinicalNarratives]
    PRIMARY KEY CLUSTERED ([DiagnosisClinicalNarrativeID] ASC);
GO

-- Creating primary key on [DiagnosisClinicalTrialLinkID] in table 'DiagnosisClinicalTrialLinks'
ALTER TABLE [dbo].[DiagnosisClinicalTrialLinks]
ADD CONSTRAINT [PK_DiagnosisClinicalTrialLinks]
    PRIMARY KEY CLUSTERED ([DiagnosisClinicalTrialLinkID] ASC);
GO

-- Creating primary key on [DiagnosisConfigurationID] in table 'DiagnosisConfigurations'
ALTER TABLE [dbo].[DiagnosisConfigurations]
ADD CONSTRAINT [PK_DiagnosisConfigurations]
    PRIMARY KEY CLUSTERED ([DiagnosisConfigurationID] ASC);
GO

-- Creating primary key on [DiagnosisDistantMetaStasisID] in table 'DiagnosisDistantMetaStasis'
ALTER TABLE [dbo].[DiagnosisDistantMetaStasis]
ADD CONSTRAINT [PK_DiagnosisDistantMetaStasis]
    PRIMARY KEY CLUSTERED ([DiagnosisDistantMetaStasisID] ASC);
GO

-- Creating primary key on [DiagnosisICDCodeID] in table 'DiagnosisICDCodes'
ALTER TABLE [dbo].[DiagnosisICDCodes]
ADD CONSTRAINT [PK_DiagnosisICDCodes]
    PRIMARY KEY CLUSTERED ([DiagnosisICDCodeID] ASC);
GO

-- Creating primary key on [DiagnosisLineOfTherapyID] in table 'DiagnosisLineOfTherapies'
ALTER TABLE [dbo].[DiagnosisLineOfTherapies]
ADD CONSTRAINT [PK_DiagnosisLineOfTherapies]
    PRIMARY KEY CLUSTERED ([DiagnosisLineOfTherapyID] ASC);
GO

-- Creating primary key on [DiagnosisLocalizedDiseaseID] in table 'DiagnosisLocalizedDiseases'
ALTER TABLE [dbo].[DiagnosisLocalizedDiseases]
ADD CONSTRAINT [PK_DiagnosisLocalizedDiseases]
    PRIMARY KEY CLUSTERED ([DiagnosisLocalizedDiseaseID] ASC);
GO

-- Creating primary key on [DiagnosisLocalizedDiseaseStageID] in table 'DiagnosisLocalizedDiseaseStages'
ALTER TABLE [dbo].[DiagnosisLocalizedDiseaseStages]
ADD CONSTRAINT [PK_DiagnosisLocalizedDiseaseStages]
    PRIMARY KEY CLUSTERED ([DiagnosisLocalizedDiseaseStageID] ASC);
GO

-- Creating primary key on [DiagnosisMolecularMarkerID] in table 'DiagnosisMolecularMarkers'
ALTER TABLE [dbo].[DiagnosisMolecularMarkers]
ADD CONSTRAINT [PK_DiagnosisMolecularMarkers]
    PRIMARY KEY CLUSTERED ([DiagnosisMolecularMarkerID] ASC);
GO

-- Creating primary key on [DiagnosisNodalStatusID] in table 'DiagnosisNodalStatus'
ALTER TABLE [dbo].[DiagnosisNodalStatus]
ADD CONSTRAINT [PK_DiagnosisNodalStatus]
    PRIMARY KEY CLUSTERED ([DiagnosisNodalStatusID] ASC);
GO

-- Creating primary key on [DiagnosisOptionID] in table 'DiagnosisOptions'
ALTER TABLE [dbo].[DiagnosisOptions]
ADD CONSTRAINT [PK_DiagnosisOptions]
    PRIMARY KEY CLUSTERED ([DiagnosisOptionID] ASC);
GO

-- Creating primary key on [DiagnosisPhaseID] in table 'DiagnosisPhases'
ALTER TABLE [dbo].[DiagnosisPhases]
ADD CONSTRAINT [PK_DiagnosisPhases]
    PRIMARY KEY CLUSTERED ([DiagnosisPhaseID] ASC);
GO

-- Creating primary key on [DiagnosisSettingOfTherapyID] in table 'DiagnosisSettingOfTherapies'
ALTER TABLE [dbo].[DiagnosisSettingOfTherapies]
ADD CONSTRAINT [PK_DiagnosisSettingOfTherapies]
    PRIMARY KEY CLUSTERED ([DiagnosisSettingOfTherapyID] ASC);
GO

-- Creating primary key on [DiagnosisStageID] in table 'DiagnosisStages'
ALTER TABLE [dbo].[DiagnosisStages]
ADD CONSTRAINT [PK_DiagnosisStages]
    PRIMARY KEY CLUSTERED ([DiagnosisStageID] ASC);
GO

-- Creating primary key on [DiagnosisTumorSizeID] in table 'DiagnosisTumorSizes'
ALTER TABLE [dbo].[DiagnosisTumorSizes]
ADD CONSTRAINT [PK_DiagnosisTumorSizes]
    PRIMARY KEY CLUSTERED ([DiagnosisTumorSizeID] ASC);
GO

-- Creating primary key on [DimPayerID] in table 'DimPayers'
ALTER TABLE [dbo].[DimPayers]
ADD CONSTRAINT [PK_DimPayers]
    PRIMARY KEY CLUSTERED ([DimPayerID] ASC);
GO

-- Creating primary key on [DimPayerPreferredProtocolProgramID] in table 'DimPayerPreferredProtocolPrograms'
ALTER TABLE [dbo].[DimPayerPreferredProtocolPrograms]
ADD CONSTRAINT [PK_DimPayerPreferredProtocolPrograms]
    PRIMARY KEY CLUSTERED ([DimPayerPreferredProtocolProgramID] ASC);
GO

-- Creating primary key on [DimPayerPreferredProtocolProgramPatientDiagnosisID] in table 'DimPayerPreferredProtocolProgram_PatientDiagnosis'
ALTER TABLE [dbo].[DimPayerPreferredProtocolProgram_PatientDiagnosis]
ADD CONSTRAINT [PK_DimPayerPreferredProtocolProgram_PatientDiagnosis]
    PRIMARY KEY CLUSTERED ([DimPayerPreferredProtocolProgramPatientDiagnosisID] ASC);
GO

-- Creating primary key on [RuleID], [DimPayerID] in table 'DimPayerRules'
ALTER TABLE [dbo].[DimPayerRules]
ADD CONSTRAINT [PK_DimPayerRules]
    PRIMARY KEY CLUSTERED ([RuleID], [DimPayerID] ASC);
GO

-- Creating primary key on [DiscontinueAuthorizationAssignmentID] in table 'DiscontiueAuthorizationAssignments'
ALTER TABLE [dbo].[DiscontiueAuthorizationAssignments]
ADD CONSTRAINT [PK_DiscontiueAuthorizationAssignments]
    PRIMARY KEY CLUSTERED ([DiscontinueAuthorizationAssignmentID] ASC);
GO

-- Creating primary key on [DiscontiueAuthorizationLinkedAssignmentID] in table 'DiscontiueAuthorizationLinkedAssignments'
ALTER TABLE [dbo].[DiscontiueAuthorizationLinkedAssignments]
ADD CONSTRAINT [PK_DiscontiueAuthorizationLinkedAssignments]
    PRIMARY KEY CLUSTERED ([DiscontiueAuthorizationLinkedAssignmentID] ASC);
GO

-- Creating primary key on [DocumentDeletionReasonID] in table 'DocumentDeletionReasons'
ALTER TABLE [dbo].[DocumentDeletionReasons]
ADD CONSTRAINT [PK_DocumentDeletionReasons]
    PRIMARY KEY CLUSTERED ([DocumentDeletionReasonID] ASC);
GO

-- Creating primary key on [DocumentDownloadHistoryID] in table 'DocumentDownloadHistories'
ALTER TABLE [dbo].[DocumentDownloadHistories]
ADD CONSTRAINT [PK_DocumentDownloadHistories]
    PRIMARY KEY CLUSTERED ([DocumentDownloadHistoryID] ASC);
GO

-- Creating primary key on [DocumentRepositoryID] in table 'DocumentExtraInfoes'
ALTER TABLE [dbo].[DocumentExtraInfoes]
ADD CONSTRAINT [PK_DocumentExtraInfoes]
    PRIMARY KEY CLUSTERED ([DocumentRepositoryID] ASC);
GO

-- Creating primary key on [DocumentRepositoryID] in table 'DocumentRepositories'
ALTER TABLE [dbo].[DocumentRepositories]
ADD CONSTRAINT [PK_DocumentRepositories]
    PRIMARY KEY CLUSTERED ([DocumentRepositoryID] ASC);
GO

-- Creating primary key on [DocumentTextBlockID] in table 'DocumentTextBlocks'
ALTER TABLE [dbo].[DocumentTextBlocks]
ADD CONSTRAINT [PK_DocumentTextBlocks]
    PRIMARY KEY CLUSTERED ([DocumentTextBlockID] ASC);
GO

-- Creating primary key on [DrugID] in table 'Drugs'
ALTER TABLE [dbo].[Drugs]
ADD CONSTRAINT [PK_Drugs]
    PRIMARY KEY CLUSTERED ([DrugID] ASC);
GO

-- Creating primary key on [DrugSideEffectID] in table 'Drug_SideEffect'
ALTER TABLE [dbo].[Drug_SideEffect]
ADD CONSTRAINT [PK_Drug_SideEffect]
    PRIMARY KEY CLUSTERED ([DrugSideEffectID] ASC);
GO

-- Creating primary key on [DrugBiosimilarityID] in table 'DrugBiosimilarities'
ALTER TABLE [dbo].[DrugBiosimilarities]
ADD CONSTRAINT [PK_DrugBiosimilarities]
    PRIMARY KEY CLUSTERED ([DrugBiosimilarityID] ASC);
GO

-- Creating primary key on [DrugCodeID] in table 'DrugCodes'
ALTER TABLE [dbo].[DrugCodes]
ADD CONSTRAINT [PK_DrugCodes]
    PRIMARY KEY CLUSTERED ([DrugCodeID] ASC);
GO

-- Creating primary key on [DrugPolicyID] in table 'DrugPolicies'
ALTER TABLE [dbo].[DrugPolicies]
ADD CONSTRAINT [PK_DrugPolicies]
    PRIMARY KEY CLUSTERED ([DrugPolicyID] ASC);
GO

-- Creating primary key on [DrugPolicyCriteriaID] in table 'DrugPolicyCriterias'
ALTER TABLE [dbo].[DrugPolicyCriterias]
ADD CONSTRAINT [PK_DrugPolicyCriterias]
    PRIMARY KEY CLUSTERED ([DrugPolicyCriteriaID] ASC);
GO

-- Creating primary key on [DrugPolicyCriteriaDiagnosisID] in table 'DrugPolicyCriteriaDiagnosis'
ALTER TABLE [dbo].[DrugPolicyCriteriaDiagnosis]
ADD CONSTRAINT [PK_DrugPolicyCriteriaDiagnosis]
    PRIMARY KEY CLUSTERED ([DrugPolicyCriteriaDiagnosisID] ASC);
GO

-- Creating primary key on [DrugPolicyLOBID] in table 'DrugPolicyLOBs'
ALTER TABLE [dbo].[DrugPolicyLOBs]
ADD CONSTRAINT [PK_DrugPolicyLOBs]
    PRIMARY KEY CLUSTERED ([DrugPolicyLOBID] ASC);
GO

-- Creating primary key on [DrugProtocolTotalBillingUnitsID] in table 'DrugProtocolTotalBillingUnits'
ALTER TABLE [dbo].[DrugProtocolTotalBillingUnits]
ADD CONSTRAINT [PK_DrugProtocolTotalBillingUnits]
    PRIMARY KEY CLUSTERED ([DrugProtocolTotalBillingUnitsID] ASC);
GO

-- Creating primary key on [EligibilityID] in table 'Eligibilities'
ALTER TABLE [dbo].[Eligibilities]
ADD CONSTRAINT [PK_Eligibilities]
    PRIMARY KEY CLUSTERED ([EligibilityID] ASC);
GO

-- Creating primary key on [LogID] in table 'EligiblityServiceLogs'
ALTER TABLE [dbo].[EligiblityServiceLogs]
ADD CONSTRAINT [PK_EligiblityServiceLogs]
    PRIMARY KEY CLUSTERED ([LogID] ASC);
GO

-- Creating primary key on [EmailArchiveID] in table 'EmailArchives'
ALTER TABLE [dbo].[EmailArchives]
ADD CONSTRAINT [PK_EmailArchives]
    PRIMARY KEY CLUSTERED ([EmailArchiveID] ASC);
GO

-- Creating primary key on [EmailArchiveDetailID] in table 'EmailArchiveDetails'
ALTER TABLE [dbo].[EmailArchiveDetails]
ADD CONSTRAINT [PK_EmailArchiveDetails]
    PRIMARY KEY CLUSTERED ([EmailArchiveDetailID] ASC);
GO

-- Creating primary key on [EmailArchiveDocumentID] in table 'EmailArchiveDocuments'
ALTER TABLE [dbo].[EmailArchiveDocuments]
ADD CONSTRAINT [PK_EmailArchiveDocuments]
    PRIMARY KEY CLUSTERED ([EmailArchiveDocumentID] ASC);
GO

-- Creating primary key on [EODFileID] in table 'EODFiles'
ALTER TABLE [dbo].[EODFiles]
ADD CONSTRAINT [PK_EODFiles]
    PRIMARY KEY CLUSTERED ([EODFileID] ASC);
GO

-- Creating primary key on [EODFileProtocolAssignmentID] in table 'EODFileProtocolAssignments'
ALTER TABLE [dbo].[EODFileProtocolAssignments]
ADD CONSTRAINT [PK_EODFileProtocolAssignments]
    PRIMARY KEY CLUSTERED ([EODFileProtocolAssignmentID] ASC);
GO

-- Creating primary key on [ID] in table 'ExceptionsLogs'
ALTER TABLE [dbo].[ExceptionsLogs]
ADD CONSTRAINT [PK_ExceptionsLogs]
    PRIMARY KEY CLUSTERED ([ID] ASC);
GO

-- Creating primary key on [ExecutionLogID] in table 'ExecutionLogs'
ALTER TABLE [dbo].[ExecutionLogs]
ADD CONSTRAINT [PK_ExecutionLogs]
    PRIMARY KEY CLUSTERED ([ExecutionLogID] ASC);
GO

-- Creating primary key on [ExplicitAnswerXRTID] in table 'ExplicitAnswerXRTs'
ALTER TABLE [dbo].[ExplicitAnswerXRTs]
ADD CONSTRAINT [PK_ExplicitAnswerXRTs]
    PRIMARY KEY CLUSTERED ([ExplicitAnswerXRTID] ASC);
GO

-- Creating primary key on [QuestionID] in table 'ExplicitQuestions'
ALTER TABLE [dbo].[ExplicitQuestions]
ADD CONSTRAINT [PK_ExplicitQuestions]
    PRIMARY KEY CLUSTERED ([QuestionID] ASC);
GO

-- Creating primary key on [QuestionAnswerID] in table 'ExplicitQuestionAnswers'
ALTER TABLE [dbo].[ExplicitQuestionAnswers]
ADD CONSTRAINT [PK_ExplicitQuestionAnswers]
    PRIMARY KEY CLUSTERED ([QuestionAnswerID] ASC);
GO

-- Creating primary key on [ExplicitQuestionXRTID] in table 'ExplicitQuestionXRTs'
ALTER TABLE [dbo].[ExplicitQuestionXRTs]
ADD CONSTRAINT [PK_ExplicitQuestionXRTs]
    PRIMARY KEY CLUSTERED ([ExplicitQuestionXRTID] ASC);
GO

-- Creating primary key on [ExractionDetailID] in table 'ExtractionDetails'
ALTER TABLE [dbo].[ExtractionDetails]
ADD CONSTRAINT [PK_ExtractionDetails]
    PRIMARY KEY CLUSTERED ([ExractionDetailID] ASC);
GO

-- Creating primary key on [FaxAddressID] in table 'FaxAddresses'
ALTER TABLE [dbo].[FaxAddresses]
ADD CONSTRAINT [PK_FaxAddresses]
    PRIMARY KEY CLUSTERED ([FaxAddressID] ASC);
GO

-- Creating primary key on [FaxArchiveID] in table 'FaxArchives'
ALTER TABLE [dbo].[FaxArchives]
ADD CONSTRAINT [PK_FaxArchives]
    PRIMARY KEY CLUSTERED ([FaxArchiveID] ASC);
GO

-- Creating primary key on [FaxArchiveDocumentID] in table 'FaxArchiveDocuments'
ALTER TABLE [dbo].[FaxArchiveDocuments]
ADD CONSTRAINT [PK_FaxArchiveDocuments]
    PRIMARY KEY CLUSTERED ([FaxArchiveDocumentID] ASC);
GO

-- Creating primary key on [FaxCatalogID] in table 'FaxCatalogs'
ALTER TABLE [dbo].[FaxCatalogs]
ADD CONSTRAINT [PK_FaxCatalogs]
    PRIMARY KEY CLUSTERED ([FaxCatalogID] ASC);
GO

-- Creating primary key on [FaxDetailsID] in table 'FaxDetails'
ALTER TABLE [dbo].[FaxDetails]
ADD CONSTRAINT [PK_FaxDetails]
    PRIMARY KEY CLUSTERED ([FaxDetailsID] ASC);
GO

-- Creating primary key on [DocumentRepositoryID] in table 'FaxDocumentAssignments'
ALTER TABLE [dbo].[FaxDocumentAssignments]
ADD CONSTRAINT [PK_FaxDocumentAssignments]
    PRIMARY KEY CLUSTERED ([DocumentRepositoryID] ASC);
GO

-- Creating primary key on [FaxParameterID] in table 'FaxParameters'
ALTER TABLE [dbo].[FaxParameters]
ADD CONSTRAINT [PK_FaxParameters]
    PRIMARY KEY CLUSTERED ([FaxParameterID] ASC);
GO

-- Creating primary key on [FaxRecipientID] in table 'FaxRecipients'
ALTER TABLE [dbo].[FaxRecipients]
ADD CONSTRAINT [PK_FaxRecipients]
    PRIMARY KEY CLUSTERED ([FaxRecipientID] ASC);
GO

-- Creating primary key on [FaxRecipientConfigurationID] in table 'FaxRecipientConfigurations'
ALTER TABLE [dbo].[FaxRecipientConfigurations]
ADD CONSTRAINT [PK_FaxRecipientConfigurations]
    PRIMARY KEY CLUSTERED ([FaxRecipientConfigurationID] ASC);
GO

-- Creating primary key on [FaxRecipientConfigurationFaxRecipientTypeID] in table 'FaxRecipientConfigurationFaxRecipientTypes'
ALTER TABLE [dbo].[FaxRecipientConfigurationFaxRecipientTypes]
ADD CONSTRAINT [PK_FaxRecipientConfigurationFaxRecipientTypes]
    PRIMARY KEY CLUSTERED ([FaxRecipientConfigurationFaxRecipientTypeID] ASC);
GO

-- Creating primary key on [FaxRecipientConfigurationStateID] in table 'FaxRecipientConfigurationStates'
ALTER TABLE [dbo].[FaxRecipientConfigurationStates]
ADD CONSTRAINT [PK_FaxRecipientConfigurationStates]
    PRIMARY KEY CLUSTERED ([FaxRecipientConfigurationStateID] ASC);
GO

-- Creating primary key on [FebrileNeutropeniaClinicalValuesRuleID] in table 'FebrileNeutropeniaClinicalValuesRules'
ALTER TABLE [dbo].[FebrileNeutropeniaClinicalValuesRules]
ADD CONSTRAINT [PK_FebrileNeutropeniaClinicalValuesRules]
    PRIMARY KEY CLUSTERED ([FebrileNeutropeniaClinicalValuesRuleID] ASC);
GO

-- Creating primary key on [FileExtension1] in table 'FileExtensions'
ALTER TABLE [dbo].[FileExtensions]
ADD CONSTRAINT [PK_FileExtensions]
    PRIMARY KEY CLUSTERED ([FileExtension1] ASC);
GO

-- Creating primary key on [FormularyExceptionID] in table 'FormularyExceptions'
ALTER TABLE [dbo].[FormularyExceptions]
ADD CONSTRAINT [PK_FormularyExceptions]
    PRIMARY KEY CLUSTERED ([FormularyExceptionID] ASC);
GO

-- Creating primary key on [FormularyException_AlternativeCodeID] in table 'FormularyException_AlternativeCode'
ALTER TABLE [dbo].[FormularyException_AlternativeCode]
ADD CONSTRAINT [PK_FormularyException_AlternativeCode]
    PRIMARY KEY CLUSTERED ([FormularyException_AlternativeCodeID] ASC);
GO

-- Creating primary key on [FormularyException_ExceptionTypeID] in table 'FormularyException_ExceptionType'
ALTER TABLE [dbo].[FormularyException_ExceptionType]
ADD CONSTRAINT [PK_FormularyException_ExceptionType]
    PRIMARY KEY CLUSTERED ([FormularyException_ExceptionTypeID] ASC);
GO

-- Creating primary key on [FtnConfigurationID] in table 'FtnConfigurations'
ALTER TABLE [dbo].[FtnConfigurations]
ADD CONSTRAINT [PK_FtnConfigurations]
    PRIMARY KEY CLUSTERED ([FtnConfigurationID] ASC);
GO

-- Creating primary key on [GrandfatherRuleID] in table 'GrandfatherRules'
ALTER TABLE [dbo].[GrandfatherRules]
ADD CONSTRAINT [PK_GrandfatherRules]
    PRIMARY KEY CLUSTERED ([GrandfatherRuleID] ASC);
GO

-- Creating primary key on [GrandfatherRuleDrugID] in table 'GrandfatherRuleDrugs'
ALTER TABLE [dbo].[GrandfatherRuleDrugs]
ADD CONSTRAINT [PK_GrandfatherRuleDrugs]
    PRIMARY KEY CLUSTERED ([GrandfatherRuleDrugID] ASC);
GO

-- Creating primary key on [HelpfulLinkID] in table 'HelpfulLinks'
ALTER TABLE [dbo].[HelpfulLinks]
ADD CONSTRAINT [PK_HelpfulLinks]
    PRIMARY KEY CLUSTERED ([HelpfulLinkID] ASC);
GO

-- Creating primary key on [Code], [CodeVersion] in table 'ICDCodes'
ALTER TABLE [dbo].[ICDCodes]
ADD CONSTRAINT [PK_ICDCodes]
    PRIMARY KEY CLUSTERED ([Code], [CodeVersion] ASC);
GO

-- Creating primary key on [ImageID] in table 'Images'
ALTER TABLE [dbo].[Images]
ADD CONSTRAINT [PK_Images]
    PRIMARY KEY CLUSTERED ([ImageID] ASC);
GO

-- Creating primary key on [InScopeICDCodeID] in table 'InScopeICDCodes'
ALTER TABLE [dbo].[InScopeICDCodes]
ADD CONSTRAINT [PK_InScopeICDCodes]
    PRIMARY KEY CLUSTERED ([InScopeICDCodeID] ASC);
GO

-- Creating primary key on [InsuranceGroupID] in table 'InScopeInsuranceGroups'
ALTER TABLE [dbo].[InScopeInsuranceGroups]
ADD CONSTRAINT [PK_InScopeInsuranceGroups]
    PRIMARY KEY CLUSTERED ([InsuranceGroupID] ASC);
GO

-- Creating primary key on [InScopeJCodeID] in table 'InScopeJCodes'
ALTER TABLE [dbo].[InScopeJCodes]
ADD CONSTRAINT [PK_InScopeJCodes]
    PRIMARY KEY CLUSTERED ([InScopeJCodeID] ASC);
GO

-- Creating primary key on [MCCIId] in table 'InScopePCPCenters'
ALTER TABLE [dbo].[InScopePCPCenters]
ADD CONSTRAINT [PK_InScopePCPCenters]
    PRIMARY KEY CLUSTERED ([MCCIId] ASC);
GO

-- Creating primary key on [InScopeStateID] in table 'InScopeStates'
ALTER TABLE [dbo].[InScopeStates]
ADD CONSTRAINT [PK_InScopeStates]
    PRIMARY KEY CLUSTERED ([InScopeStateID] ASC);
GO

-- Creating primary key on [InScopeZipCodeID] in table 'InScopeZipCodes'
ALTER TABLE [dbo].[InScopeZipCodes]
ADD CONSTRAINT [PK_InScopeZipCodes]
    PRIMARY KEY CLUSTERED ([InScopeZipCodeID] ASC);
GO

-- Creating primary key on [InsuranceProviderID] in table 'InsuranceProviders'
ALTER TABLE [dbo].[InsuranceProviders]
ADD CONSTRAINT [PK_InsuranceProviders]
    PRIMARY KEY CLUSTERED ([InsuranceProviderID] ASC);
GO

-- Creating primary key on [InsuranceProviderAddressID] in table 'InsuranceProvider_Address'
ALTER TABLE [dbo].[InsuranceProvider_Address]
ADD CONSTRAINT [PK_InsuranceProvider_Address]
    PRIMARY KEY CLUSTERED ([InsuranceProviderAddressID] ASC);
GO

-- Creating primary key on [InsuranceProviderLookupElementID] in table 'InsuranceProvider_LookupElement'
ALTER TABLE [dbo].[InsuranceProvider_LookupElement]
ADD CONSTRAINT [PK_InsuranceProvider_LookupElement]
    PRIMARY KEY CLUSTERED ([InsuranceProviderLookupElementID] ASC);
GO

-- Creating primary key on [InsuranceProviderAttributeKeyID] in table 'InsuranceProviderAttributeKeys'
ALTER TABLE [dbo].[InsuranceProviderAttributeKeys]
ADD CONSTRAINT [PK_InsuranceProviderAttributeKeys]
    PRIMARY KEY CLUSTERED ([InsuranceProviderAttributeKeyID] ASC);
GO

-- Creating primary key on [InsuranceProviderAttributeValueID] in table 'InsuranceProviderAttributeValues'
ALTER TABLE [dbo].[InsuranceProviderAttributeValues]
ADD CONSTRAINT [PK_InsuranceProviderAttributeValues]
    PRIMARY KEY CLUSTERED ([InsuranceProviderAttributeValueID] ASC);
GO

-- Creating primary key on [InsuranceProviderConfigurationID] in table 'InsuranceProviderConfigurations'
ALTER TABLE [dbo].[InsuranceProviderConfigurations]
ADD CONSTRAINT [PK_InsuranceProviderConfigurations]
    PRIMARY KEY CLUSTERED ([InsuranceProviderConfigurationID] ASC);
GO

-- Creating primary key on [InsuranceProviderContactDetailID] in table 'InsuranceProviderContactDetails'
ALTER TABLE [dbo].[InsuranceProviderContactDetails]
ADD CONSTRAINT [PK_InsuranceProviderContactDetails]
    PRIMARY KEY CLUSTERED ([InsuranceProviderContactDetailID] ASC);
GO

-- Creating primary key on [InsuranceProviderDayLightSavingSettingID] in table 'InsuranceProviderDaylightSavingSettings'
ALTER TABLE [dbo].[InsuranceProviderDaylightSavingSettings]
ADD CONSTRAINT [PK_InsuranceProviderDaylightSavingSettings]
    PRIMARY KEY CLUSTERED ([InsuranceProviderDayLightSavingSettingID] ASC);
GO

-- Creating primary key on [InsuranceProviderDrugID] in table 'InsuranceProviderDrugs'
ALTER TABLE [dbo].[InsuranceProviderDrugs]
ADD CONSTRAINT [PK_InsuranceProviderDrugs]
    PRIMARY KEY CLUSTERED ([InsuranceProviderDrugID] ASC);
GO

-- Creating primary key on [InsuranceProviderDrugConfigurationID] in table 'InsuranceProviderDrugConfigurations'
ALTER TABLE [dbo].[InsuranceProviderDrugConfigurations]
ADD CONSTRAINT [PK_InsuranceProviderDrugConfigurations]
    PRIMARY KEY CLUSTERED ([InsuranceProviderDrugConfigurationID] ASC);
GO

-- Creating primary key on [InsuranceProviderDrugConfigurationLOBID] in table 'InsuranceProviderDrugConfiguration_LOB'
ALTER TABLE [dbo].[InsuranceProviderDrugConfiguration_LOB]
ADD CONSTRAINT [PK_InsuranceProviderDrugConfiguration_LOB]
    PRIMARY KEY CLUSTERED ([InsuranceProviderDrugConfigurationLOBID] ASC);
GO

-- Creating primary key on [InsuranceProviderDrugConfigurationStageID] in table 'InsuranceProviderDrugConfiguration_Stage'
ALTER TABLE [dbo].[InsuranceProviderDrugConfiguration_Stage]
ADD CONSTRAINT [PK_InsuranceProviderDrugConfiguration_Stage]
    PRIMARY KEY CLUSTERED ([InsuranceProviderDrugConfigurationStageID] ASC);
GO

-- Creating primary key on [InsuranceProviderEODFileRecipientID] in table 'InsuranceProviderEODFileRecipients'
ALTER TABLE [dbo].[InsuranceProviderEODFileRecipients]
ADD CONSTRAINT [PK_InsuranceProviderEODFileRecipients]
    PRIMARY KEY CLUSTERED ([InsuranceProviderEODFileRecipientID] ASC);
GO

-- Creating primary key on [InsuranceProviderEODStatusOverrideID] in table 'InsuranceProviderEODStatusOverrides'
ALTER TABLE [dbo].[InsuranceProviderEODStatusOverrides]
ADD CONSTRAINT [PK_InsuranceProviderEODStatusOverrides]
    PRIMARY KEY CLUSTERED ([InsuranceProviderEODStatusOverrideID] ASC);
GO

-- Creating primary key on [InsuranceProviderFaxTemplateID] in table 'InsuranceProviderFaxTemplates'
ALTER TABLE [dbo].[InsuranceProviderFaxTemplates]
ADD CONSTRAINT [PK_InsuranceProviderFaxTemplates]
    PRIMARY KEY CLUSTERED ([InsuranceProviderFaxTemplateID] ASC);
GO

-- Creating primary key on [InsuranceProviderFaxTemplate_ProductLineID] in table 'InsuranceProviderFaxTemplate_ProductLine'
ALTER TABLE [dbo].[InsuranceProviderFaxTemplate_ProductLine]
ADD CONSTRAINT [PK_InsuranceProviderFaxTemplate_ProductLine]
    PRIMARY KEY CLUSTERED ([InsuranceProviderFaxTemplate_ProductLineID] ASC);
GO

-- Creating primary key on [InsuranceProviderFaxTemplateRuleID] in table 'InsuranceProviderFaxTemplate_Rule'
ALTER TABLE [dbo].[InsuranceProviderFaxTemplate_Rule]
ADD CONSTRAINT [PK_InsuranceProviderFaxTemplate_Rule]
    PRIMARY KEY CLUSTERED ([InsuranceProviderFaxTemplateRuleID] ASC);
GO

-- Creating primary key on [InsuranceProviderGlobalFaxParameterID] in table 'InsuranceProviderGlobalFaxParameters'
ALTER TABLE [dbo].[InsuranceProviderGlobalFaxParameters]
ADD CONSTRAINT [PK_InsuranceProviderGlobalFaxParameters]
    PRIMARY KEY CLUSTERED ([InsuranceProviderGlobalFaxParameterID] ASC);
GO

-- Creating primary key on [InsuranceProviderHomePageID] in table 'InsuranceProviderHomePages'
ALTER TABLE [dbo].[InsuranceProviderHomePages]
ADD CONSTRAINT [PK_InsuranceProviderHomePages]
    PRIMARY KEY CLUSTERED ([InsuranceProviderHomePageID] ASC);
GO

-- Creating primary key on [InsuranceProviderSpecialtyCodeId] in table 'InsuranceProviderSpecialtyCodes'
ALTER TABLE [dbo].[InsuranceProviderSpecialtyCodes]
ADD CONSTRAINT [PK_InsuranceProviderSpecialtyCodes]
    PRIMARY KEY CLUSTERED ([InsuranceProviderSpecialtyCodeId] ASC);
GO

-- Creating primary key on [InsuranceProviderTreatmentTypeID] in table 'InsuranceProviderTreatmentTypes'
ALTER TABLE [dbo].[InsuranceProviderTreatmentTypes]
ADD CONSTRAINT [PK_InsuranceProviderTreatmentTypes]
    PRIMARY KEY CLUSTERED ([InsuranceProviderTreatmentTypeID] ASC);
GO

-- Creating primary key on [LabResultID] in table 'LabResults'
ALTER TABLE [dbo].[LabResults]
ADD CONSTRAINT [PK_LabResults]
    PRIMARY KEY CLUSTERED ([LabResultID] ASC);
GO

-- Creating primary key on [LineOfBusinessID] in table 'LineofBusinesses'
ALTER TABLE [dbo].[LineofBusinesses]
ADD CONSTRAINT [PK_LineofBusinesses]
    PRIMARY KEY CLUSTERED ([LineOfBusinessID] ASC);
GO

-- Creating primary key on [LookupName] in table 'Lookups'
ALTER TABLE [dbo].[Lookups]
ADD CONSTRAINT [PK_Lookups]
    PRIMARY KEY CLUSTERED ([LookupName] ASC);
GO

-- Creating primary key on [LookupElementID] in table 'LookupElements'
ALTER TABLE [dbo].[LookupElements]
ADD CONSTRAINT [PK_LookupElements]
    PRIMARY KEY CLUSTERED ([LookupElementID] ASC);
GO

-- Creating primary key on [LookupElementSecurityGroupID] in table 'LookupElement_SecurityGroup'
ALTER TABLE [dbo].[LookupElement_SecurityGroup]
ADD CONSTRAINT [PK_LookupElement_SecurityGroup]
    PRIMARY KEY CLUSTERED ([LookupElementSecurityGroupID] ASC);
GO

-- Creating primary key on [LookupElementMappingID] in table 'LookupElementMappings'
ALTER TABLE [dbo].[LookupElementMappings]
ADD CONSTRAINT [PK_LookupElementMappings]
    PRIMARY KEY CLUSTERED ([LookupElementMappingID] ASC);
GO

-- Creating primary key on [MailArchiveID] in table 'MailArchives'
ALTER TABLE [dbo].[MailArchives]
ADD CONSTRAINT [PK_MailArchives]
    PRIMARY KEY CLUSTERED ([MailArchiveID] ASC);
GO

-- Creating primary key on [MailArchiveDocumentID] in table 'MailArchiveDocuments'
ALTER TABLE [dbo].[MailArchiveDocuments]
ADD CONSTRAINT [PK_MailArchiveDocuments]
    PRIMARY KEY CLUSTERED ([MailArchiveDocumentID] ASC);
GO

-- Creating primary key on [MailArchiveLogID] in table 'MailArchiveLogs'
ALTER TABLE [dbo].[MailArchiveLogs]
ADD CONSTRAINT [PK_MailArchiveLogs]
    PRIMARY KEY CLUSTERED ([MailArchiveLogID] ASC);
GO

-- Creating primary key on [MailArchiveTrackingID] in table 'MailArchiveTrackings'
ALTER TABLE [dbo].[MailArchiveTrackings]
ADD CONSTRAINT [PK_MailArchiveTrackings]
    PRIMARY KEY CLUSTERED ([MailArchiveTrackingID] ASC);
GO

-- Creating primary key on [MailingCutoffCalculationLogID] in table 'MailingCutoffCalculationLogs'
ALTER TABLE [dbo].[MailingCutoffCalculationLogs]
ADD CONSTRAINT [PK_MailingCutoffCalculationLogs]
    PRIMARY KEY CLUSTERED ([MailingCutoffCalculationLogID] ASC);
GO

-- Creating primary key on [MailingCutoffConfigurationID] in table 'MailingCutoffConfigurations'
ALTER TABLE [dbo].[MailingCutoffConfigurations]
ADD CONSTRAINT [PK_MailingCutoffConfigurations]
    PRIMARY KEY CLUSTERED ([MailingCutoffConfigurationID] ASC);
GO

-- Creating primary key on [MemberContactLogID] in table 'MemberContactLogs'
ALTER TABLE [dbo].[MemberContactLogs]
ADD CONSTRAINT [PK_MemberContactLogs]
    PRIMARY KEY CLUSTERED ([MemberContactLogID] ASC);
GO

-- Creating primary key on [MenuOptionID] in table 'MenuOptions'
ALTER TABLE [dbo].[MenuOptions]
ADD CONSTRAINT [PK_MenuOptions]
    PRIMARY KEY CLUSTERED ([MenuOptionID] ASC);
GO

-- Creating primary key on [MetastaticSiteID] in table 'MetastaticSites'
ALTER TABLE [dbo].[MetastaticSites]
ADD CONSTRAINT [PK_MetastaticSites]
    PRIMARY KEY CLUSTERED ([MetastaticSiteID] ASC);
GO

-- Creating primary key on [MimicEligibilityServiceResponseID] in table 'MimicEligibilityServiceResponses'
ALTER TABLE [dbo].[MimicEligibilityServiceResponses]
ADD CONSTRAINT [PK_MimicEligibilityServiceResponses]
    PRIMARY KEY CLUSTERED ([MimicEligibilityServiceResponseID] ASC);
GO

-- Creating primary key on [MultilingualDataID] in table 'MultilingualDatas'
ALTER TABLE [dbo].[MultilingualDatas]
ADD CONSTRAINT [PK_MultilingualDatas]
    PRIMARY KEY CLUSTERED ([MultilingualDataID] ASC);
GO

-- Creating primary key on [MultilingualObjectID] in table 'MultilingualObjects'
ALTER TABLE [dbo].[MultilingualObjects]
ADD CONSTRAINT [PK_MultilingualObjects]
    PRIMARY KEY CLUSTERED ([MultilingualObjectID] ASC);
GO

-- Creating primary key on [MultilingualObjectFieldID] in table 'MultilingualObjectFields'
ALTER TABLE [dbo].[MultilingualObjectFields]
ADD CONSTRAINT [PK_MultilingualObjectFields]
    PRIMARY KEY CLUSTERED ([MultilingualObjectFieldID] ASC);
GO

-- Creating primary key on [NCCNRecurrenceRiskFormulaID] in table 'NCCNRecurrenceRiskFormulas'
ALTER TABLE [dbo].[NCCNRecurrenceRiskFormulas]
ADD CONSTRAINT [PK_NCCNRecurrenceRiskFormulas]
    PRIMARY KEY CLUSTERED ([NCCNRecurrenceRiskFormulaID] ASC);
GO

-- Creating primary key on [NCCNRecurrenceRiskGroupID] in table 'NCCNRecurrenceRiskGroups'
ALTER TABLE [dbo].[NCCNRecurrenceRiskGroups]
ADD CONSTRAINT [PK_NCCNRecurrenceRiskGroups]
    PRIMARY KEY CLUSTERED ([NCCNRecurrenceRiskGroupID] ASC);
GO

-- Creating primary key on [DrugID] in table 'NeutropeniaOverTurnDrugs'
ALTER TABLE [dbo].[NeutropeniaOverTurnDrugs]
ADD CONSTRAINT [PK_NeutropeniaOverTurnDrugs]
    PRIMARY KEY CLUSTERED ([DrugID] ASC);
GO

-- Creating primary key on [NoteID] in table 'Notes'
ALTER TABLE [dbo].[Notes]
ADD CONSTRAINT [PK_Notes]
    PRIMARY KEY CLUSTERED ([NoteID] ASC);
GO

-- Creating primary key on [NotificationEnclosureID] in table 'NotificationEnclosures'
ALTER TABLE [dbo].[NotificationEnclosures]
ADD CONSTRAINT [PK_NotificationEnclosures]
    PRIMARY KEY CLUSTERED ([NotificationEnclosureID] ASC);
GO

-- Creating primary key on [NotificationEnclosureImageID] in table 'NotificationEnclosureImages'
ALTER TABLE [dbo].[NotificationEnclosureImages]
ADD CONSTRAINT [PK_NotificationEnclosureImages]
    PRIMARY KEY CLUSTERED ([NotificationEnclosureImageID] ASC);
GO

-- Creating primary key on [PatientID] in table 'Patients'
ALTER TABLE [dbo].[Patients]
ADD CONSTRAINT [PK_Patients]
    PRIMARY KEY CLUSTERED ([PatientID] ASC);
GO

-- Creating primary key on [PatientAssessmentID] in table 'PatientAssessments'
ALTER TABLE [dbo].[PatientAssessments]
ADD CONSTRAINT [PK_PatientAssessments]
    PRIMARY KEY CLUSTERED ([PatientAssessmentID] ASC);
GO

-- Creating primary key on [PatientAssessmentAnswerID] in table 'PatientAssessmentAnswers'
ALTER TABLE [dbo].[PatientAssessmentAnswers]
ADD CONSTRAINT [PK_PatientAssessmentAnswers]
    PRIMARY KEY CLUSTERED ([PatientAssessmentAnswerID] ASC);
GO

-- Creating primary key on [PatientClinicalDecisionSupportID] in table 'PatientClinicalDecisionSupports'
ALTER TABLE [dbo].[PatientClinicalDecisionSupports]
ADD CONSTRAINT [PK_PatientClinicalDecisionSupports]
    PRIMARY KEY CLUSTERED ([PatientClinicalDecisionSupportID] ASC);
GO

-- Creating primary key on [PatientClinicalDecisionSupportProtocolID] in table 'PatientClinicalDecisionSupport_Protocol'
ALTER TABLE [dbo].[PatientClinicalDecisionSupport_Protocol]
ADD CONSTRAINT [PK_PatientClinicalDecisionSupport_Protocol]
    PRIMARY KEY CLUSTERED ([PatientClinicalDecisionSupportProtocolID] ASC);
GO

-- Creating primary key on [PatientDiagnosisID] in table 'PatientDiagnosis'
ALTER TABLE [dbo].[PatientDiagnosis]
ADD CONSTRAINT [PK_PatientDiagnosis]
    PRIMARY KEY CLUSTERED ([PatientDiagnosisID] ASC);
GO

-- Creating primary key on [PatientICDCodeID] in table 'PatientICDCodes'
ALTER TABLE [dbo].[PatientICDCodes]
ADD CONSTRAINT [PK_PatientICDCodes]
    PRIMARY KEY CLUSTERED ([PatientICDCodeID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentID] in table 'PatientProtocolAssignments'
ALTER TABLE [dbo].[PatientProtocolAssignments]
ADD CONSTRAINT [PK_PatientProtocolAssignments]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentLabResultID] in table 'PatientProtocolAssignment_Labresult'
ALTER TABLE [dbo].[PatientProtocolAssignment_Labresult]
ADD CONSTRAINT [PK_PatientProtocolAssignment_Labresult]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentLabResultID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentProtocolID] in table 'PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [PK_PatientProtocolAssignment_Protocol]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentProtocolID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignment_Protocol_ProtocolElementCodeID] in table 'PatientProtocolAssignment_Protocol_ProtocolElementCode'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode]
ADD CONSTRAINT [PK_PatientProtocolAssignment_Protocol_ProtocolElementCode]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignment_Protocol_ProtocolElementCodeID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentProtocolCPTCodeXRTID] in table 'PatientProtocolAssignment_ProtocolCPTCodeXRT'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT]
ADD CONSTRAINT [PK_PatientProtocolAssignment_ProtocolCPTCodeXRT]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentProtocolCPTCodeXRTID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentProtocolDiagnosisID] in table 'PatientProtocolAssignment_ProtocolDiagnosis'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDiagnosis]
ADD CONSTRAINT [PK_PatientProtocolAssignment_ProtocolDiagnosis]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentProtocolDiagnosisID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignment_ProtocolDosingID] in table 'PatientProtocolAssignment_ProtocolDosing'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing]
ADD CONSTRAINT [PK_PatientProtocolAssignment_ProtocolDosing]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignment_ProtocolDosingID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignment_ProtocolHCPCSCodeGMTID] in table 'PatientProtocolAssignment_ProtocolHCPCSCodeGMT'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolHCPCSCodeGMT]
ADD CONSTRAINT [PK_PatientProtocolAssignment_ProtocolHCPCSCodeGMT]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignment_ProtocolHCPCSCodeGMTID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentProtocolICDCodeID] in table 'PatientProtocolAssignment_ProtocolICDCode'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolICDCode]
ADD CONSTRAINT [PK_PatientProtocolAssignment_ProtocolICDCode]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentProtocolICDCodeID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentProtocolQuestionAnswerID] in table 'PatientProtocolAssignment_ProtocolQuestionAnswer'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolQuestionAnswer]
ADD CONSTRAINT [PK_PatientProtocolAssignment_ProtocolQuestionAnswer]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentProtocolQuestionAnswerID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentQuestionAnswerXRTID] in table 'PatientProtocolAssignment_QuestionAnswerXRT'
ALTER TABLE [dbo].[PatientProtocolAssignment_QuestionAnswerXRT]
ADD CONSTRAINT [PK_PatientProtocolAssignment_QuestionAnswerXRT]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentQuestionAnswerXRTID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentTimerID] in table 'PatientProtocolAssignment_Timer'
ALTER TABLE [dbo].[PatientProtocolAssignment_Timer]
ADD CONSTRAINT [PK_PatientProtocolAssignment_Timer]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentTimerID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentEffectuationDateID] in table 'PatientProtocolAssignmentEffectuationDates'
ALTER TABLE [dbo].[PatientProtocolAssignmentEffectuationDates]
ADD CONSTRAINT [PK_PatientProtocolAssignmentEffectuationDates]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentEffectuationDateID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentHistoryID] in table 'PatientProtocolAssignmentHistories'
ALTER TABLE [dbo].[PatientProtocolAssignmentHistories]
ADD CONSTRAINT [PK_PatientProtocolAssignmentHistories]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentHistoryID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentID] in table 'PatientProtocolAssignmentInfoes'
ALTER TABLE [dbo].[PatientProtocolAssignmentInfoes]
ADD CONSTRAINT [PK_PatientProtocolAssignmentInfoes]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentPostDenialID] in table 'PatientProtocolAssignmentPostDenials'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenials]
ADD CONSTRAINT [PK_PatientProtocolAssignmentPostDenials]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentPostDenialID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentPostDenialID] in table 'PatientProtocolAssignmentPostDenialInfoes'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialInfoes]
ADD CONSTRAINT [PK_PatientProtocolAssignmentPostDenialInfoes]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentPostDenialID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentPostDenialProtocolID] in table 'PatientProtocolAssignmentPostDenialProtocols'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialProtocols]
ADD CONSTRAINT [PK_PatientProtocolAssignmentPostDenialProtocols]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentPostDenialProtocolID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentProtocolElementAliasID] in table 'PatientProtocolAssignmentProtocolElementAlias'
ALTER TABLE [dbo].[PatientProtocolAssignmentProtocolElementAlias]
ADD CONSTRAINT [PK_PatientProtocolAssignmentProtocolElementAlias]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentProtocolElementAliasID] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentTimeCountdownID] in table 'PatientProtocolAssignmentTimeCountdowns'
ALTER TABLE [dbo].[PatientProtocolAssignmentTimeCountdowns]
ADD CONSTRAINT [PK_PatientProtocolAssignmentTimeCountdowns]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentTimeCountdownID] ASC);
GO

-- Creating primary key on [PatientProtocolRulesTrailID] in table 'PatientProtocolRulesTrails'
ALTER TABLE [dbo].[PatientProtocolRulesTrails]
ADD CONSTRAINT [PK_PatientProtocolRulesTrails]
    PRIMARY KEY CLUSTERED ([PatientProtocolRulesTrailID] ASC);
GO

-- Creating primary key on [PayerBusinessDayConfigID] in table 'PayerBusinessDayConfigs'
ALTER TABLE [dbo].[PayerBusinessDayConfigs]
ADD CONSTRAINT [PK_PayerBusinessDayConfigs]
    PRIMARY KEY CLUSTERED ([PayerBusinessDayConfigID] ASC);
GO

-- Creating primary key on [PayerContactDetailId] in table 'PayerContactDetails'
ALTER TABLE [dbo].[PayerContactDetails]
ADD CONSTRAINT [PK_PayerContactDetails]
    PRIMARY KEY CLUSTERED ([PayerContactDetailId] ASC);
GO

-- Creating primary key on [PayerFormularyID] in table 'PayerFormularies'
ALTER TABLE [dbo].[PayerFormularies]
ADD CONSTRAINT [PK_PayerFormularies]
    PRIMARY KEY CLUSTERED ([PayerFormularyID] ASC);
GO

-- Creating primary key on [PayerOrganizationID] in table 'PayerOrganizations'
ALTER TABLE [dbo].[PayerOrganizations]
ADD CONSTRAINT [PK_PayerOrganizations]
    PRIMARY KEY CLUSTERED ([PayerOrganizationID] ASC);
GO

-- Creating primary key on [PayerPrimaryTimerID] in table 'PayerPrimaryTimers'
ALTER TABLE [dbo].[PayerPrimaryTimers]
ADD CONSTRAINT [PK_PayerPrimaryTimers]
    PRIMARY KEY CLUSTERED ([PayerPrimaryTimerID] ASC);
GO

-- Creating primary key on [PayerTimerConfigurationID] in table 'PayerTimerConfigurations'
ALTER TABLE [dbo].[PayerTimerConfigurations]
ADD CONSTRAINT [PK_PayerTimerConfigurations]
    PRIMARY KEY CLUSTERED ([PayerTimerConfigurationID] ASC);
GO

-- Creating primary key on [PayerTimerConfigurationStateID] in table 'PayerTimerConfiguration_State'
ALTER TABLE [dbo].[PayerTimerConfiguration_State]
ADD CONSTRAINT [PK_PayerTimerConfiguration_State]
    PRIMARY KEY CLUSTERED ([PayerTimerConfigurationStateID] ASC);
GO

-- Creating primary key on [PayerXrtCodeID] in table 'PayerXrtCodes'
ALTER TABLE [dbo].[PayerXrtCodes]
ADD CONSTRAINT [PK_PayerXrtCodes]
    PRIMARY KEY CLUSTERED ([PayerXrtCodeID] ASC);
GO

-- Creating primary key on [PostDenialConfigurationID] in table 'PostDenialConfigurations'
ALTER TABLE [dbo].[PostDenialConfigurations]
ADD CONSTRAINT [PK_PostDenialConfigurations]
    PRIMARY KEY CLUSTERED ([PostDenialConfigurationID] ASC);
GO

-- Creating primary key on [PracticeGroupID] in table 'PracticeGroups'
ALTER TABLE [dbo].[PracticeGroups]
ADD CONSTRAINT [PK_PracticeGroups]
    PRIMARY KEY CLUSTERED ([PracticeGroupID] ASC);
GO

-- Creating primary key on [PracticeGroupAddressID] in table 'PracticeGroupAddresses'
ALTER TABLE [dbo].[PracticeGroupAddresses]
ADD CONSTRAINT [PK_PracticeGroupAddresses]
    PRIMARY KEY CLUSTERED ([PracticeGroupAddressID] ASC);
GO

-- Creating primary key on [PracticeGroupPayerID] in table 'PracticeGroupPayers'
ALTER TABLE [dbo].[PracticeGroupPayers]
ADD CONSTRAINT [PK_PracticeGroupPayers]
    PRIMARY KEY CLUSTERED ([PracticeGroupPayerID] ASC);
GO

-- Creating primary key on [PracticeGroupUserID] in table 'PracticeGroupUsers'
ALTER TABLE [dbo].[PracticeGroupUsers]
ADD CONSTRAINT [PK_PracticeGroupUsers]
    PRIMARY KEY CLUSTERED ([PracticeGroupUserID] ASC);
GO

-- Creating primary key on [PreferredDrugRuleID] in table 'PreferredDrugRules'
ALTER TABLE [dbo].[PreferredDrugRules]
ADD CONSTRAINT [PK_PreferredDrugRules]
    PRIMARY KEY CLUSTERED ([PreferredDrugRuleID] ASC);
GO

-- Creating primary key on [PreferredProtocolProgram_PatientProtocolAssignment_ProtocolID] in table 'PreferredProtocolProgram_PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PreferredProtocolProgram_PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [PK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol]
    PRIMARY KEY CLUSTERED ([PreferredProtocolProgram_PatientProtocolAssignment_ProtocolID] ASC);
GO

-- Creating primary key on [PreferredRegimenDrugBagId] in table 'PreferredRegimenDrugBags'
ALTER TABLE [dbo].[PreferredRegimenDrugBags]
ADD CONSTRAINT [PK_PreferredRegimenDrugBags]
    PRIMARY KEY CLUSTERED ([PreferredRegimenDrugBagId] ASC);
GO

-- Creating primary key on [PreferredRegimenEvaluationId] in table 'PreferredRegimenEvaluations'
ALTER TABLE [dbo].[PreferredRegimenEvaluations]
ADD CONSTRAINT [PK_PreferredRegimenEvaluations]
    PRIMARY KEY CLUSTERED ([PreferredRegimenEvaluationId] ASC);
GO

-- Creating primary key on [PreferredRegimenRuleId] in table 'PreferredRegimenRules'
ALTER TABLE [dbo].[PreferredRegimenRules]
ADD CONSTRAINT [PK_PreferredRegimenRules]
    PRIMARY KEY CLUSTERED ([PreferredRegimenRuleId] ASC);
GO

-- Creating primary key on [PrerequisiteDrugID] in table 'PrerequisiteDrugs'
ALTER TABLE [dbo].[PrerequisiteDrugs]
ADD CONSTRAINT [PK_PrerequisiteDrugs]
    PRIMARY KEY CLUSTERED ([PrerequisiteDrugID] ASC);
GO

-- Creating primary key on [ProcedureCodeSimpleDescriptionID] in table 'ProcedureCodeSimpleDescriptions'
ALTER TABLE [dbo].[ProcedureCodeSimpleDescriptions]
ADD CONSTRAINT [PK_ProcedureCodeSimpleDescriptions]
    PRIMARY KEY CLUSTERED ([ProcedureCodeSimpleDescriptionID] ASC);
GO

-- Creating primary key on [ProductLineID] in table 'ProductLines'
ALTER TABLE [dbo].[ProductLines]
ADD CONSTRAINT [PK_ProductLines]
    PRIMARY KEY CLUSTERED ([ProductLineID] ASC);
GO

-- Creating primary key on [ProfileSettingID] in table 'ProfileSettings'
ALTER TABLE [dbo].[ProfileSettings]
ADD CONSTRAINT [PK_ProfileSettings]
    PRIMARY KEY CLUSTERED ([ProfileSettingID] ASC);
GO

-- Creating primary key on [ProtocolID] in table 'Protocols'
ALTER TABLE [dbo].[Protocols]
ADD CONSTRAINT [PK_Protocols]
    PRIMARY KEY CLUSTERED ([ProtocolID] ASC);
GO

-- Creating primary key on [ProtocolDiagnosisID] in table 'Protocol_Diagnosis'
ALTER TABLE [dbo].[Protocol_Diagnosis]
ADD CONSTRAINT [PK_Protocol_Diagnosis]
    PRIMARY KEY CLUSTERED ([ProtocolDiagnosisID] ASC);
GO

-- Creating primary key on [ProtocolApprovalLogID] in table 'ProtocolApprovalLogs'
ALTER TABLE [dbo].[ProtocolApprovalLogs]
ADD CONSTRAINT [PK_ProtocolApprovalLogs]
    PRIMARY KEY CLUSTERED ([ProtocolApprovalLogID] ASC);
GO

-- Creating primary key on [ProtocolApprovalLogRuleID] in table 'ProtocolApprovalLogRules'
ALTER TABLE [dbo].[ProtocolApprovalLogRules]
ADD CONSTRAINT [PK_ProtocolApprovalLogRules]
    PRIMARY KEY CLUSTERED ([ProtocolApprovalLogRuleID] ASC);
GO

-- Creating primary key on [ProtocolAuthorizationTipID] in table 'ProtocolAuthorizationTips'
ALTER TABLE [dbo].[ProtocolAuthorizationTips]
ADD CONSTRAINT [PK_ProtocolAuthorizationTips]
    PRIMARY KEY CLUSTERED ([ProtocolAuthorizationTipID] ASC);
GO

-- Creating primary key on [ProtocolElementID] in table 'ProtocolElements'
ALTER TABLE [dbo].[ProtocolElements]
ADD CONSTRAINT [PK_ProtocolElements]
    PRIMARY KEY CLUSTERED ([ProtocolElementID] ASC);
GO

-- Creating primary key on [ProtocolElement_RxNavDenormID] in table 'ProtocolElement_RxNavDenorms'
ALTER TABLE [dbo].[ProtocolElement_RxNavDenorms]
ADD CONSTRAINT [PK_ProtocolElement_RxNavDenorms]
    PRIMARY KEY CLUSTERED ([ProtocolElement_RxNavDenormID] ASC);
GO

-- Creating primary key on [ProtocolElementBillingUnitsID] in table 'ProtocolElementBillingUnits'
ALTER TABLE [dbo].[ProtocolElementBillingUnits]
ADD CONSTRAINT [PK_ProtocolElementBillingUnits]
    PRIMARY KEY CLUSTERED ([ProtocolElementBillingUnitsID] ASC);
GO

-- Creating primary key on [ProtocolElementCodeID] in table 'ProtocolElementCodes'
ALTER TABLE [dbo].[ProtocolElementCodes]
ADD CONSTRAINT [PK_ProtocolElementCodes]
    PRIMARY KEY CLUSTERED ([ProtocolElementCodeID] ASC);
GO

-- Creating primary key on [ProtocolElementCodeFormularyDataID] in table 'ProtocolElementCodeFormularyDatas'
ALTER TABLE [dbo].[ProtocolElementCodeFormularyDatas]
ADD CONSTRAINT [PK_ProtocolElementCodeFormularyDatas]
    PRIMARY KEY CLUSTERED ([ProtocolElementCodeFormularyDataID] ASC);
GO

-- Creating primary key on [ProtocolElementDosingID] in table 'ProtocolElementDosings'
ALTER TABLE [dbo].[ProtocolElementDosings]
ADD CONSTRAINT [PK_ProtocolElementDosings]
    PRIMARY KEY CLUSTERED ([ProtocolElementDosingID] ASC);
GO

-- Creating primary key on [ProtocolElementDosingVialID] in table 'ProtocolElementDosingVials'
ALTER TABLE [dbo].[ProtocolElementDosingVials]
ADD CONSTRAINT [PK_ProtocolElementDosingVials]
    PRIMARY KEY CLUSTERED ([ProtocolElementDosingVialID] ASC);
GO

-- Creating primary key on [ProtocolElementXRTID] in table 'ProtocolElementXRTs'
ALTER TABLE [dbo].[ProtocolElementXRTs]
ADD CONSTRAINT [PK_ProtocolElementXRTs]
    PRIMARY KEY CLUSTERED ([ProtocolElementXRTID] ASC);
GO

-- Creating primary key on [ProtocolEvidenceLinkID] in table 'ProtocolEvidenceLinks'
ALTER TABLE [dbo].[ProtocolEvidenceLinks]
ADD CONSTRAINT [PK_ProtocolEvidenceLinks]
    PRIMARY KEY CLUSTERED ([ProtocolEvidenceLinkID] ASC);
GO

-- Creating primary key on [ProtocolIntentOfTherapyID] in table 'ProtocolIntentOfTherapies'
ALTER TABLE [dbo].[ProtocolIntentOfTherapies]
ADD CONSTRAINT [PK_ProtocolIntentOfTherapies]
    PRIMARY KEY CLUSTERED ([ProtocolIntentOfTherapyID] ASC);
GO

-- Creating primary key on [ProtocolLineOfTherapyID] in table 'ProtocolLineOfTherapies'
ALTER TABLE [dbo].[ProtocolLineOfTherapies]
ADD CONSTRAINT [PK_ProtocolLineOfTherapies]
    PRIMARY KEY CLUSTERED ([ProtocolLineOfTherapyID] ASC);
GO

-- Creating primary key on [ProtocolID] in table 'ProtocolMGTs'
ALTER TABLE [dbo].[ProtocolMGTs]
ADD CONSTRAINT [PK_ProtocolMGTs]
    PRIMARY KEY CLUSTERED ([ProtocolID] ASC);
GO

-- Creating primary key on [ProtocolMolecularMarkerID] in table 'ProtocolMolecularMarkers'
ALTER TABLE [dbo].[ProtocolMolecularMarkers]
ADD CONSTRAINT [PK_ProtocolMolecularMarkers]
    PRIMARY KEY CLUSTERED ([ProtocolMolecularMarkerID] ASC);
GO

-- Creating primary key on [ProtocolNCCNCategoryID] in table 'ProtocolNCCNCategories'
ALTER TABLE [dbo].[ProtocolNCCNCategories]
ADD CONSTRAINT [PK_ProtocolNCCNCategories]
    PRIMARY KEY CLUSTERED ([ProtocolNCCNCategoryID] ASC);
GO

-- Creating primary key on [ProtocolPerformaceStatusID] in table 'ProtocolPerformaceStatus'
ALTER TABLE [dbo].[ProtocolPerformaceStatus]
ADD CONSTRAINT [PK_ProtocolPerformaceStatus]
    PRIMARY KEY CLUSTERED ([ProtocolPerformaceStatusID] ASC);
GO

-- Creating primary key on [ProtocolQuestionID] in table 'ProtocolQuestions'
ALTER TABLE [dbo].[ProtocolQuestions]
ADD CONSTRAINT [PK_ProtocolQuestions]
    PRIMARY KEY CLUSTERED ([ProtocolQuestionID] ASC);
GO

-- Creating primary key on [ProtocolRequestID] in table 'ProtocolRequests'
ALTER TABLE [dbo].[ProtocolRequests]
ADD CONSTRAINT [PK_ProtocolRequests]
    PRIMARY KEY CLUSTERED ([ProtocolRequestID] ASC);
GO

-- Creating primary key on [ProtocolRequestDrugID] in table 'ProtocolRequestDrugs'
ALTER TABLE [dbo].[ProtocolRequestDrugs]
ADD CONSTRAINT [PK_ProtocolRequestDrugs]
    PRIMARY KEY CLUSTERED ([ProtocolRequestDrugID] ASC);
GO

-- Creating primary key on [ProtocolSettingOfTherapyID] in table 'ProtocolSettingOfTherapies'
ALTER TABLE [dbo].[ProtocolSettingOfTherapies]
ADD CONSTRAINT [PK_ProtocolSettingOfTherapies]
    PRIMARY KEY CLUSTERED ([ProtocolSettingOfTherapyID] ASC);
GO

-- Creating primary key on [ProtocolID] in table 'ProtocolXRTs'
ALTER TABLE [dbo].[ProtocolXRTs]
ADD CONSTRAINT [PK_ProtocolXRTs]
    PRIMARY KEY CLUSTERED ([ProtocolID] ASC);
GO

-- Creating primary key on [ProviderID] in table 'Providers'
ALTER TABLE [dbo].[Providers]
ADD CONSTRAINT [PK_Providers]
    PRIMARY KEY CLUSTERED ([ProviderID] ASC);
GO

-- Creating primary key on [ProviderInfoDataID] in table 'ProviderInfoDatas'
ALTER TABLE [dbo].[ProviderInfoDatas]
ADD CONSTRAINT [PK_ProviderInfoDatas]
    PRIMARY KEY CLUSTERED ([ProviderInfoDataID] ASC);
GO

-- Creating primary key on [QppAttestationReportResultID] in table 'QppAttestationReportResults'
ALTER TABLE [dbo].[QppAttestationReportResults]
ADD CONSTRAINT [PK_QppAttestationReportResults]
    PRIMARY KEY CLUSTERED ([QppAttestationReportResultID] ASC);
GO

-- Creating primary key on [QppReportSettingId] in table 'QppReportSettings'
ALTER TABLE [dbo].[QppReportSettings]
ADD CONSTRAINT [PK_QppReportSettings]
    PRIMARY KEY CLUSTERED ([QppReportSettingId] ASC);
GO

-- Creating primary key on [ReferenceNumberID] in table 'ReferenceNumbers'
ALTER TABLE [dbo].[ReferenceNumbers]
ADD CONSTRAINT [PK_ReferenceNumbers]
    PRIMARY KEY CLUSTERED ([ReferenceNumberID] ASC);
GO

-- Creating primary key on [RuleID] in table 'Rules'
ALTER TABLE [dbo].[Rules]
ADD CONSTRAINT [PK_Rules]
    PRIMARY KEY CLUSTERED ([RuleID] ASC);
GO

-- Creating primary key on [RxNavDenormId] in table 'RxNavDenorms'
ALTER TABLE [dbo].[RxNavDenorms]
ADD CONSTRAINT [PK_RxNavDenorms]
    PRIMARY KEY CLUSTERED ([RxNavDenormId] ASC);
GO

-- Creating primary key on [SalesforceStagingLoadID] in table 'SalesforceStagingLoads'
ALTER TABLE [dbo].[SalesforceStagingLoads]
ADD CONSTRAINT [PK_SalesforceStagingLoads]
    PRIMARY KEY CLUSTERED ([SalesforceStagingLoadID] ASC);
GO

-- Creating primary key on [SecurityGroupID] in table 'SecurityGroups'
ALTER TABLE [dbo].[SecurityGroups]
ADD CONSTRAINT [PK_SecurityGroups]
    PRIMARY KEY CLUSTERED ([SecurityGroupID] ASC);
GO

-- Creating primary key on [SecurityGroupMenuOptionID] in table 'SecurityGroup_MenuOption'
ALTER TABLE [dbo].[SecurityGroup_MenuOption]
ADD CONSTRAINT [PK_SecurityGroup_MenuOption]
    PRIMARY KEY CLUSTERED ([SecurityGroupMenuOptionID] ASC);
GO

-- Creating primary key on [sfId] in table 'SfOriginAccounts'
ALTER TABLE [dbo].[SfOriginAccounts]
ADD CONSTRAINT [PK_SfOriginAccounts]
    PRIMARY KEY CLUSTERED ([sfId] ASC);
GO

-- Creating primary key on [sfId] in table 'SfOriginAccountStagings'
ALTER TABLE [dbo].[SfOriginAccountStagings]
ADD CONSTRAINT [PK_SfOriginAccountStagings]
    PRIMARY KEY CLUSTERED ([sfId] ASC);
GO

-- Creating primary key on [sfId] in table 'SfOriginContacts'
ALTER TABLE [dbo].[SfOriginContacts]
ADD CONSTRAINT [PK_SfOriginContacts]
    PRIMARY KEY CLUSTERED ([sfId] ASC);
GO

-- Creating primary key on [sfId] in table 'SfOriginContactStagings'
ALTER TABLE [dbo].[SfOriginContactStagings]
ADD CONSTRAINT [PK_SfOriginContactStagings]
    PRIMARY KEY CLUSTERED ([sfId] ASC);
GO

-- Creating primary key on [SideEffectID] in table 'SideEffects'
ALTER TABLE [dbo].[SideEffects]
ADD CONSTRAINT [PK_SideEffects]
    PRIMARY KEY CLUSTERED ([SideEffectID] ASC);
GO

-- Creating primary key on [StateCode] in table 'States'
ALTER TABLE [dbo].[States]
ADD CONSTRAINT [PK_States]
    PRIMARY KEY CLUSTERED ([StateCode] ASC);
GO

-- Creating primary key on [StateOutofScopeRuleID] in table 'StateOutofScopeRules'
ALTER TABLE [dbo].[StateOutofScopeRules]
ADD CONSTRAINT [PK_StateOutofScopeRules]
    PRIMARY KEY CLUSTERED ([StateOutofScopeRuleID] ASC);
GO

-- Creating primary key on [StepTherapyRuleID] in table 'StepTherapyRules'
ALTER TABLE [dbo].[StepTherapyRules]
ADD CONSTRAINT [PK_StepTherapyRules]
    PRIMARY KEY CLUSTERED ([StepTherapyRuleID] ASC);
GO

-- Creating primary key on [StepTherapyRuleDiagnosisExcludedID] in table 'StepTherapyRuleDiagnosisExcludeds'
ALTER TABLE [dbo].[StepTherapyRuleDiagnosisExcludeds]
ADD CONSTRAINT [PK_StepTherapyRuleDiagnosisExcludeds]
    PRIMARY KEY CLUSTERED ([StepTherapyRuleDiagnosisExcludedID] ASC);
GO

-- Creating primary key on [StepTherapyRulePatientCancerStageExcludedID] in table 'StepTherapyRulePatientCancerStageExcludeds'
ALTER TABLE [dbo].[StepTherapyRulePatientCancerStageExcludeds]
ADD CONSTRAINT [PK_StepTherapyRulePatientCancerStageExcludeds]
    PRIMARY KEY CLUSTERED ([StepTherapyRulePatientCancerStageExcludedID] ASC);
GO

-- Creating primary key on [StepTherapyRulePriorDrugID] in table 'StepTherapyRulePriorDrugs'
ALTER TABLE [dbo].[StepTherapyRulePriorDrugs]
ADD CONSTRAINT [PK_StepTherapyRulePriorDrugs]
    PRIMARY KEY CLUSTERED ([StepTherapyRulePriorDrugID] ASC);
GO

-- Creating primary key on [StepTherapyStateExcludedID] in table 'StepTherapyStateExcludeds'
ALTER TABLE [dbo].[StepTherapyStateExcludeds]
ADD CONSTRAINT [PK_StepTherapyStateExcludeds]
    PRIMARY KEY CLUSTERED ([StepTherapyStateExcludedID] ASC);
GO

-- Creating primary key on [StepTherapyStateOfPlanIssueExcludedID] in table 'StepTherapyStateOfPlanIssueExcludeds'
ALTER TABLE [dbo].[StepTherapyStateOfPlanIssueExcludeds]
ADD CONSTRAINT [PK_StepTherapyStateOfPlanIssueExcludeds]
    PRIMARY KEY CLUSTERED ([StepTherapyStateOfPlanIssueExcludedID] ASC);
GO

-- Creating primary key on [StopLossRuleID] in table 'StopLossRules'
ALTER TABLE [dbo].[StopLossRules]
ADD CONSTRAINT [PK_StopLossRules]
    PRIMARY KEY CLUSTERED ([StopLossRuleID] ASC);
GO

-- Creating primary key on [SupportedProtocolConfigurationID] in table 'SupportedProtocolConfigurations'
ALTER TABLE [dbo].[SupportedProtocolConfigurations]
ADD CONSTRAINT [PK_SupportedProtocolConfigurations]
    PRIMARY KEY CLUSTERED ([SupportedProtocolConfigurationID] ASC);
GO

-- Creating primary key on [diagram_id] in table 'sysdiagrams'
ALTER TABLE [dbo].[sysdiagrams]
ADD CONSTRAINT [PK_sysdiagrams]
    PRIMARY KEY CLUSTERED ([diagram_id] ASC);
GO

-- Creating primary key on [id] in table 'sysssislogs'
ALTER TABLE [dbo].[sysssislogs]
ADD CONSTRAINT [PK_sysssislogs]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [UniqueName] in table 'SystemConfigurations'
ALTER TABLE [dbo].[SystemConfigurations]
ADD CONSTRAINT [PK_SystemConfigurations]
    PRIMARY KEY CLUSTERED ([UniqueName] ASC);
GO

-- Creating primary key on [TATConfigurationID] in table 'TATConfigurations'
ALTER TABLE [dbo].[TATConfigurations]
ADD CONSTRAINT [PK_TATConfigurations]
    PRIMARY KEY CLUSTERED ([TATConfigurationID] ASC);
GO

-- Creating primary key on [TatEventId] in table 'TatEvents'
ALTER TABLE [dbo].[TatEvents]
ADD CONSTRAINT [PK_TatEvents]
    PRIMARY KEY CLUSTERED ([TatEventId] ASC);
GO

-- Creating primary key on [TatExtensionConfigurationID] in table 'TatExtensionConfigurations'
ALTER TABLE [dbo].[TatExtensionConfigurations]
ADD CONSTRAINT [PK_TatExtensionConfigurations]
    PRIMARY KEY CLUSTERED ([TatExtensionConfigurationID] ASC);
GO

-- Creating primary key on [AssignmentNotificationConfigurationID] in table 'TATNotifications'
ALTER TABLE [dbo].[TATNotifications]
ADD CONSTRAINT [PK_TATNotifications]
    PRIMARY KEY CLUSTERED ([AssignmentNotificationConfigurationID] ASC);
GO

-- Creating primary key on [UserID] in table 'Users'
ALTER TABLE [dbo].[Users]
ADD CONSTRAINT [PK_Users]
    PRIMARY KEY CLUSTERED ([UserID] ASC);
GO

-- Creating primary key on [UserMemberAssociationID] in table 'User_MemberAssociation'
ALTER TABLE [dbo].[User_MemberAssociation]
ADD CONSTRAINT [PK_User_MemberAssociation]
    PRIMARY KEY CLUSTERED ([UserMemberAssociationID] ASC);
GO

-- Creating primary key on [UserSecurityGroupID] in table 'User_SecurityGroup'
ALTER TABLE [dbo].[User_SecurityGroup]
ADD CONSTRAINT [PK_User_SecurityGroup]
    PRIMARY KEY CLUSTERED ([UserSecurityGroupID] ASC);
GO

-- Creating primary key on [UserAccessListID] in table 'UserAccessLists'
ALTER TABLE [dbo].[UserAccessLists]
ADD CONSTRAINT [PK_UserAccessLists]
    PRIMARY KEY CLUSTERED ([UserAccessListID] ASC);
GO

-- Creating primary key on [UserAccessList_ProviderID] in table 'UserAccessList_Provider'
ALTER TABLE [dbo].[UserAccessList_Provider]
ADD CONSTRAINT [PK_UserAccessList_Provider]
    PRIMARY KEY CLUSTERED ([UserAccessList_ProviderID] ASC);
GO

-- Creating primary key on [UserAddressID] in table 'UserAddresses'
ALTER TABLE [dbo].[UserAddresses]
ADD CONSTRAINT [PK_UserAddresses]
    PRIMARY KEY CLUSTERED ([UserAddressID] ASC);
GO

-- Creating primary key on [UserAreaCodeID] in table 'UserAreaCodes'
ALTER TABLE [dbo].[UserAreaCodes]
ADD CONSTRAINT [PK_UserAreaCodes]
    PRIMARY KEY CLUSTERED ([UserAreaCodeID] ASC);
GO

-- Creating primary key on [UserCaseAcceptanceTimeID] in table 'UserCaseAcceptanceTimes'
ALTER TABLE [dbo].[UserCaseAcceptanceTimes]
ADD CONSTRAINT [PK_UserCaseAcceptanceTimes]
    PRIMARY KEY CLUSTERED ([UserCaseAcceptanceTimeID] ASC);
GO

-- Creating primary key on [UserContactID] in table 'UserContacts'
ALTER TABLE [dbo].[UserContacts]
ADD CONSTRAINT [PK_UserContacts]
    PRIMARY KEY CLUSTERED ([UserContactID] ASC);
GO

-- Creating primary key on [UserFeedbackID] in table 'UserFeedbacks'
ALTER TABLE [dbo].[UserFeedbacks]
ADD CONSTRAINT [PK_UserFeedbacks]
    PRIMARY KEY CLUSTERED ([UserFeedbackID] ASC);
GO

-- Creating primary key on [UserLicenseID] in table 'UserLicenses'
ALTER TABLE [dbo].[UserLicenses]
ADD CONSTRAINT [PK_UserLicenses]
    PRIMARY KEY CLUSTERED ([UserLicenseID] ASC);
GO

-- Creating primary key on [UserLoginActivityID] in table 'UserLoginActivities'
ALTER TABLE [dbo].[UserLoginActivities]
ADD CONSTRAINT [PK_UserLoginActivities]
    PRIMARY KEY CLUSTERED ([UserLoginActivityID] ASC);
GO

-- Creating primary key on [UserProfileSettingID] in table 'UserProfileSettings'
ALTER TABLE [dbo].[UserProfileSettings]
ADD CONSTRAINT [PK_UserProfileSettings]
    PRIMARY KEY CLUSTERED ([UserProfileSettingID] ASC);
GO

-- Creating primary key on [VerificationCodeActivityID] in table 'VerificationCodeActivities'
ALTER TABLE [dbo].[VerificationCodeActivities]
ADD CONSTRAINT [PK_VerificationCodeActivities]
    PRIMARY KEY CLUSTERED ([VerificationCodeActivityID] ASC);
GO

-- Creating primary key on [WorkFlowQueueConfigurationID] in table 'WorkFlowQueueConfigurations'
ALTER TABLE [dbo].[WorkFlowQueueConfigurations]
ADD CONSTRAINT [PK_WorkFlowQueueConfigurations]
    PRIMARY KEY CLUSTERED ([WorkFlowQueueConfigurationID] ASC);
GO

-- Creating primary key on [WorkQueueID] in table 'WorkQueues'
ALTER TABLE [dbo].[WorkQueues]
ADD CONSTRAINT [PK_WorkQueues]
    PRIMARY KEY CLUSTERED ([WorkQueueID] ASC);
GO

-- Creating primary key on [WorkQueueSecurityGroupID] in table 'WorkQueue_SecurityGroup'
ALTER TABLE [dbo].[WorkQueue_SecurityGroup]
ADD CONSTRAINT [PK_WorkQueue_SecurityGroup]
    PRIMARY KEY CLUSTERED ([WorkQueueSecurityGroupID] ASC);
GO

-- Creating primary key on [runid], [ruleid], [ruleblock], [rulenum], [rulesubscript], [ruletype], [rulecreated], [ruleupdated], [secondsactive], [rulestatus] in table 'DMSSTAT_RSTATS'
ALTER TABLE [dbo].[DMSSTAT_RSTATS]
ADD CONSTRAINT [PK_DMSSTAT_RSTATS]
    PRIMARY KEY CLUSTERED ([runid], [ruleid], [ruleblock], [rulenum], [rulesubscript], [ruletype], [rulecreated], [ruleupdated], [secondsactive], [rulestatus] ASC);
GO

-- Creating primary key on [runid], [ruleid], [statscreated], [statsupdated], [ruletype], [ruleblock], [rulenum], [rulesubscript], [tabledatabase], [tableschema], [tablename] in table 'DMSSTAT_TSTATS'
ALTER TABLE [dbo].[DMSSTAT_TSTATS]
ADD CONSTRAINT [PK_DMSSTAT_TSTATS]
    PRIMARY KEY CLUSTERED ([runid], [ruleid], [statscreated], [statsupdated], [ruletype], [ruleblock], [rulenum], [rulesubscript], [tabledatabase], [tableschema], [tablename] ASC);
GO

-- Creating primary key on [PatientProtocolAssignmentVitalSignID] in table 'PatientProtocolAssignment_VitalSign'
ALTER TABLE [dbo].[PatientProtocolAssignment_VitalSign]
ADD CONSTRAINT [PK_PatientProtocolAssignment_VitalSign]
    PRIMARY KEY CLUSTERED ([PatientProtocolAssignmentVitalSignID] ASC);
GO

-- Creating primary key on [DynamicFaxContentID] in table 'DynamicFaxContents'
ALTER TABLE [dbo].[DynamicFaxContents]
ADD CONSTRAINT [PK_DynamicFaxContents]
    PRIMARY KEY CLUSTERED ([DynamicFaxContentID] ASC);
GO

-- Creating primary key on [ExcludedPCPID] in table 'ExcludedPCPs'
ALTER TABLE [dbo].[ExcludedPCPs]
ADD CONSTRAINT [PK_ExcludedPCPs]
    PRIMARY KEY CLUSTERED ([ExcludedPCPID] ASC);
GO

-- Creating primary key on [SpecialtyDrugCodeID] in table 'SpecialtyDrugCodes'
ALTER TABLE [dbo].[SpecialtyDrugCodes]
ADD CONSTRAINT [PK_SpecialtyDrugCodes]
    PRIMARY KEY CLUSTERED ([SpecialtyDrugCodeID] ASC);
GO

-- Creating primary key on [LineOfBusiness_CAGSettingId] in table 'LineOfBusiness_CAGSetting'
ALTER TABLE [dbo].[LineOfBusiness_CAGSetting]
ADD CONSTRAINT [PK_LineOfBusiness_CAGSetting]
    PRIMARY KEY CLUSTERED ([LineOfBusiness_CAGSettingId] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [LifeExpectancyDescriptionID] in table 'ActiveSurveillanceLifeExpectancies'
ALTER TABLE [dbo].[ActiveSurveillanceLifeExpectancies]
ADD CONSTRAINT [FK_ActiveSurveillanceLifeExpectancy_ActiveSruveillanceLifeExpectancyDescription]
    FOREIGN KEY ([LifeExpectancyDescriptionID])
    REFERENCES [dbo].[ActiveSruveillanceLifeExpectancyDescriptions]
        ([LifeExpectancyDescriptionID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ActiveSurveillanceLifeExpectancy_ActiveSruveillanceLifeExpectancyDescription'
CREATE INDEX [IX_FK_ActiveSurveillanceLifeExpectancy_ActiveSruveillanceLifeExpectancyDescription]
ON [dbo].[ActiveSurveillanceLifeExpectancies]
    ([LifeExpectancyDescriptionID]);
GO

-- Creating foreign key on [AssessmentQuestionPossibleAnswerID] in table 'ActiveSurveillanceLifeExpectancies'
ALTER TABLE [dbo].[ActiveSurveillanceLifeExpectancies]
ADD CONSTRAINT [FK_ActiveSurveillanceLifeExpectancy_AssessmentQuestionPossibleAnswer]
    FOREIGN KEY ([AssessmentQuestionPossibleAnswerID])
    REFERENCES [dbo].[AssessmentQuestionPossibleAnswers]
        ([AssessmentQuestionPossibleAnswerID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ActiveSurveillanceLifeExpectancy_AssessmentQuestionPossibleAnswer'
CREATE INDEX [IX_FK_ActiveSurveillanceLifeExpectancy_AssessmentQuestionPossibleAnswer]
ON [dbo].[ActiveSurveillanceLifeExpectancies]
    ([AssessmentQuestionPossibleAnswerID]);
GO

-- Creating foreign key on [StateCode] in table 'Addresses'
ALTER TABLE [dbo].[Addresses]
ADD CONSTRAINT [FK_Address_State]
    FOREIGN KEY ([StateCode])
    REFERENCES [dbo].[States]
        ([StateCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Address_State'
CREATE INDEX [IX_FK_Address_State]
ON [dbo].[Addresses]
    ([StateCode]);
GO

-- Creating foreign key on [AddressID] in table 'InsuranceProvider_Address'
ALTER TABLE [dbo].[InsuranceProvider_Address]
ADD CONSTRAINT [FK_InsuranceProvider_Address_Address]
    FOREIGN KEY ([AddressID])
    REFERENCES [dbo].[Addresses]
        ([AddressID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProvider_Address_Address'
CREATE INDEX [IX_FK_InsuranceProvider_Address_Address]
ON [dbo].[InsuranceProvider_Address]
    ([AddressID]);
GO

-- Creating foreign key on [AddressID] in table 'PracticeGroupAddresses'
ALTER TABLE [dbo].[PracticeGroupAddresses]
ADD CONSTRAINT [FK_PracticeGroupAddress_Address_AddressID]
    FOREIGN KEY ([AddressID])
    REFERENCES [dbo].[Addresses]
        ([AddressID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PracticeGroupAddress_Address_AddressID'
CREATE INDEX [IX_FK_PracticeGroupAddress_Address_AddressID]
ON [dbo].[PracticeGroupAddresses]
    ([AddressID]);
GO

-- Creating foreign key on [AggregationRuleID] in table 'Aggregations'
ALTER TABLE [dbo].[Aggregations]
ADD CONSTRAINT [FK_Aggregation_AggregationRule]
    FOREIGN KEY ([AggregationRuleID])
    REFERENCES [dbo].[AggregationRules]
        ([AggregationRuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Aggregation_AggregationRule'
CREATE INDEX [IX_FK_Aggregation_AggregationRule]
ON [dbo].[Aggregations]
    ([AggregationRuleID]);
GO

-- Creating foreign key on [ApprovalReasonID] in table 'Aggregations'
ALTER TABLE [dbo].[Aggregations]
ADD CONSTRAINT [FK_Aggregation_LookupElement_ApprovalReason]
    FOREIGN KEY ([ApprovalReasonID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Aggregation_LookupElement_ApprovalReason'
CREATE INDEX [IX_FK_Aggregation_LookupElement_ApprovalReason]
ON [dbo].[Aggregations]
    ([ApprovalReasonID]);
GO

-- Creating foreign key on [ApprovalRuleID] in table 'Aggregations'
ALTER TABLE [dbo].[Aggregations]
ADD CONSTRAINT [FK_Aggregation_LookupElement_ApprovalRule]
    FOREIGN KEY ([ApprovalRuleID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Aggregation_LookupElement_ApprovalRule'
CREATE INDEX [IX_FK_Aggregation_LookupElement_ApprovalRule]
ON [dbo].[Aggregations]
    ([ApprovalRuleID]);
GO

-- Creating foreign key on [AutoProcessID] in table 'Aggregations'
ALTER TABLE [dbo].[Aggregations]
ADD CONSTRAINT [FK_Aggregation_LookupElement_AutoProcess]
    FOREIGN KEY ([AutoProcessID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Aggregation_LookupElement_AutoProcess'
CREATE INDEX [IX_FK_Aggregation_LookupElement_AutoProcess]
ON [dbo].[Aggregations]
    ([AutoProcessID]);
GO

-- Creating foreign key on [AggregationRuleID] in table 'AggregationResolutions'
ALTER TABLE [dbo].[AggregationResolutions]
ADD CONSTRAINT [FK_AggregationResolution_AggregationRule]
    FOREIGN KEY ([AggregationRuleID])
    REFERENCES [dbo].[AggregationRules]
        ([AggregationRuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AggregationResolution_AggregationRule'
CREATE INDEX [IX_FK_AggregationResolution_AggregationRule]
ON [dbo].[AggregationResolutions]
    ([AggregationRuleID]);
GO

-- Creating foreign key on [AutoProcessID] in table 'AggregationResolutions'
ALTER TABLE [dbo].[AggregationResolutions]
ADD CONSTRAINT [FK_AggregationResulution_LookupElement_AutoProcess]
    FOREIGN KEY ([AutoProcessID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AggregationResulution_LookupElement_AutoProcess'
CREATE INDEX [IX_FK_AggregationResulution_LookupElement_AutoProcess]
ON [dbo].[AggregationResolutions]
    ([AutoProcessID]);
GO

-- Creating foreign key on [RuleID] in table 'AggregationRules'
ALTER TABLE [dbo].[AggregationRules]
ADD CONSTRAINT [FK_AggregationRule_Rule]
    FOREIGN KEY ([RuleID])
    REFERENCES [dbo].[Rules]
        ([RuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AggregationRule_Rule'
CREATE INDEX [IX_FK_AggregationRule_Rule]
ON [dbo].[AggregationRules]
    ([RuleID]);
GO

-- Creating foreign key on [DrugID] in table 'ApprovedDrugsOverturnLists'
ALTER TABLE [dbo].[ApprovedDrugsOverturnLists]
ADD CONSTRAINT [FK_ApprovedDrugsOverturnList_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ApprovedDrugsOverturnList_Drug'
CREATE INDEX [IX_FK_ApprovedDrugsOverturnList_Drug]
ON [dbo].[ApprovedDrugsOverturnLists]
    ([DrugID]);
GO

-- Creating foreign key on [AreaCodeID] in table 'UserAreaCodes'
ALTER TABLE [dbo].[UserAreaCodes]
ADD CONSTRAINT [FK_UserAreaCode_AreaCodeLookupElement]
    FOREIGN KEY ([AreaCodeID])
    REFERENCES [dbo].[AreaCodeLookupElements]
        ([AreaCodeID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserAreaCode_AreaCodeLookupElement'
CREATE INDEX [IX_FK_UserAreaCode_AreaCodeLookupElement]
ON [dbo].[UserAreaCodes]
    ([AreaCodeID]);
GO

-- Creating foreign key on [ActiveSurveillanceFormID] in table 'AssessmentDiagnosis'
ALTER TABLE [dbo].[AssessmentDiagnosis]
ADD CONSTRAINT [FK_AssessmentDiagnosis_AssessmentType]
    FOREIGN KEY ([ActiveSurveillanceFormID])
    REFERENCES [dbo].[AssessmentTypes]
        ([AssessmentTypeID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssessmentDiagnosis_AssessmentType'
CREATE INDEX [IX_FK_AssessmentDiagnosis_AssessmentType]
ON [dbo].[AssessmentDiagnosis]
    ([ActiveSurveillanceFormID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'AssessmentDiagnosis'
ALTER TABLE [dbo].[AssessmentDiagnosis]
ADD CONSTRAINT [FK_AssessmentDiagnosis_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssessmentDiagnosis_Diagnosis'
CREATE INDEX [IX_FK_AssessmentDiagnosis_Diagnosis]
ON [dbo].[AssessmentDiagnosis]
    ([DiagnosisID]);
GO

-- Creating foreign key on [StageID] in table 'AssessmentDiagnosis'
ALTER TABLE [dbo].[AssessmentDiagnosis]
ADD CONSTRAINT [FK_AssessmentDiagnosis_LookupElement]
    FOREIGN KEY ([StageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssessmentDiagnosis_LookupElement'
CREATE INDEX [IX_FK_AssessmentDiagnosis_LookupElement]
ON [dbo].[AssessmentDiagnosis]
    ([StageID]);
GO

-- Creating foreign key on [ProtocolID] in table 'AssessmentDiagnosis'
ALTER TABLE [dbo].[AssessmentDiagnosis]
ADD CONSTRAINT [FK_AssessmentDiagnosis_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssessmentDiagnosis_Protocol'
CREATE INDEX [IX_FK_AssessmentDiagnosis_Protocol]
ON [dbo].[AssessmentDiagnosis]
    ([ProtocolID]);
GO

-- Creating foreign key on [ParentQuestionID] in table 'AssessmentQuestions'
ALTER TABLE [dbo].[AssessmentQuestions]
ADD CONSTRAINT [FK_AssessmentQuestion_AssessmentQuestion]
    FOREIGN KEY ([ParentQuestionID])
    REFERENCES [dbo].[AssessmentQuestions]
        ([AssessmentQuestionID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssessmentQuestion_AssessmentQuestion'
CREATE INDEX [IX_FK_AssessmentQuestion_AssessmentQuestion]
ON [dbo].[AssessmentQuestions]
    ([ParentQuestionID]);
GO

-- Creating foreign key on [AssessmentQuestionID] in table 'AssessmentQuestionPossibleAnswers'
ALTER TABLE [dbo].[AssessmentQuestionPossibleAnswers]
ADD CONSTRAINT [FK_AssessmentQuestionPossibleAnswer_AssessmentQuestion]
    FOREIGN KEY ([AssessmentQuestionID])
    REFERENCES [dbo].[AssessmentQuestions]
        ([AssessmentQuestionID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssessmentQuestionPossibleAnswer_AssessmentQuestion'
CREATE INDEX [IX_FK_AssessmentQuestionPossibleAnswer_AssessmentQuestion]
ON [dbo].[AssessmentQuestionPossibleAnswers]
    ([AssessmentQuestionID]);
GO

-- Creating foreign key on [AssessmentQuestionID] in table 'AssessmentType_AssessmentQuestion'
ALTER TABLE [dbo].[AssessmentType_AssessmentQuestion]
ADD CONSTRAINT [FK_AssessmentType_AssessmentQuestion_AssessmentQuestion]
    FOREIGN KEY ([AssessmentQuestionID])
    REFERENCES [dbo].[AssessmentQuestions]
        ([AssessmentQuestionID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssessmentType_AssessmentQuestion_AssessmentQuestion'
CREATE INDEX [IX_FK_AssessmentType_AssessmentQuestion_AssessmentQuestion]
ON [dbo].[AssessmentType_AssessmentQuestion]
    ([AssessmentQuestionID]);
GO

-- Creating foreign key on [AssessmentQuestionID] in table 'NCCNRecurrenceRiskFormulas'
ALTER TABLE [dbo].[NCCNRecurrenceRiskFormulas]
ADD CONSTRAINT [FK_NCCNRecurrenceRiskFormula_AssessmentQuestion]
    FOREIGN KEY ([AssessmentQuestionID])
    REFERENCES [dbo].[AssessmentQuestions]
        ([AssessmentQuestionID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_NCCNRecurrenceRiskFormula_AssessmentQuestion'
CREATE INDEX [IX_FK_NCCNRecurrenceRiskFormula_AssessmentQuestion]
ON [dbo].[NCCNRecurrenceRiskFormulas]
    ([AssessmentQuestionID]);
GO

-- Creating foreign key on [AssessmentQuestionID] in table 'PatientAssessmentAnswers'
ALTER TABLE [dbo].[PatientAssessmentAnswers]
ADD CONSTRAINT [FK_PatientAssessmentAnswer_AssessmentQuestion]
    FOREIGN KEY ([AssessmentQuestionID])
    REFERENCES [dbo].[AssessmentQuestions]
        ([AssessmentQuestionID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientAssessmentAnswer_AssessmentQuestion'
CREATE INDEX [IX_FK_PatientAssessmentAnswer_AssessmentQuestion]
ON [dbo].[PatientAssessmentAnswers]
    ([AssessmentQuestionID]);
GO

-- Creating foreign key on [AssessmentQuestionPossibleAnswerID] in table 'PatientAssessmentAnswers'
ALTER TABLE [dbo].[PatientAssessmentAnswers]
ADD CONSTRAINT [FK_PatientAssessmentAnswer_AssessmentQuestionPossibleAnswer]
    FOREIGN KEY ([AssessmentQuestionPossibleAnswerID])
    REFERENCES [dbo].[AssessmentQuestionPossibleAnswers]
        ([AssessmentQuestionPossibleAnswerID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientAssessmentAnswer_AssessmentQuestionPossibleAnswer'
CREATE INDEX [IX_FK_PatientAssessmentAnswer_AssessmentQuestionPossibleAnswer]
ON [dbo].[PatientAssessmentAnswers]
    ([AssessmentQuestionPossibleAnswerID]);
GO

-- Creating foreign key on [AssessmentTypeID] in table 'AssessmentType_AssessmentQuestion'
ALTER TABLE [dbo].[AssessmentType_AssessmentQuestion]
ADD CONSTRAINT [FK_AssessmentType_AssessmentQuestion_AssessmentType]
    FOREIGN KEY ([AssessmentTypeID])
    REFERENCES [dbo].[AssessmentTypes]
        ([AssessmentTypeID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssessmentType_AssessmentQuestion_AssessmentType'
CREATE INDEX [IX_FK_AssessmentType_AssessmentQuestion_AssessmentType]
ON [dbo].[AssessmentType_AssessmentQuestion]
    ([AssessmentTypeID]);
GO

-- Creating foreign key on [AssessmentTypeID] in table 'PatientAssessments'
ALTER TABLE [dbo].[PatientAssessments]
ADD CONSTRAINT [FK_PatientAssessment_AssessmentType]
    FOREIGN KEY ([AssessmentTypeID])
    REFERENCES [dbo].[AssessmentTypes]
        ([AssessmentTypeID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientAssessment_AssessmentType'
CREATE INDEX [IX_FK_PatientAssessment_AssessmentType]
ON [dbo].[PatientAssessments]
    ([AssessmentTypeID]);
GO

-- Creating foreign key on [ActionID] in table 'AssignmentActions'
ALTER TABLE [dbo].[AssignmentActions]
ADD CONSTRAINT [FK_AssignmentAction_LookupElement]
    FOREIGN KEY ([ActionID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssignmentAction_LookupElement'
CREATE INDEX [IX_FK_AssignmentAction_LookupElement]
ON [dbo].[AssignmentActions]
    ([ActionID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'AssignmentActions'
ALTER TABLE [dbo].[AssignmentActions]
ADD CONSTRAINT [FK_AssignmentAction_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssignmentAction_PatientProtocolAssignment'
CREATE INDEX [IX_FK_AssignmentAction_PatientProtocolAssignment]
ON [dbo].[AssignmentActions]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentPostDenialID] in table 'AssignmentActions'
ALTER TABLE [dbo].[AssignmentActions]
ADD CONSTRAINT [FK_AssignmentAction_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID]
    FOREIGN KEY ([PatientProtocolAssignmentPostDenialID])
    REFERENCES [dbo].[PatientProtocolAssignmentPostDenials]
        ([PatientProtocolAssignmentPostDenialID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssignmentAction_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID'
CREATE INDEX [IX_FK_AssignmentAction_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID]
ON [dbo].[AssignmentActions]
    ([PatientProtocolAssignmentPostDenialID]);
GO

-- Creating foreign key on [AssignmentActionID] in table 'Notes'
ALTER TABLE [dbo].[Notes]
ADD CONSTRAINT [FK_Note_AssignmentAction]
    FOREIGN KEY ([AssignmentActionID])
    REFERENCES [dbo].[AssignmentActions]
        ([AssignmentActionID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Note_AssignmentAction'
CREATE INDEX [IX_FK_Note_AssignmentAction]
ON [dbo].[Notes]
    ([AssignmentActionID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'AssignmentLockByUsers'
ALTER TABLE [dbo].[AssignmentLockByUsers]
ADD CONSTRAINT [FK_AssignmentLockByUser_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssignmentLockByUser_PatientProtocolAssignment'
CREATE INDEX [IX_FK_AssignmentLockByUser_PatientProtocolAssignment]
ON [dbo].[AssignmentLockByUsers]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [LockedBy] in table 'AssignmentLockByUsers'
ALTER TABLE [dbo].[AssignmentLockByUsers]
ADD CONSTRAINT [FK_AssignmentLockByUser_User]
    FOREIGN KEY ([LockedBy])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssignmentLockByUser_User'
CREATE INDEX [IX_FK_AssignmentLockByUser_User]
ON [dbo].[AssignmentLockByUsers]
    ([LockedBy]);
GO

-- Creating foreign key on [PrimaryContactID] in table 'AssignmentProviders'
ALTER TABLE [dbo].[AssignmentProviders]
ADD CONSTRAINT [FK_AssignmentProvider_Contact]
    FOREIGN KEY ([PrimaryContactID])
    REFERENCES [dbo].[Contacts]
        ([ContactID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssignmentProvider_Contact'
CREATE INDEX [IX_FK_AssignmentProvider_Contact]
ON [dbo].[AssignmentProviders]
    ([PrimaryContactID]);
GO

-- Creating foreign key on [TypeID] in table 'AssignmentProviders'
ALTER TABLE [dbo].[AssignmentProviders]
ADD CONSTRAINT [FK_AssignmentProvider_LookupElement]
    FOREIGN KEY ([TypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssignmentProvider_LookupElement'
CREATE INDEX [IX_FK_AssignmentProvider_LookupElement]
ON [dbo].[AssignmentProviders]
    ([TypeID]);
GO

-- Creating foreign key on [ProtocolAssignmentID] in table 'AssignmentProviders'
ALTER TABLE [dbo].[AssignmentProviders]
ADD CONSTRAINT [FK_AssignmentProvider_PatientProtocolAssignment]
    FOREIGN KEY ([ProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssignmentProvider_PatientProtocolAssignment'
CREATE INDEX [IX_FK_AssignmentProvider_PatientProtocolAssignment]
ON [dbo].[AssignmentProviders]
    ([ProtocolAssignmentID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'AssignmentTimeZones'
ALTER TABLE [dbo].[AssignmentTimeZones]
ADD CONSTRAINT [FK_AssignmentTimeZone_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssignmentTimeZone_PatientProtocolAssignment'
CREATE INDEX [IX_FK_AssignmentTimeZone_PatientProtocolAssignment]
ON [dbo].[AssignmentTimeZones]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'AssignmentWorkflowStatusLogs'
ALTER TABLE [dbo].[AssignmentWorkflowStatusLogs]
ADD CONSTRAINT [FK_AssignmentWorkflowStatusLog_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssignmentWorkflowStatusLog_PatientProtocolAssignment'
CREATE INDEX [IX_FK_AssignmentWorkflowStatusLog_PatientProtocolAssignment]
ON [dbo].[AssignmentWorkflowStatusLogs]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentPostDenialID] in table 'AssignmentWorkflowStatusLogs'
ALTER TABLE [dbo].[AssignmentWorkflowStatusLogs]
ADD CONSTRAINT [FK_AssignmentWorkflowStatusLog_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID]
    FOREIGN KEY ([PatientProtocolAssignmentPostDenialID])
    REFERENCES [dbo].[PatientProtocolAssignmentPostDenials]
        ([PatientProtocolAssignmentPostDenialID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssignmentWorkflowStatusLog_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID'
CREATE INDEX [IX_FK_AssignmentWorkflowStatusLog_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID]
ON [dbo].[AssignmentWorkflowStatusLogs]
    ([PatientProtocolAssignmentPostDenialID]);
GO

-- Creating foreign key on [WorkQueueID] in table 'AssignmentWorkflowStatusLogs'
ALTER TABLE [dbo].[AssignmentWorkflowStatusLogs]
ADD CONSTRAINT [FK_AssignmentWorkflowStatusLog_WorkQueue]
    FOREIGN KEY ([WorkQueueID])
    REFERENCES [dbo].[WorkQueues]
        ([WorkQueueID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AssignmentWorkflowStatusLog_WorkQueue'
CREATE INDEX [IX_FK_AssignmentWorkflowStatusLog_WorkQueue]
ON [dbo].[AssignmentWorkflowStatusLogs]
    ([WorkQueueID]);
GO

-- Creating foreign key on [DocumentRepositoryID] in table 'Attachments'
ALTER TABLE [dbo].[Attachments]
ADD CONSTRAINT [FK_Attachment_DocumentRepository]
    FOREIGN KEY ([DocumentRepositoryID])
    REFERENCES [dbo].[DocumentRepositories]
        ([DocumentRepositoryID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [PatientID] in table 'Attachments'
ALTER TABLE [dbo].[Attachments]
ADD CONSTRAINT [FK_Attachment_Patient]
    FOREIGN KEY ([PatientID])
    REFERENCES [dbo].[Patients]
        ([PatientID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Attachment_Patient'
CREATE INDEX [IX_FK_Attachment_Patient]
ON [dbo].[Attachments]
    ([PatientID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'Attachments'
ALTER TABLE [dbo].[Attachments]
ADD CONSTRAINT [FK_Attachment_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Attachment_PatientProtocolAssignment'
CREATE INDEX [IX_FK_Attachment_PatientProtocolAssignment]
ON [dbo].[Attachments]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentProtocolID] in table 'Attachments'
ALTER TABLE [dbo].[Attachments]
ADD CONSTRAINT [FK_Attachment_PatientProtocolAssignment_Protocol]
    FOREIGN KEY ([PatientProtocolAssignmentProtocolID])
    REFERENCES [dbo].[PatientProtocolAssignment_Protocol]
        ([PatientProtocolAssignmentProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Attachment_PatientProtocolAssignment_Protocol'
CREATE INDEX [IX_FK_Attachment_PatientProtocolAssignment_Protocol]
ON [dbo].[Attachments]
    ([PatientProtocolAssignmentProtocolID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentPostDenialID] in table 'Attachments'
ALTER TABLE [dbo].[Attachments]
ADD CONSTRAINT [FK_Attachment_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID]
    FOREIGN KEY ([PatientProtocolAssignmentPostDenialID])
    REFERENCES [dbo].[PatientProtocolAssignmentPostDenials]
        ([PatientProtocolAssignmentPostDenialID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Attachment_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID'
CREATE INDEX [IX_FK_Attachment_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID]
ON [dbo].[Attachments]
    ([PatientProtocolAssignmentPostDenialID]);
GO

-- Creating foreign key on [CurrentMDID] in table 'Attachments'
ALTER TABLE [dbo].[Attachments]
ADD CONSTRAINT [FK_Attachment_User_CurrentMD]
    FOREIGN KEY ([CurrentMDID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Attachment_User_CurrentMD'
CREATE INDEX [IX_FK_Attachment_User_CurrentMD]
ON [dbo].[Attachments]
    ([CurrentMDID]);
GO

-- Creating foreign key on [ObjectTypeID] in table 'AuditTrailFields'
ALTER TABLE [dbo].[AuditTrailFields]
ADD CONSTRAINT [FK_AuditTrailField_AuditTrailObjectType]
    FOREIGN KEY ([ObjectTypeID])
    REFERENCES [dbo].[AuditTrailObjectTypes]
        ([ObjectTypeID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AuditTrailField_AuditTrailObjectType'
CREATE INDEX [IX_FK_AuditTrailField_AuditTrailObjectType]
ON [dbo].[AuditTrailFields]
    ([ObjectTypeID]);
GO

-- Creating foreign key on [FieldID] in table 'AuditTrailTransactionDetails'
ALTER TABLE [dbo].[AuditTrailTransactionDetails]
ADD CONSTRAINT [FK_AuditTrailTransactionDetail_AuditTrailField]
    FOREIGN KEY ([FieldID])
    REFERENCES [dbo].[AuditTrailFields]
        ([FieldID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AuditTrailTransactionDetail_AuditTrailField'
CREATE INDEX [IX_FK_AuditTrailTransactionDetail_AuditTrailField]
ON [dbo].[AuditTrailTransactionDetails]
    ([FieldID]);
GO

-- Creating foreign key on [ObjectTypeID] in table 'AuditTrailTransactions'
ALTER TABLE [dbo].[AuditTrailTransactions]
ADD CONSTRAINT [FK_AuditTrailTransaction_AuditTrailObjectType]
    FOREIGN KEY ([ObjectTypeID])
    REFERENCES [dbo].[AuditTrailObjectTypes]
        ([ObjectTypeID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AuditTrailTransaction_AuditTrailObjectType'
CREATE INDEX [IX_FK_AuditTrailTransaction_AuditTrailObjectType]
ON [dbo].[AuditTrailTransactions]
    ([ObjectTypeID]);
GO

-- Creating foreign key on [AuditTrailTransactionID] in table 'AuditTrailTransactionDetails'
ALTER TABLE [dbo].[AuditTrailTransactionDetails]
ADD CONSTRAINT [FK_AuditTrailTransactionDetail_AuditTrailTransaction]
    FOREIGN KEY ([AuditTrailTransactionID])
    REFERENCES [dbo].[AuditTrailTransactions]
        ([AuditTrailTransactionID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AuditTrailTransactionDetail_AuditTrailTransaction'
CREATE INDEX [IX_FK_AuditTrailTransactionDetail_AuditTrailTransaction]
ON [dbo].[AuditTrailTransactionDetails]
    ([AuditTrailTransactionID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'AutoProtocolConfigurations'
ALTER TABLE [dbo].[AutoProtocolConfigurations]
ADD CONSTRAINT [FK_AutoProtocolConfiguration_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AutoProtocolConfiguration_Diagnosis'
CREATE INDEX [IX_FK_AutoProtocolConfiguration_Diagnosis]
ON [dbo].[AutoProtocolConfigurations]
    ([DiagnosisID]);
GO

-- Creating foreign key on [ConfigurationType] in table 'AutoProtocolConfigurations'
ALTER TABLE [dbo].[AutoProtocolConfigurations]
ADD CONSTRAINT [FK_AutoProtocolConfiguration_Lookup]
    FOREIGN KEY ([ConfigurationType])
    REFERENCES [dbo].[Lookups]
        ([LookupName])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AutoProtocolConfiguration_Lookup'
CREATE INDEX [IX_FK_AutoProtocolConfiguration_Lookup]
ON [dbo].[AutoProtocolConfigurations]
    ([ConfigurationType]);
GO

-- Creating foreign key on [AssignmentCategoryID] in table 'AutoProtocolConfigurations'
ALTER TABLE [dbo].[AutoProtocolConfigurations]
ADD CONSTRAINT [FK_AutoProtocolConfiguration_LookupElement_AssignmentCategory]
    FOREIGN KEY ([AssignmentCategoryID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AutoProtocolConfiguration_LookupElement_AssignmentCategory'
CREATE INDEX [IX_FK_AutoProtocolConfiguration_LookupElement_AssignmentCategory]
ON [dbo].[AutoProtocolConfigurations]
    ([AssignmentCategoryID]);
GO

-- Creating foreign key on [ConfigurationSubID] in table 'AutoProtocolConfigurations'
ALTER TABLE [dbo].[AutoProtocolConfigurations]
ADD CONSTRAINT [FK_AutoProtocolConfiguration_LookupElement_ConfigurationSubID]
    FOREIGN KEY ([ConfigurationSubID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AutoProtocolConfiguration_LookupElement_ConfigurationSubID'
CREATE INDEX [IX_FK_AutoProtocolConfiguration_LookupElement_ConfigurationSubID]
ON [dbo].[AutoProtocolConfigurations]
    ([ConfigurationSubID]);
GO

-- Creating foreign key on [Gender] in table 'AutoProtocolConfigurations'
ALTER TABLE [dbo].[AutoProtocolConfigurations]
ADD CONSTRAINT [FK_AutoProtocolConfiguration_LookupElement_Gender]
    FOREIGN KEY ([Gender])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AutoProtocolConfiguration_LookupElement_Gender'
CREATE INDEX [IX_FK_AutoProtocolConfiguration_LookupElement_Gender]
ON [dbo].[AutoProtocolConfigurations]
    ([Gender]);
GO

-- Creating foreign key on [TurnToAutoReasonID] in table 'AutoProtocolConfigurations'
ALTER TABLE [dbo].[AutoProtocolConfigurations]
ADD CONSTRAINT [FK_AutoProtocolConfiguration_LookupElement_TurnToAutoReason]
    FOREIGN KEY ([TurnToAutoReasonID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AutoProtocolConfiguration_LookupElement_TurnToAutoReason'
CREATE INDEX [IX_FK_AutoProtocolConfiguration_LookupElement_TurnToAutoReason]
ON [dbo].[AutoProtocolConfigurations]
    ([TurnToAutoReasonID]);
GO

-- Creating foreign key on [DrugID] in table 'BrandDrugs'
ALTER TABLE [dbo].[BrandDrugs]
ADD CONSTRAINT [FK_BrandDrug_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_BrandDrug_Drug'
CREATE INDEX [IX_FK_BrandDrug_Drug]
ON [dbo].[BrandDrugs]
    ([DrugID]);
GO

-- Creating foreign key on [BrandDrugID] in table 'BrandDrugCodes'
ALTER TABLE [dbo].[BrandDrugCodes]
ADD CONSTRAINT [FK_BrandDrugCode_BrandDrug]
    FOREIGN KEY ([BrandDrugID])
    REFERENCES [dbo].[BrandDrugs]
        ([BrandDrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_BrandDrugCode_BrandDrug'
CREATE INDEX [IX_FK_BrandDrugCode_BrandDrug]
ON [dbo].[BrandDrugCodes]
    ([BrandDrugID]);
GO

-- Creating foreign key on [PreferredBrandID] in table 'PreferredDrugRules'
ALTER TABLE [dbo].[PreferredDrugRules]
ADD CONSTRAINT [FK_PreferredDrugRule_PreferredBrandID]
    FOREIGN KEY ([PreferredBrandID])
    REFERENCES [dbo].[BrandDrugs]
        ([BrandDrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PreferredDrugRule_PreferredBrandID'
CREATE INDEX [IX_FK_PreferredDrugRule_PreferredBrandID]
ON [dbo].[PreferredDrugRules]
    ([PreferredBrandID]);
GO

-- Creating foreign key on [BrandDrugID] in table 'StopLossRules'
ALTER TABLE [dbo].[StopLossRules]
ADD CONSTRAINT [FK_StopLossRule_BrandDrugID]
    FOREIGN KEY ([BrandDrugID])
    REFERENCES [dbo].[BrandDrugs]
        ([BrandDrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StopLossRule_BrandDrugID'
CREATE INDEX [IX_FK_StopLossRule_BrandDrugID]
ON [dbo].[StopLossRules]
    ([BrandDrugID]);
GO

-- Creating foreign key on [CallMethod] in table 'CallerContactDetails'
ALTER TABLE [dbo].[CallerContactDetails]
ADD CONSTRAINT [FK_CallerContactDetail_LookupElement_CallMethod]
    FOREIGN KEY ([CallMethod])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CallerContactDetail_LookupElement_CallMethod'
CREATE INDEX [IX_FK_CallerContactDetail_LookupElement_CallMethod]
ON [dbo].[CallerContactDetails]
    ([CallMethod]);
GO

-- Creating foreign key on [CallSubjectID] in table 'CallerContactDetails'
ALTER TABLE [dbo].[CallerContactDetails]
ADD CONSTRAINT [FK_CallerContactDetail_LookupElement_CallSubject]
    FOREIGN KEY ([CallSubjectID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CallerContactDetail_LookupElement_CallSubject'
CREATE INDEX [IX_FK_CallerContactDetail_LookupElement_CallSubject]
ON [dbo].[CallerContactDetails]
    ([CallSubjectID]);
GO

-- Creating foreign key on [CallType] in table 'CallerContactDetails'
ALTER TABLE [dbo].[CallerContactDetails]
ADD CONSTRAINT [FK_CallerContactDetail_LookupElement_CallType]
    FOREIGN KEY ([CallType])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CallerContactDetail_LookupElement_CallType'
CREATE INDEX [IX_FK_CallerContactDetail_LookupElement_CallType]
ON [dbo].[CallerContactDetails]
    ([CallType]);
GO

-- Creating foreign key on [ContactTitle] in table 'CallerContactDetails'
ALTER TABLE [dbo].[CallerContactDetails]
ADD CONSTRAINT [FK_CallerContactDetail_LookupElement_ContactTitle]
    FOREIGN KEY ([ContactTitle])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CallerContactDetail_LookupElement_ContactTitle'
CREATE INDEX [IX_FK_CallerContactDetail_LookupElement_ContactTitle]
ON [dbo].[CallerContactDetails]
    ([ContactTitle]);
GO

-- Creating foreign key on [MessageType] in table 'CallerContactDetails'
ALTER TABLE [dbo].[CallerContactDetails]
ADD CONSTRAINT [FK_CallerContactDetail_LookupElement_MessageType]
    FOREIGN KEY ([MessageType])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CallerContactDetail_LookupElement_MessageType'
CREATE INDEX [IX_FK_CallerContactDetail_LookupElement_MessageType]
ON [dbo].[CallerContactDetails]
    ([MessageType]);
GO

-- Creating foreign key on [Outcome] in table 'CallerContactDetails'
ALTER TABLE [dbo].[CallerContactDetails]
ADD CONSTRAINT [FK_CallerContactDetail_LookupElement_Outcome]
    FOREIGN KEY ([Outcome])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CallerContactDetail_LookupElement_Outcome'
CREATE INDEX [IX_FK_CallerContactDetail_LookupElement_Outcome]
ON [dbo].[CallerContactDetails]
    ([Outcome]);
GO

-- Creating foreign key on [UnsuccessfulContactMethod] in table 'CallerContactDetails'
ALTER TABLE [dbo].[CallerContactDetails]
ADD CONSTRAINT [FK_CallerContactDetail_LookupElement_UnsuccessfulContactMethod]
    FOREIGN KEY ([UnsuccessfulContactMethod])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CallerContactDetail_LookupElement_UnsuccessfulContactMethod'
CREATE INDEX [IX_FK_CallerContactDetail_LookupElement_UnsuccessfulContactMethod]
ON [dbo].[CallerContactDetails]
    ([UnsuccessfulContactMethod]);
GO

-- Creating foreign key on [PatientProtocolAssignmentProtocolID] in table 'CallerContactDetails'
ALTER TABLE [dbo].[CallerContactDetails]
ADD CONSTRAINT [FK_CallerContactDetail_PatientProtocolAssignment_Protocol]
    FOREIGN KEY ([PatientProtocolAssignmentProtocolID])
    REFERENCES [dbo].[PatientProtocolAssignment_Protocol]
        ([PatientProtocolAssignmentProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CallerContactDetail_PatientProtocolAssignment_Protocol'
CREATE INDEX [IX_FK_CallerContactDetail_PatientProtocolAssignment_Protocol]
ON [dbo].[CallerContactDetails]
    ([PatientProtocolAssignmentProtocolID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'CallerContactDetails'
ALTER TABLE [dbo].[CallerContactDetails]
ADD CONSTRAINT [FK_CallerContactDetail_PatientProtocolAssignment1]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CallerContactDetail_PatientProtocolAssignment1'
CREATE INDEX [IX_FK_CallerContactDetail_PatientProtocolAssignment1]
ON [dbo].[CallerContactDetails]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [CodingSystemId] in table 'ClinicalObservations'
ALTER TABLE [dbo].[ClinicalObservations]
ADD CONSTRAINT [FK_ClinicalObservation_LookupElement_CodingSystem]
    FOREIGN KEY ([CodingSystemId])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalObservation_LookupElement_CodingSystem'
CREATE INDEX [IX_FK_ClinicalObservation_LookupElement_CodingSystem]
ON [dbo].[ClinicalObservations]
    ([CodingSystemId]);
GO

-- Creating foreign key on [TypeId] in table 'ClinicalObservations'
ALTER TABLE [dbo].[ClinicalObservations]
ADD CONSTRAINT [FK_ClinicalObservation_LookupElement_Type]
    FOREIGN KEY ([TypeId])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalObservation_LookupElement_Type'
CREATE INDEX [IX_FK_ClinicalObservation_LookupElement_Type]
ON [dbo].[ClinicalObservations]
    ([TypeId]);
GO

-- Creating foreign key on [UnitsOfMeasureId] in table 'ClinicalObservations'
ALTER TABLE [dbo].[ClinicalObservations]
ADD CONSTRAINT [FK_ClinicalObservation_LookupElement_UnitsOfMeasure]
    FOREIGN KEY ([UnitsOfMeasureId])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalObservation_LookupElement_UnitsOfMeasure'
CREATE INDEX [IX_FK_ClinicalObservation_LookupElement_UnitsOfMeasure]
ON [dbo].[ClinicalObservations]
    ([UnitsOfMeasureId]);
GO

-- Creating foreign key on [ValueTypeId] in table 'ClinicalObservations'
ALTER TABLE [dbo].[ClinicalObservations]
ADD CONSTRAINT [FK_ClinicalObservation_LookupElement_ValueType]
    FOREIGN KEY ([ValueTypeId])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalObservation_LookupElement_ValueType'
CREATE INDEX [IX_FK_ClinicalObservation_LookupElement_ValueType]
ON [dbo].[ClinicalObservations]
    ([ValueTypeId]);
GO

-- Creating foreign key on [ClinicalObservationID] in table 'ClinicalObservationLabResults'
ALTER TABLE [dbo].[ClinicalObservationLabResults]
ADD CONSTRAINT [FK_ClinicalObservationLabResult_ClinicalObservation]
    FOREIGN KEY ([ClinicalObservationID])
    REFERENCES [dbo].[ClinicalObservations]
        ([ClinicalObservationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalObservationLabResult_ClinicalObservation'
CREATE INDEX [IX_FK_ClinicalObservationLabResult_ClinicalObservation]
ON [dbo].[ClinicalObservationLabResults]
    ([ClinicalObservationID]);
GO

-- Creating foreign key on [ClinicalObservationID] in table 'ClinicalValuesRuleLabResults'
ALTER TABLE [dbo].[ClinicalValuesRuleLabResults]
ADD CONSTRAINT [FK_ClinicalValuesRuleLabResult_ClinicalObservation]
    FOREIGN KEY ([ClinicalObservationID])
    REFERENCES [dbo].[ClinicalObservations]
        ([ClinicalObservationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalValuesRuleLabResult_ClinicalObservation'
CREATE INDEX [IX_FK_ClinicalValuesRuleLabResult_ClinicalObservation]
ON [dbo].[ClinicalValuesRuleLabResults]
    ([ClinicalObservationID]);
GO

-- Creating foreign key on [SourceID] in table 'ClinicalObservationLabResults'
ALTER TABLE [dbo].[ClinicalObservationLabResults]
ADD CONSTRAINT [FK_ClinicalObservationLabResult_LookupElement_Source]
    FOREIGN KEY ([SourceID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalObservationLabResult_LookupElement_Source'
CREATE INDEX [IX_FK_ClinicalObservationLabResult_LookupElement_Source]
ON [dbo].[ClinicalObservationLabResults]
    ([SourceID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'ClinicalObservationLabResults'
ALTER TABLE [dbo].[ClinicalObservationLabResults]
ADD CONSTRAINT [FK_ClinicalObservationLabResult_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalObservationLabResult_PatientProtocolAssignment'
CREATE INDEX [IX_FK_ClinicalObservationLabResult_PatientProtocolAssignment]
ON [dbo].[ClinicalObservationLabResults]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [StatusId] in table 'ClinicalQuestions'
ALTER TABLE [dbo].[ClinicalQuestions]
ADD CONSTRAINT [FK_ClinicalQuestion_LookupElement_QuestionStatus]
    FOREIGN KEY ([StatusId])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalQuestion_LookupElement_QuestionStatus'
CREATE INDEX [IX_FK_ClinicalQuestion_LookupElement_QuestionStatus]
ON [dbo].[ClinicalQuestions]
    ([StatusId]);
GO

-- Creating foreign key on [QuestionTypeId] in table 'ClinicalQuestions'
ALTER TABLE [dbo].[ClinicalQuestions]
ADD CONSTRAINT [FK_ClinicalQuestion_LookupElement_QuestionTypeId]
    FOREIGN KEY ([QuestionTypeId])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalQuestion_LookupElement_QuestionTypeId'
CREATE INDEX [IX_FK_ClinicalQuestion_LookupElement_QuestionTypeId]
ON [dbo].[ClinicalQuestions]
    ([QuestionTypeId]);
GO

-- Creating foreign key on [ClinicalQuestionId] in table 'ClinicalQuestionDiagnosis'
ALTER TABLE [dbo].[ClinicalQuestionDiagnosis]
ADD CONSTRAINT [FK_ClinicalQuestionDiagnosisId_ClinicalQuestionId]
    FOREIGN KEY ([ClinicalQuestionId])
    REFERENCES [dbo].[ClinicalQuestions]
        ([ClinicalQuestionId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalQuestionDiagnosisId_ClinicalQuestionId'
CREATE INDEX [IX_FK_ClinicalQuestionDiagnosisId_ClinicalQuestionId]
ON [dbo].[ClinicalQuestionDiagnosis]
    ([ClinicalQuestionId]);
GO

-- Creating foreign key on [ClinicalQuestionId] in table 'ClinicalQuestionAnswers'
ALTER TABLE [dbo].[ClinicalQuestionAnswers]
ADD CONSTRAINT [FK_ClinicalQuestionId]
    FOREIGN KEY ([ClinicalQuestionId])
    REFERENCES [dbo].[ClinicalQuestions]
        ([ClinicalQuestionId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalQuestionId'
CREATE INDEX [IX_FK_ClinicalQuestionId]
ON [dbo].[ClinicalQuestionAnswers]
    ([ClinicalQuestionId]);
GO

-- Creating foreign key on [StatusId] in table 'ClinicalQuestionAnswers'
ALTER TABLE [dbo].[ClinicalQuestionAnswers]
ADD CONSTRAINT [FK_ClinicalQuestionAnswer_LookupElement_AnswerStatus]
    FOREIGN KEY ([StatusId])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalQuestionAnswer_LookupElement_AnswerStatus'
CREATE INDEX [IX_FK_ClinicalQuestionAnswer_LookupElement_AnswerStatus]
ON [dbo].[ClinicalQuestionAnswers]
    ([StatusId]);
GO

-- Creating foreign key on [AnswerTypeId] in table 'ClinicalQuestionAnswers'
ALTER TABLE [dbo].[ClinicalQuestionAnswers]
ADD CONSTRAINT [FK_ClinicalQuestionAnswer_LookupElement_AnswerTypeId]
    FOREIGN KEY ([AnswerTypeId])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalQuestionAnswer_LookupElement_AnswerTypeId'
CREATE INDEX [IX_FK_ClinicalQuestionAnswer_LookupElement_AnswerTypeId]
ON [dbo].[ClinicalQuestionAnswers]
    ([AnswerTypeId]);
GO

-- Creating foreign key on [DiagnosisId] in table 'ClinicalQuestionDiagnosis'
ALTER TABLE [dbo].[ClinicalQuestionDiagnosis]
ADD CONSTRAINT [FK_ClinicalQuestionDiagnosisId_DiagnosisId]
    FOREIGN KEY ([DiagnosisId])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalQuestionDiagnosisId_DiagnosisId'
CREATE INDEX [IX_FK_ClinicalQuestionDiagnosisId_DiagnosisId]
ON [dbo].[ClinicalQuestionDiagnosis]
    ([DiagnosisId]);
GO

-- Creating foreign key on [DrugID] in table 'ClinicalValuesRules'
ALTER TABLE [dbo].[ClinicalValuesRules]
ADD CONSTRAINT [FK_ClinicalValuesRule_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalValuesRule_Drug'
CREATE INDEX [IX_FK_ClinicalValuesRule_Drug]
ON [dbo].[ClinicalValuesRules]
    ([DrugID]);
GO

-- Creating foreign key on [TreatmentID] in table 'ClinicalValuesRules'
ALTER TABLE [dbo].[ClinicalValuesRules]
ADD CONSTRAINT [FK_ClinicalValuesRule_LookupElement]
    FOREIGN KEY ([TreatmentID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalValuesRule_LookupElement'
CREATE INDEX [IX_FK_ClinicalValuesRule_LookupElement]
ON [dbo].[ClinicalValuesRules]
    ([TreatmentID]);
GO

-- Creating foreign key on [RuleID] in table 'ClinicalValuesRules'
ALTER TABLE [dbo].[ClinicalValuesRules]
ADD CONSTRAINT [FK_ClinicalValuesRule_Rule]
    FOREIGN KEY ([RuleID])
    REFERENCES [dbo].[Rules]
        ([RuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalValuesRule_Rule'
CREATE INDEX [IX_FK_ClinicalValuesRule_Rule]
ON [dbo].[ClinicalValuesRules]
    ([RuleID]);
GO

-- Creating foreign key on [ClinicalValuesRuleID] in table 'ClinicalValuesRuleDiagnosisExcludeds'
ALTER TABLE [dbo].[ClinicalValuesRuleDiagnosisExcludeds]
ADD CONSTRAINT [FK_ClinicalValuesRuleDiagnosisExcluded_ClinicalValuesRule]
    FOREIGN KEY ([ClinicalValuesRuleID])
    REFERENCES [dbo].[ClinicalValuesRules]
        ([ClinicalValuesRuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalValuesRuleDiagnosisExcluded_ClinicalValuesRule'
CREATE INDEX [IX_FK_ClinicalValuesRuleDiagnosisExcluded_ClinicalValuesRule]
ON [dbo].[ClinicalValuesRuleDiagnosisExcludeds]
    ([ClinicalValuesRuleID]);
GO

-- Creating foreign key on [ClinicalValuesRuleID] in table 'ClinicalValuesRuleLabResults'
ALTER TABLE [dbo].[ClinicalValuesRuleLabResults]
ADD CONSTRAINT [FK_ClinicalValuesRuleLabResult_ClinicalValuesRule]
    FOREIGN KEY ([ClinicalValuesRuleID])
    REFERENCES [dbo].[ClinicalValuesRules]
        ([ClinicalValuesRuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalValuesRuleLabResult_ClinicalValuesRule'
CREATE INDEX [IX_FK_ClinicalValuesRuleLabResult_ClinicalValuesRule]
ON [dbo].[ClinicalValuesRuleLabResults]
    ([ClinicalValuesRuleID]);
GO

-- Creating foreign key on [ClinicalValuesRuleID] in table 'FebrileNeutropeniaClinicalValuesRules'
ALTER TABLE [dbo].[FebrileNeutropeniaClinicalValuesRules]
ADD CONSTRAINT [FK_FebrileNeutropeniaClinicalValuesRule_ClinicalValuesRule]
    FOREIGN KEY ([ClinicalValuesRuleID])
    REFERENCES [dbo].[ClinicalValuesRules]
        ([ClinicalValuesRuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FebrileNeutropeniaClinicalValuesRule_ClinicalValuesRule'
CREATE INDEX [IX_FK_FebrileNeutropeniaClinicalValuesRule_ClinicalValuesRule]
ON [dbo].[FebrileNeutropeniaClinicalValuesRules]
    ([ClinicalValuesRuleID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'ClinicalValuesRuleDiagnosisExcludeds'
ALTER TABLE [dbo].[ClinicalValuesRuleDiagnosisExcludeds]
ADD CONSTRAINT [FK_ClinicalValuesRuleDiagnosisExcluded_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalValuesRuleDiagnosisExcluded_Diagnosis'
CREATE INDEX [IX_FK_ClinicalValuesRuleDiagnosisExcluded_Diagnosis]
ON [dbo].[ClinicalValuesRuleDiagnosisExcludeds]
    ([DiagnosisID]);
GO

-- Creating foreign key on [ConditionID] in table 'ClinicalValuesRuleLabResults'
ALTER TABLE [dbo].[ClinicalValuesRuleLabResults]
ADD CONSTRAINT [FK_ClinicalValuesRuleLabResult_LookupElement]
    FOREIGN KEY ([ConditionID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClinicalValuesRuleLabResult_LookupElement'
CREATE INDEX [IX_FK_ClinicalValuesRuleLabResult_LookupElement]
ON [dbo].[ClinicalValuesRuleLabResults]
    ([ConditionID]);
GO

-- Creating foreign key on [StateCode] in table 'Counties'
ALTER TABLE [dbo].[Counties]
ADD CONSTRAINT [FK_County_State]
    FOREIGN KEY ([StateCode])
    REFERENCES [dbo].[States]
        ([StateCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_County_State'
CREATE INDEX [IX_FK_County_State]
ON [dbo].[Counties]
    ([StateCode]);
GO

-- Creating foreign key on [CountyID] in table 'StopLossRules'
ALTER TABLE [dbo].[StopLossRules]
ADD CONSTRAINT [FK_StopLossRule_CountyID]
    FOREIGN KEY ([CountyID])
    REFERENCES [dbo].[Counties]
        ([CountyID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StopLossRule_CountyID'
CREATE INDEX [IX_FK_StopLossRule_CountyID]
ON [dbo].[StopLossRules]
    ([CountyID]);
GO

-- Creating foreign key on [CountyID] in table 'UserAddresses'
ALTER TABLE [dbo].[UserAddresses]
ADD CONSTRAINT [FK_UserAddress_County]
    FOREIGN KEY ([CountyID])
    REFERENCES [dbo].[Counties]
        ([CountyID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserAddress_County'
CREATE INDEX [IX_FK_UserAddress_County]
ON [dbo].[UserAddresses]
    ([CountyID]);
GO

-- Creating foreign key on [CalculationMethodID] in table 'CPTCodeXRTs'
ALTER TABLE [dbo].[CPTCodeXRTs]
ADD CONSTRAINT [FK_CPTCodeXRT_LookupElement]
    FOREIGN KEY ([CalculationMethodID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CPTCodeXRT_LookupElement'
CREATE INDEX [IX_FK_CPTCodeXRT_LookupElement]
ON [dbo].[CPTCodeXRTs]
    ([CalculationMethodID]);
GO

-- Creating foreign key on [CPTCodeXRTID] in table 'PatientProtocolAssignment_ProtocolCPTCodeXRT'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_CPTCodeXRT]
    FOREIGN KEY ([CPTCodeXRTID])
    REFERENCES [dbo].[CPTCodeXRTs]
        ([CPTCodeXRTID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_CPTCodeXRT'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_CPTCodeXRT]
ON [dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT]
    ([CPTCodeXRTID]);
GO

-- Creating foreign key on [CPTCodeXRTID] in table 'PayerXrtCodes'
ALTER TABLE [dbo].[PayerXrtCodes]
ADD CONSTRAINT [FK_PayerXrtCode_CPTCodeXRT]
    FOREIGN KEY ([CPTCodeXRTID])
    REFERENCES [dbo].[CPTCodeXRTs]
        ([CPTCodeXRTID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerXrtCode_CPTCodeXRT'
CREATE INDEX [IX_FK_PayerXrtCode_CPTCodeXRT]
ON [dbo].[PayerXrtCodes]
    ([CPTCodeXRTID]);
GO

-- Creating foreign key on [CPTCodeXRTID] in table 'ProtocolElementXRTs'
ALTER TABLE [dbo].[ProtocolElementXRTs]
ADD CONSTRAINT [FK_ProtocolElementXRT_CPTCodeXRT]
    FOREIGN KEY ([CPTCodeXRTID])
    REFERENCES [dbo].[CPTCodeXRTs]
        ([CPTCodeXRTID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElementXRT_CPTCodeXRT'
CREATE INDEX [IX_FK_ProtocolElementXRT_CPTCodeXRT]
ON [dbo].[ProtocolElementXRTs]
    ([CPTCodeXRTID]);
GO

-- Creating foreign key on [DecisionReasonID] in table 'DecisionReasonElements'
ALTER TABLE [dbo].[DecisionReasonElements]
ADD CONSTRAINT [FK_DecisionReason_DecisionReasonElement]
    FOREIGN KEY ([DecisionReasonID])
    REFERENCES [dbo].[DecisionReasons]
        ([DecisionReasonID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DecisionReason_DecisionReasonElement'
CREATE INDEX [IX_FK_DecisionReason_DecisionReasonElement]
ON [dbo].[DecisionReasonElements]
    ([DecisionReasonID]);
GO

-- Creating foreign key on [DecisionReasonElementID] in table 'DecisionReasonElementRequestTypes'
ALTER TABLE [dbo].[DecisionReasonElementRequestTypes]
ADD CONSTRAINT [FK_DecisionReasonElementRequestType_DecisionReasonElement]
    FOREIGN KEY ([DecisionReasonElementID])
    REFERENCES [dbo].[DecisionReasonElements]
        ([DecisionReasonElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DecisionReasonElementRequestType_DecisionReasonElement'
CREATE INDEX [IX_FK_DecisionReasonElementRequestType_DecisionReasonElement]
ON [dbo].[DecisionReasonElementRequestTypes]
    ([DecisionReasonElementID]);
GO

-- Creating foreign key on [TreatmentTypeID] in table 'DecisionReasonElementRequestTypes'
ALTER TABLE [dbo].[DecisionReasonElementRequestTypes]
ADD CONSTRAINT [FK_DecisionReasonElementRequestType_LookupElement]
    FOREIGN KEY ([TreatmentTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DecisionReasonElementRequestType_LookupElement'
CREATE INDEX [IX_FK_DecisionReasonElementRequestType_LookupElement]
ON [dbo].[DecisionReasonElementRequestTypes]
    ([TreatmentTypeID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'Diagnosis_MetastaticSite'
ALTER TABLE [dbo].[Diagnosis_MetastaticSite]
ADD CONSTRAINT [FK_Diagnosis_MetastaticSite_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Diagnosis_MetastaticSite_Diagnosis'
CREATE INDEX [IX_FK_Diagnosis_MetastaticSite_Diagnosis]
ON [dbo].[Diagnosis_MetastaticSite]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'DiagnosisClinicalNarratives'
ALTER TABLE [dbo].[DiagnosisClinicalNarratives]
ADD CONSTRAINT [FK_DiagnosisClinicalNarrative_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisClinicalNarrative_Diagnosis'
CREATE INDEX [IX_FK_DiagnosisClinicalNarrative_Diagnosis]
ON [dbo].[DiagnosisClinicalNarratives]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'DiagnosisClinicalTrialLinks'
ALTER TABLE [dbo].[DiagnosisClinicalTrialLinks]
ADD CONSTRAINT [FK_DiagnosisClinicalTrialLink_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisClinicalTrialLink_Diagnosis'
CREATE INDEX [IX_FK_DiagnosisClinicalTrialLink_Diagnosis]
ON [dbo].[DiagnosisClinicalTrialLinks]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'DiagnosisConfigurations'
ALTER TABLE [dbo].[DiagnosisConfigurations]
ADD CONSTRAINT [FK_DiagnosisConfiguration_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisConfiguration_Diagnosis'
CREATE INDEX [IX_FK_DiagnosisConfiguration_Diagnosis]
ON [dbo].[DiagnosisConfigurations]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'DiagnosisDistantMetaStasis'
ALTER TABLE [dbo].[DiagnosisDistantMetaStasis]
ADD CONSTRAINT [FK_DiagnosisDistantMetaStasis_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisDistantMetaStasis_Diagnosis'
CREATE INDEX [IX_FK_DiagnosisDistantMetaStasis_Diagnosis]
ON [dbo].[DiagnosisDistantMetaStasis]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'DiagnosisICDCodes'
ALTER TABLE [dbo].[DiagnosisICDCodes]
ADD CONSTRAINT [FK_DiagnosisICDCode_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisICDCode_Diagnosis'
CREATE INDEX [IX_FK_DiagnosisICDCode_Diagnosis]
ON [dbo].[DiagnosisICDCodes]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'DiagnosisLineOfTherapies'
ALTER TABLE [dbo].[DiagnosisLineOfTherapies]
ADD CONSTRAINT [FK_DiagnosisLineOfTherapy_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisLineOfTherapy_Diagnosis'
CREATE INDEX [IX_FK_DiagnosisLineOfTherapy_Diagnosis]
ON [dbo].[DiagnosisLineOfTherapies]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'DiagnosisLocalizedDiseases'
ALTER TABLE [dbo].[DiagnosisLocalizedDiseases]
ADD CONSTRAINT [FK_DiagnosisLocalizedDisease_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisLocalizedDisease_Diagnosis'
CREATE INDEX [IX_FK_DiagnosisLocalizedDisease_Diagnosis]
ON [dbo].[DiagnosisLocalizedDiseases]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'DiagnosisMolecularMarkers'
ALTER TABLE [dbo].[DiagnosisMolecularMarkers]
ADD CONSTRAINT [FK_DiagnosisMolecularMarker_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisMolecularMarker_Diagnosis'
CREATE INDEX [IX_FK_DiagnosisMolecularMarker_Diagnosis]
ON [dbo].[DiagnosisMolecularMarkers]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'DiagnosisNodalStatus'
ALTER TABLE [dbo].[DiagnosisNodalStatus]
ADD CONSTRAINT [FK_DiagnosisNodalStatus_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisNodalStatus_Diagnosis'
CREATE INDEX [IX_FK_DiagnosisNodalStatus_Diagnosis]
ON [dbo].[DiagnosisNodalStatus]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'DiagnosisPhases'
ALTER TABLE [dbo].[DiagnosisPhases]
ADD CONSTRAINT [FK_DiagnosisPhase_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisPhase_Diagnosis'
CREATE INDEX [IX_FK_DiagnosisPhase_Diagnosis]
ON [dbo].[DiagnosisPhases]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'DiagnosisSettingOfTherapies'
ALTER TABLE [dbo].[DiagnosisSettingOfTherapies]
ADD CONSTRAINT [FK_DiagnosisSettingOfTherapy_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisSettingOfTherapy_Diagnosis'
CREATE INDEX [IX_FK_DiagnosisSettingOfTherapy_Diagnosis]
ON [dbo].[DiagnosisSettingOfTherapies]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'DiagnosisStages'
ALTER TABLE [dbo].[DiagnosisStages]
ADD CONSTRAINT [FK_DiagnosisStage_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisStage_Diagnosis'
CREATE INDEX [IX_FK_DiagnosisStage_Diagnosis]
ON [dbo].[DiagnosisStages]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'DiagnosisTumorSizes'
ALTER TABLE [dbo].[DiagnosisTumorSizes]
ADD CONSTRAINT [FK_DiagnosisTumorSize_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisTumorSize_Diagnosis'
CREATE INDEX [IX_FK_DiagnosisTumorSize_Diagnosis]
ON [dbo].[DiagnosisTumorSizes]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'DimPayerPreferredProtocolProgram_PatientDiagnosis'
ALTER TABLE [dbo].[DimPayerPreferredProtocolProgram_PatientDiagnosis]
ADD CONSTRAINT [FK_DimPayerPreferredProtocolProgramPatientDiagnosis_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DimPayerPreferredProtocolProgramPatientDiagnosis_Diagnosis'
CREATE INDEX [IX_FK_DimPayerPreferredProtocolProgramPatientDiagnosis_Diagnosis]
ON [dbo].[DimPayerPreferredProtocolProgram_PatientDiagnosis]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'DrugPolicyCriteriaDiagnosis'
ALTER TABLE [dbo].[DrugPolicyCriteriaDiagnosis]
ADD CONSTRAINT [FK_DrugPolicyCriteriaDiagnosis_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DrugPolicyCriteriaDiagnosis_Diagnosis'
CREATE INDEX [IX_FK_DrugPolicyCriteriaDiagnosis_Diagnosis]
ON [dbo].[DrugPolicyCriteriaDiagnosis]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'InsuranceProviderDrugConfigurations'
ALTER TABLE [dbo].[InsuranceProviderDrugConfigurations]
ADD CONSTRAINT [FK_InsuranceProviderDrugConfiguration_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderDrugConfiguration_Diagnosis'
CREATE INDEX [IX_FK_InsuranceProviderDrugConfiguration_Diagnosis]
ON [dbo].[InsuranceProviderDrugConfigurations]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'PatientAssessments'
ALTER TABLE [dbo].[PatientAssessments]
ADD CONSTRAINT [FK_PatientAssessment_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientAssessment_Diagnosis'
CREATE INDEX [IX_FK_PatientAssessment_Diagnosis]
ON [dbo].[PatientAssessments]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'PatientDiagnosis'
ALTER TABLE [dbo].[PatientDiagnosis]
ADD CONSTRAINT [FK_PatientDiagnosis_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientDiagnosis_Diagnosis'
CREATE INDEX [IX_FK_PatientDiagnosis_Diagnosis]
ON [dbo].[PatientDiagnosis]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'PatientProtocolAssignment_ProtocolDiagnosis'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDiagnosis]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDiagnosis_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolDiagnosis_Diagnosis'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolDiagnosis_Diagnosis]
ON [dbo].[PatientProtocolAssignment_ProtocolDiagnosis]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'Protocols'
ALTER TABLE [dbo].[Protocols]
ADD CONSTRAINT [FK_Protocol_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Protocol_Diagnosis'
CREATE INDEX [IX_FK_Protocol_Diagnosis]
ON [dbo].[Protocols]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'Protocol_Diagnosis'
ALTER TABLE [dbo].[Protocol_Diagnosis]
ADD CONSTRAINT [FK_Protocol_Diagnosis_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Protocol_Diagnosis_Diagnosis'
CREATE INDEX [IX_FK_Protocol_Diagnosis_Diagnosis]
ON [dbo].[Protocol_Diagnosis]
    ([DiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'ProtocolRequests'
ALTER TABLE [dbo].[ProtocolRequests]
ADD CONSTRAINT [FK_ProtocolRequest_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolRequest_Diagnosis'
CREATE INDEX [IX_FK_ProtocolRequest_Diagnosis]
ON [dbo].[ProtocolRequests]
    ([DiagnosisID]);
GO

-- Creating foreign key on [PatientDiagnosisID] in table 'Rules'
ALTER TABLE [dbo].[Rules]
ADD CONSTRAINT [FK_Rule_PatientDiagnosis]
    FOREIGN KEY ([PatientDiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Rule_PatientDiagnosis'
CREATE INDEX [IX_FK_Rule_PatientDiagnosis]
ON [dbo].[Rules]
    ([PatientDiagnosisID]);
GO

-- Creating foreign key on [ProtocolDiagnosisID] in table 'Rules'
ALTER TABLE [dbo].[Rules]
ADD CONSTRAINT [FK_Rule_ProtocolDiagnosis]
    FOREIGN KEY ([ProtocolDiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Rule_ProtocolDiagnosis'
CREATE INDEX [IX_FK_Rule_ProtocolDiagnosis]
ON [dbo].[Rules]
    ([ProtocolDiagnosisID]);
GO

-- Creating foreign key on [DiagnosisID] in table 'StepTherapyRuleDiagnosisExcludeds'
ALTER TABLE [dbo].[StepTherapyRuleDiagnosisExcludeds]
ADD CONSTRAINT [FK_StepTherapyRuleDiagnosisExcluded_Diagnosis]
    FOREIGN KEY ([DiagnosisID])
    REFERENCES [dbo].[Diagnosis]
        ([DiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StepTherapyRuleDiagnosisExcluded_Diagnosis'
CREATE INDEX [IX_FK_StepTherapyRuleDiagnosisExcluded_Diagnosis]
ON [dbo].[StepTherapyRuleDiagnosisExcludeds]
    ([DiagnosisID]);
GO

-- Creating foreign key on [MetastaticSiteID] in table 'Diagnosis_MetastaticSite'
ALTER TABLE [dbo].[Diagnosis_MetastaticSite]
ADD CONSTRAINT [FK_Diagnosis_MetastaticSite_MetastaticSite]
    FOREIGN KEY ([MetastaticSiteID])
    REFERENCES [dbo].[MetastaticSites]
        ([MetastaticSiteID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Diagnosis_MetastaticSite_MetastaticSite'
CREATE INDEX [IX_FK_Diagnosis_MetastaticSite_MetastaticSite]
ON [dbo].[Diagnosis_MetastaticSite]
    ([MetastaticSiteID]);
GO

-- Creating foreign key on [StageID] in table 'DiagnosisClinicalTrialLinks'
ALTER TABLE [dbo].[DiagnosisClinicalTrialLinks]
ADD CONSTRAINT [FK_DiagnosisClinicalTrialLink_LookupElement_StageID]
    FOREIGN KEY ([StageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisClinicalTrialLink_LookupElement_StageID'
CREATE INDEX [IX_FK_DiagnosisClinicalTrialLink_LookupElement_StageID]
ON [dbo].[DiagnosisClinicalTrialLinks]
    ([StageID]);
GO

-- Creating foreign key on [ProtocolTypeID] in table 'DiagnosisConfigurations'
ALTER TABLE [dbo].[DiagnosisConfigurations]
ADD CONSTRAINT [FK_DiagnosisConfiguration_LookupElement_ProtocolType]
    FOREIGN KEY ([ProtocolTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisConfiguration_LookupElement_ProtocolType'
CREATE INDEX [IX_FK_DiagnosisConfiguration_LookupElement_ProtocolType]
ON [dbo].[DiagnosisConfigurations]
    ([ProtocolTypeID]);
GO

-- Creating foreign key on [DistantMetaStasisID] in table 'DiagnosisDistantMetaStasis'
ALTER TABLE [dbo].[DiagnosisDistantMetaStasis]
ADD CONSTRAINT [FK_DiagnosisDistantMetaStasis_LookupElement_Stage]
    FOREIGN KEY ([DistantMetaStasisID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisDistantMetaStasis_LookupElement_Stage'
CREATE INDEX [IX_FK_DiagnosisDistantMetaStasis_LookupElement_Stage]
ON [dbo].[DiagnosisDistantMetaStasis]
    ([DistantMetaStasisID]);
GO

-- Creating foreign key on [DistantMetaStasisID] in table 'DiagnosisDistantMetaStasis'
ALTER TABLE [dbo].[DiagnosisDistantMetaStasis]
ADD CONSTRAINT [FK_DiagnosisDistantMetaStasiss_LookupElement_Stage]
    FOREIGN KEY ([DistantMetaStasisID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisDistantMetaStasiss_LookupElement_Stage'
CREATE INDEX [IX_FK_DiagnosisDistantMetaStasiss_LookupElement_Stage]
ON [dbo].[DiagnosisDistantMetaStasis]
    ([DistantMetaStasisID]);
GO

-- Creating foreign key on [ICDCode], [ICDversion] in table 'DiagnosisICDCodes'
ALTER TABLE [dbo].[DiagnosisICDCodes]
ADD CONSTRAINT [FK_DiagnosisICDCode_ICDCode]
    FOREIGN KEY ([ICDCode], [ICDversion])
    REFERENCES [dbo].[ICDCodes]
        ([Code], [CodeVersion])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisICDCode_ICDCode'
CREATE INDEX [IX_FK_DiagnosisICDCode_ICDCode]
ON [dbo].[DiagnosisICDCodes]
    ([ICDCode], [ICDversion]);
GO

-- Creating foreign key on [LineOfTherapyID] in table 'DiagnosisLineOfTherapies'
ALTER TABLE [dbo].[DiagnosisLineOfTherapies]
ADD CONSTRAINT [FK_DiagnosisLineOfTherapy_LookupElement_Stage]
    FOREIGN KEY ([LineOfTherapyID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisLineOfTherapy_LookupElement_Stage'
CREATE INDEX [IX_FK_DiagnosisLineOfTherapy_LookupElement_Stage]
ON [dbo].[DiagnosisLineOfTherapies]
    ([LineOfTherapyID]);
GO

-- Creating foreign key on [DiagnosisLocalizedDiseaseID] in table 'DiagnosisLocalizedDiseaseStages'
ALTER TABLE [dbo].[DiagnosisLocalizedDiseaseStages]
ADD CONSTRAINT [FK_DiagnosisLocalizedDiseaseStage_DiagnosisLocalizedDisease]
    FOREIGN KEY ([DiagnosisLocalizedDiseaseID])
    REFERENCES [dbo].[DiagnosisLocalizedDiseases]
        ([DiagnosisLocalizedDiseaseID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisLocalizedDiseaseStage_DiagnosisLocalizedDisease'
CREATE INDEX [IX_FK_DiagnosisLocalizedDiseaseStage_DiagnosisLocalizedDisease]
ON [dbo].[DiagnosisLocalizedDiseaseStages]
    ([DiagnosisLocalizedDiseaseID]);
GO

-- Creating foreign key on [StageID] in table 'DiagnosisLocalizedDiseaseStages'
ALTER TABLE [dbo].[DiagnosisLocalizedDiseaseStages]
ADD CONSTRAINT [FK_DiagnosisLocalizedDiseaseStage_LookupElement]
    FOREIGN KEY ([StageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisLocalizedDiseaseStage_LookupElement'
CREATE INDEX [IX_FK_DiagnosisLocalizedDiseaseStage_LookupElement]
ON [dbo].[DiagnosisLocalizedDiseaseStages]
    ([StageID]);
GO

-- Creating foreign key on [MolecularMarkerID] in table 'DiagnosisMolecularMarkers'
ALTER TABLE [dbo].[DiagnosisMolecularMarkers]
ADD CONSTRAINT [FK_DiagnosisMolecularMarker_LookupElement_Stage]
    FOREIGN KEY ([MolecularMarkerID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisMolecularMarker_LookupElement_Stage'
CREATE INDEX [IX_FK_DiagnosisMolecularMarker_LookupElement_Stage]
ON [dbo].[DiagnosisMolecularMarkers]
    ([MolecularMarkerID]);
GO

-- Creating foreign key on [NodalStatusID] in table 'DiagnosisNodalStatus'
ALTER TABLE [dbo].[DiagnosisNodalStatus]
ADD CONSTRAINT [FK_DiagnosisNodalStatus_LookupElement_Stage]
    FOREIGN KEY ([NodalStatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisNodalStatus_LookupElement_Stage'
CREATE INDEX [IX_FK_DiagnosisNodalStatus_LookupElement_Stage]
ON [dbo].[DiagnosisNodalStatus]
    ([NodalStatusID]);
GO

-- Creating foreign key on [NodalStatusID] in table 'DiagnosisNodalStatus'
ALTER TABLE [dbo].[DiagnosisNodalStatus]
ADD CONSTRAINT [FK_DiagnosisNodalStatuss_LookupElement_Stage]
    FOREIGN KEY ([NodalStatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisNodalStatuss_LookupElement_Stage'
CREATE INDEX [IX_FK_DiagnosisNodalStatuss_LookupElement_Stage]
ON [dbo].[DiagnosisNodalStatus]
    ([NodalStatusID]);
GO

-- Creating foreign key on [PhaseID] in table 'DiagnosisPhases'
ALTER TABLE [dbo].[DiagnosisPhases]
ADD CONSTRAINT [FK_DiagnosisPhases_LookupElement_Phase]
    FOREIGN KEY ([PhaseID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisPhases_LookupElement_Phase'
CREATE INDEX [IX_FK_DiagnosisPhases_LookupElement_Phase]
ON [dbo].[DiagnosisPhases]
    ([PhaseID]);
GO

-- Creating foreign key on [SettingOfTherapyID] in table 'DiagnosisSettingOfTherapies'
ALTER TABLE [dbo].[DiagnosisSettingOfTherapies]
ADD CONSTRAINT [FK_DiagnosisSettingOfTherapy_LookupElement_Stage]
    FOREIGN KEY ([SettingOfTherapyID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisSettingOfTherapy_LookupElement_Stage'
CREATE INDEX [IX_FK_DiagnosisSettingOfTherapy_LookupElement_Stage]
ON [dbo].[DiagnosisSettingOfTherapies]
    ([SettingOfTherapyID]);
GO

-- Creating foreign key on [StageID] in table 'DiagnosisStages'
ALTER TABLE [dbo].[DiagnosisStages]
ADD CONSTRAINT [FK_DiagnosisStage_LookupElement_Stage]
    FOREIGN KEY ([StageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisStage_LookupElement_Stage'
CREATE INDEX [IX_FK_DiagnosisStage_LookupElement_Stage]
ON [dbo].[DiagnosisStages]
    ([StageID]);
GO

-- Creating foreign key on [StageID] in table 'DiagnosisStages'
ALTER TABLE [dbo].[DiagnosisStages]
ADD CONSTRAINT [FK_DiagnosisStages_LookupElement_Stage]
    FOREIGN KEY ([StageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisStages_LookupElement_Stage'
CREATE INDEX [IX_FK_DiagnosisStages_LookupElement_Stage]
ON [dbo].[DiagnosisStages]
    ([StageID]);
GO

-- Creating foreign key on [TumorSizeID] in table 'DiagnosisTumorSizes'
ALTER TABLE [dbo].[DiagnosisTumorSizes]
ADD CONSTRAINT [FK_DiagnosisTumorSize_LookupElement_Stage]
    FOREIGN KEY ([TumorSizeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisTumorSize_LookupElement_Stage'
CREATE INDEX [IX_FK_DiagnosisTumorSize_LookupElement_Stage]
ON [dbo].[DiagnosisTumorSizes]
    ([TumorSizeID]);
GO

-- Creating foreign key on [TumorSizeID] in table 'DiagnosisTumorSizes'
ALTER TABLE [dbo].[DiagnosisTumorSizes]
ADD CONSTRAINT [FK_DiagnosisTumorSizes_LookupElement_Stage]
    FOREIGN KEY ([TumorSizeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiagnosisTumorSizes_LookupElement_Stage'
CREATE INDEX [IX_FK_DiagnosisTumorSizes_LookupElement_Stage]
ON [dbo].[DiagnosisTumorSizes]
    ([TumorSizeID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'DimPayers'
ALTER TABLE [dbo].[DimPayers]
ADD CONSTRAINT [FK_DimPayer_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DimPayer_InsuranceProvider'
CREATE INDEX [IX_FK_DimPayer_InsuranceProvider]
ON [dbo].[DimPayers]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [LineOfBusinessID] in table 'DimPayers'
ALTER TABLE [dbo].[DimPayers]
ADD CONSTRAINT [FK_DimPayer_LineofBusiness]
    FOREIGN KEY ([LineOfBusinessID])
    REFERENCES [dbo].[LineofBusinesses]
        ([LineOfBusinessID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DimPayer_LineofBusiness'
CREATE INDEX [IX_FK_DimPayer_LineofBusiness]
ON [dbo].[DimPayers]
    ([LineOfBusinessID]);
GO

-- Creating foreign key on [MajorLineOfBusinessID] in table 'DimPayers'
ALTER TABLE [dbo].[DimPayers]
ADD CONSTRAINT [FK_DimPayer_LookupElement_MajorLineOfBusiness]
    FOREIGN KEY ([MajorLineOfBusinessID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DimPayer_LookupElement_MajorLineOfBusiness'
CREATE INDEX [IX_FK_DimPayer_LookupElement_MajorLineOfBusiness]
ON [dbo].[DimPayers]
    ([MajorLineOfBusinessID]);
GO

-- Creating foreign key on [ProductLineID] in table 'DimPayers'
ALTER TABLE [dbo].[DimPayers]
ADD CONSTRAINT [FK_DimPayer_ProductLine]
    FOREIGN KEY ([ProductLineID])
    REFERENCES [dbo].[ProductLines]
        ([ProductLineID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DimPayer_ProductLine'
CREATE INDEX [IX_FK_DimPayer_ProductLine]
ON [dbo].[DimPayers]
    ([ProductLineID]);
GO

-- Creating foreign key on [StateCode] in table 'DimPayers'
ALTER TABLE [dbo].[DimPayers]
ADD CONSTRAINT [FK_DimPayer_StateCode]
    FOREIGN KEY ([StateCode])
    REFERENCES [dbo].[States]
        ([StateCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DimPayer_StateCode'
CREATE INDEX [IX_FK_DimPayer_StateCode]
ON [dbo].[DimPayers]
    ([StateCode]);
GO

-- Creating foreign key on [StateOfPlanIssue] in table 'DimPayers'
ALTER TABLE [dbo].[DimPayers]
ADD CONSTRAINT [FK_DimPayer_StateOfPlanIssue]
    FOREIGN KEY ([StateOfPlanIssue])
    REFERENCES [dbo].[States]
        ([StateCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DimPayer_StateOfPlanIssue'
CREATE INDEX [IX_FK_DimPayer_StateOfPlanIssue]
ON [dbo].[DimPayers]
    ([StateOfPlanIssue]);
GO

-- Creating foreign key on [DimPayerID] in table 'DimPayerPreferredProtocolPrograms'
ALTER TABLE [dbo].[DimPayerPreferredProtocolPrograms]
ADD CONSTRAINT [FK_DimPayerPreferredProtocolProgram_DimPayer]
    FOREIGN KEY ([DimPayerID])
    REFERENCES [dbo].[DimPayers]
        ([DimPayerID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DimPayerPreferredProtocolProgram_DimPayer'
CREATE INDEX [IX_FK_DimPayerPreferredProtocolProgram_DimPayer]
ON [dbo].[DimPayerPreferredProtocolPrograms]
    ([DimPayerID]);
GO

-- Creating foreign key on [DimPayerID] in table 'DimPayerRules'
ALTER TABLE [dbo].[DimPayerRules]
ADD CONSTRAINT [FK_DimPayerRule_DimPayer]
    FOREIGN KEY ([DimPayerID])
    REFERENCES [dbo].[DimPayers]
        ([DimPayerID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DimPayerRule_DimPayer'
CREATE INDEX [IX_FK_DimPayerRule_DimPayer]
ON [dbo].[DimPayerRules]
    ([DimPayerID]);
GO

-- Creating foreign key on [DimPayerID] in table 'InsuranceProviderFaxTemplate_Rule'
ALTER TABLE [dbo].[InsuranceProviderFaxTemplate_Rule]
ADD CONSTRAINT [FK_InsuranceProviderFaxTemplate_Rule_DimPayer]
    FOREIGN KEY ([DimPayerID])
    REFERENCES [dbo].[DimPayers]
        ([DimPayerID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderFaxTemplate_Rule_DimPayer'
CREATE INDEX [IX_FK_InsuranceProviderFaxTemplate_Rule_DimPayer]
ON [dbo].[InsuranceProviderFaxTemplate_Rule]
    ([DimPayerID]);
GO

-- Creating foreign key on [DimPayerID] in table 'PayerBusinessDayConfigs'
ALTER TABLE [dbo].[PayerBusinessDayConfigs]
ADD CONSTRAINT [FK_PayerBusinessDayConfig_DimPayer]
    FOREIGN KEY ([DimPayerID])
    REFERENCES [dbo].[DimPayers]
        ([DimPayerID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerBusinessDayConfig_DimPayer'
CREATE INDEX [IX_FK_PayerBusinessDayConfig_DimPayer]
ON [dbo].[PayerBusinessDayConfigs]
    ([DimPayerID]);
GO

-- Creating foreign key on [DimPayerID] in table 'PayerFormularies'
ALTER TABLE [dbo].[PayerFormularies]
ADD CONSTRAINT [FK_PayerFormulary_DimPayer]
    FOREIGN KEY ([DimPayerID])
    REFERENCES [dbo].[DimPayers]
        ([DimPayerID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerFormulary_DimPayer'
CREATE INDEX [IX_FK_PayerFormulary_DimPayer]
ON [dbo].[PayerFormularies]
    ([DimPayerID]);
GO

-- Creating foreign key on [DimPayerID] in table 'PayerPrimaryTimers'
ALTER TABLE [dbo].[PayerPrimaryTimers]
ADD CONSTRAINT [FK_PayerPrimaryTimer_DimPayer]
    FOREIGN KEY ([DimPayerID])
    REFERENCES [dbo].[DimPayers]
        ([DimPayerID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerPrimaryTimer_DimPayer'
CREATE INDEX [IX_FK_PayerPrimaryTimer_DimPayer]
ON [dbo].[PayerPrimaryTimers]
    ([DimPayerID]);
GO

-- Creating foreign key on [DimPayerID] in table 'PayerTimerConfigurations'
ALTER TABLE [dbo].[PayerTimerConfigurations]
ADD CONSTRAINT [FK_PayerTimerConfiguration_DimPayer]
    FOREIGN KEY ([DimPayerID])
    REFERENCES [dbo].[DimPayers]
        ([DimPayerID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerTimerConfiguration_DimPayer'
CREATE INDEX [IX_FK_PayerTimerConfiguration_DimPayer]
ON [dbo].[PayerTimerConfigurations]
    ([DimPayerID]);
GO

-- Creating foreign key on [DimPayerID] in table 'PayerXrtCodes'
ALTER TABLE [dbo].[PayerXrtCodes]
ADD CONSTRAINT [FK_PayerXrtCode_DimPayer]
    FOREIGN KEY ([DimPayerID])
    REFERENCES [dbo].[DimPayers]
        ([DimPayerID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerXrtCode_DimPayer'
CREATE INDEX [IX_FK_PayerXrtCode_DimPayer]
ON [dbo].[PayerXrtCodes]
    ([DimPayerID]);
GO

-- Creating foreign key on [ProgramID] in table 'DimPayerPreferredProtocolPrograms'
ALTER TABLE [dbo].[DimPayerPreferredProtocolPrograms]
ADD CONSTRAINT [FK_DimPayerPreferredProtocolProgram_LookupElement_PreferredProgram]
    FOREIGN KEY ([ProgramID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DimPayerPreferredProtocolProgram_LookupElement_PreferredProgram'
CREATE INDEX [IX_FK_DimPayerPreferredProtocolProgram_LookupElement_PreferredProgram]
ON [dbo].[DimPayerPreferredProtocolPrograms]
    ([ProgramID]);
GO

-- Creating foreign key on [StatusID] in table 'DimPayerPreferredProtocolPrograms'
ALTER TABLE [dbo].[DimPayerPreferredProtocolPrograms]
ADD CONSTRAINT [FK_DimPayerPreferredProtocolProgram_LookupElement_PreferredStatus]
    FOREIGN KEY ([StatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DimPayerPreferredProtocolProgram_LookupElement_PreferredStatus'
CREATE INDEX [IX_FK_DimPayerPreferredProtocolProgram_LookupElement_PreferredStatus]
ON [dbo].[DimPayerPreferredProtocolPrograms]
    ([StatusID]);
GO

-- Creating foreign key on [ProtocolID] in table 'DimPayerPreferredProtocolPrograms'
ALTER TABLE [dbo].[DimPayerPreferredProtocolPrograms]
ADD CONSTRAINT [FK_DimPayerPreferredProtocolProgram_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DimPayerPreferredProtocolProgram_Protocol'
CREATE INDEX [IX_FK_DimPayerPreferredProtocolProgram_Protocol]
ON [dbo].[DimPayerPreferredProtocolPrograms]
    ([ProtocolID]);
GO

-- Creating foreign key on [DimPayerPreferredProtocolProgramID] in table 'DimPayerPreferredProtocolProgram_PatientDiagnosis'
ALTER TABLE [dbo].[DimPayerPreferredProtocolProgram_PatientDiagnosis]
ADD CONSTRAINT [FK_DimPayerPreferredProtocolProgramPatientDiagnosis_DimPayerPreferredProtocolProgram]
    FOREIGN KEY ([DimPayerPreferredProtocolProgramID])
    REFERENCES [dbo].[DimPayerPreferredProtocolPrograms]
        ([DimPayerPreferredProtocolProgramID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DimPayerPreferredProtocolProgramPatientDiagnosis_DimPayerPreferredProtocolProgram'
CREATE INDEX [IX_FK_DimPayerPreferredProtocolProgramPatientDiagnosis_DimPayerPreferredProtocolProgram]
ON [dbo].[DimPayerPreferredProtocolProgram_PatientDiagnosis]
    ([DimPayerPreferredProtocolProgramID]);
GO

-- Creating foreign key on [ApprovalRuleModeID] in table 'DimPayerRules'
ALTER TABLE [dbo].[DimPayerRules]
ADD CONSTRAINT [FK_DimPayerRule_LookupElement_ApprovalRuleMode]
    FOREIGN KEY ([ApprovalRuleModeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DimPayerRule_LookupElement_ApprovalRuleMode'
CREATE INDEX [IX_FK_DimPayerRule_LookupElement_ApprovalRuleMode]
ON [dbo].[DimPayerRules]
    ([ApprovalRuleModeID]);
GO

-- Creating foreign key on [RuleID] in table 'DimPayerRules'
ALTER TABLE [dbo].[DimPayerRules]
ADD CONSTRAINT [FK_DimPayerRule_Rule]
    FOREIGN KEY ([RuleID])
    REFERENCES [dbo].[Rules]
        ([RuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'DiscontiueAuthorizationAssignments'
ALTER TABLE [dbo].[DiscontiueAuthorizationAssignments]
ADD CONSTRAINT [FK_DiscontiueAuthorizationAssignment_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiscontiueAuthorizationAssignment_PatientProtocolAssignment'
CREATE INDEX [IX_FK_DiscontiueAuthorizationAssignment_PatientProtocolAssignment]
ON [dbo].[DiscontiueAuthorizationAssignments]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [DiscontinueAuthorizationAssignmentID] in table 'DiscontiueAuthorizationLinkedAssignments'
ALTER TABLE [dbo].[DiscontiueAuthorizationLinkedAssignments]
ADD CONSTRAINT [FK_DiscontiueAuthorizationLinkedAssignment_DiscontiueAuthorizationAssignment]
    FOREIGN KEY ([DiscontinueAuthorizationAssignmentID])
    REFERENCES [dbo].[DiscontiueAuthorizationAssignments]
        ([DiscontinueAuthorizationAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiscontiueAuthorizationLinkedAssignment_DiscontiueAuthorizationAssignment'
CREATE INDEX [IX_FK_DiscontiueAuthorizationLinkedAssignment_DiscontiueAuthorizationAssignment]
ON [dbo].[DiscontiueAuthorizationLinkedAssignments]
    ([DiscontinueAuthorizationAssignmentID]);
GO

-- Creating foreign key on [PatientProtocolLinkedAssignmentID] in table 'DiscontiueAuthorizationLinkedAssignments'
ALTER TABLE [dbo].[DiscontiueAuthorizationLinkedAssignments]
ADD CONSTRAINT [FK_DiscontiueAuthorizationLinkedAssignment_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolLinkedAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DiscontiueAuthorizationLinkedAssignment_PatientProtocolAssignment'
CREATE INDEX [IX_FK_DiscontiueAuthorizationLinkedAssignment_PatientProtocolAssignment]
ON [dbo].[DiscontiueAuthorizationLinkedAssignments]
    ([PatientProtocolLinkedAssignmentID]);
GO

-- Creating foreign key on [DocumentRepositoryID] in table 'DocumentDeletionReasons'
ALTER TABLE [dbo].[DocumentDeletionReasons]
ADD CONSTRAINT [FK_DocumentDeletionReason_DocumentRepository]
    FOREIGN KEY ([DocumentRepositoryID])
    REFERENCES [dbo].[DocumentRepositories]
        ([DocumentRepositoryID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DocumentDeletionReason_DocumentRepository'
CREATE INDEX [IX_FK_DocumentDeletionReason_DocumentRepository]
ON [dbo].[DocumentDeletionReasons]
    ([DocumentRepositoryID]);
GO

-- Creating foreign key on [DocumentDeletionID] in table 'DocumentDeletionReasons'
ALTER TABLE [dbo].[DocumentDeletionReasons]
ADD CONSTRAINT [FK_DocumentDeletionReason_LookupElement]
    FOREIGN KEY ([DocumentDeletionID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DocumentDeletionReason_LookupElement'
CREATE INDEX [IX_FK_DocumentDeletionReason_LookupElement]
ON [dbo].[DocumentDeletionReasons]
    ([DocumentDeletionID]);
GO

-- Creating foreign key on [DocumentID] in table 'DocumentDownloadHistories'
ALTER TABLE [dbo].[DocumentDownloadHistories]
ADD CONSTRAINT [FK_DocumentDownloadHistory_DocumentRepository]
    FOREIGN KEY ([DocumentID])
    REFERENCES [dbo].[DocumentRepositories]
        ([DocumentRepositoryID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DocumentDownloadHistory_DocumentRepository'
CREATE INDEX [IX_FK_DocumentDownloadHistory_DocumentRepository]
ON [dbo].[DocumentDownloadHistories]
    ([DocumentID]);
GO

-- Creating foreign key on [DocumentRepositoryID] in table 'DocumentExtraInfoes'
ALTER TABLE [dbo].[DocumentExtraInfoes]
ADD CONSTRAINT [FK_DocumentExtraInfo_DocumentRepository]
    FOREIGN KEY ([DocumentRepositoryID])
    REFERENCES [dbo].[DocumentRepositories]
        ([DocumentRepositoryID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [PriorityID] in table 'DocumentExtraInfoes'
ALTER TABLE [dbo].[DocumentExtraInfoes]
ADD CONSTRAINT [FK_DocumentExtraInfo_Priority]
    FOREIGN KEY ([PriorityID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DocumentExtraInfo_Priority'
CREATE INDEX [IX_FK_DocumentExtraInfo_Priority]
ON [dbo].[DocumentExtraInfoes]
    ([PriorityID]);
GO

-- Creating foreign key on [DocumentrepositoryID] in table 'PatientAssessments'
ALTER TABLE [dbo].[PatientAssessments]
ADD CONSTRAINT [FK__PatientAs__Docum__0A54486F]
    FOREIGN KEY ([DocumentrepositoryID])
    REFERENCES [dbo].[DocumentRepositories]
        ([DocumentRepositoryID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK__PatientAs__Docum__0A54486F'
CREATE INDEX [IX_FK__PatientAs__Docum__0A54486F]
ON [dbo].[PatientAssessments]
    ([DocumentrepositoryID]);
GO

-- Creating foreign key on [FileExtension] in table 'DocumentRepositories'
ALTER TABLE [dbo].[DocumentRepositories]
ADD CONSTRAINT [FK_DocumentRepository_FileExtension]
    FOREIGN KEY ([FileExtension])
    REFERENCES [dbo].[FileExtensions]
        ([FileExtension1])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DocumentRepository_FileExtension'
CREATE INDEX [IX_FK_DocumentRepository_FileExtension]
ON [dbo].[DocumentRepositories]
    ([FileExtension]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'DocumentRepositories'
ALTER TABLE [dbo].[DocumentRepositories]
ADD CONSTRAINT [FK_DocumentRepository_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DocumentRepository_InsuranceProvider'
CREATE INDEX [IX_FK_DocumentRepository_InsuranceProvider]
ON [dbo].[DocumentRepositories]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [DocumentType] in table 'DocumentRepositories'
ALTER TABLE [dbo].[DocumentRepositories]
ADD CONSTRAINT [FK_DocumentRepository_LookupElement_DocumentType]
    FOREIGN KEY ([DocumentType])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DocumentRepository_LookupElement_DocumentType'
CREATE INDEX [IX_FK_DocumentRepository_LookupElement_DocumentType]
ON [dbo].[DocumentRepositories]
    ([DocumentType]);
GO

-- Creating foreign key on [DocumentRepositoryID] in table 'EmailArchiveDocuments'
ALTER TABLE [dbo].[EmailArchiveDocuments]
ADD CONSTRAINT [FK_EmailArchiveDocument_DocumentRepository]
    FOREIGN KEY ([DocumentRepositoryID])
    REFERENCES [dbo].[DocumentRepositories]
        ([DocumentRepositoryID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_EmailArchiveDocument_DocumentRepository'
CREATE INDEX [IX_FK_EmailArchiveDocument_DocumentRepository]
ON [dbo].[EmailArchiveDocuments]
    ([DocumentRepositoryID]);
GO

-- Creating foreign key on [DocumentID] in table 'FaxArchiveDocuments'
ALTER TABLE [dbo].[FaxArchiveDocuments]
ADD CONSTRAINT [FK_FaxArchiveDocument_DocumentRepository]
    FOREIGN KEY ([DocumentID])
    REFERENCES [dbo].[DocumentRepositories]
        ([DocumentRepositoryID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxArchiveDocument_DocumentRepository'
CREATE INDEX [IX_FK_FaxArchiveDocument_DocumentRepository]
ON [dbo].[FaxArchiveDocuments]
    ([DocumentID]);
GO

-- Creating foreign key on [DocumentRepositoryID] in table 'FaxDetails'
ALTER TABLE [dbo].[FaxDetails]
ADD CONSTRAINT [FK_FaxDetails_DocumentRepository]
    FOREIGN KEY ([DocumentRepositoryID])
    REFERENCES [dbo].[DocumentRepositories]
        ([DocumentRepositoryID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxDetails_DocumentRepository'
CREATE INDEX [IX_FK_FaxDetails_DocumentRepository]
ON [dbo].[FaxDetails]
    ([DocumentRepositoryID]);
GO

-- Creating foreign key on [DocumentRepositoryID] in table 'FaxDocumentAssignments'
ALTER TABLE [dbo].[FaxDocumentAssignments]
ADD CONSTRAINT [FK_FaxDocumentAssignment_DocumentRepository]
    FOREIGN KEY ([DocumentRepositoryID])
    REFERENCES [dbo].[DocumentRepositories]
        ([DocumentRepositoryID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [DocumentRepositoryID] in table 'MailArchiveDocuments'
ALTER TABLE [dbo].[MailArchiveDocuments]
ADD CONSTRAINT [FK_MailArchiveDocument_DocumentRepository]
    FOREIGN KEY ([DocumentRepositoryID])
    REFERENCES [dbo].[DocumentRepositories]
        ([DocumentRepositoryID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MailArchiveDocument_DocumentRepository'
CREATE INDEX [IX_FK_MailArchiveDocument_DocumentRepository]
ON [dbo].[MailArchiveDocuments]
    ([DocumentRepositoryID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'DocumentTextBlocks'
ALTER TABLE [dbo].[DocumentTextBlocks]
ADD CONSTRAINT [FK_DocumentTextBlock_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DocumentTextBlock_InsuranceProvider'
CREATE INDEX [IX_FK_DocumentTextBlock_InsuranceProvider]
ON [dbo].[DocumentTextBlocks]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [DocumentTextBlockTypeID] in table 'DocumentTextBlocks'
ALTER TABLE [dbo].[DocumentTextBlocks]
ADD CONSTRAINT [FK_DocumentTextBlock_LookupElement]
    FOREIGN KEY ([DocumentTextBlockTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DocumentTextBlock_LookupElement'
CREATE INDEX [IX_FK_DocumentTextBlock_LookupElement]
ON [dbo].[DocumentTextBlocks]
    ([DocumentTextBlockTypeID]);
GO

-- Creating foreign key on [UnitOfMeasureID] in table 'Drugs'
ALTER TABLE [dbo].[Drugs]
ADD CONSTRAINT [FK_Drug_LookupElement]
    FOREIGN KEY ([UnitOfMeasureID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Drug_LookupElement'
CREATE INDEX [IX_FK_Drug_LookupElement]
ON [dbo].[Drugs]
    ([UnitOfMeasureID]);
GO

-- Creating foreign key on [DrugClassID] in table 'Drugs'
ALTER TABLE [dbo].[Drugs]
ADD CONSTRAINT [FK_Drug_LookupElement_DrugClass]
    FOREIGN KEY ([DrugClassID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Drug_LookupElement_DrugClass'
CREATE INDEX [IX_FK_Drug_LookupElement_DrugClass]
ON [dbo].[Drugs]
    ([DrugClassID]);
GO

-- Creating foreign key on [DrugSubClassID] in table 'Drugs'
ALTER TABLE [dbo].[Drugs]
ADD CONSTRAINT [FK_Drug_LookupElement_DrugSubClass]
    FOREIGN KEY ([DrugSubClassID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Drug_LookupElement_DrugSubClass'
CREATE INDEX [IX_FK_Drug_LookupElement_DrugSubClass]
ON [dbo].[Drugs]
    ([DrugSubClassID]);
GO

-- Creating foreign key on [GCSFTypeID] in table 'Drugs'
ALTER TABLE [dbo].[Drugs]
ADD CONSTRAINT [FK_Drug_LookupElement_GCSFType]
    FOREIGN KEY ([GCSFTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Drug_LookupElement_GCSFType'
CREATE INDEX [IX_FK_Drug_LookupElement_GCSFType]
ON [dbo].[Drugs]
    ([GCSFTypeID]);
GO

-- Creating foreign key on [RxNormTermTypeID] in table 'Drugs'
ALTER TABLE [dbo].[Drugs]
ADD CONSTRAINT [FK_Drug_LookupElement_RxNormTermType]
    FOREIGN KEY ([RxNormTermTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Drug_LookupElement_RxNormTermType'
CREATE INDEX [IX_FK_Drug_LookupElement_RxNormTermType]
ON [dbo].[Drugs]
    ([RxNormTermTypeID]);
GO

-- Creating foreign key on [DrugID] in table 'Drug_SideEffect'
ALTER TABLE [dbo].[Drug_SideEffect]
ADD CONSTRAINT [FK_Drug_SideEffect_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Drug_SideEffect_Drug'
CREATE INDEX [IX_FK_Drug_SideEffect_Drug]
ON [dbo].[Drug_SideEffect]
    ([DrugID]);
GO

-- Creating foreign key on [BiosimilarDrugID] in table 'DrugBiosimilarities'
ALTER TABLE [dbo].[DrugBiosimilarities]
ADD CONSTRAINT [FK_DrugBiosimilarity_BiosimilarDrug]
    FOREIGN KEY ([BiosimilarDrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DrugBiosimilarity_BiosimilarDrug'
CREATE INDEX [IX_FK_DrugBiosimilarity_BiosimilarDrug]
ON [dbo].[DrugBiosimilarities]
    ([BiosimilarDrugID]);
GO

-- Creating foreign key on [OriginalDrugID] in table 'DrugBiosimilarities'
ALTER TABLE [dbo].[DrugBiosimilarities]
ADD CONSTRAINT [FK_DrugBiosimilarity_OriginalDrug]
    FOREIGN KEY ([OriginalDrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DrugBiosimilarity_OriginalDrug'
CREATE INDEX [IX_FK_DrugBiosimilarity_OriginalDrug]
ON [dbo].[DrugBiosimilarities]
    ([OriginalDrugID]);
GO

-- Creating foreign key on [DrugID] in table 'DrugCodes'
ALTER TABLE [dbo].[DrugCodes]
ADD CONSTRAINT [FK_DrugCode_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DrugCode_Drug'
CREATE INDEX [IX_FK_DrugCode_Drug]
ON [dbo].[DrugCodes]
    ([DrugID]);
GO

-- Creating foreign key on [DrugID] in table 'DrugPolicies'
ALTER TABLE [dbo].[DrugPolicies]
ADD CONSTRAINT [FK_DrugPolicy_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DrugPolicy_Drug'
CREATE INDEX [IX_FK_DrugPolicy_Drug]
ON [dbo].[DrugPolicies]
    ([DrugID]);
GO

-- Creating foreign key on [DrugID] in table 'DrugProtocolTotalBillingUnits'
ALTER TABLE [dbo].[DrugProtocolTotalBillingUnits]
ADD CONSTRAINT [FK_DrugProtocolTotalBillingUnits_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DrugProtocolTotalBillingUnits_Drug'
CREATE INDEX [IX_FK_DrugProtocolTotalBillingUnits_Drug]
ON [dbo].[DrugProtocolTotalBillingUnits]
    ([DrugID]);
GO

-- Creating foreign key on [DrugID] in table 'GrandfatherRuleDrugs'
ALTER TABLE [dbo].[GrandfatherRuleDrugs]
ADD CONSTRAINT [FK_GrandfatherRuleDrug_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_GrandfatherRuleDrug_Drug'
CREATE INDEX [IX_FK_GrandfatherRuleDrug_Drug]
ON [dbo].[GrandfatherRuleDrugs]
    ([DrugID]);
GO

-- Creating foreign key on [DrugID] in table 'InsuranceProviderDrugs'
ALTER TABLE [dbo].[InsuranceProviderDrugs]
ADD CONSTRAINT [FK_InsuranceProviderDrug_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderDrug_Drug'
CREATE INDEX [IX_FK_InsuranceProviderDrug_Drug]
ON [dbo].[InsuranceProviderDrugs]
    ([DrugID]);
GO

-- Creating foreign key on [DrugID] in table 'InsuranceProviderDrugConfigurations'
ALTER TABLE [dbo].[InsuranceProviderDrugConfigurations]
ADD CONSTRAINT [FK_InsuranceProviderDrugConfiguration_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderDrugConfiguration_Drug'
CREATE INDEX [IX_FK_InsuranceProviderDrugConfiguration_Drug]
ON [dbo].[InsuranceProviderDrugConfigurations]
    ([DrugID]);
GO

-- Creating foreign key on [DrugID] in table 'NeutropeniaOverTurnDrugs'
ALTER TABLE [dbo].[NeutropeniaOverTurnDrugs]
ADD CONSTRAINT [FK_NeutropeniaOverTurnDrug_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [DrugID] in table 'PatientProtocolAssignment_Protocol_ProtocolElementCode'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_Drug'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_Drug]
ON [dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode]
    ([DrugID]);
GO

-- Creating foreign key on [DrugID] in table 'PatientProtocolAssignment_ProtocolDosing'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDosing_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolDosing_Drug'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolDosing_Drug]
ON [dbo].[PatientProtocolAssignment_ProtocolDosing]
    ([DrugID]);
GO

-- Creating foreign key on [DrugID] in table 'PayerFormularies'
ALTER TABLE [dbo].[PayerFormularies]
ADD CONSTRAINT [FK_PayerFormulary_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerFormulary_Drug'
CREATE INDEX [IX_FK_PayerFormulary_Drug]
ON [dbo].[PayerFormularies]
    ([DrugID]);
GO

-- Creating foreign key on [DrugID] in table 'PreferredDrugRules'
ALTER TABLE [dbo].[PreferredDrugRules]
ADD CONSTRAINT [FK_PreferredDrugRule_DrugID]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PreferredDrugRule_DrugID'
CREATE INDEX [IX_FK_PreferredDrugRule_DrugID]
ON [dbo].[PreferredDrugRules]
    ([DrugID]);
GO

-- Creating foreign key on [PreferredGenericDrugID] in table 'PreferredDrugRules'
ALTER TABLE [dbo].[PreferredDrugRules]
ADD CONSTRAINT [FK_PreferredDrugRule_PreferredGenericDrugID]
    FOREIGN KEY ([PreferredGenericDrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PreferredDrugRule_PreferredGenericDrugID'
CREATE INDEX [IX_FK_PreferredDrugRule_PreferredGenericDrugID]
ON [dbo].[PreferredDrugRules]
    ([PreferredGenericDrugID]);
GO

-- Creating foreign key on [DrugID] in table 'PrerequisiteDrugs'
ALTER TABLE [dbo].[PrerequisiteDrugs]
ADD CONSTRAINT [FK_PrerequisiteDrug_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PrerequisiteDrug_Drug'
CREATE INDEX [IX_FK_PrerequisiteDrug_Drug]
ON [dbo].[PrerequisiteDrugs]
    ([DrugID]);
GO

-- Creating foreign key on [DrugID] in table 'ProtocolElements'
ALTER TABLE [dbo].[ProtocolElements]
ADD CONSTRAINT [FK_ProtocolElement_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElement_Drug'
CREATE INDEX [IX_FK_ProtocolElement_Drug]
ON [dbo].[ProtocolElements]
    ([DrugID]);
GO

-- Creating foreign key on [DrugID] in table 'ProtocolRequestDrugs'
ALTER TABLE [dbo].[ProtocolRequestDrugs]
ADD CONSTRAINT [FK_ProtocolRequestDrug_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolRequestDrug_Drug'
CREATE INDEX [IX_FK_ProtocolRequestDrug_Drug]
ON [dbo].[ProtocolRequestDrugs]
    ([DrugID]);
GO

-- Creating foreign key on [PriorDrugID] in table 'StepTherapyRulePriorDrugs'
ALTER TABLE [dbo].[StepTherapyRulePriorDrugs]
ADD CONSTRAINT [FK_SStepTherapyRulePriorDrug_Drug]
    FOREIGN KEY ([PriorDrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_SStepTherapyRulePriorDrug_Drug'
CREATE INDEX [IX_FK_SStepTherapyRulePriorDrug_Drug]
ON [dbo].[StepTherapyRulePriorDrugs]
    ([PriorDrugID]);
GO

-- Creating foreign key on [DrugID] in table 'StepTherapyRules'
ALTER TABLE [dbo].[StepTherapyRules]
ADD CONSTRAINT [FK_StepTherapyRule_Drug]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StepTherapyRule_Drug'
CREATE INDEX [IX_FK_StepTherapyRule_Drug]
ON [dbo].[StepTherapyRules]
    ([DrugID]);
GO

-- Creating foreign key on [DrugID] in table 'StopLossRules'
ALTER TABLE [dbo].[StopLossRules]
ADD CONSTRAINT [FK_StopLossRule_DrugID]
    FOREIGN KEY ([DrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StopLossRule_DrugID'
CREATE INDEX [IX_FK_StopLossRule_DrugID]
ON [dbo].[StopLossRules]
    ([DrugID]);
GO

-- Creating foreign key on [StopLossDrugID] in table 'StopLossRules'
ALTER TABLE [dbo].[StopLossRules]
ADD CONSTRAINT [FK_StopLossRule_StopLossDrugID]
    FOREIGN KEY ([StopLossDrugID])
    REFERENCES [dbo].[Drugs]
        ([DrugID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StopLossRule_StopLossDrugID'
CREATE INDEX [IX_FK_StopLossRule_StopLossDrugID]
ON [dbo].[StopLossRules]
    ([StopLossDrugID]);
GO

-- Creating foreign key on [SideEffectFrequencyID] in table 'Drug_SideEffect'
ALTER TABLE [dbo].[Drug_SideEffect]
ADD CONSTRAINT [FK_Drug_SideEffect_LookupElement]
    FOREIGN KEY ([SideEffectFrequencyID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Drug_SideEffect_LookupElement'
CREATE INDEX [IX_FK_Drug_SideEffect_LookupElement]
ON [dbo].[Drug_SideEffect]
    ([SideEffectFrequencyID]);
GO

-- Creating foreign key on [SideEffectID] in table 'Drug_SideEffect'
ALTER TABLE [dbo].[Drug_SideEffect]
ADD CONSTRAINT [FK_SideEffect_Drug_SideEffect]
    FOREIGN KEY ([SideEffectID])
    REFERENCES [dbo].[SideEffects]
        ([SideEffectID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_SideEffect_Drug_SideEffect'
CREATE INDEX [IX_FK_SideEffect_Drug_SideEffect]
ON [dbo].[Drug_SideEffect]
    ([SideEffectID]);
GO

-- Creating foreign key on [DrugCodeID] in table 'PatientProtocolAssignment_Protocol_ProtocolElementCode'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_DrugCode]
    FOREIGN KEY ([DrugCodeID])
    REFERENCES [dbo].[DrugCodes]
        ([DrugCodeID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_DrugCode'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_DrugCode]
ON [dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode]
    ([DrugCodeID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'DrugPolicies'
ALTER TABLE [dbo].[DrugPolicies]
ADD CONSTRAINT [FK_DrugPolicy_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DrugPolicy_InsuranceProvider'
CREATE INDEX [IX_FK_DrugPolicy_InsuranceProvider]
ON [dbo].[DrugPolicies]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [DrugPolicyID] in table 'DrugPolicyCriterias'
ALTER TABLE [dbo].[DrugPolicyCriterias]
ADD CONSTRAINT [FK_DrugPolicyCriteria_DrugPolicy]
    FOREIGN KEY ([DrugPolicyID])
    REFERENCES [dbo].[DrugPolicies]
        ([DrugPolicyID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DrugPolicyCriteria_DrugPolicy'
CREATE INDEX [IX_FK_DrugPolicyCriteria_DrugPolicy]
ON [dbo].[DrugPolicyCriterias]
    ([DrugPolicyID]);
GO

-- Creating foreign key on [DrugPolicyID] in table 'DrugPolicyLOBs'
ALTER TABLE [dbo].[DrugPolicyLOBs]
ADD CONSTRAINT [FK_DrugPolicyLOB_DrugPolicy]
    FOREIGN KEY ([DrugPolicyID])
    REFERENCES [dbo].[DrugPolicies]
        ([DrugPolicyID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DrugPolicyLOB_DrugPolicy'
CREATE INDEX [IX_FK_DrugPolicyLOB_DrugPolicy]
ON [dbo].[DrugPolicyLOBs]
    ([DrugPolicyID]);
GO

-- Creating foreign key on [DrugPolicyCriteriaID] in table 'DrugPolicyCriteriaDiagnosis'
ALTER TABLE [dbo].[DrugPolicyCriteriaDiagnosis]
ADD CONSTRAINT [FK_DrugPolicyCriteriaDiagnosis_DrugPolicyCriteria]
    FOREIGN KEY ([DrugPolicyCriteriaID])
    REFERENCES [dbo].[DrugPolicyCriterias]
        ([DrugPolicyCriteriaID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DrugPolicyCriteriaDiagnosis_DrugPolicyCriteria'
CREATE INDEX [IX_FK_DrugPolicyCriteriaDiagnosis_DrugPolicyCriteria]
ON [dbo].[DrugPolicyCriteriaDiagnosis]
    ([DrugPolicyCriteriaID]);
GO

-- Creating foreign key on [StageID] in table 'DrugPolicyCriteriaDiagnosis'
ALTER TABLE [dbo].[DrugPolicyCriteriaDiagnosis]
ADD CONSTRAINT [FK_DrugPolicyCriteriaDiagnosis_LookupElement]
    FOREIGN KEY ([StageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DrugPolicyCriteriaDiagnosis_LookupElement'
CREATE INDEX [IX_FK_DrugPolicyCriteriaDiagnosis_LookupElement]
ON [dbo].[DrugPolicyCriteriaDiagnosis]
    ([StageID]);
GO

-- Creating foreign key on [LineOfBusinessID] in table 'DrugPolicyLOBs'
ALTER TABLE [dbo].[DrugPolicyLOBs]
ADD CONSTRAINT [FK_DrugPolicyLOB_LineofBusiness]
    FOREIGN KEY ([LineOfBusinessID])
    REFERENCES [dbo].[LineofBusinesses]
        ([LineOfBusinessID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DrugPolicyLOB_LineofBusiness'
CREATE INDEX [IX_FK_DrugPolicyLOB_LineofBusiness]
ON [dbo].[DrugPolicyLOBs]
    ([LineOfBusinessID]);
GO

-- Creating foreign key on [BillingMethodID] in table 'DrugProtocolTotalBillingUnits'
ALTER TABLE [dbo].[DrugProtocolTotalBillingUnits]
ADD CONSTRAINT [FK_DrugProtocolTotalBillingUnits_LookupElement_BillingMethod]
    FOREIGN KEY ([BillingMethodID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DrugProtocolTotalBillingUnits_LookupElement_BillingMethod'
CREATE INDEX [IX_FK_DrugProtocolTotalBillingUnits_LookupElement_BillingMethod]
ON [dbo].[DrugProtocolTotalBillingUnits]
    ([BillingMethodID]);
GO

-- Creating foreign key on [CodeTypeID] in table 'DrugProtocolTotalBillingUnits'
ALTER TABLE [dbo].[DrugProtocolTotalBillingUnits]
ADD CONSTRAINT [FK_DrugProtocolTotalBillingUnits_LookupElement_CodeType]
    FOREIGN KEY ([CodeTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DrugProtocolTotalBillingUnits_LookupElement_CodeType'
CREATE INDEX [IX_FK_DrugProtocolTotalBillingUnits_LookupElement_CodeType]
ON [dbo].[DrugProtocolTotalBillingUnits]
    ([CodeTypeID]);
GO

-- Creating foreign key on [ProtocolID] in table 'DrugProtocolTotalBillingUnits'
ALTER TABLE [dbo].[DrugProtocolTotalBillingUnits]
ADD CONSTRAINT [FK_DrugProtocolTotalBillingUnits_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DrugProtocolTotalBillingUnits_Protocol'
CREATE INDEX [IX_FK_DrugProtocolTotalBillingUnits_Protocol]
ON [dbo].[DrugProtocolTotalBillingUnits]
    ([ProtocolID]);
GO

-- Creating foreign key on [DualEligibilityStatusID] in table 'Eligibilities'
ALTER TABLE [dbo].[Eligibilities]
ADD CONSTRAINT [FK_Eligibility_DualEligibilityStatus]
    FOREIGN KEY ([DualEligibilityStatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Eligibility_DualEligibilityStatus'
CREATE INDEX [IX_FK_Eligibility_DualEligibilityStatus]
ON [dbo].[Eligibilities]
    ([DualEligibilityStatusID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'Eligibilities'
ALTER TABLE [dbo].[Eligibilities]
ADD CONSTRAINT [FK_Eligibility_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Eligibility_InsuranceProvider'
CREATE INDEX [IX_FK_Eligibility_InsuranceProvider]
ON [dbo].[Eligibilities]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [LineOfBusinessID] in table 'Eligibilities'
ALTER TABLE [dbo].[Eligibilities]
ADD CONSTRAINT [FK_Eligibility_LineofBusiness]
    FOREIGN KEY ([LineOfBusinessID])
    REFERENCES [dbo].[LineofBusinesses]
        ([LineOfBusinessID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Eligibility_LineofBusiness'
CREATE INDEX [IX_FK_Eligibility_LineofBusiness]
ON [dbo].[Eligibilities]
    ([LineOfBusinessID]);
GO

-- Creating foreign key on [PatientID] in table 'Eligibilities'
ALTER TABLE [dbo].[Eligibilities]
ADD CONSTRAINT [FK_Eligibility_Patient]
    FOREIGN KEY ([PatientID])
    REFERENCES [dbo].[Patients]
        ([PatientID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Eligibility_Patient'
CREATE INDEX [IX_FK_Eligibility_Patient]
ON [dbo].[Eligibilities]
    ([PatientID]);
GO

-- Creating foreign key on [ProductLineID] in table 'Eligibilities'
ALTER TABLE [dbo].[Eligibilities]
ADD CONSTRAINT [FK_Eligibility_ProductLine]
    FOREIGN KEY ([ProductLineID])
    REFERENCES [dbo].[ProductLines]
        ([ProductLineID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Eligibility_ProductLine'
CREATE INDEX [IX_FK_Eligibility_ProductLine]
ON [dbo].[Eligibilities]
    ([ProductLineID]);
GO

-- Creating foreign key on [EligibilityID] in table 'PatientProtocolAssignments'
ALTER TABLE [dbo].[PatientProtocolAssignments]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Eligibility]
    FOREIGN KEY ([EligibilityID])
    REFERENCES [dbo].[Eligibilities]
        ([EligibilityID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Eligibility'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Eligibility]
ON [dbo].[PatientProtocolAssignments]
    ([EligibilityID]);
GO

-- Creating foreign key on [PatientID] in table 'EmailArchives'
ALTER TABLE [dbo].[EmailArchives]
ADD CONSTRAINT [FK_EmailArchive_Patient]
    FOREIGN KEY ([PatientID])
    REFERENCES [dbo].[Patients]
        ([PatientID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_EmailArchive_Patient'
CREATE INDEX [IX_FK_EmailArchive_Patient]
ON [dbo].[EmailArchives]
    ([PatientID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'EmailArchives'
ALTER TABLE [dbo].[EmailArchives]
ADD CONSTRAINT [FK_EmailArchive_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_EmailArchive_PatientProtocolAssignment'
CREATE INDEX [IX_FK_EmailArchive_PatientProtocolAssignment]
ON [dbo].[EmailArchives]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [EmailArchiveID] in table 'EmailArchiveDetails'
ALTER TABLE [dbo].[EmailArchiveDetails]
ADD CONSTRAINT [FK_EmailArchiveDetail_EmailArchive]
    FOREIGN KEY ([EmailArchiveID])
    REFERENCES [dbo].[EmailArchives]
        ([EmailArchiveID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_EmailArchiveDetail_EmailArchive'
CREATE INDEX [IX_FK_EmailArchiveDetail_EmailArchive]
ON [dbo].[EmailArchiveDetails]
    ([EmailArchiveID]);
GO

-- Creating foreign key on [EmailArchiveID] in table 'EmailArchiveDocuments'
ALTER TABLE [dbo].[EmailArchiveDocuments]
ADD CONSTRAINT [FK_EmailArchiveDocument_EmailArchive]
    FOREIGN KEY ([EmailArchiveID])
    REFERENCES [dbo].[EmailArchives]
        ([EmailArchiveID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_EmailArchiveDocument_EmailArchive'
CREATE INDEX [IX_FK_EmailArchiveDocument_EmailArchive]
ON [dbo].[EmailArchiveDocuments]
    ([EmailArchiveID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'EODFiles'
ALTER TABLE [dbo].[EODFiles]
ADD CONSTRAINT [FK_EODFile_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_EODFile_InsuranceProvider'
CREATE INDEX [IX_FK_EODFile_InsuranceProvider]
ON [dbo].[EODFiles]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [EODFileID] in table 'EODFileProtocolAssignments'
ALTER TABLE [dbo].[EODFileProtocolAssignments]
ADD CONSTRAINT [FK_EODFileProtocolAssignment_EODFile]
    FOREIGN KEY ([EODFileID])
    REFERENCES [dbo].[EODFiles]
        ([EODFileID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_EODFileProtocolAssignment_EODFile'
CREATE INDEX [IX_FK_EODFileProtocolAssignment_EODFile]
ON [dbo].[EODFileProtocolAssignments]
    ([EODFileID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'EODFileProtocolAssignments'
ALTER TABLE [dbo].[EODFileProtocolAssignments]
ADD CONSTRAINT [FK_EODFileProtocolAssignment_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_EODFileProtocolAssignment_PatientProtocolAssignment'
CREATE INDEX [IX_FK_EODFileProtocolAssignment_PatientProtocolAssignment]
ON [dbo].[EODFileProtocolAssignments]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [ExplicitQuestionXRTID] in table 'ExplicitAnswerXRTs'
ALTER TABLE [dbo].[ExplicitAnswerXRTs]
ADD CONSTRAINT [FK_ExplicitQuestionAnswerXRT_ExplicitQuestionXRT]
    FOREIGN KEY ([ExplicitQuestionXRTID])
    REFERENCES [dbo].[ExplicitQuestionXRTs]
        ([ExplicitQuestionXRTID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ExplicitQuestionAnswerXRT_ExplicitQuestionXRT'
CREATE INDEX [IX_FK_ExplicitQuestionAnswerXRT_ExplicitQuestionXRT]
ON [dbo].[ExplicitAnswerXRTs]
    ([ExplicitQuestionXRTID]);
GO

-- Creating foreign key on [ExplicitAnswerXRTID] in table 'PatientProtocolAssignment_QuestionAnswerXRT'
ALTER TABLE [dbo].[PatientProtocolAssignment_QuestionAnswerXRT]
ADD CONSTRAINT [FK_PatientProtocolAssignment_QuestionAnswerXRT_ExplicitAnswerXRT]
    FOREIGN KEY ([ExplicitAnswerXRTID])
    REFERENCES [dbo].[ExplicitAnswerXRTs]
        ([ExplicitAnswerXRTID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_QuestionAnswerXRT_ExplicitAnswerXRT'
CREATE INDEX [IX_FK_PatientProtocolAssignment_QuestionAnswerXRT_ExplicitAnswerXRT]
ON [dbo].[PatientProtocolAssignment_QuestionAnswerXRT]
    ([ExplicitAnswerXRTID]);
GO

-- Creating foreign key on [QuestionID] in table 'ExplicitQuestionAnswers'
ALTER TABLE [dbo].[ExplicitQuestionAnswers]
ADD CONSTRAINT [FK_ExplicitQuestionAnswer_ExplicitQuestion]
    FOREIGN KEY ([QuestionID])
    REFERENCES [dbo].[ExplicitQuestions]
        ([QuestionID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ExplicitQuestionAnswer_ExplicitQuestion'
CREATE INDEX [IX_FK_ExplicitQuestionAnswer_ExplicitQuestion]
ON [dbo].[ExplicitQuestionAnswers]
    ([QuestionID]);
GO

-- Creating foreign key on [QuestionID] in table 'PatientProtocolAssignment_ProtocolQuestionAnswer'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolQuestionAnswer]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolQuestionAnswer_ExplicitQuestion]
    FOREIGN KEY ([QuestionID])
    REFERENCES [dbo].[ExplicitQuestions]
        ([QuestionID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolQuestionAnswer_ExplicitQuestion'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolQuestionAnswer_ExplicitQuestion]
ON [dbo].[PatientProtocolAssignment_ProtocolQuestionAnswer]
    ([QuestionID]);
GO

-- Creating foreign key on [QuestionID] in table 'ProtocolQuestions'
ALTER TABLE [dbo].[ProtocolQuestions]
ADD CONSTRAINT [FK_ProtocolQuestion_ExplicitQuestion]
    FOREIGN KEY ([QuestionID])
    REFERENCES [dbo].[ExplicitQuestions]
        ([QuestionID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolQuestion_ExplicitQuestion'
CREATE INDEX [IX_FK_ProtocolQuestion_ExplicitQuestion]
ON [dbo].[ProtocolQuestions]
    ([QuestionID]);
GO

-- Creating foreign key on [AnswerID] in table 'ExplicitQuestionAnswers'
ALTER TABLE [dbo].[ExplicitQuestionAnswers]
ADD CONSTRAINT [FK_ExplicitQuestionAnswer_LookupElement]
    FOREIGN KEY ([AnswerID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ExplicitQuestionAnswer_LookupElement'
CREATE INDEX [IX_FK_ExplicitQuestionAnswer_LookupElement]
ON [dbo].[ExplicitQuestionAnswers]
    ([AnswerID]);
GO

-- Creating foreign key on [ExplicitQuestionXRTID] in table 'PatientProtocolAssignment_QuestionAnswerXRT'
ALTER TABLE [dbo].[PatientProtocolAssignment_QuestionAnswerXRT]
ADD CONSTRAINT [FK_PatientProtocolAssignment_QuestionAnswerXRT_ExplicitQuestionXRT]
    FOREIGN KEY ([ExplicitQuestionXRTID])
    REFERENCES [dbo].[ExplicitQuestionXRTs]
        ([ExplicitQuestionXRTID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_QuestionAnswerXRT_ExplicitQuestionXRT'
CREATE INDEX [IX_FK_PatientProtocolAssignment_QuestionAnswerXRT_ExplicitQuestionXRT]
ON [dbo].[PatientProtocolAssignment_QuestionAnswerXRT]
    ([ExplicitQuestionXRTID]);
GO

-- Creating foreign key on [FaxAddressID] in table 'FaxDetails'
ALTER TABLE [dbo].[FaxDetails]
ADD CONSTRAINT [FK_FaxDetails_FaxAddress]
    FOREIGN KEY ([FaxAddressID])
    REFERENCES [dbo].[FaxAddresses]
        ([FaxAddressID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxDetails_FaxAddress'
CREATE INDEX [IX_FK_FaxDetails_FaxAddress]
ON [dbo].[FaxDetails]
    ([FaxAddressID]);
GO

-- Creating foreign key on [PatientID] in table 'FaxArchives'
ALTER TABLE [dbo].[FaxArchives]
ADD CONSTRAINT [FK_FaxArchive_Patient]
    FOREIGN KEY ([PatientID])
    REFERENCES [dbo].[Patients]
        ([PatientID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxArchive_Patient'
CREATE INDEX [IX_FK_FaxArchive_Patient]
ON [dbo].[FaxArchives]
    ([PatientID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'FaxArchives'
ALTER TABLE [dbo].[FaxArchives]
ADD CONSTRAINT [FK_FaxArchive_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxArchive_PatientProtocolAssignment'
CREATE INDEX [IX_FK_FaxArchive_PatientProtocolAssignment]
ON [dbo].[FaxArchives]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [FaxArchiveID] in table 'FaxArchiveDocuments'
ALTER TABLE [dbo].[FaxArchiveDocuments]
ADD CONSTRAINT [FK_FaxArchiveDocument_FaxArchive]
    FOREIGN KEY ([FaxArchiveID])
    REFERENCES [dbo].[FaxArchives]
        ([FaxArchiveID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxArchiveDocument_FaxArchive'
CREATE INDEX [IX_FK_FaxArchiveDocument_FaxArchive]
ON [dbo].[FaxArchiveDocuments]
    ([FaxArchiveID]);
GO

-- Creating foreign key on [InsuranceProviderFaxTemplateID] in table 'FaxCatalogs'
ALTER TABLE [dbo].[FaxCatalogs]
ADD CONSTRAINT [FK_FaxCatalog_InsuranceProviderFaxTemplate]
    FOREIGN KEY ([InsuranceProviderFaxTemplateID])
    REFERENCES [dbo].[InsuranceProviderFaxTemplates]
        ([InsuranceProviderFaxTemplateID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxCatalog_InsuranceProviderFaxTemplate'
CREATE INDEX [IX_FK_FaxCatalog_InsuranceProviderFaxTemplate]
ON [dbo].[FaxCatalogs]
    ([InsuranceProviderFaxTemplateID]);
GO

-- Creating foreign key on [FaxCatalogID] in table 'FaxParameters'
ALTER TABLE [dbo].[FaxParameters]
ADD CONSTRAINT [FK_FaxParameter_FaxCatalog]
    FOREIGN KEY ([FaxCatalogID])
    REFERENCES [dbo].[FaxCatalogs]
        ([FaxCatalogID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxParameter_FaxCatalog'
CREATE INDEX [IX_FK_FaxParameter_FaxCatalog]
ON [dbo].[FaxParameters]
    ([FaxCatalogID]);
GO

-- Creating foreign key on [AssignedTo] in table 'FaxDocumentAssignments'
ALTER TABLE [dbo].[FaxDocumentAssignments]
ADD CONSTRAINT [FK_FaxDocumentAssignment_User]
    FOREIGN KEY ([AssignedTo])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxDocumentAssignment_User'
CREATE INDEX [IX_FK_FaxDocumentAssignment_User]
ON [dbo].[FaxDocumentAssignments]
    ([AssignedTo]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'FaxRecipients'
ALTER TABLE [dbo].[FaxRecipients]
ADD CONSTRAINT [FK_FaxRecipient_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxRecipient_InsuranceProvider'
CREATE INDEX [IX_FK_FaxRecipient_InsuranceProvider]
ON [dbo].[FaxRecipients]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [LOBID] in table 'FaxRecipients'
ALTER TABLE [dbo].[FaxRecipients]
ADD CONSTRAINT [FK_FaxRecipient_LineofBusiness]
    FOREIGN KEY ([LOBID])
    REFERENCES [dbo].[LineofBusinesses]
        ([LineOfBusinessID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxRecipient_LineofBusiness'
CREATE INDEX [IX_FK_FaxRecipient_LineofBusiness]
ON [dbo].[FaxRecipients]
    ([LOBID]);
GO

-- Creating foreign key on [FaxRecipientType] in table 'FaxRecipients'
ALTER TABLE [dbo].[FaxRecipients]
ADD CONSTRAINT [FK_FaxRecipient_LookupElement_FaxRecipientType]
    FOREIGN KEY ([FaxRecipientType])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxRecipient_LookupElement_FaxRecipientType'
CREATE INDEX [IX_FK_FaxRecipient_LookupElement_FaxRecipientType]
ON [dbo].[FaxRecipients]
    ([FaxRecipientType]);
GO

-- Creating foreign key on [FaxTemplateType] in table 'FaxRecipients'
ALTER TABLE [dbo].[FaxRecipients]
ADD CONSTRAINT [FK_FaxRecipient_LookupElement_FaxTemplatetType]
    FOREIGN KEY ([FaxTemplateType])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxRecipient_LookupElement_FaxTemplatetType'
CREATE INDEX [IX_FK_FaxRecipient_LookupElement_FaxTemplatetType]
ON [dbo].[FaxRecipients]
    ([FaxTemplateType]);
GO

-- Creating foreign key on [StateCode] in table 'FaxRecipients'
ALTER TABLE [dbo].[FaxRecipients]
ADD CONSTRAINT [FK_FaxRecipient_State]
    FOREIGN KEY ([StateCode])
    REFERENCES [dbo].[States]
        ([StateCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxRecipient_State'
CREATE INDEX [IX_FK_FaxRecipient_State]
ON [dbo].[FaxRecipients]
    ([StateCode]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'FaxRecipientConfigurations'
ALTER TABLE [dbo].[FaxRecipientConfigurations]
ADD CONSTRAINT [FK_FaxRecipientConfiguration_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxRecipientConfiguration_InsuranceProvider'
CREATE INDEX [IX_FK_FaxRecipientConfiguration_InsuranceProvider]
ON [dbo].[FaxRecipientConfigurations]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [MajorLineofBusinessID] in table 'FaxRecipientConfigurations'
ALTER TABLE [dbo].[FaxRecipientConfigurations]
ADD CONSTRAINT [FK_FaxRecipientConfiguration_LineofBusiness]
    FOREIGN KEY ([MajorLineofBusinessID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxRecipientConfiguration_LineofBusiness'
CREATE INDEX [IX_FK_FaxRecipientConfiguration_LineofBusiness]
ON [dbo].[FaxRecipientConfigurations]
    ([MajorLineofBusinessID]);
GO

-- Creating foreign key on [FaxTemplateType] in table 'FaxRecipientConfigurations'
ALTER TABLE [dbo].[FaxRecipientConfigurations]
ADD CONSTRAINT [FK_FaxRecipientConfiguration_LookupElement]
    FOREIGN KEY ([FaxTemplateType])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxRecipientConfiguration_LookupElement'
CREATE INDEX [IX_FK_FaxRecipientConfiguration_LookupElement]
ON [dbo].[FaxRecipientConfigurations]
    ([FaxTemplateType]);
GO

-- Creating foreign key on [ProductLineID] in table 'FaxRecipientConfigurations'
ALTER TABLE [dbo].[FaxRecipientConfigurations]
ADD CONSTRAINT [FK_FaxRecipientConfiguration_ProductLine]
    FOREIGN KEY ([ProductLineID])
    REFERENCES [dbo].[ProductLines]
        ([ProductLineID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxRecipientConfiguration_ProductLine'
CREATE INDEX [IX_FK_FaxRecipientConfiguration_ProductLine]
ON [dbo].[FaxRecipientConfigurations]
    ([ProductLineID]);
GO

-- Creating foreign key on [FaxRecipientConfigurationID] in table 'FaxRecipientConfigurationFaxRecipientTypes'
ALTER TABLE [dbo].[FaxRecipientConfigurationFaxRecipientTypes]
ADD CONSTRAINT [FK_FaxRecipientConfigurationFaxRecipientType_FaxRecipientConfiguration]
    FOREIGN KEY ([FaxRecipientConfigurationID])
    REFERENCES [dbo].[FaxRecipientConfigurations]
        ([FaxRecipientConfigurationID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxRecipientConfigurationFaxRecipientType_FaxRecipientConfiguration'
CREATE INDEX [IX_FK_FaxRecipientConfigurationFaxRecipientType_FaxRecipientConfiguration]
ON [dbo].[FaxRecipientConfigurationFaxRecipientTypes]
    ([FaxRecipientConfigurationID]);
GO

-- Creating foreign key on [FaxRecipientConfigurationID] in table 'FaxRecipientConfigurationStates'
ALTER TABLE [dbo].[FaxRecipientConfigurationStates]
ADD CONSTRAINT [FK_FaxRecipientState_FaxRecipientConfiguration]
    FOREIGN KEY ([FaxRecipientConfigurationID])
    REFERENCES [dbo].[FaxRecipientConfigurations]
        ([FaxRecipientConfigurationID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxRecipientState_FaxRecipientConfiguration'
CREATE INDEX [IX_FK_FaxRecipientState_FaxRecipientConfiguration]
ON [dbo].[FaxRecipientConfigurationStates]
    ([FaxRecipientConfigurationID]);
GO

-- Creating foreign key on [FaxRecipientType] in table 'FaxRecipientConfigurationFaxRecipientTypes'
ALTER TABLE [dbo].[FaxRecipientConfigurationFaxRecipientTypes]
ADD CONSTRAINT [FK_FaxRecipientConfigurationFaxRecipientType_LookupElement]
    FOREIGN KEY ([FaxRecipientType])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FaxRecipientConfigurationFaxRecipientType_LookupElement'
CREATE INDEX [IX_FK_FaxRecipientConfigurationFaxRecipientType_LookupElement]
ON [dbo].[FaxRecipientConfigurationFaxRecipientTypes]
    ([FaxRecipientType]);
GO

-- Creating foreign key on [FebrileNeutropeniaID] in table 'FebrileNeutropeniaClinicalValuesRules'
ALTER TABLE [dbo].[FebrileNeutropeniaClinicalValuesRules]
ADD CONSTRAINT [FK_FebrileNeutropeniaClinicalValuesRule_LookupElement]
    FOREIGN KEY ([FebrileNeutropeniaID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FebrileNeutropeniaClinicalValuesRule_LookupElement'
CREATE INDEX [IX_FK_FebrileNeutropeniaClinicalValuesRule_LookupElement]
ON [dbo].[FebrileNeutropeniaClinicalValuesRules]
    ([FebrileNeutropeniaID]);
GO

-- Creating foreign key on [FormularyExceptionID] in table 'FormularyException_AlternativeCode'
ALTER TABLE [dbo].[FormularyException_AlternativeCode]
ADD CONSTRAINT [FK_FormularyException_AlternativeCode_FormularyException]
    FOREIGN KEY ([FormularyExceptionID])
    REFERENCES [dbo].[FormularyExceptions]
        ([FormularyExceptionID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FormularyException_AlternativeCode_FormularyException'
CREATE INDEX [IX_FK_FormularyException_AlternativeCode_FormularyException]
ON [dbo].[FormularyException_AlternativeCode]
    ([FormularyExceptionID]);
GO

-- Creating foreign key on [FormularyExceptionID] in table 'FormularyException_ExceptionType'
ALTER TABLE [dbo].[FormularyException_ExceptionType]
ADD CONSTRAINT [FK_FormularyException_ExceptionType_FormularyException]
    FOREIGN KEY ([FormularyExceptionID])
    REFERENCES [dbo].[FormularyExceptions]
        ([FormularyExceptionID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FormularyException_ExceptionType_FormularyException'
CREATE INDEX [IX_FK_FormularyException_ExceptionType_FormularyException]
ON [dbo].[FormularyException_ExceptionType]
    ([FormularyExceptionID]);
GO

-- Creating foreign key on [ExceptionReasonID] in table 'FormularyExceptions'
ALTER TABLE [dbo].[FormularyExceptions]
ADD CONSTRAINT [FK_FormularyException_LookupElement_ExceptionReason]
    FOREIGN KEY ([ExceptionReasonID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FormularyException_LookupElement_ExceptionReason'
CREATE INDEX [IX_FK_FormularyException_LookupElement_ExceptionReason]
ON [dbo].[FormularyExceptions]
    ([ExceptionReasonID]);
GO

-- Creating foreign key on [ExceptionResolutionID] in table 'FormularyExceptions'
ALTER TABLE [dbo].[FormularyExceptions]
ADD CONSTRAINT [FK_FormularyException_LookupElement_ExceptionResolution]
    FOREIGN KEY ([ExceptionResolutionID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FormularyException_LookupElement_ExceptionResolution'
CREATE INDEX [IX_FK_FormularyException_LookupElement_ExceptionResolution]
ON [dbo].[FormularyExceptions]
    ([ExceptionResolutionID]);
GO

-- Creating foreign key on [ProtocolElementCodeID] in table 'FormularyExceptions'
ALTER TABLE [dbo].[FormularyExceptions]
ADD CONSTRAINT [FK_FormularyException_ProtocolElementCode]
    FOREIGN KEY ([ProtocolElementCodeID])
    REFERENCES [dbo].[ProtocolElementCodes]
        ([ProtocolElementCodeID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FormularyException_ProtocolElementCode'
CREATE INDEX [IX_FK_FormularyException_ProtocolElementCode]
ON [dbo].[FormularyExceptions]
    ([ProtocolElementCodeID]);
GO

-- Creating foreign key on [CodeTypeID] in table 'FormularyException_AlternativeCode'
ALTER TABLE [dbo].[FormularyException_AlternativeCode]
ADD CONSTRAINT [FK_FormularyException_AlternativeCode_LookupElement_CodeType]
    FOREIGN KEY ([CodeTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FormularyException_AlternativeCode_LookupElement_CodeType'
CREATE INDEX [IX_FK_FormularyException_AlternativeCode_LookupElement_CodeType]
ON [dbo].[FormularyException_AlternativeCode]
    ([CodeTypeID]);
GO

-- Creating foreign key on [ExceptionTypeID] in table 'FormularyException_ExceptionType'
ALTER TABLE [dbo].[FormularyException_ExceptionType]
ADD CONSTRAINT [FK_FormularyException_ExceptionType_LookupElement_ExceptionType]
    FOREIGN KEY ([ExceptionTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FormularyException_ExceptionType_LookupElement_ExceptionType'
CREATE INDEX [IX_FK_FormularyException_ExceptionType_LookupElement_ExceptionType]
ON [dbo].[FormularyException_ExceptionType]
    ([ExceptionTypeID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'FtnConfigurations'
ALTER TABLE [dbo].[FtnConfigurations]
ADD CONSTRAINT [FK_FTNConfiguration_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FTNConfiguration_InsuranceProvider'
CREATE INDEX [IX_FK_FTNConfiguration_InsuranceProvider]
ON [dbo].[FtnConfigurations]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [LineOfBusinessID] in table 'FtnConfigurations'
ALTER TABLE [dbo].[FtnConfigurations]
ADD CONSTRAINT [FK_FTNConfiguration_LineOfBusiness]
    FOREIGN KEY ([LineOfBusinessID])
    REFERENCES [dbo].[LineofBusinesses]
        ([LineOfBusinessID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FTNConfiguration_LineOfBusiness'
CREATE INDEX [IX_FK_FTNConfiguration_LineOfBusiness]
ON [dbo].[FtnConfigurations]
    ([LineOfBusinessID]);
GO

-- Creating foreign key on [RuleID] in table 'GrandfatherRules'
ALTER TABLE [dbo].[GrandfatherRules]
ADD CONSTRAINT [FK_GrandfatherRule_Rule]
    FOREIGN KEY ([RuleID])
    REFERENCES [dbo].[Rules]
        ([RuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_GrandfatherRule_Rule'
CREATE INDEX [IX_FK_GrandfatherRule_Rule]
ON [dbo].[GrandfatherRules]
    ([RuleID]);
GO

-- Creating foreign key on [GrandfatherRuleID] in table 'GrandfatherRuleDrugs'
ALTER TABLE [dbo].[GrandfatherRuleDrugs]
ADD CONSTRAINT [FK_GrandfatherRuleDrug_GrandfatherRule]
    FOREIGN KEY ([GrandfatherRuleID])
    REFERENCES [dbo].[GrandfatherRules]
        ([GrandfatherRuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_GrandfatherRuleDrug_GrandfatherRule'
CREATE INDEX [IX_FK_GrandfatherRuleDrug_GrandfatherRule]
ON [dbo].[GrandfatherRuleDrugs]
    ([GrandfatherRuleID]);
GO

-- Creating foreign key on [FrequencyID] in table 'GrandfatherRuleDrugs'
ALTER TABLE [dbo].[GrandfatherRuleDrugs]
ADD CONSTRAINT [FK_GrandfatherRuleDrug_LookupElement_Frequency]
    FOREIGN KEY ([FrequencyID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_GrandfatherRuleDrug_LookupElement_Frequency'
CREATE INDEX [IX_FK_GrandfatherRuleDrug_LookupElement_Frequency]
ON [dbo].[GrandfatherRuleDrugs]
    ([FrequencyID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'HelpfulLinks'
ALTER TABLE [dbo].[HelpfulLinks]
ADD CONSTRAINT [FK_HelpfulLink_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_HelpfulLink_InsuranceProvider'
CREATE INDEX [IX_FK_HelpfulLink_InsuranceProvider]
ON [dbo].[HelpfulLinks]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [Code], [CodeVersion] in table 'PatientICDCodes'
ALTER TABLE [dbo].[PatientICDCodes]
ADD CONSTRAINT [FK_PatientICDCode_ICDCode]
    FOREIGN KEY ([Code], [CodeVersion])
    REFERENCES [dbo].[ICDCodes]
        ([Code], [CodeVersion])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientICDCode_ICDCode'
CREATE INDEX [IX_FK_PatientICDCode_ICDCode]
ON [dbo].[PatientICDCodes]
    ([Code], [CodeVersion]);
GO

-- Creating foreign key on [Code], [CodeVersion] in table 'PatientProtocolAssignment_ProtocolICDCode'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolICDCode]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolICDCode_ICDCode]
    FOREIGN KEY ([Code], [CodeVersion])
    REFERENCES [dbo].[ICDCodes]
        ([Code], [CodeVersion])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolICDCode_ICDCode'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolICDCode_ICDCode]
ON [dbo].[PatientProtocolAssignment_ProtocolICDCode]
    ([Code], [CodeVersion]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'Images'
ALTER TABLE [dbo].[Images]
ADD CONSTRAINT [FK_Image_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Image_InsuranceProvider'
CREATE INDEX [IX_FK_Image_InsuranceProvider]
ON [dbo].[Images]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [ImageID] in table 'NotificationEnclosureImages'
ALTER TABLE [dbo].[NotificationEnclosureImages]
ADD CONSTRAINT [FK_NotificationEnclosureImage_Image]
    FOREIGN KEY ([ImageID])
    REFERENCES [dbo].[Images]
        ([ImageID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_NotificationEnclosureImage_Image'
CREATE INDEX [IX_FK_NotificationEnclosureImage_Image]
ON [dbo].[NotificationEnclosureImages]
    ([ImageID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'InScopeStates'
ALTER TABLE [dbo].[InScopeStates]
ADD CONSTRAINT [FK_InScopeState_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InScopeState_InsuranceProvider'
CREATE INDEX [IX_FK_InScopeState_InsuranceProvider]
ON [dbo].[InScopeStates]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [ProductLineID] in table 'InScopeStates'
ALTER TABLE [dbo].[InScopeStates]
ADD CONSTRAINT [FK_InScopeState_ProductLine]
    FOREIGN KEY ([ProductLineID])
    REFERENCES [dbo].[ProductLines]
        ([ProductLineID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InScopeState_ProductLine'
CREATE INDEX [IX_FK_InScopeState_ProductLine]
ON [dbo].[InScopeStates]
    ([ProductLineID]);
GO

-- Creating foreign key on [StateCode] in table 'InScopeStates'
ALTER TABLE [dbo].[InScopeStates]
ADD CONSTRAINT [FK_InScopeState_State]
    FOREIGN KEY ([StateCode])
    REFERENCES [dbo].[States]
        ([StateCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InScopeState_State'
CREATE INDEX [IX_FK_InScopeState_State]
ON [dbo].[InScopeStates]
    ([StateCode]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'InsuranceProvider_Address'
ALTER TABLE [dbo].[InsuranceProvider_Address]
ADD CONSTRAINT [FK_InsuranceProvider_Address_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProvider_Address_InsuranceProvider'
CREATE INDEX [IX_FK_InsuranceProvider_Address_InsuranceProvider]
ON [dbo].[InsuranceProvider_Address]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [EligibilityPrimarySourceID] in table 'InsuranceProviders'
ALTER TABLE [dbo].[InsuranceProviders]
ADD CONSTRAINT [FK_InsuranceProvider_LookupElement_EligibilityPrimarySource]
    FOREIGN KEY ([EligibilityPrimarySourceID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProvider_LookupElement_EligibilityPrimarySource'
CREATE INDEX [IX_FK_InsuranceProvider_LookupElement_EligibilityPrimarySource]
ON [dbo].[InsuranceProviders]
    ([EligibilityPrimarySourceID]);
GO

-- Creating foreign key on [EligibilitySecondarySourceID] in table 'InsuranceProviders'
ALTER TABLE [dbo].[InsuranceProviders]
ADD CONSTRAINT [FK_InsuranceProvider_LookupElement_EligibilitySecondarySource]
    FOREIGN KEY ([EligibilitySecondarySourceID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProvider_LookupElement_EligibilitySecondarySource'
CREATE INDEX [IX_FK_InsuranceProvider_LookupElement_EligibilitySecondarySource]
ON [dbo].[InsuranceProviders]
    ([EligibilitySecondarySourceID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'InsuranceProvider_LookupElement'
ALTER TABLE [dbo].[InsuranceProvider_LookupElement]
ADD CONSTRAINT [FK_InsuranceProvider_LookupElement_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProvider_LookupElement_InsuranceProvider'
CREATE INDEX [IX_FK_InsuranceProvider_LookupElement_InsuranceProvider]
ON [dbo].[InsuranceProvider_LookupElement]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsurancProviderID] in table 'InsuranceProviderAttributeValues'
ALTER TABLE [dbo].[InsuranceProviderAttributeValues]
ADD CONSTRAINT [FK_InsuranceProviderAttributeValue_InsuranceProvider]
    FOREIGN KEY ([InsurancProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderAttributeValue_InsuranceProvider'
CREATE INDEX [IX_FK_InsuranceProviderAttributeValue_InsuranceProvider]
ON [dbo].[InsuranceProviderAttributeValues]
    ([InsurancProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'InsuranceProviderConfigurations'
ALTER TABLE [dbo].[InsuranceProviderConfigurations]
ADD CONSTRAINT [FK_InsuranceProviderConfiguration_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderConfiguration_InsuranceProvider'
CREATE INDEX [IX_FK_InsuranceProviderConfiguration_InsuranceProvider]
ON [dbo].[InsuranceProviderConfigurations]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'InsuranceProviderContactDetails'
ALTER TABLE [dbo].[InsuranceProviderContactDetails]
ADD CONSTRAINT [FK_InsuranceProviderContactDetail_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderContactDetail_InsuranceProvider'
CREATE INDEX [IX_FK_InsuranceProviderContactDetail_InsuranceProvider]
ON [dbo].[InsuranceProviderContactDetails]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'InsuranceProviderDaylightSavingSettings'
ALTER TABLE [dbo].[InsuranceProviderDaylightSavingSettings]
ADD CONSTRAINT [FK_InsuranceProviderDaylightSavingSetting_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderDaylightSavingSetting_InsuranceProvider'
CREATE INDEX [IX_FK_InsuranceProviderDaylightSavingSetting_InsuranceProvider]
ON [dbo].[InsuranceProviderDaylightSavingSettings]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'InsuranceProviderDrugs'
ALTER TABLE [dbo].[InsuranceProviderDrugs]
ADD CONSTRAINT [FK_InsuranceProviderDrug_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderDrug_InsuranceProvider'
CREATE INDEX [IX_FK_InsuranceProviderDrug_InsuranceProvider]
ON [dbo].[InsuranceProviderDrugs]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'InsuranceProviderDrugConfigurations'
ALTER TABLE [dbo].[InsuranceProviderDrugConfigurations]
ADD CONSTRAINT [FK_InsuranceProviderDrugConfiguration_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderDrugConfiguration_InsuranceProvider'
CREATE INDEX [IX_FK_InsuranceProviderDrugConfiguration_InsuranceProvider]
ON [dbo].[InsuranceProviderDrugConfigurations]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'InsuranceProviderEODFileRecipients'
ALTER TABLE [dbo].[InsuranceProviderEODFileRecipients]
ADD CONSTRAINT [FK_InsuranceProviderEODFileRecipient_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderEODFileRecipient_InsuranceProvider'
CREATE INDEX [IX_FK_InsuranceProviderEODFileRecipient_InsuranceProvider]
ON [dbo].[InsuranceProviderEODFileRecipients]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'InsuranceProviderEODStatusOverrides'
ALTER TABLE [dbo].[InsuranceProviderEODStatusOverrides]
ADD CONSTRAINT [FK_InsuranceProviderEODStatusOverride_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderEODStatusOverride_InsuranceProvider'
CREATE INDEX [IX_FK_InsuranceProviderEODStatusOverride_InsuranceProvider]
ON [dbo].[InsuranceProviderEODStatusOverrides]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'InsuranceProviderFaxTemplates'
ALTER TABLE [dbo].[InsuranceProviderFaxTemplates]
ADD CONSTRAINT [FK_InsuranceProviderFaxTemplate_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderFaxTemplate_InsuranceProvider'
CREATE INDEX [IX_FK_InsuranceProviderFaxTemplate_InsuranceProvider]
ON [dbo].[InsuranceProviderFaxTemplates]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'InsuranceProviderGlobalFaxParameters'
ALTER TABLE [dbo].[InsuranceProviderGlobalFaxParameters]
ADD CONSTRAINT [FK_InsuranceProviderGlobalFaxParameter_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderGlobalFaxParameter_InsuranceProvider'
CREATE INDEX [IX_FK_InsuranceProviderGlobalFaxParameter_InsuranceProvider]
ON [dbo].[InsuranceProviderGlobalFaxParameters]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'InsuranceProviderHomePages'
ALTER TABLE [dbo].[InsuranceProviderHomePages]
ADD CONSTRAINT [FK_InsuranceProviderHomePage_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderHomePage_InsuranceProvider'
CREATE INDEX [IX_FK_InsuranceProviderHomePage_InsuranceProvider]
ON [dbo].[InsuranceProviderHomePages]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'InsuranceProviderSpecialtyCodes'
ALTER TABLE [dbo].[InsuranceProviderSpecialtyCodes]
ADD CONSTRAINT [FK_InsuranceProviderSpecialtyCode_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderSpecialtyCode_InsuranceProvider'
CREATE INDEX [IX_FK_InsuranceProviderSpecialtyCode_InsuranceProvider]
ON [dbo].[InsuranceProviderSpecialtyCodes]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'InsuranceProviderTreatmentTypes'
ALTER TABLE [dbo].[InsuranceProviderTreatmentTypes]
ADD CONSTRAINT [FK_InsuranceProviderTreatmentType_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderTreatmentType_InsuranceProvider'
CREATE INDEX [IX_FK_InsuranceProviderTreatmentType_InsuranceProvider]
ON [dbo].[InsuranceProviderTreatmentTypes]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'LineofBusinesses'
ALTER TABLE [dbo].[LineofBusinesses]
ADD CONSTRAINT [FK_LineofBusiness_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LineofBusiness_InsuranceProvider'
CREATE INDEX [IX_FK_LineofBusiness_InsuranceProvider]
ON [dbo].[LineofBusinesses]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'MailingCutoffConfigurations'
ALTER TABLE [dbo].[MailingCutoffConfigurations]
ADD CONSTRAINT [FK_MailingCutoffConfiguration_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MailingCutoffConfiguration_InsuranceProvider'
CREATE INDEX [IX_FK_MailingCutoffConfiguration_InsuranceProvider]
ON [dbo].[MailingCutoffConfigurations]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [PayerId] in table 'PayerContactDetails'
ALTER TABLE [dbo].[PayerContactDetails]
ADD CONSTRAINT [FK_PayerContactDetail_InsuranceProvider]
    FOREIGN KEY ([PayerId])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerContactDetail_InsuranceProvider'
CREATE INDEX [IX_FK_PayerContactDetail_InsuranceProvider]
ON [dbo].[PayerContactDetails]
    ([PayerId]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'PayerOrganizations'
ALTER TABLE [dbo].[PayerOrganizations]
ADD CONSTRAINT [FK_PayerOrganization_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerOrganization_InsuranceProvider'
CREATE INDEX [IX_FK_PayerOrganization_InsuranceProvider]
ON [dbo].[PayerOrganizations]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'PracticeGroupPayers'
ALTER TABLE [dbo].[PracticeGroupPayers]
ADD CONSTRAINT [FK_PracticeGroupPayer_InsuranceProvider_InsuranceProviderID]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PracticeGroupPayer_InsuranceProvider_InsuranceProviderID'
CREATE INDEX [IX_FK_PracticeGroupPayer_InsuranceProvider_InsuranceProviderID]
ON [dbo].[PracticeGroupPayers]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'ProviderInfoDatas'
ALTER TABLE [dbo].[ProviderInfoDatas]
ADD CONSTRAINT [FK_ProviderInfoData_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProviderInfoData_InsuranceProvider'
CREATE INDEX [IX_FK_ProviderInfoData_InsuranceProvider]
ON [dbo].[ProviderInfoDatas]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'TATConfigurations'
ALTER TABLE [dbo].[TATConfigurations]
ADD CONSTRAINT [FK_TATConfigurations_TATConfigurations]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_TATConfigurations_TATConfigurations'
CREATE INDEX [IX_FK_TATConfigurations_TATConfigurations]
ON [dbo].[TATConfigurations]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'User_MemberAssociation'
ALTER TABLE [dbo].[User_MemberAssociation]
ADD CONSTRAINT [FK_User_MemberAssociation_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_User_MemberAssociation_InsuranceProvider'
CREATE INDEX [IX_FK_User_MemberAssociation_InsuranceProvider]
ON [dbo].[User_MemberAssociation]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'UserAccessLists'
ALTER TABLE [dbo].[UserAccessLists]
ADD CONSTRAINT [FK_UserAccessList_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserAccessList_InsuranceProvider'
CREATE INDEX [IX_FK_UserAccessList_InsuranceProvider]
ON [dbo].[UserAccessLists]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [InsuranceProviderAddressID] in table 'PatientProtocolAssignmentPostDenials'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenials]
ADD CONSTRAINT [FK_PatientProtocolAssignmentPostDenial_InsuranceProvider_Address]
    FOREIGN KEY ([InsuranceProviderAddressID])
    REFERENCES [dbo].[InsuranceProvider_Address]
        ([InsuranceProviderAddressID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentPostDenial_InsuranceProvider_Address'
CREATE INDEX [IX_FK_PatientProtocolAssignmentPostDenial_InsuranceProvider_Address]
ON [dbo].[PatientProtocolAssignmentPostDenials]
    ([InsuranceProviderAddressID]);
GO

-- Creating foreign key on [HealthPlanLocationId] in table 'PatientProtocolAssignmentPostDenialInfoes'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialInfoes]
ADD CONSTRAINT [FK_PatientProtocolAssignmentPostDenialInfo_InsuranceProvider_Address]
    FOREIGN KEY ([HealthPlanLocationId])
    REFERENCES [dbo].[InsuranceProvider_Address]
        ([InsuranceProviderAddressID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentPostDenialInfo_InsuranceProvider_Address'
CREATE INDEX [IX_FK_PatientProtocolAssignmentPostDenialInfo_InsuranceProvider_Address]
ON [dbo].[PatientProtocolAssignmentPostDenialInfoes]
    ([HealthPlanLocationId]);
GO

-- Creating foreign key on [LookupElementID] in table 'InsuranceProvider_LookupElement'
ALTER TABLE [dbo].[InsuranceProvider_LookupElement]
ADD CONSTRAINT [FK_InsuranceProvider_LookupElement_LookupElement]
    FOREIGN KEY ([LookupElementID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProvider_LookupElement_LookupElement'
CREATE INDEX [IX_FK_InsuranceProvider_LookupElement_LookupElement]
ON [dbo].[InsuranceProvider_LookupElement]
    ([LookupElementID]);
GO

-- Creating foreign key on [InsuranceProviderAttributeKeyID] in table 'InsuranceProviderAttributeValues'
ALTER TABLE [dbo].[InsuranceProviderAttributeValues]
ADD CONSTRAINT [FK_InsuranceProviderAttributeValue_InsuranceProviderAttributeKey]
    FOREIGN KEY ([InsuranceProviderAttributeKeyID])
    REFERENCES [dbo].[InsuranceProviderAttributeKeys]
        ([InsuranceProviderAttributeKeyID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderAttributeValue_InsuranceProviderAttributeKey'
CREATE INDEX [IX_FK_InsuranceProviderAttributeValue_InsuranceProviderAttributeKey]
ON [dbo].[InsuranceProviderAttributeValues]
    ([InsuranceProviderAttributeKeyID]);
GO

-- Creating foreign key on [InsuranceProviderDrugConfigurationID] in table 'InsuranceProviderDrugConfiguration_LOB'
ALTER TABLE [dbo].[InsuranceProviderDrugConfiguration_LOB]
ADD CONSTRAINT [FK_InsuranceProviderDrugConfiguration_LOB_InsuranceProviderDrugConfiguration]
    FOREIGN KEY ([InsuranceProviderDrugConfigurationID])
    REFERENCES [dbo].[InsuranceProviderDrugConfigurations]
        ([InsuranceProviderDrugConfigurationID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderDrugConfiguration_LOB_InsuranceProviderDrugConfiguration'
CREATE INDEX [IX_FK_InsuranceProviderDrugConfiguration_LOB_InsuranceProviderDrugConfiguration]
ON [dbo].[InsuranceProviderDrugConfiguration_LOB]
    ([InsuranceProviderDrugConfigurationID]);
GO

-- Creating foreign key on [InsuranceProviderDrugConfigurationID] in table 'InsuranceProviderDrugConfiguration_Stage'
ALTER TABLE [dbo].[InsuranceProviderDrugConfiguration_Stage]
ADD CONSTRAINT [FK_InsuranceProviderDrugConfiguration_Stage_InsuranceProviderDrugConfiguration]
    FOREIGN KEY ([InsuranceProviderDrugConfigurationID])
    REFERENCES [dbo].[InsuranceProviderDrugConfigurations]
        ([InsuranceProviderDrugConfigurationID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderDrugConfiguration_Stage_InsuranceProviderDrugConfiguration'
CREATE INDEX [IX_FK_InsuranceProviderDrugConfiguration_Stage_InsuranceProviderDrugConfiguration]
ON [dbo].[InsuranceProviderDrugConfiguration_Stage]
    ([InsuranceProviderDrugConfigurationID]);
GO

-- Creating foreign key on [LineOfBusinessID] in table 'InsuranceProviderDrugConfiguration_LOB'
ALTER TABLE [dbo].[InsuranceProviderDrugConfiguration_LOB]
ADD CONSTRAINT [FK_InsuranceProviderDrugConfiguration_LOB_LineofBusiness]
    FOREIGN KEY ([LineOfBusinessID])
    REFERENCES [dbo].[LineofBusinesses]
        ([LineOfBusinessID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderDrugConfiguration_LOB_LineofBusiness'
CREATE INDEX [IX_FK_InsuranceProviderDrugConfiguration_LOB_LineofBusiness]
ON [dbo].[InsuranceProviderDrugConfiguration_LOB]
    ([LineOfBusinessID]);
GO

-- Creating foreign key on [StageID] in table 'InsuranceProviderDrugConfiguration_Stage'
ALTER TABLE [dbo].[InsuranceProviderDrugConfiguration_Stage]
ADD CONSTRAINT [FK_InsuranceProviderDrugConfiguration_Stage_LookupElement]
    FOREIGN KEY ([StageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderDrugConfiguration_Stage_LookupElement'
CREATE INDEX [IX_FK_InsuranceProviderDrugConfiguration_Stage_LookupElement]
ON [dbo].[InsuranceProviderDrugConfiguration_Stage]
    ([StageID]);
GO

-- Creating foreign key on [LineOfBusinessID] in table 'InsuranceProviderEODStatusOverrides'
ALTER TABLE [dbo].[InsuranceProviderEODStatusOverrides]
ADD CONSTRAINT [FK_InsuranceProviderEODStatusOverride_LineOfBusiness]
    FOREIGN KEY ([LineOfBusinessID])
    REFERENCES [dbo].[LineofBusinesses]
        ([LineOfBusinessID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderEODStatusOverride_LineOfBusiness'
CREATE INDEX [IX_FK_InsuranceProviderEODStatusOverride_LineOfBusiness]
ON [dbo].[InsuranceProviderEODStatusOverrides]
    ([LineOfBusinessID]);
GO

-- Creating foreign key on [ProtocolStatusID] in table 'InsuranceProviderEODStatusOverrides'
ALTER TABLE [dbo].[InsuranceProviderEODStatusOverrides]
ADD CONSTRAINT [FK_InsuranceProviderEODStatusOverride_LookupElement_ProtocolStatus]
    FOREIGN KEY ([ProtocolStatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderEODStatusOverride_LookupElement_ProtocolStatus'
CREATE INDEX [IX_FK_InsuranceProviderEODStatusOverride_LookupElement_ProtocolStatus]
ON [dbo].[InsuranceProviderEODStatusOverrides]
    ([ProtocolStatusID]);
GO

-- Creating foreign key on [StatusOverrideTypeID] in table 'InsuranceProviderEODStatusOverrides'
ALTER TABLE [dbo].[InsuranceProviderEODStatusOverrides]
ADD CONSTRAINT [FK_InsuranceProviderEODStatusOverride_StatusOverrideType]
    FOREIGN KEY ([StatusOverrideTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderEODStatusOverride_StatusOverrideType'
CREATE INDEX [IX_FK_InsuranceProviderEODStatusOverride_StatusOverrideType]
ON [dbo].[InsuranceProviderEODStatusOverrides]
    ([StatusOverrideTypeID]);
GO

-- Creating foreign key on [BenefitTypeID] in table 'InsuranceProviderFaxTemplates'
ALTER TABLE [dbo].[InsuranceProviderFaxTemplates]
ADD CONSTRAINT [FK_InsuranceProviderFaxTemplate_LookupElement_BenefitType]
    FOREIGN KEY ([BenefitTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderFaxTemplate_LookupElement_BenefitType'
CREATE INDEX [IX_FK_InsuranceProviderFaxTemplate_LookupElement_BenefitType]
ON [dbo].[InsuranceProviderFaxTemplates]
    ([BenefitTypeID]);
GO

-- Creating foreign key on [FaxTemplateType] in table 'InsuranceProviderFaxTemplates'
ALTER TABLE [dbo].[InsuranceProviderFaxTemplates]
ADD CONSTRAINT [FK_InsuranceProviderFaxTemplate_LookupElement_FaxTemplateType]
    FOREIGN KEY ([FaxTemplateType])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderFaxTemplate_LookupElement_FaxTemplateType'
CREATE INDEX [IX_FK_InsuranceProviderFaxTemplate_LookupElement_FaxTemplateType]
ON [dbo].[InsuranceProviderFaxTemplates]
    ([FaxTemplateType]);
GO

-- Creating foreign key on [InsuranceProviderFaxTemplateID] in table 'InsuranceProviderFaxTemplate_ProductLine'
ALTER TABLE [dbo].[InsuranceProviderFaxTemplate_ProductLine]
ADD CONSTRAINT [FK_InsuranceProviderFaxTemplate_ProductLine_InsuranceProviderFaxTemplate]
    FOREIGN KEY ([InsuranceProviderFaxTemplateID])
    REFERENCES [dbo].[InsuranceProviderFaxTemplates]
        ([InsuranceProviderFaxTemplateID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderFaxTemplate_ProductLine_InsuranceProviderFaxTemplate'
CREATE INDEX [IX_FK_InsuranceProviderFaxTemplate_ProductLine_InsuranceProviderFaxTemplate]
ON [dbo].[InsuranceProviderFaxTemplate_ProductLine]
    ([InsuranceProviderFaxTemplateID]);
GO

-- Creating foreign key on [StateCode] in table 'InsuranceProviderFaxTemplates'
ALTER TABLE [dbo].[InsuranceProviderFaxTemplates]
ADD CONSTRAINT [FK_InsuranceProviderFaxTemplate_State]
    FOREIGN KEY ([StateCode])
    REFERENCES [dbo].[States]
        ([StateCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderFaxTemplate_State'
CREATE INDEX [IX_FK_InsuranceProviderFaxTemplate_State]
ON [dbo].[InsuranceProviderFaxTemplates]
    ([StateCode]);
GO

-- Creating foreign key on [ProductLineID] in table 'InsuranceProviderFaxTemplate_ProductLine'
ALTER TABLE [dbo].[InsuranceProviderFaxTemplate_ProductLine]
ADD CONSTRAINT [FK_InsuranceProviderFaxTemplate_ProductLine_ProductLine]
    FOREIGN KEY ([ProductLineID])
    REFERENCES [dbo].[ProductLines]
        ([ProductLineID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderFaxTemplate_ProductLine_ProductLine'
CREATE INDEX [IX_FK_InsuranceProviderFaxTemplate_ProductLine_ProductLine]
ON [dbo].[InsuranceProviderFaxTemplate_ProductLine]
    ([ProductLineID]);
GO

-- Creating foreign key on [BenefitTypeID] in table 'InsuranceProviderFaxTemplate_Rule'
ALTER TABLE [dbo].[InsuranceProviderFaxTemplate_Rule]
ADD CONSTRAINT [FK_InsuranceProviderFaxTemplate_Rule_LookupElement_BenefitType]
    FOREIGN KEY ([BenefitTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderFaxTemplate_Rule_LookupElement_BenefitType'
CREATE INDEX [IX_FK_InsuranceProviderFaxTemplate_Rule_LookupElement_BenefitType]
ON [dbo].[InsuranceProviderFaxTemplate_Rule]
    ([BenefitTypeID]);
GO

-- Creating foreign key on [FaxTemplateID] in table 'InsuranceProviderFaxTemplate_Rule'
ALTER TABLE [dbo].[InsuranceProviderFaxTemplate_Rule]
ADD CONSTRAINT [FK_InsuranceProviderFaxTemplate_Rule_LookupElement_FaxTemplateType]
    FOREIGN KEY ([FaxTemplateID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderFaxTemplate_Rule_LookupElement_FaxTemplateType'
CREATE INDEX [IX_FK_InsuranceProviderFaxTemplate_Rule_LookupElement_FaxTemplateType]
ON [dbo].[InsuranceProviderFaxTemplate_Rule]
    ([FaxTemplateID]);
GO

-- Creating foreign key on [GlobalFaxParameterID] in table 'InsuranceProviderGlobalFaxParameters'
ALTER TABLE [dbo].[InsuranceProviderGlobalFaxParameters]
ADD CONSTRAINT [FK_InsuranceProviderGlobalFaxParameter_LookupElement]
    FOREIGN KEY ([GlobalFaxParameterID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderGlobalFaxParameter_LookupElement'
CREATE INDEX [IX_FK_InsuranceProviderGlobalFaxParameter_LookupElement]
ON [dbo].[InsuranceProviderGlobalFaxParameters]
    ([GlobalFaxParameterID]);
GO

-- Creating foreign key on [TreatmentTypeID] in table 'InsuranceProviderTreatmentTypes'
ALTER TABLE [dbo].[InsuranceProviderTreatmentTypes]
ADD CONSTRAINT [FK_InsuranceProviderTreatmentType_LookupElement]
    FOREIGN KEY ([TreatmentTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_InsuranceProviderTreatmentType_LookupElement'
CREATE INDEX [IX_FK_InsuranceProviderTreatmentType_LookupElement]
ON [dbo].[InsuranceProviderTreatmentTypes]
    ([TreatmentTypeID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'LabResults'
ALTER TABLE [dbo].[LabResults]
ADD CONSTRAINT [FK_LabResult_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LabResult_PatientProtocolAssignment'
CREATE INDEX [IX_FK_LabResult_PatientProtocolAssignment]
ON [dbo].[LabResults]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [MajorLineOfBusinessID] in table 'LineofBusinesses'
ALTER TABLE [dbo].[LineofBusinesses]
ADD CONSTRAINT [FK_LineofBusiness_LookupElement_MajorLineOfBusiness]
    FOREIGN KEY ([MajorLineOfBusinessID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LineofBusiness_LookupElement_MajorLineOfBusiness'
CREATE INDEX [IX_FK_LineofBusiness_LookupElement_MajorLineOfBusiness]
ON [dbo].[LineofBusinesses]
    ([MajorLineOfBusinessID]);
GO

-- Creating foreign key on [MedicalBenefitDrugsSettingID] in table 'LineofBusinesses'
ALTER TABLE [dbo].[LineofBusinesses]
ADD CONSTRAINT [FK_LineofBusiness_LookupElement_MedicalBenefitDrugsSetting]
    FOREIGN KEY ([MedicalBenefitDrugsSettingID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LineofBusiness_LookupElement_MedicalBenefitDrugsSetting'
CREATE INDEX [IX_FK_LineofBusiness_LookupElement_MedicalBenefitDrugsSetting]
ON [dbo].[LineofBusinesses]
    ([MedicalBenefitDrugsSettingID]);
GO

-- Creating foreign key on [PharmacyBenefitDrugsSettingID] in table 'LineofBusinesses'
ALTER TABLE [dbo].[LineofBusinesses]
ADD CONSTRAINT [FK_LineofBusiness_LookupElement_PharmacyBenefitDrugsSetting]
    FOREIGN KEY ([PharmacyBenefitDrugsSettingID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LineofBusiness_LookupElement_PharmacyBenefitDrugsSetting'
CREATE INDEX [IX_FK_LineofBusiness_LookupElement_PharmacyBenefitDrugsSetting]
ON [dbo].[LineofBusinesses]
    ([PharmacyBenefitDrugsSettingID]);
GO

-- Creating foreign key on [ProcedureUnitsReplacementApproachID] in table 'LineofBusinesses'
ALTER TABLE [dbo].[LineofBusinesses]
ADD CONSTRAINT [FK_LineOfBusiness_LookupElement_ProcedureUnitsReplacementApproach]
    FOREIGN KEY ([ProcedureUnitsReplacementApproachID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LineOfBusiness_LookupElement_ProcedureUnitsReplacementApproach'
CREATE INDEX [IX_FK_LineOfBusiness_LookupElement_ProcedureUnitsReplacementApproach]
ON [dbo].[LineofBusinesses]
    ([ProcedureUnitsReplacementApproachID]);
GO

-- Creating foreign key on [LineOfBusinessID] in table 'MailingCutoffConfigurations'
ALTER TABLE [dbo].[MailingCutoffConfigurations]
ADD CONSTRAINT [FK_MailingCutoffConfiguration_LineOfBusiness]
    FOREIGN KEY ([LineOfBusinessID])
    REFERENCES [dbo].[LineofBusinesses]
        ([LineOfBusinessID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MailingCutoffConfiguration_LineOfBusiness'
CREATE INDEX [IX_FK_MailingCutoffConfiguration_LineOfBusiness]
ON [dbo].[MailingCutoffConfigurations]
    ([LineOfBusinessID]);
GO

-- Creating foreign key on [LineOfBusinessID] in table 'PostDenialConfigurations'
ALTER TABLE [dbo].[PostDenialConfigurations]
ADD CONSTRAINT [FK_PostDenialConfiguration_LineOfBusiness]
    FOREIGN KEY ([LineOfBusinessID])
    REFERENCES [dbo].[LineofBusinesses]
        ([LineOfBusinessID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PostDenialConfiguration_LineOfBusiness'
CREATE INDEX [IX_FK_PostDenialConfiguration_LineOfBusiness]
ON [dbo].[PostDenialConfigurations]
    ([LineOfBusinessID]);
GO

-- Creating foreign key on [LineOfBusinessID] in table 'ProductLines'
ALTER TABLE [dbo].[ProductLines]
ADD CONSTRAINT [FK_ProductLine_LineofBusiness]
    FOREIGN KEY ([LineOfBusinessID])
    REFERENCES [dbo].[LineofBusinesses]
        ([LineOfBusinessID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProductLine_LineofBusiness'
CREATE INDEX [IX_FK_ProductLine_LineofBusiness]
ON [dbo].[ProductLines]
    ([LineOfBusinessID]);
GO

-- Creating foreign key on [LineOfBusinessID] in table 'TATConfigurations'
ALTER TABLE [dbo].[TATConfigurations]
ADD CONSTRAINT [FK_TATConfigurations_LineofBusiness]
    FOREIGN KEY ([LineOfBusinessID])
    REFERENCES [dbo].[LineofBusinesses]
        ([LineOfBusinessID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_TATConfigurations_LineofBusiness'
CREATE INDEX [IX_FK_TATConfigurations_LineofBusiness]
ON [dbo].[TATConfigurations]
    ([LineOfBusinessID]);
GO

-- Creating foreign key on [ParentLookupName] in table 'Lookups'
ALTER TABLE [dbo].[Lookups]
ADD CONSTRAINT [FK_Lookup_LookupName_ParentLookupName]
    FOREIGN KEY ([ParentLookupName])
    REFERENCES [dbo].[Lookups]
        ([LookupName])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Lookup_LookupName_ParentLookupName'
CREATE INDEX [IX_FK_Lookup_LookupName_ParentLookupName]
ON [dbo].[Lookups]
    ([ParentLookupName]);
GO

-- Creating foreign key on [LookupName] in table 'LookupElements'
ALTER TABLE [dbo].[LookupElements]
ADD CONSTRAINT [FK_LookupElement_Lookup]
    FOREIGN KEY ([LookupName])
    REFERENCES [dbo].[Lookups]
        ([LookupName])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LookupElement_Lookup'
CREATE INDEX [IX_FK_LookupElement_Lookup]
ON [dbo].[LookupElements]
    ([LookupName]);
GO

-- Creating foreign key on [PerformanceStatusID] in table 'PatientProtocolAssignment_ProtocolDiagnosis'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDiagnosis]
ADD CONSTRAINT [FK__PatientProtocolAssignment_ProtocolDiagnosis__LookupElement__PerformanceStatus]
    FOREIGN KEY ([PerformanceStatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK__PatientProtocolAssignment_ProtocolDiagnosis__LookupElement__PerformanceStatus'
CREATE INDEX [IX_FK__PatientProtocolAssignment_ProtocolDiagnosis__LookupElement__PerformanceStatus]
ON [dbo].[PatientProtocolAssignment_ProtocolDiagnosis]
    ([PerformanceStatusID]);
GO

-- Creating foreign key on [ChangeReasonID] in table 'PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_ChangeReasonID_LookupElementID]
    FOREIGN KEY ([ChangeReasonID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ChangeReasonID_LookupElementID'
CREATE INDEX [IX_FK_ChangeReasonID_LookupElementID]
ON [dbo].[PatientProtocolAssignment_Protocol]
    ([ChangeReasonID]);
GO

-- Creating foreign key on [ParentLookupElementID] in table 'LookupElements'
ALTER TABLE [dbo].[LookupElements]
ADD CONSTRAINT [FK_LookupElement_LookupElementID_ParentLookupElementID]
    FOREIGN KEY ([ParentLookupElementID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LookupElement_LookupElementID_ParentLookupElementID'
CREATE INDEX [IX_FK_LookupElement_LookupElementID_ParentLookupElementID]
ON [dbo].[LookupElements]
    ([ParentLookupElementID]);
GO

-- Creating foreign key on [LookupElementID] in table 'LookupElement_SecurityGroup'
ALTER TABLE [dbo].[LookupElement_SecurityGroup]
ADD CONSTRAINT [FK_LookupElement_SecurityGroup_LookupElement]
    FOREIGN KEY ([LookupElementID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LookupElement_SecurityGroup_LookupElement'
CREATE INDEX [IX_FK_LookupElement_SecurityGroup_LookupElement]
ON [dbo].[LookupElement_SecurityGroup]
    ([LookupElementID]);
GO

-- Creating foreign key on [TreatmentTypeID] in table 'Protocols'
ALTER TABLE [dbo].[Protocols]
ADD CONSTRAINT [FK_LookupElementID_Protocol_TreatmentTypeID]
    FOREIGN KEY ([TreatmentTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LookupElementID_Protocol_TreatmentTypeID'
CREATE INDEX [IX_FK_LookupElementID_Protocol_TreatmentTypeID]
ON [dbo].[Protocols]
    ([TreatmentTypeID]);
GO

-- Creating foreign key on [ParentLookupElementID] in table 'LookupElementMappings'
ALTER TABLE [dbo].[LookupElementMappings]
ADD CONSTRAINT [FK_LookupElementMapping_LookupElement]
    FOREIGN KEY ([ParentLookupElementID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LookupElementMapping_LookupElement'
CREATE INDEX [IX_FK_LookupElementMapping_LookupElement]
ON [dbo].[LookupElementMappings]
    ([ParentLookupElementID]);
GO

-- Creating foreign key on [ChildLookupElementID] in table 'LookupElementMappings'
ALTER TABLE [dbo].[LookupElementMappings]
ADD CONSTRAINT [FK_LookupElementMapping_LookupElement1]
    FOREIGN KEY ([ChildLookupElementID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LookupElementMapping_LookupElement1'
CREATE INDEX [IX_FK_LookupElementMapping_LookupElement1]
ON [dbo].[LookupElementMappings]
    ([ChildLookupElementID]);
GO

-- Creating foreign key on [MailStatusID] in table 'MailArchiveLogs'
ALTER TABLE [dbo].[MailArchiveLogs]
ADD CONSTRAINT [FK_MailArchive_LookupElement_MailStatus]
    FOREIGN KEY ([MailStatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MailArchive_LookupElement_MailStatus'
CREATE INDEX [IX_FK_MailArchive_LookupElement_MailStatus]
ON [dbo].[MailArchiveLogs]
    ([MailStatusID]);
GO

-- Creating foreign key on [MailingOptionID] in table 'MailArchiveTrackings'
ALTER TABLE [dbo].[MailArchiveTrackings]
ADD CONSTRAINT [FK_MailingOptionID_LookupElement_MailingOptionID]
    FOREIGN KEY ([MailingOptionID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MailingOptionID_LookupElement_MailingOptionID'
CREATE INDEX [IX_FK_MailingOptionID_LookupElement_MailingOptionID]
ON [dbo].[MailArchiveTrackings]
    ([MailingOptionID]);
GO

-- Creating foreign key on [MailingPriorityID] in table 'MailArchiveTrackings'
ALTER TABLE [dbo].[MailArchiveTrackings]
ADD CONSTRAINT [FK_MailingPriorityID_LookupElement_MailingPriorityID]
    FOREIGN KEY ([MailingPriorityID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MailingPriorityID_LookupElement_MailingPriorityID'
CREATE INDEX [IX_FK_MailingPriorityID_LookupElement_MailingPriorityID]
ON [dbo].[MailArchiveTrackings]
    ([MailingPriorityID]);
GO

-- Creating foreign key on [StatusID] in table 'MemberContactLogs'
ALTER TABLE [dbo].[MemberContactLogs]
ADD CONSTRAINT [FK_MemberContactLog_LookupElement_CallStatusType]
    FOREIGN KEY ([StatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MemberContactLog_LookupElement_CallStatusType'
CREATE INDEX [IX_FK_MemberContactLog_LookupElement_CallStatusType]
ON [dbo].[MemberContactLogs]
    ([StatusID]);
GO

-- Creating foreign key on [FaxParamMetastaticSiteID] in table 'MetastaticSites'
ALTER TABLE [dbo].[MetastaticSites]
ADD CONSTRAINT [FK_MetastaticSite_LookupElement]
    FOREIGN KEY ([FaxParamMetastaticSiteID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MetastaticSite_LookupElement'
CREATE INDEX [IX_FK_MetastaticSite_LookupElement]
ON [dbo].[MetastaticSites]
    ([FaxParamMetastaticSiteID]);
GO

-- Creating foreign key on [PatientSourceID] in table 'Patients'
ALTER TABLE [dbo].[Patients]
ADD CONSTRAINT [FK_Patient_LookupElement_PatientSource]
    FOREIGN KEY ([PatientSourceID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Patient_LookupElement_PatientSource'
CREATE INDEX [IX_FK_Patient_LookupElement_PatientSource]
ON [dbo].[Patients]
    ([PatientSourceID]);
GO

-- Creating foreign key on [StageID] in table 'PatientAssessments'
ALTER TABLE [dbo].[PatientAssessments]
ADD CONSTRAINT [FK_PatientAssessment_LookupElement_Stage]
    FOREIGN KEY ([StageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientAssessment_LookupElement_Stage'
CREATE INDEX [IX_FK_PatientAssessment_LookupElement_Stage]
ON [dbo].[PatientAssessments]
    ([StageID]);
GO

-- Creating foreign key on [StageID] in table 'PatientDiagnosis'
ALTER TABLE [dbo].[PatientDiagnosis]
ADD CONSTRAINT [FK_PatientDiagnosis_LookupElement_DiagnosisStage]
    FOREIGN KEY ([StageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientDiagnosis_LookupElement_DiagnosisStage'
CREATE INDEX [IX_FK_PatientDiagnosis_LookupElement_DiagnosisStage]
ON [dbo].[PatientDiagnosis]
    ([StageID]);
GO

-- Creating foreign key on [PerformanceStatusID] in table 'PatientDiagnosis'
ALTER TABLE [dbo].[PatientDiagnosis]
ADD CONSTRAINT [FK_PatientDiagnosis_LookupElement_PerformanceStatus]
    FOREIGN KEY ([PerformanceStatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientDiagnosis_LookupElement_PerformanceStatus'
CREATE INDEX [IX_FK_PatientDiagnosis_LookupElement_PerformanceStatus]
ON [dbo].[PatientDiagnosis]
    ([PerformanceStatusID]);
GO

-- Creating foreign key on [ProtocolStatusID] in table 'PatientProtocolAssignmentHistories'
ALTER TABLE [dbo].[PatientProtocolAssignmentHistories]
ADD CONSTRAINT [FK_PatientProtocolAssignment_History_LookupElement_ProtocolStatusID]
    FOREIGN KEY ([ProtocolStatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_History_LookupElement_ProtocolStatusID'
CREATE INDEX [IX_FK_PatientProtocolAssignment_History_LookupElement_ProtocolStatusID]
ON [dbo].[PatientProtocolAssignmentHistories]
    ([ProtocolStatusID]);
GO

-- Creating foreign key on [TreatmentTypeID] in table 'PatientProtocolAssignments'
ALTER TABLE [dbo].[PatientProtocolAssignments]
ADD CONSTRAINT [FK_PatientProtocolAssignment_LookupElement]
    FOREIGN KEY ([TreatmentTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_LookupElement'
CREATE INDEX [IX_FK_PatientProtocolAssignment_LookupElement]
ON [dbo].[PatientProtocolAssignments]
    ([TreatmentTypeID]);
GO

-- Creating foreign key on [BoundaryCaseTypeID] in table 'PatientProtocolAssignments'
ALTER TABLE [dbo].[PatientProtocolAssignments]
ADD CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_BoundaryCaseTypeId]
    FOREIGN KEY ([BoundaryCaseTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_LookupElement_BoundaryCaseTypeId'
CREATE INDEX [IX_FK_PatientProtocolAssignment_LookupElement_BoundaryCaseTypeId]
ON [dbo].[PatientProtocolAssignments]
    ([BoundaryCaseTypeID]);
GO

-- Creating foreign key on [LegacyStatusID] in table 'PatientProtocolAssignments'
ALTER TABLE [dbo].[PatientProtocolAssignments]
ADD CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_LegacyStatusId]
    FOREIGN KEY ([LegacyStatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_LookupElement_LegacyStatusId'
CREATE INDEX [IX_FK_PatientProtocolAssignment_LookupElement_LegacyStatusId]
ON [dbo].[PatientProtocolAssignments]
    ([LegacyStatusID]);
GO

-- Creating foreign key on [LineOfTherapyID] in table 'PatientProtocolAssignments'
ALTER TABLE [dbo].[PatientProtocolAssignments]
ADD CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_LineOfTherapyID]
    FOREIGN KEY ([LineOfTherapyID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_LookupElement_LineOfTherapyID'
CREATE INDEX [IX_FK_PatientProtocolAssignment_LookupElement_LineOfTherapyID]
ON [dbo].[PatientProtocolAssignments]
    ([LineOfTherapyID]);
GO

-- Creating foreign key on [MedicationsOrderingMethodID] in table 'PatientProtocolAssignments'
ALTER TABLE [dbo].[PatientProtocolAssignments]
ADD CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_MedicationsReceivingMethodId]
    FOREIGN KEY ([MedicationsOrderingMethodID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_LookupElement_MedicationsReceivingMethodId'
CREATE INDEX [IX_FK_PatientProtocolAssignment_LookupElement_MedicationsReceivingMethodId]
ON [dbo].[PatientProtocolAssignments]
    ([MedicationsOrderingMethodID]);
GO

-- Creating foreign key on [ProtocolAssignmentOriginID] in table 'PatientProtocolAssignments'
ALTER TABLE [dbo].[PatientProtocolAssignments]
ADD CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_ProtocolAssignmentOriginId]
    FOREIGN KEY ([ProtocolAssignmentOriginID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_LookupElement_ProtocolAssignmentOriginId'
CREATE INDEX [IX_FK_PatientProtocolAssignment_LookupElement_ProtocolAssignmentOriginId]
ON [dbo].[PatientProtocolAssignments]
    ([ProtocolAssignmentOriginID]);
GO

-- Creating foreign key on [ProtocolAssignmentSourceID] in table 'PatientProtocolAssignments'
ALTER TABLE [dbo].[PatientProtocolAssignments]
ADD CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_ProtocolAssignmentSourceId]
    FOREIGN KEY ([ProtocolAssignmentSourceID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_LookupElement_ProtocolAssignmentSourceId'
CREATE INDEX [IX_FK_PatientProtocolAssignment_LookupElement_ProtocolAssignmentSourceId]
ON [dbo].[PatientProtocolAssignments]
    ([ProtocolAssignmentSourceID]);
GO

-- Creating foreign key on [ProtocolAssignmentTypeID] in table 'PatientProtocolAssignments'
ALTER TABLE [dbo].[PatientProtocolAssignments]
ADD CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_ProtocolAssignmentTypeId]
    FOREIGN KEY ([ProtocolAssignmentTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_LookupElement_ProtocolAssignmentTypeId'
CREATE INDEX [IX_FK_PatientProtocolAssignment_LookupElement_ProtocolAssignmentTypeId]
ON [dbo].[PatientProtocolAssignments]
    ([ProtocolAssignmentTypeID]);
GO

-- Creating foreign key on [ReviewStageID] in table 'PatientProtocolAssignments'
ALTER TABLE [dbo].[PatientProtocolAssignments]
ADD CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_ReviewStageId]
    FOREIGN KEY ([ReviewStageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_LookupElement_ReviewStageId'
CREATE INDEX [IX_FK_PatientProtocolAssignment_LookupElement_ReviewStageId]
ON [dbo].[PatientProtocolAssignments]
    ([ReviewStageID]);
GO

-- Creating foreign key on [SpecialtyPharmacyID] in table 'PatientProtocolAssignments'
ALTER TABLE [dbo].[PatientProtocolAssignments]
ADD CONSTRAINT [FK_PatientProtocolAssignment_LookupElement_SpecialtyPharmacyId]
    FOREIGN KEY ([SpecialtyPharmacyID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_LookupElement_SpecialtyPharmacyId'
CREATE INDEX [IX_FK_PatientProtocolAssignment_LookupElement_SpecialtyPharmacyId]
ON [dbo].[PatientProtocolAssignments]
    ([SpecialtyPharmacyID]);
GO

-- Creating foreign key on [ExternalReviewContactID] in table 'PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_LookupElement_ExternalReviewer]
    FOREIGN KEY ([ExternalReviewContactID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_LookupElement_ExternalReviewer'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_LookupElement_ExternalReviewer]
ON [dbo].[PatientProtocolAssignment_Protocol]
    ([ExternalReviewContactID]);
GO

-- Creating foreign key on [InternalReviewContactID] in table 'PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_LookupElement_InternalReviewer]
    FOREIGN KEY ([InternalReviewContactID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_LookupElement_InternalReviewer'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_LookupElement_InternalReviewer]
ON [dbo].[PatientProtocolAssignment_Protocol]
    ([InternalReviewContactID]);
GO

-- Creating foreign key on [LineOfTherapyID] in table 'PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_LookupElement_LineOfTherapyID]
    FOREIGN KEY ([LineOfTherapyID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_LookupElement_LineOfTherapyID'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_LookupElement_LineOfTherapyID]
ON [dbo].[PatientProtocolAssignment_Protocol]
    ([LineOfTherapyID]);
GO

-- Creating foreign key on [ProtocolTypeID] in table 'PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_LookupElement_ProtocolType]
    FOREIGN KEY ([ProtocolTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_LookupElement_ProtocolType'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_LookupElement_ProtocolType]
ON [dbo].[PatientProtocolAssignment_Protocol]
    ([ProtocolTypeID]);
GO

-- Creating foreign key on [RadiotherapyTechniqueID] in table 'PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_LookupElement_RadiotherapyTechnique]
    FOREIGN KEY ([RadiotherapyTechniqueID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_LookupElement_RadiotherapyTechnique'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_LookupElement_RadiotherapyTechnique]
ON [dbo].[PatientProtocolAssignment_Protocol]
    ([RadiotherapyTechniqueID]);
GO

-- Creating foreign key on [TreatmentIntentID] in table 'PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_LookupElement_TreatmentIntentID]
    FOREIGN KEY ([TreatmentIntentID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_LookupElement_TreatmentIntentID'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_LookupElement_TreatmentIntentID]
ON [dbo].[PatientProtocolAssignment_Protocol]
    ([TreatmentIntentID]);
GO

-- Creating foreign key on [QuantityModifyReasonID] in table 'PatientProtocolAssignment_ProtocolCPTCodeXRT'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_LookupElement_QuantityModifyReasonID]
    FOREIGN KEY ([QuantityModifyReasonID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_LookupElement_QuantityModifyReasonID'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_LookupElement_QuantityModifyReasonID]
ON [dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT]
    ([QuantityModifyReasonID]);
GO

-- Creating foreign key on [TypeId] in table 'PatientProtocolAssignment_ProtocolCPTCodeXRT'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_LookupElement_Type]
    FOREIGN KEY ([TypeId])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_LookupElement_Type'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_LookupElement_Type]
ON [dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT]
    ([TypeId]);
GO

-- Creating foreign key on [StageID] in table 'PatientProtocolAssignment_ProtocolDiagnosis'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDiagnosis]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDiagnosis_LookupElement_StageId]
    FOREIGN KEY ([StageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolDiagnosis_LookupElement_StageId'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolDiagnosis_LookupElement_StageId]
ON [dbo].[PatientProtocolAssignment_ProtocolDiagnosis]
    ([StageID]);
GO

-- Creating foreign key on [AdministrationMethodID] in table 'PatientProtocolAssignment_ProtocolDosing'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_AdministrationMethod]
    FOREIGN KEY ([AdministrationMethodID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_AdministrationMethod'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_AdministrationMethod]
ON [dbo].[PatientProtocolAssignment_ProtocolDosing]
    ([AdministrationMethodID]);
GO

-- Creating foreign key on [BillingUnitQuantityUnitID] in table 'PatientProtocolAssignment_ProtocolDosing'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_BillingUnitQuantityUnit]
    FOREIGN KEY ([BillingUnitQuantityUnitID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_BillingUnitQuantityUnit'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_BillingUnitQuantityUnit]
ON [dbo].[PatientProtocolAssignment_ProtocolDosing]
    ([BillingUnitQuantityUnitID]);
GO

-- Creating foreign key on [DoseUnitID] in table 'PatientProtocolAssignment_ProtocolDosing'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_DoseUnit]
    FOREIGN KEY ([DoseUnitID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_DoseUnit'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_DoseUnit]
ON [dbo].[PatientProtocolAssignment_ProtocolDosing]
    ([DoseUnitID]);
GO

-- Creating foreign key on [FrequencyID] in table 'PatientProtocolAssignment_ProtocolDosing'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_Frequency]
    FOREIGN KEY ([FrequencyID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_Frequency'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_Frequency]
ON [dbo].[PatientProtocolAssignment_ProtocolDosing]
    ([FrequencyID]);
GO

-- Creating foreign key on [PatientSpecificDoseUnitID] in table 'PatientProtocolAssignment_ProtocolDosing'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_PatientSpecificDoseUnit]
    FOREIGN KEY ([PatientSpecificDoseUnitID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_PatientSpecificDoseUnit'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolDosing_LookupElement_PatientSpecificDoseUnit]
ON [dbo].[PatientProtocolAssignment_ProtocolDosing]
    ([PatientSpecificDoseUnitID]);
GO

-- Creating foreign key on [ProtocolApprovalReasonID] in table 'PatientProtocolAssignment_ProtocolExtraInfo'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolExtraInfo]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolExtraInfo_LookupElement_ProtocolApprovalReason]
    FOREIGN KEY ([ProtocolApprovalReasonID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolExtraInfo_LookupElement_ProtocolApprovalReason'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolExtraInfo_LookupElement_ProtocolApprovalReason]
ON [dbo].[PatientProtocolAssignment_ProtocolExtraInfo]
    ([ProtocolApprovalReasonID]);
GO

-- Creating foreign key on [Answer] in table 'PatientProtocolAssignment_ProtocolQuestionAnswer'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolQuestionAnswer]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolQuestionAnswer_LookupElement_Answer]
    FOREIGN KEY ([Answer])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolQuestionAnswer_LookupElement_Answer'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolQuestionAnswer_LookupElement_Answer]
ON [dbo].[PatientProtocolAssignment_ProtocolQuestionAnswer]
    ([Answer]);
GO

-- Creating foreign key on [DecisionDelegationLevel] in table 'PatientProtocolAssignmentInfoes'
ALTER TABLE [dbo].[PatientProtocolAssignmentInfoes]
ADD CONSTRAINT [FK_PatientProtocolAssignmentInfo_LookupElement_DecisionDelegation]
    FOREIGN KEY ([DecisionDelegationLevel])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentInfo_LookupElement_DecisionDelegation'
CREATE INDEX [IX_FK_PatientProtocolAssignmentInfo_LookupElement_DecisionDelegation]
ON [dbo].[PatientProtocolAssignmentInfoes]
    ([DecisionDelegationLevel]);
GO

-- Creating foreign key on [PostDenialPriorityID] in table 'PatientProtocolAssignmentPostDenials'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenials]
ADD CONSTRAINT [FK_PatientProtocolAssignmentPostDenial_LookupElement]
    FOREIGN KEY ([PostDenialPriorityID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentPostDenial_LookupElement'
CREATE INDEX [IX_FK_PatientProtocolAssignmentPostDenial_LookupElement]
ON [dbo].[PatientProtocolAssignmentPostDenials]
    ([PostDenialPriorityID]);
GO

-- Creating foreign key on [PostDenialReasonID] in table 'PatientProtocolAssignmentPostDenials'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenials]
ADD CONSTRAINT [FK_PatientProtocolAssignmentPostDenial_LookupElement1]
    FOREIGN KEY ([PostDenialReasonID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentPostDenial_LookupElement1'
CREATE INDEX [IX_FK_PatientProtocolAssignmentPostDenial_LookupElement1]
ON [dbo].[PatientProtocolAssignmentPostDenials]
    ([PostDenialReasonID]);
GO

-- Creating foreign key on [PostDenialRequestTypeId] in table 'PatientProtocolAssignmentPostDenials'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenials]
ADD CONSTRAINT [FK_PatientProtocolAssignmentPostDenial_PostDenialRequestType_LookupElement]
    FOREIGN KEY ([PostDenialRequestTypeId])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentPostDenial_PostDenialRequestType_LookupElement'
CREATE INDEX [IX_FK_PatientProtocolAssignmentPostDenial_PostDenialRequestType_LookupElement]
ON [dbo].[PatientProtocolAssignmentPostDenials]
    ([PostDenialRequestTypeId]);
GO

-- Creating foreign key on [RequestInitiatorId] in table 'PatientProtocolAssignmentPostDenialInfoes'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialInfoes]
ADD CONSTRAINT [FK_PatientProtocolAssignmentPostDenialInfo_LookupElement_RequestInitiator]
    FOREIGN KEY ([RequestInitiatorId])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentPostDenialInfo_LookupElement_RequestInitiator'
CREATE INDEX [IX_FK_PatientProtocolAssignmentPostDenialInfo_LookupElement_RequestInitiator]
ON [dbo].[PatientProtocolAssignmentPostDenialInfoes]
    ([RequestInitiatorId]);
GO

-- Creating foreign key on [RequestSourceId] in table 'PatientProtocolAssignmentPostDenialInfoes'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialInfoes]
ADD CONSTRAINT [FK_PatientProtocolAssignmentPostDenialInfo_LookupElement_RequestSource]
    FOREIGN KEY ([RequestSourceId])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentPostDenialInfo_LookupElement_RequestSource'
CREATE INDEX [IX_FK_PatientProtocolAssignmentPostDenialInfo_LookupElement_RequestSource]
ON [dbo].[PatientProtocolAssignmentPostDenialInfoes]
    ([RequestSourceId]);
GO

-- Creating foreign key on [PostDenialStatusID] in table 'PatientProtocolAssignmentPostDenialProtocols'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialProtocols]
ADD CONSTRAINT [FK_PatientProtocolAssignmentPostDenialProtocol_LookupElement]
    FOREIGN KEY ([PostDenialStatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentPostDenialProtocol_LookupElement'
CREATE INDEX [IX_FK_PatientProtocolAssignmentPostDenialProtocol_LookupElement]
ON [dbo].[PatientProtocolAssignmentPostDenialProtocols]
    ([PostDenialStatusID]);
GO

-- Creating foreign key on [DrugCodeTypeID] in table 'PatientProtocolAssignmentProtocolElementAlias'
ALTER TABLE [dbo].[PatientProtocolAssignmentProtocolElementAlias]
ADD CONSTRAINT [FK_PatientProtocolAssignmentProtocolElementAlias_LookupElement_DrugCodeType]
    FOREIGN KEY ([DrugCodeTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentProtocolElementAlias_LookupElement_DrugCodeType'
CREATE INDEX [IX_FK_PatientProtocolAssignmentProtocolElementAlias_LookupElement_DrugCodeType]
ON [dbo].[PatientProtocolAssignmentProtocolElementAlias]
    ([DrugCodeTypeID]);
GO

-- Creating foreign key on [TATCalculationMethodID] in table 'PatientProtocolAssignmentTimeCountdowns'
ALTER TABLE [dbo].[PatientProtocolAssignmentTimeCountdowns]
ADD CONSTRAINT [FK_PatientProtocolAssignmentTimeCountdown_LookupElement]
    FOREIGN KEY ([TATCalculationMethodID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentTimeCountdown_LookupElement'
CREATE INDEX [IX_FK_PatientProtocolAssignmentTimeCountdown_LookupElement]
ON [dbo].[PatientProtocolAssignmentTimeCountdowns]
    ([TATCalculationMethodID]);
GO

-- Creating foreign key on [DurationUnitID] in table 'PatientProtocolAssignment_Timer'
ALTER TABLE [dbo].[PatientProtocolAssignment_Timer]
ADD CONSTRAINT [FK_PatientProtocolAssignmentTimer_LookupElement_DurationUnit]
    FOREIGN KEY ([DurationUnitID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentTimer_LookupElement_DurationUnit'
CREATE INDEX [IX_FK_PatientProtocolAssignmentTimer_LookupElement_DurationUnit]
ON [dbo].[PatientProtocolAssignment_Timer]
    ([DurationUnitID]);
GO

-- Creating foreign key on [StatusID] in table 'PatientProtocolAssignment_Timer'
ALTER TABLE [dbo].[PatientProtocolAssignment_Timer]
ADD CONSTRAINT [FK_PatientProtocolAssignmentTimer_LookupElement_TimerStatus]
    FOREIGN KEY ([StatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentTimer_LookupElement_TimerStatus'
CREATE INDEX [IX_FK_PatientProtocolAssignmentTimer_LookupElement_TimerStatus]
ON [dbo].[PatientProtocolAssignment_Timer]
    ([StatusID]);
GO

-- Creating foreign key on [TimerTypeID] in table 'PatientProtocolAssignment_Timer'
ALTER TABLE [dbo].[PatientProtocolAssignment_Timer]
ADD CONSTRAINT [FK_PatientProtocolAssignmentTimer_LookupElement_TimerType]
    FOREIGN KEY ([TimerTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentTimer_LookupElement_TimerType'
CREATE INDEX [IX_FK_PatientProtocolAssignmentTimer_LookupElement_TimerType]
ON [dbo].[PatientProtocolAssignment_Timer]
    ([TimerTypeID]);
GO

-- Creating foreign key on [BenefitTypeID] in table 'PayerFormularies'
ALTER TABLE [dbo].[PayerFormularies]
ADD CONSTRAINT [FK_PayerFormulary_LookupElement_BenefitType]
    FOREIGN KEY ([BenefitTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerFormulary_LookupElement_BenefitType'
CREATE INDEX [IX_FK_PayerFormulary_LookupElement_BenefitType]
ON [dbo].[PayerFormularies]
    ([BenefitTypeID]);
GO

-- Creating foreign key on [OrganizationID] in table 'PayerOrganizations'
ALTER TABLE [dbo].[PayerOrganizations]
ADD CONSTRAINT [FK_PayerOrganization_LookupElement]
    FOREIGN KEY ([OrganizationID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerOrganization_LookupElement'
CREATE INDEX [IX_FK_PayerOrganization_LookupElement]
ON [dbo].[PayerOrganizations]
    ([OrganizationID]);
GO

-- Creating foreign key on [TimerTypeID] in table 'PayerPrimaryTimers'
ALTER TABLE [dbo].[PayerPrimaryTimers]
ADD CONSTRAINT [FK_PayerPrimaryTimer_DimPayer_LookupElement_TimerTypeID]
    FOREIGN KEY ([TimerTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerPrimaryTimer_DimPayer_LookupElement_TimerTypeID'
CREATE INDEX [IX_FK_PayerPrimaryTimer_DimPayer_LookupElement_TimerTypeID]
ON [dbo].[PayerPrimaryTimers]
    ([TimerTypeID]);
GO

-- Creating foreign key on [DurationUnitsID] in table 'PayerTimerConfigurations'
ALTER TABLE [dbo].[PayerTimerConfigurations]
ADD CONSTRAINT [FK_PayerTimerConfiguration_LookupElement_DurationUnits]
    FOREIGN KEY ([DurationUnitsID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerTimerConfiguration_LookupElement_DurationUnits'
CREATE INDEX [IX_FK_PayerTimerConfiguration_LookupElement_DurationUnits]
ON [dbo].[PayerTimerConfigurations]
    ([DurationUnitsID]);
GO

-- Creating foreign key on [DurationUnitsID2] in table 'PayerTimerConfigurations'
ALTER TABLE [dbo].[PayerTimerConfigurations]
ADD CONSTRAINT [FK_PayerTimerConfiguration_LookupElement_DurationUnits2]
    FOREIGN KEY ([DurationUnitsID2])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerTimerConfiguration_LookupElement_DurationUnits2'
CREATE INDEX [IX_FK_PayerTimerConfiguration_LookupElement_DurationUnits2]
ON [dbo].[PayerTimerConfigurations]
    ([DurationUnitsID2]);
GO

-- Creating foreign key on [RequestTypeID] in table 'PayerTimerConfigurations'
ALTER TABLE [dbo].[PayerTimerConfigurations]
ADD CONSTRAINT [FK_PayerTimerConfiguration_LookupElement_RequestType]
    FOREIGN KEY ([RequestTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerTimerConfiguration_LookupElement_RequestType'
CREATE INDEX [IX_FK_PayerTimerConfiguration_LookupElement_RequestType]
ON [dbo].[PayerTimerConfigurations]
    ([RequestTypeID]);
GO

-- Creating foreign key on [ReviewStageID] in table 'PayerTimerConfigurations'
ALTER TABLE [dbo].[PayerTimerConfigurations]
ADD CONSTRAINT [FK_PayerTimerConfiguration_LookupElement_ReviewStage]
    FOREIGN KEY ([ReviewStageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerTimerConfiguration_LookupElement_ReviewStage'
CREATE INDEX [IX_FK_PayerTimerConfiguration_LookupElement_ReviewStage]
ON [dbo].[PayerTimerConfigurations]
    ([ReviewStageID]);
GO

-- Creating foreign key on [AccountTypeID] in table 'PracticeGroups'
ALTER TABLE [dbo].[PracticeGroups]
ADD CONSTRAINT [FK_PracticeGroup_LookupElement_AccountTypeID]
    FOREIGN KEY ([AccountTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PracticeGroup_LookupElement_AccountTypeID'
CREATE INDEX [IX_FK_PracticeGroup_LookupElement_AccountTypeID]
ON [dbo].[PracticeGroups]
    ([AccountTypeID]);
GO

-- Creating foreign key on [EHRSoftwareID] in table 'PracticeGroups'
ALTER TABLE [dbo].[PracticeGroups]
ADD CONSTRAINT [FK_PracticeGroup_LookupElement_EHRSoftwareID]
    FOREIGN KEY ([EHRSoftwareID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PracticeGroup_LookupElement_EHRSoftwareID'
CREATE INDEX [IX_FK_PracticeGroup_LookupElement_EHRSoftwareID]
ON [dbo].[PracticeGroups]
    ([EHRSoftwareID]);
GO

-- Creating foreign key on [PermissionGroupID] in table 'PracticeGroups'
ALTER TABLE [dbo].[PracticeGroups]
ADD CONSTRAINT [FK_PracticeGroup_LookupElement_PermissionGroupID]
    FOREIGN KEY ([PermissionGroupID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PracticeGroup_LookupElement_PermissionGroupID'
CREATE INDEX [IX_FK_PracticeGroup_LookupElement_PermissionGroupID]
ON [dbo].[PracticeGroups]
    ([PermissionGroupID]);
GO

-- Creating foreign key on [TaxonomyTypeID] in table 'PracticeGroups'
ALTER TABLE [dbo].[PracticeGroups]
ADD CONSTRAINT [FK_PracticeGroup_LookupElement_TaxonomyTypeID]
    FOREIGN KEY ([TaxonomyTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PracticeGroup_LookupElement_TaxonomyTypeID'
CREATE INDEX [IX_FK_PracticeGroup_LookupElement_TaxonomyTypeID]
ON [dbo].[PracticeGroups]
    ([TaxonomyTypeID]);
GO

-- Creating foreign key on [AddressTypeID] in table 'PracticeGroupAddresses'
ALTER TABLE [dbo].[PracticeGroupAddresses]
ADD CONSTRAINT [FK_PracticeGroupAddress_LookupElement_AddressTypeID]
    FOREIGN KEY ([AddressTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PracticeGroupAddress_LookupElement_AddressTypeID'
CREATE INDEX [IX_FK_PracticeGroupAddress_LookupElement_AddressTypeID]
ON [dbo].[PracticeGroupAddresses]
    ([AddressTypeID]);
GO

-- Creating foreign key on [RuleLevelID] in table 'PreferredDrugRules'
ALTER TABLE [dbo].[PreferredDrugRules]
ADD CONSTRAINT [FK_PreferredDrugRule_RuleLevelID]
    FOREIGN KEY ([RuleLevelID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PreferredDrugRule_RuleLevelID'
CREATE INDEX [IX_FK_PreferredDrugRule_RuleLevelID]
ON [dbo].[PreferredDrugRules]
    ([RuleLevelID]);
GO

-- Creating foreign key on [ProgramID] in table 'PreferredProtocolProgram_PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PreferredProtocolProgram_PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_LookupElement_Program]
    FOREIGN KEY ([ProgramID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_LookupElement_Program'
CREATE INDEX [IX_FK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_LookupElement_Program]
ON [dbo].[PreferredProtocolProgram_PatientProtocolAssignment_Protocol]
    ([ProgramID]);
GO

-- Creating foreign key on [StatusID] in table 'PreferredProtocolProgram_PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PreferredProtocolProgram_PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_LookupElement_Status]
    FOREIGN KEY ([StatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_LookupElement_Status'
CREATE INDEX [IX_FK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_LookupElement_Status]
ON [dbo].[PreferredProtocolProgram_PatientProtocolAssignment_Protocol]
    ([StatusID]);
GO

-- Creating foreign key on [ProcedureCodeCategoryID] in table 'ProcedureCodeSimpleDescriptions'
ALTER TABLE [dbo].[ProcedureCodeSimpleDescriptions]
ADD CONSTRAINT [FK_ProcedureCodeSimpleDescription_LookupElement_ProcedureCodeCategory]
    FOREIGN KEY ([ProcedureCodeCategoryID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProcedureCodeSimpleDescription_LookupElement_ProcedureCodeCategory'
CREATE INDEX [IX_FK_ProcedureCodeSimpleDescription_LookupElement_ProcedureCodeCategory]
ON [dbo].[ProcedureCodeSimpleDescriptions]
    ([ProcedureCodeCategoryID]);
GO

-- Creating foreign key on [PlanTypeID] in table 'ProductLines'
ALTER TABLE [dbo].[ProductLines]
ADD CONSTRAINT [FK_ProductLine_PlanType]
    FOREIGN KEY ([PlanTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProductLine_PlanType'
CREATE INDEX [IX_FK_ProductLine_PlanType]
ON [dbo].[ProductLines]
    ([PlanTypeID]);
GO

-- Creating foreign key on [ProviderNetworkRuleID] in table 'ProductLines'
ALTER TABLE [dbo].[ProductLines]
ADD CONSTRAINT [FK_ProductLine_ProviderNetworkRule]
    FOREIGN KEY ([ProviderNetworkRuleID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProductLine_ProviderNetworkRule'
CREATE INDEX [IX_FK_ProductLine_ProviderNetworkRule]
ON [dbo].[ProductLines]
    ([ProviderNetworkRuleID]);
GO

-- Creating foreign key on [StageID] in table 'Protocols'
ALTER TABLE [dbo].[Protocols]
ADD CONSTRAINT [FK_Protocol_LookupElement_DiagnosisStage]
    FOREIGN KEY ([StageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Protocol_LookupElement_DiagnosisStage'
CREATE INDEX [IX_FK_Protocol_LookupElement_DiagnosisStage]
ON [dbo].[Protocols]
    ([StageID]);
GO

-- Creating foreign key on [EfficacyRatingID] in table 'Protocols'
ALTER TABLE [dbo].[Protocols]
ADD CONSTRAINT [FK_Protocol_LookupElement_EfficacyRating]
    FOREIGN KEY ([EfficacyRatingID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Protocol_LookupElement_EfficacyRating'
CREATE INDEX [IX_FK_Protocol_LookupElement_EfficacyRating]
ON [dbo].[Protocols]
    ([EfficacyRatingID]);
GO

-- Creating foreign key on [EmetogenicPotentialID] in table 'Protocols'
ALTER TABLE [dbo].[Protocols]
ADD CONSTRAINT [FK_Protocol_LookupElement_EmetogenicPotential]
    FOREIGN KEY ([EmetogenicPotentialID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Protocol_LookupElement_EmetogenicPotential'
CREATE INDEX [IX_FK_Protocol_LookupElement_EmetogenicPotential]
ON [dbo].[Protocols]
    ([EmetogenicPotentialID]);
GO

-- Creating foreign key on [FebrileNeutropeniaRiskID] in table 'Protocols'
ALTER TABLE [dbo].[Protocols]
ADD CONSTRAINT [FK_Protocol_LookupElement_FebrileNeutropenia]
    FOREIGN KEY ([FebrileNeutropeniaRiskID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Protocol_LookupElement_FebrileNeutropenia'
CREATE INDEX [IX_FK_Protocol_LookupElement_FebrileNeutropenia]
ON [dbo].[Protocols]
    ([FebrileNeutropeniaRiskID]);
GO

-- Creating foreign key on [FinancialToxicityID] in table 'Protocols'
ALTER TABLE [dbo].[Protocols]
ADD CONSTRAINT [FK_Protocol_LookupElement_FinancialToxicity]
    FOREIGN KEY ([FinancialToxicityID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Protocol_LookupElement_FinancialToxicity'
CREATE INDEX [IX_FK_Protocol_LookupElement_FinancialToxicity]
ON [dbo].[Protocols]
    ([FinancialToxicityID]);
GO

-- Creating foreign key on [ApplicableGenderID] in table 'Protocols'
ALTER TABLE [dbo].[Protocols]
ADD CONSTRAINT [FK_Protocol_LookupElement_Gender]
    FOREIGN KEY ([ApplicableGenderID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Protocol_LookupElement_Gender'
CREATE INDEX [IX_FK_Protocol_LookupElement_Gender]
ON [dbo].[Protocols]
    ([ApplicableGenderID]);
GO

-- Creating foreign key on [ToxicityRatingID] in table 'Protocols'
ALTER TABLE [dbo].[Protocols]
ADD CONSTRAINT [FK_Protocol_LookupElement_ToxicityRating]
    FOREIGN KEY ([ToxicityRatingID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Protocol_LookupElement_ToxicityRating'
CREATE INDEX [IX_FK_Protocol_LookupElement_ToxicityRating]
ON [dbo].[Protocols]
    ([ToxicityRatingID]);
GO

-- Creating foreign key on [ProcessedID] in table 'ProtocolApprovalLogs'
ALTER TABLE [dbo].[ProtocolApprovalLogs]
ADD CONSTRAINT [FK_ProtocolApprovalLog_LookupElement_ProcessedID]
    FOREIGN KEY ([ProcessedID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolApprovalLog_LookupElement_ProcessedID'
CREATE INDEX [IX_FK_ProtocolApprovalLog_LookupElement_ProcessedID]
ON [dbo].[ProtocolApprovalLogs]
    ([ProcessedID]);
GO

-- Creating foreign key on [ProtocolStatusID] in table 'ProtocolApprovalLogs'
ALTER TABLE [dbo].[ProtocolApprovalLogs]
ADD CONSTRAINT [FK_ProtocolApprovalLog_LookupElement_ProtocolStatusID]
    FOREIGN KEY ([ProtocolStatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolApprovalLog_LookupElement_ProtocolStatusID'
CREATE INDEX [IX_FK_ProtocolApprovalLog_LookupElement_ProtocolStatusID]
ON [dbo].[ProtocolApprovalLogs]
    ([ProtocolStatusID]);
GO

-- Creating foreign key on [ApprovalReasonID] in table 'ProtocolApprovalLogRules'
ALTER TABLE [dbo].[ProtocolApprovalLogRules]
ADD CONSTRAINT [FK_ProtocolApprovalLogRule_ApprovalReason]
    FOREIGN KEY ([ApprovalReasonID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolApprovalLogRule_ApprovalReason'
CREATE INDEX [IX_FK_ProtocolApprovalLogRule_ApprovalReason]
ON [dbo].[ProtocolApprovalLogRules]
    ([ApprovalReasonID]);
GO

-- Creating foreign key on [LookupRuleID] in table 'ProtocolApprovalLogRules'
ALTER TABLE [dbo].[ProtocolApprovalLogRules]
ADD CONSTRAINT [FK_ProtocolApprovalLogRule_LookupRule]
    FOREIGN KEY ([LookupRuleID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolApprovalLogRule_LookupRule'
CREATE INDEX [IX_FK_ProtocolApprovalLogRule_LookupRule]
ON [dbo].[ProtocolApprovalLogRules]
    ([LookupRuleID]);
GO

-- Creating foreign key on [ProcessedAsID] in table 'ProtocolApprovalLogRules'
ALTER TABLE [dbo].[ProtocolApprovalLogRules]
ADD CONSTRAINT [FK_ProtocolApprovalLogRule_ProcessedAs]
    FOREIGN KEY ([ProcessedAsID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolApprovalLogRule_ProcessedAs'
CREATE INDEX [IX_FK_ProtocolApprovalLogRule_ProcessedAs]
ON [dbo].[ProtocolApprovalLogRules]
    ([ProcessedAsID]);
GO

-- Creating foreign key on [RuleModeID] in table 'ProtocolApprovalLogRules'
ALTER TABLE [dbo].[ProtocolApprovalLogRules]
ADD CONSTRAINT [FK_ProtocolApprovalLogRule_RuleMode]
    FOREIGN KEY ([RuleModeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolApprovalLogRule_RuleMode'
CREATE INDEX [IX_FK_ProtocolApprovalLogRule_RuleMode]
ON [dbo].[ProtocolApprovalLogRules]
    ([RuleModeID]);
GO

-- Creating foreign key on [AdministrationMethodID] in table 'ProtocolElements'
ALTER TABLE [dbo].[ProtocolElements]
ADD CONSTRAINT [FK_ProtocolElement_LookupElement_AdminMethod]
    FOREIGN KEY ([AdministrationMethodID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElement_LookupElement_AdminMethod'
CREATE INDEX [IX_FK_ProtocolElement_LookupElement_AdminMethod]
ON [dbo].[ProtocolElements]
    ([AdministrationMethodID]);
GO

-- Creating foreign key on [DoseUnitID] in table 'ProtocolElements'
ALTER TABLE [dbo].[ProtocolElements]
ADD CONSTRAINT [FK_ProtocolElement_LookupElement_DoseUnit]
    FOREIGN KEY ([DoseUnitID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElement_LookupElement_DoseUnit'
CREATE INDEX [IX_FK_ProtocolElement_LookupElement_DoseUnit]
ON [dbo].[ProtocolElements]
    ([DoseUnitID]);
GO

-- Creating foreign key on [FrequencyID] in table 'ProtocolElements'
ALTER TABLE [dbo].[ProtocolElements]
ADD CONSTRAINT [FK_ProtocolElement_LookupElement_Frequency]
    FOREIGN KEY ([FrequencyID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElement_LookupElement_Frequency'
CREATE INDEX [IX_FK_ProtocolElement_LookupElement_Frequency]
ON [dbo].[ProtocolElements]
    ([FrequencyID]);
GO

-- Creating foreign key on [FrequencyPerDayID] in table 'ProtocolElements'
ALTER TABLE [dbo].[ProtocolElements]
ADD CONSTRAINT [FK_ProtocolElement_LookupElement_FrequencyPerDay]
    FOREIGN KEY ([FrequencyPerDayID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElement_LookupElement_FrequencyPerDay'
CREATE INDEX [IX_FK_ProtocolElement_LookupElement_FrequencyPerDay]
ON [dbo].[ProtocolElements]
    ([FrequencyPerDayID]);
GO

-- Creating foreign key on [BillingUnitsQuantityUnitID] in table 'ProtocolElementBillingUnits'
ALTER TABLE [dbo].[ProtocolElementBillingUnits]
ADD CONSTRAINT [FK_ProtocolElementBillingUnits_LookupElement_BillingUnitsQuantityUnit]
    FOREIGN KEY ([BillingUnitsQuantityUnitID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElementBillingUnits_LookupElement_BillingUnitsQuantityUnit'
CREATE INDEX [IX_FK_ProtocolElementBillingUnits_LookupElement_BillingUnitsQuantityUnit]
ON [dbo].[ProtocolElementBillingUnits]
    ([BillingUnitsQuantityUnitID]);
GO

-- Creating foreign key on [BillingMethodID] in table 'ProtocolElementCodes'
ALTER TABLE [dbo].[ProtocolElementCodes]
ADD CONSTRAINT [FK_ProtocolElementCode_LookupElement_BillingMethod]
    FOREIGN KEY ([BillingMethodID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElementCode_LookupElement_BillingMethod'
CREATE INDEX [IX_FK_ProtocolElementCode_LookupElement_BillingMethod]
ON [dbo].[ProtocolElementCodes]
    ([BillingMethodID]);
GO

-- Creating foreign key on [CodeTypeID] in table 'ProtocolElementCodes'
ALTER TABLE [dbo].[ProtocolElementCodes]
ADD CONSTRAINT [FK_ProtocolElementCode_LookupElement_CodeType]
    FOREIGN KEY ([CodeTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElementCode_LookupElement_CodeType'
CREATE INDEX [IX_FK_ProtocolElementCode_LookupElement_CodeType]
ON [dbo].[ProtocolElementCodes]
    ([CodeTypeID]);
GO

-- Creating foreign key on [PatientSpecificDoseUnitID] in table 'ProtocolElementCodes'
ALTER TABLE [dbo].[ProtocolElementCodes]
ADD CONSTRAINT [FK_ProtocolElementCode_LookupElement_PatientSpecificDoseUnit]
    FOREIGN KEY ([PatientSpecificDoseUnitID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElementCode_LookupElement_PatientSpecificDoseUnit'
CREATE INDEX [IX_FK_ProtocolElementCode_LookupElement_PatientSpecificDoseUnit]
ON [dbo].[ProtocolElementCodes]
    ([PatientSpecificDoseUnitID]);
GO

-- Creating foreign key on [OptimalPatientSpecificDoseUnitID] in table 'ProtocolElementDosings'
ALTER TABLE [dbo].[ProtocolElementDosings]
ADD CONSTRAINT [FK_ProtocolElementDosing_OptimalPatientSpecificDoseUnitID]
    FOREIGN KEY ([OptimalPatientSpecificDoseUnitID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElementDosing_OptimalPatientSpecificDoseUnitID'
CREATE INDEX [IX_FK_ProtocolElementDosing_OptimalPatientSpecificDoseUnitID]
ON [dbo].[ProtocolElementDosings]
    ([OptimalPatientSpecificDoseUnitID]);
GO

-- Creating foreign key on [OriginalPatientSpecificDoseUnitID] in table 'ProtocolElementDosings'
ALTER TABLE [dbo].[ProtocolElementDosings]
ADD CONSTRAINT [FK_ProtocolElementDosing_OriginalPatientSpecificDoseUnitID]
    FOREIGN KEY ([OriginalPatientSpecificDoseUnitID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElementDosing_OriginalPatientSpecificDoseUnitID'
CREATE INDEX [IX_FK_ProtocolElementDosing_OriginalPatientSpecificDoseUnitID]
ON [dbo].[ProtocolElementDosings]
    ([OriginalPatientSpecificDoseUnitID]);
GO

-- Creating foreign key on [ReducedDoseUnitID] in table 'ProtocolElementDosings'
ALTER TABLE [dbo].[ProtocolElementDosings]
ADD CONSTRAINT [FK_ProtocolElementDosing_ReducedDoseUnitID]
    FOREIGN KEY ([ReducedDoseUnitID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElementDosing_ReducedDoseUnitID'
CREATE INDEX [IX_FK_ProtocolElementDosing_ReducedDoseUnitID]
ON [dbo].[ProtocolElementDosings]
    ([ReducedDoseUnitID]);
GO

-- Creating foreign key on [VialUnitID] in table 'ProtocolElementDosingVials'
ALTER TABLE [dbo].[ProtocolElementDosingVials]
ADD CONSTRAINT [FK_ProtocolElementDosingVial_VialUnitID]
    FOREIGN KEY ([VialUnitID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElementDosingVial_VialUnitID'
CREATE INDEX [IX_FK_ProtocolElementDosingVial_VialUnitID]
ON [dbo].[ProtocolElementDosingVials]
    ([VialUnitID]);
GO

-- Creating foreign key on [IntentOfTherapyID] in table 'ProtocolIntentOfTherapies'
ALTER TABLE [dbo].[ProtocolIntentOfTherapies]
ADD CONSTRAINT [FK_ProtocolIntentOfTherapy_LookupElement]
    FOREIGN KEY ([IntentOfTherapyID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolIntentOfTherapy_LookupElement'
CREATE INDEX [IX_FK_ProtocolIntentOfTherapy_LookupElement]
ON [dbo].[ProtocolIntentOfTherapies]
    ([IntentOfTherapyID]);
GO

-- Creating foreign key on [LineOfTherapyID] in table 'ProtocolLineOfTherapies'
ALTER TABLE [dbo].[ProtocolLineOfTherapies]
ADD CONSTRAINT [FK_ProtocolLineOfTherapy_LookupElement]
    FOREIGN KEY ([LineOfTherapyID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolLineOfTherapy_LookupElement'
CREATE INDEX [IX_FK_ProtocolLineOfTherapy_LookupElement]
ON [dbo].[ProtocolLineOfTherapies]
    ([LineOfTherapyID]);
GO

-- Creating foreign key on [TestType] in table 'ProtocolMGTs'
ALTER TABLE [dbo].[ProtocolMGTs]
ADD CONSTRAINT [FK_ProtocolMGT_LookupElement_TestType]
    FOREIGN KEY ([TestType])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolMGT_LookupElement_TestType'
CREATE INDEX [IX_FK_ProtocolMGT_LookupElement_TestType]
ON [dbo].[ProtocolMGTs]
    ([TestType]);
GO

-- Creating foreign key on [MolecularMarkerID] in table 'ProtocolMolecularMarkers'
ALTER TABLE [dbo].[ProtocolMolecularMarkers]
ADD CONSTRAINT [FK_ProtocolMolecularMarker_LookupElement]
    FOREIGN KEY ([MolecularMarkerID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolMolecularMarker_LookupElement'
CREATE INDEX [IX_FK_ProtocolMolecularMarker_LookupElement]
ON [dbo].[ProtocolMolecularMarkers]
    ([MolecularMarkerID]);
GO

-- Creating foreign key on [NCCNCategoryID] in table 'ProtocolNCCNCategories'
ALTER TABLE [dbo].[ProtocolNCCNCategories]
ADD CONSTRAINT [FK_ProtocolNCCNCategory_LookupElement]
    FOREIGN KEY ([NCCNCategoryID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolNCCNCategory_LookupElement'
CREATE INDEX [IX_FK_ProtocolNCCNCategory_LookupElement]
ON [dbo].[ProtocolNCCNCategories]
    ([NCCNCategoryID]);
GO

-- Creating foreign key on [PerformanceStatusID] in table 'ProtocolPerformaceStatus'
ALTER TABLE [dbo].[ProtocolPerformaceStatus]
ADD CONSTRAINT [FK_ProtocolPerformaceStatus_LookupElement]
    FOREIGN KEY ([PerformanceStatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolPerformaceStatus_LookupElement'
CREATE INDEX [IX_FK_ProtocolPerformaceStatus_LookupElement]
ON [dbo].[ProtocolPerformaceStatus]
    ([PerformanceStatusID]);
GO

-- Creating foreign key on [StageID] in table 'ProtocolRequests'
ALTER TABLE [dbo].[ProtocolRequests]
ADD CONSTRAINT [FK_ProtocolRequest_LookupElement]
    FOREIGN KEY ([StageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolRequest_LookupElement'
CREATE INDEX [IX_FK_ProtocolRequest_LookupElement]
ON [dbo].[ProtocolRequests]
    ([StageID]);
GO

-- Creating foreign key on [StatusID] in table 'ProtocolRequests'
ALTER TABLE [dbo].[ProtocolRequests]
ADD CONSTRAINT [FK_ProtocolRequest_LookupElement_Status]
    FOREIGN KEY ([StatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolRequest_LookupElement_Status'
CREATE INDEX [IX_FK_ProtocolRequest_LookupElement_Status]
ON [dbo].[ProtocolRequests]
    ([StatusID]);
GO

-- Creating foreign key on [SettingOfTherapyID] in table 'ProtocolSettingOfTherapies'
ALTER TABLE [dbo].[ProtocolSettingOfTherapies]
ADD CONSTRAINT [FK_ProtocolSettingOfTherapy_LookupElement]
    FOREIGN KEY ([SettingOfTherapyID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolSettingOfTherapy_LookupElement'
CREATE INDEX [IX_FK_ProtocolSettingOfTherapy_LookupElement]
ON [dbo].[ProtocolSettingOfTherapies]
    ([SettingOfTherapyID]);
GO

-- Creating foreign key on [AdministrationMethodID] in table 'ProtocolXRTs'
ALTER TABLE [dbo].[ProtocolXRTs]
ADD CONSTRAINT [FK_ProtocolXRT_LookupElement_AdministrationMethod]
    FOREIGN KEY ([AdministrationMethodID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolXRT_LookupElement_AdministrationMethod'
CREATE INDEX [IX_FK_ProtocolXRT_LookupElement_AdministrationMethod]
ON [dbo].[ProtocolXRTs]
    ([AdministrationMethodID]);
GO

-- Creating foreign key on [FrequencyID] in table 'ProtocolXRTs'
ALTER TABLE [dbo].[ProtocolXRTs]
ADD CONSTRAINT [FK_ProtocolXRT_LookupElement_Frequency]
    FOREIGN KEY ([FrequencyID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolXRT_LookupElement_Frequency'
CREATE INDEX [IX_FK_ProtocolXRT_LookupElement_Frequency]
ON [dbo].[ProtocolXRTs]
    ([FrequencyID]);
GO

-- Creating foreign key on [StatusID] in table 'QppAttestationReportResults'
ALTER TABLE [dbo].[QppAttestationReportResults]
ADD CONSTRAINT [FK_QppAttestationReportResult_LookupElement_Status]
    FOREIGN KEY ([StatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_QppAttestationReportResult_LookupElement_Status'
CREATE INDEX [IX_FK_QppAttestationReportResult_LookupElement_Status]
ON [dbo].[QppAttestationReportResults]
    ([StatusID]);
GO

-- Creating foreign key on [UserGroupID] in table 'QppAttestationReportResults'
ALTER TABLE [dbo].[QppAttestationReportResults]
ADD CONSTRAINT [FK_QppAttestationReportResult_LookupElement_UserGroupID]
    FOREIGN KEY ([UserGroupID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_QppAttestationReportResult_LookupElement_UserGroupID'
CREATE INDEX [IX_FK_QppAttestationReportResult_LookupElement_UserGroupID]
ON [dbo].[QppAttestationReportResults]
    ([UserGroupID]);
GO

-- Creating foreign key on [StatusID] in table 'QppReportSettings'
ALTER TABLE [dbo].[QppReportSettings]
ADD CONSTRAINT [FK_QppReportSetting_LookupElement_Status]
    FOREIGN KEY ([StatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_QppReportSetting_LookupElement_Status'
CREATE INDEX [IX_FK_QppReportSetting_LookupElement_Status]
ON [dbo].[QppReportSettings]
    ([StatusID]);
GO

-- Creating foreign key on [RuleTypeID] in table 'Rules'
ALTER TABLE [dbo].[Rules]
ADD CONSTRAINT [FK_Rule_LookupElement_RuleType]
    FOREIGN KEY ([RuleTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Rule_LookupElement_RuleType'
CREATE INDEX [IX_FK_Rule_LookupElement_RuleType]
ON [dbo].[Rules]
    ([RuleTypeID]);
GO

-- Creating foreign key on [StageID] in table 'Rules'
ALTER TABLE [dbo].[Rules]
ADD CONSTRAINT [FK_Rule_LookupElement_Stage]
    FOREIGN KEY ([StageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Rule_LookupElement_Stage'
CREATE INDEX [IX_FK_Rule_LookupElement_Stage]
ON [dbo].[Rules]
    ([StageID]);
GO

-- Creating foreign key on [UserGroupID] in table 'SecurityGroups'
ALTER TABLE [dbo].[SecurityGroups]
ADD CONSTRAINT [FK_SecurityGroup_LookupElement]
    FOREIGN KEY ([UserGroupID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_SecurityGroup_LookupElement'
CREATE INDEX [IX_FK_SecurityGroup_LookupElement]
ON [dbo].[SecurityGroups]
    ([UserGroupID]);
GO

-- Creating foreign key on [FaxParamSideEffectID] in table 'SideEffects'
ALTER TABLE [dbo].[SideEffects]
ADD CONSTRAINT [FK_SideEffect_LookupElement]
    FOREIGN KEY ([FaxParamSideEffectID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_SideEffect_LookupElement'
CREATE INDEX [IX_FK_SideEffect_LookupElement]
ON [dbo].[SideEffects]
    ([FaxParamSideEffectID]);
GO

-- Creating foreign key on [EligibilityStateFieldTypeID] in table 'StateOutofScopeRules'
ALTER TABLE [dbo].[StateOutofScopeRules]
ADD CONSTRAINT [FK_StateOutofScopeRule_LookupElement_EligibilityStateFieldType]
    FOREIGN KEY ([EligibilityStateFieldTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StateOutofScopeRule_LookupElement_EligibilityStateFieldType'
CREATE INDEX [IX_FK_StateOutofScopeRule_LookupElement_EligibilityStateFieldType]
ON [dbo].[StateOutofScopeRules]
    ([EligibilityStateFieldTypeID]);
GO

-- Creating foreign key on [RuleConditionID] in table 'StepTherapyRules'
ALTER TABLE [dbo].[StepTherapyRules]
ADD CONSTRAINT [FK_StepTherapyRule_LookupElement_RuleCondition]
    FOREIGN KEY ([RuleConditionID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StepTherapyRule_LookupElement_RuleCondition'
CREATE INDEX [IX_FK_StepTherapyRule_LookupElement_RuleCondition]
ON [dbo].[StepTherapyRules]
    ([RuleConditionID]);
GO

-- Creating foreign key on [CancerStageID] in table 'StepTherapyRulePatientCancerStageExcludeds'
ALTER TABLE [dbo].[StepTherapyRulePatientCancerStageExcludeds]
ADD CONSTRAINT [FK_StepTherapyRulePatientCancerStageExcluded_LookupElement]
    FOREIGN KEY ([CancerStageID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StepTherapyRulePatientCancerStageExcluded_LookupElement'
CREATE INDEX [IX_FK_StepTherapyRulePatientCancerStageExcluded_LookupElement]
ON [dbo].[StepTherapyRulePatientCancerStageExcludeds]
    ([CancerStageID]);
GO

-- Creating foreign key on [EmetogenicPotentialID] in table 'SupportedProtocolConfigurations'
ALTER TABLE [dbo].[SupportedProtocolConfigurations]
ADD CONSTRAINT [FK_SupportedProtocolConfiguration_LookupElement]
    FOREIGN KEY ([EmetogenicPotentialID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_SupportedProtocolConfiguration_LookupElement'
CREATE INDEX [IX_FK_SupportedProtocolConfiguration_LookupElement]
ON [dbo].[SupportedProtocolConfigurations]
    ([EmetogenicPotentialID]);
GO

-- Creating foreign key on [FebrileNeutropeniaRiskID] in table 'SupportedProtocolConfigurations'
ALTER TABLE [dbo].[SupportedProtocolConfigurations]
ADD CONSTRAINT [FK_SupportedProtocolConfiguration_LookupElement1]
    FOREIGN KEY ([FebrileNeutropeniaRiskID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_SupportedProtocolConfiguration_LookupElement1'
CREATE INDEX [IX_FK_SupportedProtocolConfiguration_LookupElement1]
ON [dbo].[SupportedProtocolConfigurations]
    ([FebrileNeutropeniaRiskID]);
GO

-- Creating foreign key on [RequestTypeID] in table 'TATConfigurations'
ALTER TABLE [dbo].[TATConfigurations]
ADD CONSTRAINT [FK_TATConfiguration_LookupElement_RequestType]
    FOREIGN KEY ([RequestTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_TATConfiguration_LookupElement_RequestType'
CREATE INDEX [IX_FK_TATConfiguration_LookupElement_RequestType]
ON [dbo].[TATConfigurations]
    ([RequestTypeID]);
GO

-- Creating foreign key on [TreatmentTypeID] in table 'TATConfigurations'
ALTER TABLE [dbo].[TATConfigurations]
ADD CONSTRAINT [FK_TATConfiguration_LookupElement_TreatmentType]
    FOREIGN KEY ([TreatmentTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_TATConfiguration_LookupElement_TreatmentType'
CREATE INDEX [IX_FK_TATConfiguration_LookupElement_TreatmentType]
ON [dbo].[TATConfigurations]
    ([TreatmentTypeID]);
GO

-- Creating foreign key on [EventTypeId] in table 'TatEvents'
ALTER TABLE [dbo].[TatEvents]
ADD CONSTRAINT [FK_TatEvent_LookupElement_EventType]
    FOREIGN KEY ([EventTypeId])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_TatEvent_LookupElement_EventType'
CREATE INDEX [IX_FK_TatEvent_LookupElement_EventType]
ON [dbo].[TatEvents]
    ([EventTypeId]);
GO

-- Creating foreign key on [ReviewStageId] in table 'TatEvents'
ALTER TABLE [dbo].[TatEvents]
ADD CONSTRAINT [FK_TatEvent_LookupElement_ReviewStageId]
    FOREIGN KEY ([ReviewStageId])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_TatEvent_LookupElement_ReviewStageId'
CREATE INDEX [IX_FK_TatEvent_LookupElement_ReviewStageId]
ON [dbo].[TatEvents]
    ([ReviewStageId]);
GO

-- Creating foreign key on [TypeOfDeterminationID] in table 'TatExtensionConfigurations'
ALTER TABLE [dbo].[TatExtensionConfigurations]
ADD CONSTRAINT [FK_TatExtensionConfiguration_TypeOfDetermination]
    FOREIGN KEY ([TypeOfDeterminationID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_TatExtensionConfiguration_TypeOfDetermination'
CREATE INDEX [IX_FK_TatExtensionConfiguration_TypeOfDetermination]
ON [dbo].[TatExtensionConfigurations]
    ([TypeOfDeterminationID]);
GO

-- Creating foreign key on [StatusID] in table 'Users'
ALTER TABLE [dbo].[Users]
ADD CONSTRAINT [FK_User_LookupElement_Status]
    FOREIGN KEY ([StatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_User_LookupElement_Status'
CREATE INDEX [IX_FK_User_LookupElement_Status]
ON [dbo].[Users]
    ([StatusID]);
GO

-- Creating foreign key on [UserGroupID] in table 'Users'
ALTER TABLE [dbo].[Users]
ADD CONSTRAINT [FK_User_LookupElement_UserGroup]
    FOREIGN KEY ([UserGroupID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_User_LookupElement_UserGroup'
CREATE INDEX [IX_FK_User_LookupElement_UserGroup]
ON [dbo].[Users]
    ([UserGroupID]);
GO

-- Creating foreign key on [AddressType] in table 'UserAddresses'
ALTER TABLE [dbo].[UserAddresses]
ADD CONSTRAINT [FK_UserAddress_LookupElement_AddressType]
    FOREIGN KEY ([AddressType])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserAddress_LookupElement_AddressType'
CREATE INDEX [IX_FK_UserAddress_LookupElement_AddressType]
ON [dbo].[UserAddresses]
    ([AddressType]);
GO

-- Creating foreign key on [ContactType] in table 'UserContacts'
ALTER TABLE [dbo].[UserContacts]
ADD CONSTRAINT [FK_UserContact_LookupElement_ContactType]
    FOREIGN KEY ([ContactType])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserContact_LookupElement_ContactType'
CREATE INDEX [IX_FK_UserContact_LookupElement_ContactType]
ON [dbo].[UserContacts]
    ([ContactType]);
GO

-- Creating foreign key on [LicenseTypeID] in table 'UserLicenses'
ALTER TABLE [dbo].[UserLicenses]
ADD CONSTRAINT [FK_UserLicense_LookupElement]
    FOREIGN KEY ([LicenseTypeID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserLicense_LookupElement'
CREATE INDEX [IX_FK_UserLicense_LookupElement]
ON [dbo].[UserLicenses]
    ([LicenseTypeID]);
GO

-- Creating foreign key on [ReasonID] in table 'VerificationCodeActivities'
ALTER TABLE [dbo].[VerificationCodeActivities]
ADD CONSTRAINT [FK_VerificationCodeActivity_LookupElement_Reason]
    FOREIGN KEY ([ReasonID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_VerificationCodeActivity_LookupElement_Reason'
CREATE INDEX [IX_FK_VerificationCodeActivity_LookupElement_Reason]
ON [dbo].[VerificationCodeActivities]
    ([ReasonID]);
GO

-- Creating foreign key on [WorkFlowStatusID] in table 'WorkFlowQueueConfigurations'
ALTER TABLE [dbo].[WorkFlowQueueConfigurations]
ADD CONSTRAINT [FK_WorkFlowQueueConfiguration_LookupElement]
    FOREIGN KEY ([WorkFlowStatusID])
    REFERENCES [dbo].[LookupElements]
        ([LookupElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_WorkFlowQueueConfiguration_LookupElement'
CREATE INDEX [IX_FK_WorkFlowQueueConfiguration_LookupElement]
ON [dbo].[WorkFlowQueueConfigurations]
    ([WorkFlowStatusID]);
GO

-- Creating foreign key on [SecurityGroupID] in table 'LookupElement_SecurityGroup'
ALTER TABLE [dbo].[LookupElement_SecurityGroup]
ADD CONSTRAINT [FK_LookupElement_SecurityGroup_SecurityGroup]
    FOREIGN KEY ([SecurityGroupID])
    REFERENCES [dbo].[SecurityGroups]
        ([SecurityGroupID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LookupElement_SecurityGroup_SecurityGroup'
CREATE INDEX [IX_FK_LookupElement_SecurityGroup_SecurityGroup]
ON [dbo].[LookupElement_SecurityGroup]
    ([SecurityGroupID]);
GO

-- Creating foreign key on [PatientID] in table 'MailArchives'
ALTER TABLE [dbo].[MailArchives]
ADD CONSTRAINT [FK_MailArchive_Patient]
    FOREIGN KEY ([PatientID])
    REFERENCES [dbo].[Patients]
        ([PatientID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MailArchive_Patient'
CREATE INDEX [IX_FK_MailArchive_Patient]
ON [dbo].[MailArchives]
    ([PatientID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'MailArchives'
ALTER TABLE [dbo].[MailArchives]
ADD CONSTRAINT [FK_MailArchive_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MailArchive_PatientProtocolAssignment'
CREATE INDEX [IX_FK_MailArchive_PatientProtocolAssignment]
ON [dbo].[MailArchives]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [StateCode] in table 'MailArchives'
ALTER TABLE [dbo].[MailArchives]
ADD CONSTRAINT [FK_MailArchive_State]
    FOREIGN KEY ([StateCode])
    REFERENCES [dbo].[States]
        ([StateCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MailArchive_State'
CREATE INDEX [IX_FK_MailArchive_State]
ON [dbo].[MailArchives]
    ([StateCode]);
GO

-- Creating foreign key on [MailArchiveID] in table 'MailArchiveDocuments'
ALTER TABLE [dbo].[MailArchiveDocuments]
ADD CONSTRAINT [FK_MailArchiveDocument_MailArchive]
    FOREIGN KEY ([MailArchiveID])
    REFERENCES [dbo].[MailArchives]
        ([MailArchiveID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MailArchiveDocument_MailArchive'
CREATE INDEX [IX_FK_MailArchiveDocument_MailArchive]
ON [dbo].[MailArchiveDocuments]
    ([MailArchiveID]);
GO

-- Creating foreign key on [MailArchiveID] in table 'MailArchiveLogs'
ALTER TABLE [dbo].[MailArchiveLogs]
ADD CONSTRAINT [FK_MailArchiveLog_MailArchive]
    FOREIGN KEY ([MailArchiveID])
    REFERENCES [dbo].[MailArchives]
        ([MailArchiveID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MailArchiveLog_MailArchive'
CREATE INDEX [IX_FK_MailArchiveLog_MailArchive]
ON [dbo].[MailArchiveLogs]
    ([MailArchiveID]);
GO

-- Creating foreign key on [MailArchiveDocumentID] in table 'MailArchiveTrackings'
ALTER TABLE [dbo].[MailArchiveTrackings]
ADD CONSTRAINT [FK_MailArchiveDocumentID_MailArchiveTracking_MailArchiveDocumentID]
    FOREIGN KEY ([MailArchiveDocumentID])
    REFERENCES [dbo].[MailArchiveDocuments]
        ([MailArchiveDocumentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MailArchiveDocumentID_MailArchiveTracking_MailArchiveDocumentID'
CREATE INDEX [IX_FK_MailArchiveDocumentID_MailArchiveTracking_MailArchiveDocumentID]
ON [dbo].[MailArchiveTrackings]
    ([MailArchiveDocumentID]);
GO

-- Creating foreign key on [NoteID] in table 'MailArchiveTrackings'
ALTER TABLE [dbo].[MailArchiveTrackings]
ADD CONSTRAINT [FK_NoteID_Note_NoteID]
    FOREIGN KEY ([NoteID])
    REFERENCES [dbo].[Notes]
        ([NoteID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_NoteID_Note_NoteID'
CREATE INDEX [IX_FK_NoteID_Note_NoteID]
ON [dbo].[MailArchiveTrackings]
    ([NoteID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentTimeCountdownID] in table 'MailingCutoffCalculationLogs'
ALTER TABLE [dbo].[MailingCutoffCalculationLogs]
ADD CONSTRAINT [FK_MailingCutoffCalculationLog_PatientProtocolAssignmentTimeCountdown]
    FOREIGN KEY ([PatientProtocolAssignmentTimeCountdownID])
    REFERENCES [dbo].[PatientProtocolAssignmentTimeCountdowns]
        ([PatientProtocolAssignmentTimeCountdownID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MailingCutoffCalculationLog_PatientProtocolAssignmentTimeCountdown'
CREATE INDEX [IX_FK_MailingCutoffCalculationLog_PatientProtocolAssignmentTimeCountdown]
ON [dbo].[MailingCutoffCalculationLogs]
    ([PatientProtocolAssignmentTimeCountdownID]);
GO

-- Creating foreign key on [PatientID] in table 'MemberContactLogs'
ALTER TABLE [dbo].[MemberContactLogs]
ADD CONSTRAINT [FK_MemberContactLog_Patient]
    FOREIGN KEY ([PatientID])
    REFERENCES [dbo].[Patients]
        ([PatientID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MemberContactLog_Patient'
CREATE INDEX [IX_FK_MemberContactLog_Patient]
ON [dbo].[MemberContactLogs]
    ([PatientID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'MemberContactLogs'
ALTER TABLE [dbo].[MemberContactLogs]
ADD CONSTRAINT [FK_MemberContactLog_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MemberContactLog_PatientProtocolAssignment'
CREATE INDEX [IX_FK_MemberContactLog_PatientProtocolAssignment]
ON [dbo].[MemberContactLogs]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [RequesterID] in table 'MemberContactLogs'
ALTER TABLE [dbo].[MemberContactLogs]
ADD CONSTRAINT [FK_MemberContactLog_Requester]
    FOREIGN KEY ([RequesterID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MemberContactLog_Requester'
CREATE INDEX [IX_FK_MemberContactLog_Requester]
ON [dbo].[MemberContactLogs]
    ([RequesterID]);
GO

-- Creating foreign key on [MenuOptionID] in table 'SecurityGroup_MenuOption'
ALTER TABLE [dbo].[SecurityGroup_MenuOption]
ADD CONSTRAINT [FK_SecurityGroup_MenuOption_MenuOption]
    FOREIGN KEY ([MenuOptionID])
    REFERENCES [dbo].[MenuOptions]
        ([MenuOptionID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_SecurityGroup_MenuOption_MenuOption'
CREATE INDEX [IX_FK_SecurityGroup_MenuOption_MenuOption]
ON [dbo].[SecurityGroup_MenuOption]
    ([MenuOptionID]);
GO

-- Creating foreign key on [MultilingualObjectFieldID] in table 'MultilingualDatas'
ALTER TABLE [dbo].[MultilingualDatas]
ADD CONSTRAINT [FK_MultilingualData_MultilingualObjectField]
    FOREIGN KEY ([MultilingualObjectFieldID])
    REFERENCES [dbo].[MultilingualObjectFields]
        ([MultilingualObjectFieldID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MultilingualData_MultilingualObjectField'
CREATE INDEX [IX_FK_MultilingualData_MultilingualObjectField]
ON [dbo].[MultilingualDatas]
    ([MultilingualObjectFieldID]);
GO

-- Creating foreign key on [MultilingualObjectID] in table 'MultilingualObjectFields'
ALTER TABLE [dbo].[MultilingualObjectFields]
ADD CONSTRAINT [FK_MultilingualObjectField_MultilingualObject]
    FOREIGN KEY ([MultilingualObjectID])
    REFERENCES [dbo].[MultilingualObjects]
        ([MultilingualObjectID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MultilingualObjectField_MultilingualObject'
CREATE INDEX [IX_FK_MultilingualObjectField_MultilingualObject]
ON [dbo].[MultilingualObjectFields]
    ([MultilingualObjectID]);
GO

-- Creating foreign key on [NCCNRecurrenceRiskGroupID] in table 'NCCNRecurrenceRiskFormulas'
ALTER TABLE [dbo].[NCCNRecurrenceRiskFormulas]
ADD CONSTRAINT [FK_NCCNRecurrenceRiskFormula_NCCNRecurrenceRiskGroup]
    FOREIGN KEY ([NCCNRecurrenceRiskGroupID])
    REFERENCES [dbo].[NCCNRecurrenceRiskGroups]
        ([NCCNRecurrenceRiskGroupID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_NCCNRecurrenceRiskFormula_NCCNRecurrenceRiskGroup'
CREATE INDEX [IX_FK_NCCNRecurrenceRiskFormula_NCCNRecurrenceRiskGroup]
ON [dbo].[NCCNRecurrenceRiskFormulas]
    ([NCCNRecurrenceRiskGroupID]);
GO

-- Creating foreign key on [PatientID] in table 'Notes'
ALTER TABLE [dbo].[Notes]
ADD CONSTRAINT [FK_Note_Patient]
    FOREIGN KEY ([PatientID])
    REFERENCES [dbo].[Patients]
        ([PatientID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Note_Patient'
CREATE INDEX [IX_FK_Note_Patient]
ON [dbo].[Notes]
    ([PatientID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'Notes'
ALTER TABLE [dbo].[Notes]
ADD CONSTRAINT [FK_Note_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Note_PatientProtocolAssignment'
CREATE INDEX [IX_FK_Note_PatientProtocolAssignment]
ON [dbo].[Notes]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentPostDenialID] in table 'Notes'
ALTER TABLE [dbo].[Notes]
ADD CONSTRAINT [FK_Note_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID]
    FOREIGN KEY ([PatientProtocolAssignmentPostDenialID])
    REFERENCES [dbo].[PatientProtocolAssignmentPostDenials]
        ([PatientProtocolAssignmentPostDenialID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Note_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID'
CREATE INDEX [IX_FK_Note_PatientProtocolAssignmentPostDenial_PatientProtocolAssignmentPostDenialID]
ON [dbo].[Notes]
    ([PatientProtocolAssignmentPostDenialID]);
GO

-- Creating foreign key on [UserID] in table 'Notes'
ALTER TABLE [dbo].[Notes]
ADD CONSTRAINT [FK_Note_User]
    FOREIGN KEY ([UserID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Note_User'
CREATE INDEX [IX_FK_Note_User]
ON [dbo].[Notes]
    ([UserID]);
GO

-- Creating foreign key on [NotificationEnclosureID] in table 'NotificationEnclosureImages'
ALTER TABLE [dbo].[NotificationEnclosureImages]
ADD CONSTRAINT [FK_NotificationEnclosureImage_NotificationEnclosure]
    FOREIGN KEY ([NotificationEnclosureID])
    REFERENCES [dbo].[NotificationEnclosures]
        ([NotificationEnclosureID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_NotificationEnclosureImage_NotificationEnclosure'
CREATE INDEX [IX_FK_NotificationEnclosureImage_NotificationEnclosure]
ON [dbo].[NotificationEnclosureImages]
    ([NotificationEnclosureID]);
GO

-- Creating foreign key on [CurrentMDID] in table 'Patients'
ALTER TABLE [dbo].[Patients]
ADD CONSTRAINT [FK_Patient_User]
    FOREIGN KEY ([CurrentMDID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Patient_User'
CREATE INDEX [IX_FK_Patient_User]
ON [dbo].[Patients]
    ([CurrentMDID]);
GO

-- Creating foreign key on [PatientID] in table 'PatientAssessments'
ALTER TABLE [dbo].[PatientAssessments]
ADD CONSTRAINT [FK_PatientAssessment_Patient]
    FOREIGN KEY ([PatientID])
    REFERENCES [dbo].[Patients]
        ([PatientID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientAssessment_Patient'
CREATE INDEX [IX_FK_PatientAssessment_Patient]
ON [dbo].[PatientAssessments]
    ([PatientID]);
GO

-- Creating foreign key on [PatientID] in table 'PatientClinicalDecisionSupports'
ALTER TABLE [dbo].[PatientClinicalDecisionSupports]
ADD CONSTRAINT [FK_PatientClinicalDecisionSupport_Patient]
    FOREIGN KEY ([PatientID])
    REFERENCES [dbo].[Patients]
        ([PatientID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientClinicalDecisionSupport_Patient'
CREATE INDEX [IX_FK_PatientClinicalDecisionSupport_Patient]
ON [dbo].[PatientClinicalDecisionSupports]
    ([PatientID]);
GO

-- Creating foreign key on [PatientID] in table 'PatientDiagnosis'
ALTER TABLE [dbo].[PatientDiagnosis]
ADD CONSTRAINT [FK_PatientDiagnosis_Patient]
    FOREIGN KEY ([PatientID])
    REFERENCES [dbo].[Patients]
        ([PatientID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientDiagnosis_Patient'
CREATE INDEX [IX_FK_PatientDiagnosis_Patient]
ON [dbo].[PatientDiagnosis]
    ([PatientID]);
GO

-- Creating foreign key on [PatientID] in table 'PatientICDCodes'
ALTER TABLE [dbo].[PatientICDCodes]
ADD CONSTRAINT [FK_PatientICDCode_Patient]
    FOREIGN KEY ([PatientID])
    REFERENCES [dbo].[Patients]
        ([PatientID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientICDCode_Patient'
CREATE INDEX [IX_FK_PatientICDCode_Patient]
ON [dbo].[PatientICDCodes]
    ([PatientID]);
GO

-- Creating foreign key on [PatientID] in table 'PatientProtocolAssignment_Labresult'
ALTER TABLE [dbo].[PatientProtocolAssignment_Labresult]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Labresult_Patient]
    FOREIGN KEY ([PatientID])
    REFERENCES [dbo].[Patients]
        ([PatientID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Labresult_Patient'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Labresult_Patient]
ON [dbo].[PatientProtocolAssignment_Labresult]
    ([PatientID]);
GO

-- Creating foreign key on [PatientID] in table 'PatientProtocolAssignments'
ALTER TABLE [dbo].[PatientProtocolAssignments]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Patient]
    FOREIGN KEY ([PatientID])
    REFERENCES [dbo].[Patients]
        ([PatientID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Patient'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Patient]
ON [dbo].[PatientProtocolAssignments]
    ([PatientID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'PatientAssessments'
ALTER TABLE [dbo].[PatientAssessments]
ADD CONSTRAINT [FK_PatientAssessment_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientAssessment_PatientProtocolAssignment'
CREATE INDEX [IX_FK_PatientAssessment_PatientProtocolAssignment]
ON [dbo].[PatientAssessments]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [CurrentMD] in table 'PatientAssessments'
ALTER TABLE [dbo].[PatientAssessments]
ADD CONSTRAINT [FK_PatientAssessment_User]
    FOREIGN KEY ([CurrentMD])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientAssessment_User'
CREATE INDEX [IX_FK_PatientAssessment_User]
ON [dbo].[PatientAssessments]
    ([CurrentMD]);
GO

-- Creating foreign key on [PatientAssessmentID] in table 'PatientAssessmentAnswers'
ALTER TABLE [dbo].[PatientAssessmentAnswers]
ADD CONSTRAINT [FK_PatientAssessmentAnswer_PatientAssessment]
    FOREIGN KEY ([PatientAssessmentID])
    REFERENCES [dbo].[PatientAssessments]
        ([PatientAssessmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientAssessmentAnswer_PatientAssessment'
CREATE INDEX [IX_FK_PatientAssessmentAnswer_PatientAssessment]
ON [dbo].[PatientAssessmentAnswers]
    ([PatientAssessmentID]);
GO

-- Creating foreign key on [PatientClinicalDecisionSupportID] in table 'PatientClinicalDecisionSupport_Protocol'
ALTER TABLE [dbo].[PatientClinicalDecisionSupport_Protocol]
ADD CONSTRAINT [FK_PatientClinicalDecisionSupport_Protocol_PatientClinicalDecisionSupport]
    FOREIGN KEY ([PatientClinicalDecisionSupportID])
    REFERENCES [dbo].[PatientClinicalDecisionSupports]
        ([PatientClinicalDecisionSupportID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientClinicalDecisionSupport_Protocol_PatientClinicalDecisionSupport'
CREATE INDEX [IX_FK_PatientClinicalDecisionSupport_Protocol_PatientClinicalDecisionSupport]
ON [dbo].[PatientClinicalDecisionSupport_Protocol]
    ([PatientClinicalDecisionSupportID]);
GO

-- Creating foreign key on [ProtocolID] in table 'PatientClinicalDecisionSupport_Protocol'
ALTER TABLE [dbo].[PatientClinicalDecisionSupport_Protocol]
ADD CONSTRAINT [FK_PatientClinicalDecisionSupport_Protocol_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientClinicalDecisionSupport_Protocol_Protocol'
CREATE INDEX [IX_FK_PatientClinicalDecisionSupport_Protocol_Protocol]
ON [dbo].[PatientClinicalDecisionSupport_Protocol]
    ([ProtocolID]);
GO

-- Creating foreign key on [PatientDiagnosisID] in table 'PatientICDCodes'
ALTER TABLE [dbo].[PatientICDCodes]
ADD CONSTRAINT [FK_PatientICDCode_PatientDiagnosis]
    FOREIGN KEY ([PatientDiagnosisID])
    REFERENCES [dbo].[PatientDiagnosis]
        ([PatientDiagnosisID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientICDCode_PatientDiagnosis'
CREATE INDEX [IX_FK_PatientICDCode_PatientDiagnosis]
ON [dbo].[PatientICDCodes]
    ([PatientDiagnosisID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'PatientProtocolAssignment_Labresult'
ALTER TABLE [dbo].[PatientProtocolAssignment_Labresult]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Labresult_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Labresult_PatientProtocolAssignment'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Labresult_PatientProtocolAssignment]
ON [dbo].[PatientProtocolAssignment_Labresult]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_PatientProtocolAssignment'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_PatientProtocolAssignment]
ON [dbo].[PatientProtocolAssignment_Protocol]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'PatientProtocolAssignment_QuestionAnswerXRT'
ALTER TABLE [dbo].[PatientProtocolAssignment_QuestionAnswerXRT]
ADD CONSTRAINT [FK_PatientProtocolAssignment_QuestionAnswerXRT_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_QuestionAnswerXRT_PatientProtocolAssignment'
CREATE INDEX [IX_FK_PatientProtocolAssignment_QuestionAnswerXRT_PatientProtocolAssignment]
ON [dbo].[PatientProtocolAssignment_QuestionAnswerXRT]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [CRSID] in table 'PatientProtocolAssignments'
ALTER TABLE [dbo].[PatientProtocolAssignments]
ADD CONSTRAINT [FK_PatientProtocolAssignment_User_CSRId]
    FOREIGN KEY ([CRSID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_User_CSRId'
CREATE INDEX [IX_FK_PatientProtocolAssignment_User_CSRId]
ON [dbo].[PatientProtocolAssignments]
    ([CRSID]);
GO

-- Creating foreign key on [CurrentMDID] in table 'PatientProtocolAssignments'
ALTER TABLE [dbo].[PatientProtocolAssignments]
ADD CONSTRAINT [FK_PatientProtocolAssignment_User_CurrentMD]
    FOREIGN KEY ([CurrentMDID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_User_CurrentMD'
CREATE INDEX [IX_FK_PatientProtocolAssignment_User_CurrentMD]
ON [dbo].[PatientProtocolAssignments]
    ([CurrentMDID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentId] in table 'PatientProtocolAssignmentEffectuationDates'
ALTER TABLE [dbo].[PatientProtocolAssignmentEffectuationDates]
ADD CONSTRAINT [FK_PatientProtocolAssignmentEffectuationDate_PatientProtocolAssignmentId]
    FOREIGN KEY ([PatientProtocolAssignmentId])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentEffectuationDate_PatientProtocolAssignmentId'
CREATE INDEX [IX_FK_PatientProtocolAssignmentEffectuationDate_PatientProtocolAssignmentId]
ON [dbo].[PatientProtocolAssignmentEffectuationDates]
    ([PatientProtocolAssignmentId]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'PatientProtocolAssignmentPostDenials'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenials]
ADD CONSTRAINT [FK_PatientProtocolAssignmentPostDenial_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentPostDenial_PatientProtocolAssignment'
CREATE INDEX [IX_FK_PatientProtocolAssignmentPostDenial_PatientProtocolAssignment]
ON [dbo].[PatientProtocolAssignmentPostDenials]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'PatientProtocolAssignmentProtocolElementAlias'
ALTER TABLE [dbo].[PatientProtocolAssignmentProtocolElementAlias]
ADD CONSTRAINT [FK_PatientProtocolAssignmentProtocolElementAlias_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentProtocolElementAlias_PatientProtocolAssignment'
CREATE INDEX [IX_FK_PatientProtocolAssignmentProtocolElementAlias_PatientProtocolAssignment]
ON [dbo].[PatientProtocolAssignmentProtocolElementAlias]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'PatientProtocolAssignment_Timer'
ALTER TABLE [dbo].[PatientProtocolAssignment_Timer]
ADD CONSTRAINT [FK_PatientProtocolAssignmentTimer_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentTimer_PatientProtocolAssignment'
CREATE INDEX [IX_FK_PatientProtocolAssignmentTimer_PatientProtocolAssignment]
ON [dbo].[PatientProtocolAssignment_Timer]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'PatientProtocolRulesTrails'
ALTER TABLE [dbo].[PatientProtocolRulesTrails]
ADD CONSTRAINT [FK_PatientProtocolRulesTrail_patientprotocolassignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolRulesTrail_patientprotocolassignment'
CREATE INDEX [IX_FK_PatientProtocolRulesTrail_patientprotocolassignment]
ON [dbo].[PatientProtocolRulesTrails]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'ProtocolApprovalLogs'
ALTER TABLE [dbo].[ProtocolApprovalLogs]
ADD CONSTRAINT [FK_ProtocolApprovalLog_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolApprovalLog_PatientProtocolAssignment'
CREATE INDEX [IX_FK_ProtocolApprovalLog_PatientProtocolAssignment]
ON [dbo].[ProtocolApprovalLogs]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentId] in table 'TatEvents'
ALTER TABLE [dbo].[TatEvents]
ADD CONSTRAINT [FK_TatEvent_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentId])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_TatEvent_PatientProtocolAssignment'
CREATE INDEX [IX_FK_TatEvent_PatientProtocolAssignment]
ON [dbo].[TatEvents]
    ([PatientProtocolAssignmentId]);
GO

-- Creating foreign key on [PatientProtocolAssignmentProtocolID] in table 'PatientProtocolAssignmentHistories'
ALTER TABLE [dbo].[PatientProtocolAssignmentHistories]
ADD CONSTRAINT [FK_PatientProtocolAssignment_History_PatientProtocolAssignment_Protocol]
    FOREIGN KEY ([PatientProtocolAssignmentProtocolID])
    REFERENCES [dbo].[PatientProtocolAssignment_Protocol]
        ([PatientProtocolAssignmentProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_History_PatientProtocolAssignment_Protocol'
CREATE INDEX [IX_FK_PatientProtocolAssignment_History_PatientProtocolAssignment_Protocol]
ON [dbo].[PatientProtocolAssignmentHistories]
    ([PatientProtocolAssignmentProtocolID]);
GO

-- Creating foreign key on [FromProtocolID] in table 'PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_Protocol]
    FOREIGN KEY ([FromProtocolID])
    REFERENCES [dbo].[PatientProtocolAssignment_Protocol]
        ([PatientProtocolAssignmentProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_Protocol'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_Protocol]
ON [dbo].[PatientProtocolAssignment_Protocol]
    ([FromProtocolID]);
GO

-- Creating foreign key on [ProtocolID] in table 'PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_Protocol'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_Protocol]
ON [dbo].[PatientProtocolAssignment_Protocol]
    ([ProtocolID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentProtocolID] in table 'PatientProtocolAssignment_Protocol_ProtocolElementCode'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_PatientProtocolAssignment_Protocol]
    FOREIGN KEY ([PatientProtocolAssignmentProtocolID])
    REFERENCES [dbo].[PatientProtocolAssignment_Protocol]
        ([PatientProtocolAssignmentProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_PatientProtocolAssignment_Protocol'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_PatientProtocolAssignment_Protocol]
ON [dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode]
    ([PatientProtocolAssignmentProtocolID]);
GO

-- Creating foreign key on [InitialPharmDReviewerID] in table 'PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_User_InitialPharmDReviewerID]
    FOREIGN KEY ([InitialPharmDReviewerID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_User_InitialPharmDReviewerID'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_User_InitialPharmDReviewerID]
ON [dbo].[PatientProtocolAssignment_Protocol]
    ([InitialPharmDReviewerID]);
GO

-- Creating foreign key on [Reviewer1] in table 'PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_User_Reviewer1]
    FOREIGN KEY ([Reviewer1])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_User_Reviewer1'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_User_Reviewer1]
ON [dbo].[PatientProtocolAssignment_Protocol]
    ([Reviewer1]);
GO

-- Creating foreign key on [Reviewer2] in table 'PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_User_Reviewer2]
    FOREIGN KEY ([Reviewer2])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_User_Reviewer2'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_User_Reviewer2]
ON [dbo].[PatientProtocolAssignment_Protocol]
    ([Reviewer2]);
GO

-- Creating foreign key on [TranslatorID] in table 'PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_User_TranslatorID]
    FOREIGN KEY ([TranslatorID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_User_TranslatorID'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_User_TranslatorID]
ON [dbo].[PatientProtocolAssignment_Protocol]
    ([TranslatorID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentProtocolID] in table 'PatientProtocolAssignment_ProtocolCPTCodeXRT'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_PatientProtocolAssignment_Protocol]
    FOREIGN KEY ([PatientProtocolAssignmentProtocolID])
    REFERENCES [dbo].[PatientProtocolAssignment_Protocol]
        ([PatientProtocolAssignmentProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_PatientProtocolAssignment_Protocol'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolCPTCodeXRT_PatientProtocolAssignment_Protocol]
ON [dbo].[PatientProtocolAssignment_ProtocolCPTCodeXRT]
    ([PatientProtocolAssignmentProtocolID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentProtocolID] in table 'PatientProtocolAssignment_ProtocolDiagnosis'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDiagnosis]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDiagnosis_PatientProtocolAssignment_Protocol]
    FOREIGN KEY ([PatientProtocolAssignmentProtocolID])
    REFERENCES [dbo].[PatientProtocolAssignment_Protocol]
        ([PatientProtocolAssignmentProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolDiagnosis_PatientProtocolAssignment_Protocol'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolDiagnosis_PatientProtocolAssignment_Protocol]
ON [dbo].[PatientProtocolAssignment_ProtocolDiagnosis]
    ([PatientProtocolAssignmentProtocolID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentProtocolID] in table 'PatientProtocolAssignment_ProtocolDosing'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolDosing]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolDosing_PatientProtocolAssignment_Protocol]
    FOREIGN KEY ([PatientProtocolAssignmentProtocolID])
    REFERENCES [dbo].[PatientProtocolAssignment_Protocol]
        ([PatientProtocolAssignmentProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolDosing_PatientProtocolAssignment_Protocol'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolDosing_PatientProtocolAssignment_Protocol]
ON [dbo].[PatientProtocolAssignment_ProtocolDosing]
    ([PatientProtocolAssignmentProtocolID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentProtocolID] in table 'PatientProtocolAssignment_ProtocolExtraInfo'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolExtraInfo]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolExtraInfo_PatientProtocolAssignment_Protocol]
    FOREIGN KEY ([PatientProtocolAssignmentProtocolID])
    REFERENCES [dbo].[PatientProtocolAssignment_Protocol]
        ([PatientProtocolAssignmentProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [PatientProtocolAssignmentProtocolID] in table 'PatientProtocolAssignment_ProtocolHCPCSCodeGMT'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolHCPCSCodeGMT]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolHCPCSCodeGMT_PatientProtocolAssignment_Protocol]
    FOREIGN KEY ([PatientProtocolAssignmentProtocolID])
    REFERENCES [dbo].[PatientProtocolAssignment_Protocol]
        ([PatientProtocolAssignmentProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolHCPCSCodeGMT_PatientProtocolAssignment_Protocol'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolHCPCSCodeGMT_PatientProtocolAssignment_Protocol]
ON [dbo].[PatientProtocolAssignment_ProtocolHCPCSCodeGMT]
    ([PatientProtocolAssignmentProtocolID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentProtocolID] in table 'PatientProtocolAssignment_ProtocolICDCode'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolICDCode]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolICDCode_PatientProtocolAssignment_Protocol]
    FOREIGN KEY ([PatientProtocolAssignmentProtocolID])
    REFERENCES [dbo].[PatientProtocolAssignment_Protocol]
        ([PatientProtocolAssignmentProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolICDCode_PatientProtocolAssignment_Protocol'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolICDCode_PatientProtocolAssignment_Protocol]
ON [dbo].[PatientProtocolAssignment_ProtocolICDCode]
    ([PatientProtocolAssignmentProtocolID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentProtocolID] in table 'PatientProtocolAssignment_ProtocolQuestionAnswer'
ALTER TABLE [dbo].[PatientProtocolAssignment_ProtocolQuestionAnswer]
ADD CONSTRAINT [FK_PatientProtocolAssignment_ProtocolQuestionAnswer_PatientProtocolAssignment_Protocol]
    FOREIGN KEY ([PatientProtocolAssignmentProtocolID])
    REFERENCES [dbo].[PatientProtocolAssignment_Protocol]
        ([PatientProtocolAssignmentProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_ProtocolQuestionAnswer_PatientProtocolAssignment_Protocol'
CREATE INDEX [IX_FK_PatientProtocolAssignment_ProtocolQuestionAnswer_PatientProtocolAssignment_Protocol]
ON [dbo].[PatientProtocolAssignment_ProtocolQuestionAnswer]
    ([PatientProtocolAssignmentProtocolID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentProtocolID] in table 'PatientProtocolAssignmentPostDenialProtocols'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialProtocols]
ADD CONSTRAINT [FK_PatientProtocolAssignmentPostDenialProtocol_PatientProtocolAssignment_Protocol]
    FOREIGN KEY ([PatientProtocolAssignmentProtocolID])
    REFERENCES [dbo].[PatientProtocolAssignment_Protocol]
        ([PatientProtocolAssignmentProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentPostDenialProtocol_PatientProtocolAssignment_Protocol'
CREATE INDEX [IX_FK_PatientProtocolAssignmentPostDenialProtocol_PatientProtocolAssignment_Protocol]
ON [dbo].[PatientProtocolAssignmentPostDenialProtocols]
    ([PatientProtocolAssignmentProtocolID]);
GO

-- Creating foreign key on [PatientProtocolAssignment_ProtocolID] in table 'PreferredProtocolProgram_PatientProtocolAssignment_Protocol'
ALTER TABLE [dbo].[PreferredProtocolProgram_PatientProtocolAssignment_Protocol]
ADD CONSTRAINT [FK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_Protocol]
    FOREIGN KEY ([PatientProtocolAssignment_ProtocolID])
    REFERENCES [dbo].[PatientProtocolAssignment_Protocol]
        ([PatientProtocolAssignmentProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_Protocol'
CREATE INDEX [IX_FK_PreferredProtocolProgram_PatientProtocolAssignment_Protocol_PatientProtocolAssignment_Protocol]
ON [dbo].[PreferredProtocolProgram_PatientProtocolAssignment_Protocol]
    ([PatientProtocolAssignment_ProtocolID]);
GO

-- Creating foreign key on [ProtocolElementID] in table 'PatientProtocolAssignment_Protocol_ProtocolElementCode'
ALTER TABLE [dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode]
ADD CONSTRAINT [FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_ProtocolElementID]
    FOREIGN KEY ([ProtocolElementID])
    REFERENCES [dbo].[ProtocolElements]
        ([ProtocolElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_ProtocolElementID'
CREATE INDEX [IX_FK_PatientProtocolAssignment_Protocol_ProtocolElementCode_ProtocolElementID]
ON [dbo].[PatientProtocolAssignment_Protocol_ProtocolElementCode]
    ([ProtocolElementID]);
GO

-- Creating foreign key on [PayerTimerConfigurationID] in table 'PatientProtocolAssignment_Timer'
ALTER TABLE [dbo].[PatientProtocolAssignment_Timer]
ADD CONSTRAINT [FK_PatientProtocolAssignmentTimer_PayerTimerConfiguration]
    FOREIGN KEY ([PayerTimerConfigurationID])
    REFERENCES [dbo].[PayerTimerConfigurations]
        ([PayerTimerConfigurationID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentTimer_PayerTimerConfiguration'
CREATE INDEX [IX_FK_PatientProtocolAssignmentTimer_PayerTimerConfiguration]
ON [dbo].[PatientProtocolAssignment_Timer]
    ([PayerTimerConfigurationID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentPostDenialID] in table 'PatientProtocolAssignmentPostDenialInfoes'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialInfoes]
ADD CONSTRAINT [FK_PatientProtocolAssignmentPostDenialInfo_PatientProtocolAssignmentPostDenial]
    FOREIGN KEY ([PatientProtocolAssignmentPostDenialID])
    REFERENCES [dbo].[PatientProtocolAssignmentPostDenials]
        ([PatientProtocolAssignmentPostDenialID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [PatientProtocolAssignmentPostDenialID] in table 'PatientProtocolAssignmentPostDenialProtocols'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialProtocols]
ADD CONSTRAINT [FK_PatientProtocolAssignmentPostDenialProtocol_PatientProtocolAssignmentPostDenial]
    FOREIGN KEY ([PatientProtocolAssignmentPostDenialID])
    REFERENCES [dbo].[PatientProtocolAssignmentPostDenials]
        ([PatientProtocolAssignmentPostDenialID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentPostDenialProtocol_PatientProtocolAssignmentPostDenial'
CREATE INDEX [IX_FK_PatientProtocolAssignmentPostDenialProtocol_PatientProtocolAssignmentPostDenial]
ON [dbo].[PatientProtocolAssignmentPostDenialProtocols]
    ([PatientProtocolAssignmentPostDenialID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentPostDenialID] in table 'PatientProtocolAssignmentTimeCountdowns'
ALTER TABLE [dbo].[PatientProtocolAssignmentTimeCountdowns]
ADD CONSTRAINT [FK_PatientProtocolAssignmentTimeCountdown_PatientProtocolAssignmentPostDenial]
    FOREIGN KEY ([PatientProtocolAssignmentPostDenialID])
    REFERENCES [dbo].[PatientProtocolAssignmentPostDenials]
        ([PatientProtocolAssignmentPostDenialID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentTimeCountdown_PatientProtocolAssignmentPostDenial'
CREATE INDEX [IX_FK_PatientProtocolAssignmentTimeCountdown_PatientProtocolAssignmentPostDenial]
ON [dbo].[PatientProtocolAssignmentTimeCountdowns]
    ([PatientProtocolAssignmentPostDenialID]);
GO

-- Creating foreign key on [PostDenialReviewerID] in table 'PatientProtocolAssignmentPostDenialProtocols'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialProtocols]
ADD CONSTRAINT [FK_PatientProtocolAssignmentPostDenialProtocol_User]
    FOREIGN KEY ([PostDenialReviewerID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentPostDenialProtocol_User'
CREATE INDEX [IX_FK_PatientProtocolAssignmentPostDenialProtocol_User]
ON [dbo].[PatientProtocolAssignmentPostDenialProtocols]
    ([PostDenialReviewerID]);
GO

-- Creating foreign key on [PostDenialTranslatorID] in table 'PatientProtocolAssignmentPostDenialProtocols'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialProtocols]
ADD CONSTRAINT [FK_PatientProtocolAssignmentPostDenialProtocol_User1]
    FOREIGN KEY ([PostDenialTranslatorID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentPostDenialProtocol_User1'
CREATE INDEX [IX_FK_PatientProtocolAssignmentPostDenialProtocol_User1]
ON [dbo].[PatientProtocolAssignmentPostDenialProtocols]
    ([PostDenialTranslatorID]);
GO

-- Creating foreign key on [PostDenialPharmDReviewerID] in table 'PatientProtocolAssignmentPostDenialProtocols'
ALTER TABLE [dbo].[PatientProtocolAssignmentPostDenialProtocols]
ADD CONSTRAINT [FK_PatientProtocolAssignmentPostDenialProtocol_User2]
    FOREIGN KEY ([PostDenialPharmDReviewerID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentPostDenialProtocol_User2'
CREATE INDEX [IX_FK_PatientProtocolAssignmentPostDenialProtocol_User2]
ON [dbo].[PatientProtocolAssignmentPostDenialProtocols]
    ([PostDenialPharmDReviewerID]);
GO

-- Creating foreign key on [ProtocolID] in table 'PatientProtocolAssignmentProtocolElementAlias'
ALTER TABLE [dbo].[PatientProtocolAssignmentProtocolElementAlias]
ADD CONSTRAINT [FK_PatientProtocolAssignmentProtocolElementAlias_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentProtocolElementAlias_Protocol'
CREATE INDEX [IX_FK_PatientProtocolAssignmentProtocolElementAlias_Protocol]
ON [dbo].[PatientProtocolAssignmentProtocolElementAlias]
    ([ProtocolID]);
GO

-- Creating foreign key on [ProtocolElementID] in table 'PatientProtocolAssignmentProtocolElementAlias'
ALTER TABLE [dbo].[PatientProtocolAssignmentProtocolElementAlias]
ADD CONSTRAINT [FK_PatientProtocolAssignmentProtocolElementAlias_ProtocolElement]
    FOREIGN KEY ([ProtocolElementID])
    REFERENCES [dbo].[ProtocolElements]
        ([ProtocolElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignmentProtocolElementAlias_ProtocolElement'
CREATE INDEX [IX_FK_PatientProtocolAssignmentProtocolElementAlias_ProtocolElement]
ON [dbo].[PatientProtocolAssignmentProtocolElementAlias]
    ([ProtocolElementID]);
GO

-- Creating foreign key on [ProtocolID] in table 'PatientProtocolRulesTrails'
ALTER TABLE [dbo].[PatientProtocolRulesTrails]
ADD CONSTRAINT [FK_PatientProtocolRulesTrail_protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolRulesTrail_protocol'
CREATE INDEX [IX_FK_PatientProtocolRulesTrail_protocol]
ON [dbo].[PatientProtocolRulesTrails]
    ([ProtocolID]);
GO

-- Creating foreign key on [PayerTimerConfigurationID] in table 'PayerTimerConfiguration_State'
ALTER TABLE [dbo].[PayerTimerConfiguration_State]
ADD CONSTRAINT [FK_PayerTimerConfigurationState_PayerTimerConfiguration]
    FOREIGN KEY ([PayerTimerConfigurationID])
    REFERENCES [dbo].[PayerTimerConfigurations]
        ([PayerTimerConfigurationID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerTimerConfigurationState_PayerTimerConfiguration'
CREATE INDEX [IX_FK_PayerTimerConfigurationState_PayerTimerConfiguration]
ON [dbo].[PayerTimerConfiguration_State]
    ([PayerTimerConfigurationID]);
GO

-- Creating foreign key on [StateCode] in table 'PayerTimerConfiguration_State'
ALTER TABLE [dbo].[PayerTimerConfiguration_State]
ADD CONSTRAINT [FK_PayerTimerConfigurationState_State]
    FOREIGN KEY ([StateCode])
    REFERENCES [dbo].[States]
        ([StateCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PayerTimerConfigurationState_State'
CREATE INDEX [IX_FK_PayerTimerConfigurationState_State]
ON [dbo].[PayerTimerConfiguration_State]
    ([StateCode]);
GO

-- Creating foreign key on [ParentID] in table 'PracticeGroups'
ALTER TABLE [dbo].[PracticeGroups]
ADD CONSTRAINT [FK_PracticeGroup_PracticeGroup_ParentID]
    FOREIGN KEY ([ParentID])
    REFERENCES [dbo].[PracticeGroups]
        ([PracticeGroupID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PracticeGroup_PracticeGroup_ParentID'
CREATE INDEX [IX_FK_PracticeGroup_PracticeGroup_ParentID]
ON [dbo].[PracticeGroups]
    ([ParentID]);
GO

-- Creating foreign key on [PracticeGroupID] in table 'PracticeGroupAddresses'
ALTER TABLE [dbo].[PracticeGroupAddresses]
ADD CONSTRAINT [FK_PracticeGroupAddress_PracticeGroup_PracticeGroupID]
    FOREIGN KEY ([PracticeGroupID])
    REFERENCES [dbo].[PracticeGroups]
        ([PracticeGroupID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PracticeGroupAddress_PracticeGroup_PracticeGroupID'
CREATE INDEX [IX_FK_PracticeGroupAddress_PracticeGroup_PracticeGroupID]
ON [dbo].[PracticeGroupAddresses]
    ([PracticeGroupID]);
GO

-- Creating foreign key on [PracticeGroupID] in table 'PracticeGroupUsers'
ALTER TABLE [dbo].[PracticeGroupUsers]
ADD CONSTRAINT [FK_PracticeGroupUser_PracticeGroup_PracticeGroupID]
    FOREIGN KEY ([PracticeGroupID])
    REFERENCES [dbo].[PracticeGroups]
        ([PracticeGroupID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PracticeGroupUser_PracticeGroup_PracticeGroupID'
CREATE INDEX [IX_FK_PracticeGroupUser_PracticeGroup_PracticeGroupID]
ON [dbo].[PracticeGroupUsers]
    ([PracticeGroupID]);
GO

-- Creating foreign key on [PracticeGroupPayerID] in table 'PracticeGroupPayers'
ALTER TABLE [dbo].[PracticeGroupPayers]
ADD CONSTRAINT [FK_PracticeGroupPayer_PracticeGroupPayer_PracticeGroupPayerID]
    FOREIGN KEY ([PracticeGroupPayerID])
    REFERENCES [dbo].[PracticeGroupPayers]
        ([PracticeGroupPayerID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [UserID] in table 'PracticeGroupUsers'
ALTER TABLE [dbo].[PracticeGroupUsers]
ADD CONSTRAINT [FK_PracticeGroupUser_User_UserID]
    FOREIGN KEY ([UserID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PracticeGroupUser_User_UserID'
CREATE INDEX [IX_FK_PracticeGroupUser_User_UserID]
ON [dbo].[PracticeGroupUsers]
    ([UserID]);
GO

-- Creating foreign key on [RuleID] in table 'PreferredDrugRules'
ALTER TABLE [dbo].[PreferredDrugRules]
ADD CONSTRAINT [FK_PreferredDrugRule_RuleID]
    FOREIGN KEY ([RuleID])
    REFERENCES [dbo].[Rules]
        ([RuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PreferredDrugRule_RuleID'
CREATE INDEX [IX_FK_PreferredDrugRule_RuleID]
ON [dbo].[PreferredDrugRules]
    ([RuleID]);
GO

-- Creating foreign key on [ProtocolID] in table 'PrerequisiteDrugs'
ALTER TABLE [dbo].[PrerequisiteDrugs]
ADD CONSTRAINT [FK_PrerequisiteDrug_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PrerequisiteDrug_Protocol'
CREATE INDEX [IX_FK_PrerequisiteDrug_Protocol]
ON [dbo].[PrerequisiteDrugs]
    ([ProtocolID]);
GO

-- Creating foreign key on [ProfileSettingID] in table 'UserProfileSettings'
ALTER TABLE [dbo].[UserProfileSettings]
ADD CONSTRAINT [FK_UserProfileSetting_ProfileSetting]
    FOREIGN KEY ([ProfileSettingID])
    REFERENCES [dbo].[ProfileSettings]
        ([ProfileSettingID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserProfileSetting_ProfileSetting'
CREATE INDEX [IX_FK_UserProfileSetting_ProfileSetting]
ON [dbo].[UserProfileSettings]
    ([ProfileSettingID]);
GO

-- Creating foreign key on [ProtocolID] in table 'Protocol_Diagnosis'
ALTER TABLE [dbo].[Protocol_Diagnosis]
ADD CONSTRAINT [FK_Protocol_Diagnosis_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Protocol_Diagnosis_Protocol'
CREATE INDEX [IX_FK_Protocol_Diagnosis_Protocol]
ON [dbo].[Protocol_Diagnosis]
    ([ProtocolID]);
GO

-- Creating foreign key on [ParentProtocolID] in table 'Protocols'
ALTER TABLE [dbo].[Protocols]
ADD CONSTRAINT [FK_Protocol_Protocol_ParentProtocolID]
    FOREIGN KEY ([ParentProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Protocol_Protocol_ParentProtocolID'
CREATE INDEX [IX_FK_Protocol_Protocol_ParentProtocolID]
ON [dbo].[Protocols]
    ([ParentProtocolID]);
GO

-- Creating foreign key on [ProtocolID] in table 'ProtocolApprovalLogs'
ALTER TABLE [dbo].[ProtocolApprovalLogs]
ADD CONSTRAINT [FK_ProtocolApprovalLog_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolApprovalLog_Protocol'
CREATE INDEX [IX_FK_ProtocolApprovalLog_Protocol]
ON [dbo].[ProtocolApprovalLogs]
    ([ProtocolID]);
GO

-- Creating foreign key on [ProtocolID] in table 'ProtocolAuthorizationTips'
ALTER TABLE [dbo].[ProtocolAuthorizationTips]
ADD CONSTRAINT [FK_ProtocolAuthorizationTip_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolAuthorizationTip_Protocol'
CREATE INDEX [IX_FK_ProtocolAuthorizationTip_Protocol]
ON [dbo].[ProtocolAuthorizationTips]
    ([ProtocolID]);
GO

-- Creating foreign key on [ProtocolID] in table 'ProtocolElements'
ALTER TABLE [dbo].[ProtocolElements]
ADD CONSTRAINT [FK_ProtocolElement_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElement_Protocol'
CREATE INDEX [IX_FK_ProtocolElement_Protocol]
ON [dbo].[ProtocolElements]
    ([ProtocolID]);
GO

-- Creating foreign key on [ProtocolID] in table 'ProtocolElementXRTs'
ALTER TABLE [dbo].[ProtocolElementXRTs]
ADD CONSTRAINT [FK_ProtocolElementXRT_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElementXRT_Protocol'
CREATE INDEX [IX_FK_ProtocolElementXRT_Protocol]
ON [dbo].[ProtocolElementXRTs]
    ([ProtocolID]);
GO

-- Creating foreign key on [ProtocolID] in table 'ProtocolEvidenceLinks'
ALTER TABLE [dbo].[ProtocolEvidenceLinks]
ADD CONSTRAINT [FK_ProtocolEvidenceLink_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolEvidenceLink_Protocol'
CREATE INDEX [IX_FK_ProtocolEvidenceLink_Protocol]
ON [dbo].[ProtocolEvidenceLinks]
    ([ProtocolID]);
GO

-- Creating foreign key on [ProtocolID] in table 'ProtocolIntentOfTherapies'
ALTER TABLE [dbo].[ProtocolIntentOfTherapies]
ADD CONSTRAINT [FK_ProtocolIntentOfTherapy_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolIntentOfTherapy_Protocol'
CREATE INDEX [IX_FK_ProtocolIntentOfTherapy_Protocol]
ON [dbo].[ProtocolIntentOfTherapies]
    ([ProtocolID]);
GO

-- Creating foreign key on [ProtocolID] in table 'ProtocolLineOfTherapies'
ALTER TABLE [dbo].[ProtocolLineOfTherapies]
ADD CONSTRAINT [FK_ProtocolLineOfTherapy_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolLineOfTherapy_Protocol'
CREATE INDEX [IX_FK_ProtocolLineOfTherapy_Protocol]
ON [dbo].[ProtocolLineOfTherapies]
    ([ProtocolID]);
GO

-- Creating foreign key on [ProtocolID] in table 'ProtocolMGTs'
ALTER TABLE [dbo].[ProtocolMGTs]
ADD CONSTRAINT [FK_ProtocolMGT_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [ProtocolID] in table 'ProtocolMolecularMarkers'
ALTER TABLE [dbo].[ProtocolMolecularMarkers]
ADD CONSTRAINT [FK_ProtocolMolecularMarker_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolMolecularMarker_Protocol'
CREATE INDEX [IX_FK_ProtocolMolecularMarker_Protocol]
ON [dbo].[ProtocolMolecularMarkers]
    ([ProtocolID]);
GO

-- Creating foreign key on [ProtocolID] in table 'ProtocolNCCNCategories'
ALTER TABLE [dbo].[ProtocolNCCNCategories]
ADD CONSTRAINT [FK_ProtocolNCCNCategory_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolNCCNCategory_Protocol'
CREATE INDEX [IX_FK_ProtocolNCCNCategory_Protocol]
ON [dbo].[ProtocolNCCNCategories]
    ([ProtocolID]);
GO

-- Creating foreign key on [ProtocolID] in table 'ProtocolPerformaceStatus'
ALTER TABLE [dbo].[ProtocolPerformaceStatus]
ADD CONSTRAINT [FK_ProtocolPerformaceStatus_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolPerformaceStatus_Protocol'
CREATE INDEX [IX_FK_ProtocolPerformaceStatus_Protocol]
ON [dbo].[ProtocolPerformaceStatus]
    ([ProtocolID]);
GO

-- Creating foreign key on [ProtocolID] in table 'ProtocolQuestions'
ALTER TABLE [dbo].[ProtocolQuestions]
ADD CONSTRAINT [FK_ProtocolQuestion_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolQuestion_Protocol'
CREATE INDEX [IX_FK_ProtocolQuestion_Protocol]
ON [dbo].[ProtocolQuestions]
    ([ProtocolID]);
GO

-- Creating foreign key on [ProtocolID] in table 'ProtocolSettingOfTherapies'
ALTER TABLE [dbo].[ProtocolSettingOfTherapies]
ADD CONSTRAINT [FK_ProtocolSettingOfTherapy_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolSettingOfTherapy_Protocol'
CREATE INDEX [IX_FK_ProtocolSettingOfTherapy_Protocol]
ON [dbo].[ProtocolSettingOfTherapies]
    ([ProtocolID]);
GO

-- Creating foreign key on [ProtocolID] in table 'ProtocolXRTs'
ALTER TABLE [dbo].[ProtocolXRTs]
ADD CONSTRAINT [FK_ProtocolXRT_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [ProtocolID] in table 'SupportedProtocolConfigurations'
ALTER TABLE [dbo].[SupportedProtocolConfigurations]
ADD CONSTRAINT [FK_SupportedProtocolConfiguration_Protocol]
    FOREIGN KEY ([ProtocolID])
    REFERENCES [dbo].[Protocols]
        ([ProtocolID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_SupportedProtocolConfiguration_Protocol'
CREATE INDEX [IX_FK_SupportedProtocolConfiguration_Protocol]
ON [dbo].[SupportedProtocolConfigurations]
    ([ProtocolID]);
GO

-- Creating foreign key on [ProtocolApprovalLogID] in table 'ProtocolApprovalLogRules'
ALTER TABLE [dbo].[ProtocolApprovalLogRules]
ADD CONSTRAINT [FK_ProtocolApprovalLogRule_ProtocolApprovalLog]
    FOREIGN KEY ([ProtocolApprovalLogID])
    REFERENCES [dbo].[ProtocolApprovalLogs]
        ([ProtocolApprovalLogID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolApprovalLogRule_ProtocolApprovalLog'
CREATE INDEX [IX_FK_ProtocolApprovalLogRule_ProtocolApprovalLog]
ON [dbo].[ProtocolApprovalLogRules]
    ([ProtocolApprovalLogID]);
GO

-- Creating foreign key on [ProtocolElementID] in table 'ProtocolElementBillingUnits'
ALTER TABLE [dbo].[ProtocolElementBillingUnits]
ADD CONSTRAINT [FK_ProtocolElementBillingUnits_ProtocolElement]
    FOREIGN KEY ([ProtocolElementID])
    REFERENCES [dbo].[ProtocolElements]
        ([ProtocolElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElementBillingUnits_ProtocolElement'
CREATE INDEX [IX_FK_ProtocolElementBillingUnits_ProtocolElement]
ON [dbo].[ProtocolElementBillingUnits]
    ([ProtocolElementID]);
GO

-- Creating foreign key on [ProtocolElementID] in table 'ProtocolElementCodes'
ALTER TABLE [dbo].[ProtocolElementCodes]
ADD CONSTRAINT [FK_ProtocolElementCode_ProtocolElement]
    FOREIGN KEY ([ProtocolElementID])
    REFERENCES [dbo].[ProtocolElements]
        ([ProtocolElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElementCode_ProtocolElement'
CREATE INDEX [IX_FK_ProtocolElementCode_ProtocolElement]
ON [dbo].[ProtocolElementCodes]
    ([ProtocolElementID]);
GO

-- Creating foreign key on [ProtocolElementID] in table 'ProtocolElement_RxNavDenorms'
ALTER TABLE [dbo].[ProtocolElement_RxNavDenorms]
ADD CONSTRAINT [FK_ProtocolElement_RxNavDenormID_ProtocolElement]
    FOREIGN KEY ([ProtocolElementID])
    REFERENCES [dbo].[ProtocolElements]
        ([ProtocolElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElement_RxNavDenormID_ProtocolElement'
CREATE INDEX [IX_FK_ProtocolElement_RxNavDenormID_ProtocolElement]
ON [dbo].[ProtocolElement_RxNavDenorms]
    ([ProtocolElementID]);
GO

-- Creating foreign key on [ProtocolElementID] in table 'ProtocolElementDosings'
ALTER TABLE [dbo].[ProtocolElementDosings]
ADD CONSTRAINT [FK_ProtocolElementDosing_ProtocolElementID]
    FOREIGN KEY ([ProtocolElementID])
    REFERENCES [dbo].[ProtocolElements]
        ([ProtocolElementID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElementDosing_ProtocolElementID'
CREATE INDEX [IX_FK_ProtocolElementDosing_ProtocolElementID]
ON [dbo].[ProtocolElementDosings]
    ([ProtocolElementID]);
GO

-- Creating foreign key on [ProtocolElementCodeID] in table 'ProtocolElementCodeFormularyDatas'
ALTER TABLE [dbo].[ProtocolElementCodeFormularyDatas]
ADD CONSTRAINT [FK_ProtocolElementCodeFormularyDataID_ProtocolElementCode]
    FOREIGN KEY ([ProtocolElementCodeID])
    REFERENCES [dbo].[ProtocolElementCodes]
        ([ProtocolElementCodeID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElementCodeFormularyDataID_ProtocolElementCode'
CREATE INDEX [IX_FK_ProtocolElementCodeFormularyDataID_ProtocolElementCode]
ON [dbo].[ProtocolElementCodeFormularyDatas]
    ([ProtocolElementCodeID]);
GO

-- Creating foreign key on [ProtocolElementDosingID] in table 'ProtocolElementDosingVials'
ALTER TABLE [dbo].[ProtocolElementDosingVials]
ADD CONSTRAINT [FK_ProtocolElementDosingVial_ProtocolElementDosingID]
    FOREIGN KEY ([ProtocolElementDosingID])
    REFERENCES [dbo].[ProtocolElementDosings]
        ([ProtocolElementDosingID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolElementDosingVial_ProtocolElementDosingID'
CREATE INDEX [IX_FK_ProtocolElementDosingVial_ProtocolElementDosingID]
ON [dbo].[ProtocolElementDosingVials]
    ([ProtocolElementDosingID]);
GO

-- Creating foreign key on [ProtocolRequestID] in table 'ProtocolRequestDrugs'
ALTER TABLE [dbo].[ProtocolRequestDrugs]
ADD CONSTRAINT [FK_ProtocolRequestDrug_ProtocolRequest]
    FOREIGN KEY ([ProtocolRequestID])
    REFERENCES [dbo].[ProtocolRequests]
        ([ProtocolRequestID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProtocolRequestDrug_ProtocolRequest'
CREATE INDEX [IX_FK_ProtocolRequestDrug_ProtocolRequest]
ON [dbo].[ProtocolRequestDrugs]
    ([ProtocolRequestID]);
GO

-- Creating foreign key on [ProviderID] in table 'UserAccessList_Provider'
ALTER TABLE [dbo].[UserAccessList_Provider]
ADD CONSTRAINT [FK_ProviderID_UserAccessList]
    FOREIGN KEY ([ProviderID])
    REFERENCES [dbo].[Providers]
        ([ProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProviderID_UserAccessList'
CREATE INDEX [IX_FK_ProviderID_UserAccessList]
ON [dbo].[UserAccessList_Provider]
    ([ProviderID]);
GO

-- Creating foreign key on [QppReportSettingID] in table 'QppAttestationReportResults'
ALTER TABLE [dbo].[QppAttestationReportResults]
ADD CONSTRAINT [FK_QppAttestationReportResult_QppReportSettings_ID]
    FOREIGN KEY ([QppReportSettingID])
    REFERENCES [dbo].[QppReportSettings]
        ([QppReportSettingId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_QppAttestationReportResult_QppReportSettings_ID'
CREATE INDEX [IX_FK_QppAttestationReportResult_QppReportSettings_ID]
ON [dbo].[QppAttestationReportResults]
    ([QppReportSettingID]);
GO

-- Creating foreign key on [AttestedBy] in table 'QppAttestationReportResults'
ALTER TABLE [dbo].[QppAttestationReportResults]
ADD CONSTRAINT [FK_QppAttestationReportResult_User_AttestatedBy]
    FOREIGN KEY ([AttestedBy])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_QppAttestationReportResult_User_AttestatedBy'
CREATE INDEX [IX_FK_QppAttestationReportResult_User_AttestatedBy]
ON [dbo].[QppAttestationReportResults]
    ([AttestedBy]);
GO

-- Creating foreign key on [RuleID] in table 'StepTherapyRules'
ALTER TABLE [dbo].[StepTherapyRules]
ADD CONSTRAINT [FK_StepTherapyRule_Rule]
    FOREIGN KEY ([RuleID])
    REFERENCES [dbo].[Rules]
        ([RuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StepTherapyRule_Rule'
CREATE INDEX [IX_FK_StepTherapyRule_Rule]
ON [dbo].[StepTherapyRules]
    ([RuleID]);
GO

-- Creating foreign key on [RuleID] in table 'StopLossRules'
ALTER TABLE [dbo].[StopLossRules]
ADD CONSTRAINT [FK_StopLossRule_RuleID]
    FOREIGN KEY ([RuleID])
    REFERENCES [dbo].[Rules]
        ([RuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StopLossRule_RuleID'
CREATE INDEX [IX_FK_StopLossRule_RuleID]
ON [dbo].[StopLossRules]
    ([RuleID]);
GO

-- Creating foreign key on [SecurityGroupID] in table 'SecurityGroup_MenuOption'
ALTER TABLE [dbo].[SecurityGroup_MenuOption]
ADD CONSTRAINT [FK_SecurityGroup_MenuOption_SecurityGroup]
    FOREIGN KEY ([SecurityGroupID])
    REFERENCES [dbo].[SecurityGroups]
        ([SecurityGroupID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_SecurityGroup_MenuOption_SecurityGroup'
CREATE INDEX [IX_FK_SecurityGroup_MenuOption_SecurityGroup]
ON [dbo].[SecurityGroup_MenuOption]
    ([SecurityGroupID]);
GO

-- Creating foreign key on [SecurityGroupID] in table 'User_SecurityGroup'
ALTER TABLE [dbo].[User_SecurityGroup]
ADD CONSTRAINT [FK_User_SecurityGroup_SecurityGroup]
    FOREIGN KEY ([SecurityGroupID])
    REFERENCES [dbo].[SecurityGroups]
        ([SecurityGroupID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_User_SecurityGroup_SecurityGroup'
CREATE INDEX [IX_FK_User_SecurityGroup_SecurityGroup]
ON [dbo].[User_SecurityGroup]
    ([SecurityGroupID]);
GO

-- Creating foreign key on [SecurityGroupID] in table 'WorkQueue_SecurityGroup'
ALTER TABLE [dbo].[WorkQueue_SecurityGroup]
ADD CONSTRAINT [FK_WorkQueue_SecurityGroup_SecurityGroup]
    FOREIGN KEY ([SecurityGroupID])
    REFERENCES [dbo].[SecurityGroups]
        ([SecurityGroupID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_WorkQueue_SecurityGroup_SecurityGroup'
CREATE INDEX [IX_FK_WorkQueue_SecurityGroup_SecurityGroup]
ON [dbo].[WorkQueue_SecurityGroup]
    ([SecurityGroupID]);
GO

-- Creating foreign key on [RefSfId] in table 'SfOriginAccounts'
ALTER TABLE [dbo].[SfOriginAccounts]
ADD CONSTRAINT [FK_SfOriginAccount_SfOriginAccount]
    FOREIGN KEY ([RefSfId])
    REFERENCES [dbo].[SfOriginAccounts]
        ([sfId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_SfOriginAccount_SfOriginAccount'
CREATE INDEX [IX_FK_SfOriginAccount_SfOriginAccount]
ON [dbo].[SfOriginAccounts]
    ([RefSfId]);
GO

-- Creating foreign key on [AccountId] in table 'SfOriginContacts'
ALTER TABLE [dbo].[SfOriginContacts]
ADD CONSTRAINT [FK_SfOriginContact_SfOriginAccount]
    FOREIGN KEY ([AccountId])
    REFERENCES [dbo].[SfOriginAccounts]
        ([sfId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_SfOriginContact_SfOriginAccount'
CREATE INDEX [IX_FK_SfOriginContact_SfOriginAccount]
ON [dbo].[SfOriginContacts]
    ([AccountId]);
GO

-- Creating foreign key on [SalesforceAccountID] in table 'Users'
ALTER TABLE [dbo].[Users]
ADD CONSTRAINT [FK_User_SfOriginAccount]
    FOREIGN KEY ([SalesforceAccountID])
    REFERENCES [dbo].[SfOriginAccounts]
        ([sfId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_User_SfOriginAccount'
CREATE INDEX [IX_FK_User_SfOriginAccount]
ON [dbo].[Users]
    ([SalesforceAccountID]);
GO

-- Creating foreign key on [RefSfId] in table 'SfOriginContacts'
ALTER TABLE [dbo].[SfOriginContacts]
ADD CONSTRAINT [FK_SfOriginContact_SfOriginContact]
    FOREIGN KEY ([RefSfId])
    REFERENCES [dbo].[SfOriginContacts]
        ([sfId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_SfOriginContact_SfOriginContact'
CREATE INDEX [IX_FK_SfOriginContact_SfOriginContact]
ON [dbo].[SfOriginContacts]
    ([RefSfId]);
GO

-- Creating foreign key on [SalesforceContactID] in table 'Users'
ALTER TABLE [dbo].[Users]
ADD CONSTRAINT [FK_User_SfOriginContact]
    FOREIGN KEY ([SalesforceContactID])
    REFERENCES [dbo].[SfOriginContacts]
        ([sfId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_User_SfOriginContact'
CREATE INDEX [IX_FK_User_SfOriginContact]
ON [dbo].[Users]
    ([SalesforceContactID]);
GO

-- Creating foreign key on [StateCode] in table 'StepTherapyStateExcludeds'
ALTER TABLE [dbo].[StepTherapyStateExcludeds]
ADD CONSTRAINT [FK_StepTherapyStateExcluded_State]
    FOREIGN KEY ([StateCode])
    REFERENCES [dbo].[States]
        ([StateCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StepTherapyStateExcluded_State'
CREATE INDEX [IX_FK_StepTherapyStateExcluded_State]
ON [dbo].[StepTherapyStateExcludeds]
    ([StateCode]);
GO

-- Creating foreign key on [StateCode] in table 'StepTherapyStateOfPlanIssueExcludeds'
ALTER TABLE [dbo].[StepTherapyStateOfPlanIssueExcludeds]
ADD CONSTRAINT [FK_StepTherapyStateOfPlanIssueExcluded_State]
    FOREIGN KEY ([StateCode])
    REFERENCES [dbo].[States]
        ([StateCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StepTherapyStateOfPlanIssueExcluded_State'
CREATE INDEX [IX_FK_StepTherapyStateOfPlanIssueExcluded_State]
ON [dbo].[StepTherapyStateOfPlanIssueExcludeds]
    ([StateCode]);
GO

-- Creating foreign key on [State] in table 'TatExtensionConfigurations'
ALTER TABLE [dbo].[TatExtensionConfigurations]
ADD CONSTRAINT [FK_TatExtensionConfiguration_State]
    FOREIGN KEY ([State])
    REFERENCES [dbo].[States]
        ([StateCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_TatExtensionConfiguration_State'
CREATE INDEX [IX_FK_TatExtensionConfiguration_State]
ON [dbo].[TatExtensionConfigurations]
    ([State]);
GO

-- Creating foreign key on [StateCode] in table 'UserAddresses'
ALTER TABLE [dbo].[UserAddresses]
ADD CONSTRAINT [FK_UserAddress_State]
    FOREIGN KEY ([StateCode])
    REFERENCES [dbo].[States]
        ([StateCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserAddress_State'
CREATE INDEX [IX_FK_UserAddress_State]
ON [dbo].[UserAddresses]
    ([StateCode]);
GO

-- Creating foreign key on [StateCode] in table 'UserLicenses'
ALTER TABLE [dbo].[UserLicenses]
ADD CONSTRAINT [FK_UserLicense_State_StateCode]
    FOREIGN KEY ([StateCode])
    REFERENCES [dbo].[States]
        ([StateCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserLicense_State_StateCode'
CREATE INDEX [IX_FK_UserLicense_State_StateCode]
ON [dbo].[UserLicenses]
    ([StateCode]);
GO

-- Creating foreign key on [StepTherapyRuleID] in table 'StepTherapyRulePriorDrugs'
ALTER TABLE [dbo].[StepTherapyRulePriorDrugs]
ADD CONSTRAINT [FK_SStepTherapyRulePriorDrug_Rule]
    FOREIGN KEY ([StepTherapyRuleID])
    REFERENCES [dbo].[StepTherapyRules]
        ([StepTherapyRuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_SStepTherapyRulePriorDrug_Rule'
CREATE INDEX [IX_FK_SStepTherapyRulePriorDrug_Rule]
ON [dbo].[StepTherapyRulePriorDrugs]
    ([StepTherapyRuleID]);
GO

-- Creating foreign key on [StepTherapyRuleID] in table 'StepTherapyRuleDiagnosisExcludeds'
ALTER TABLE [dbo].[StepTherapyRuleDiagnosisExcludeds]
ADD CONSTRAINT [FK_StepTherapyRuleDiagnosisExcluded_StepTherapyRule]
    FOREIGN KEY ([StepTherapyRuleID])
    REFERENCES [dbo].[StepTherapyRules]
        ([StepTherapyRuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StepTherapyRuleDiagnosisExcluded_StepTherapyRule'
CREATE INDEX [IX_FK_StepTherapyRuleDiagnosisExcluded_StepTherapyRule]
ON [dbo].[StepTherapyRuleDiagnosisExcludeds]
    ([StepTherapyRuleID]);
GO

-- Creating foreign key on [StepTherapyRuleID] in table 'StepTherapyRulePatientCancerStageExcludeds'
ALTER TABLE [dbo].[StepTherapyRulePatientCancerStageExcludeds]
ADD CONSTRAINT [FK_StepTherapyRulePatientCancerStageExcluded_StepTherapyRule]
    FOREIGN KEY ([StepTherapyRuleID])
    REFERENCES [dbo].[StepTherapyRules]
        ([StepTherapyRuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StepTherapyRulePatientCancerStageExcluded_StepTherapyRule'
CREATE INDEX [IX_FK_StepTherapyRulePatientCancerStageExcluded_StepTherapyRule]
ON [dbo].[StepTherapyRulePatientCancerStageExcludeds]
    ([StepTherapyRuleID]);
GO

-- Creating foreign key on [StepTherapyRuleID] in table 'StepTherapyStateExcludeds'
ALTER TABLE [dbo].[StepTherapyStateExcludeds]
ADD CONSTRAINT [FK_StepTherapyStateExcluded_StepTherapyRule]
    FOREIGN KEY ([StepTherapyRuleID])
    REFERENCES [dbo].[StepTherapyRules]
        ([StepTherapyRuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StepTherapyStateExcluded_StepTherapyRule'
CREATE INDEX [IX_FK_StepTherapyStateExcluded_StepTherapyRule]
ON [dbo].[StepTherapyStateExcludeds]
    ([StepTherapyRuleID]);
GO

-- Creating foreign key on [StepTherapyRuleID] in table 'StepTherapyStateOfPlanIssueExcludeds'
ALTER TABLE [dbo].[StepTherapyStateOfPlanIssueExcludeds]
ADD CONSTRAINT [FK_StepTherapyStateOfPlanIssueExcluded_StepTherapyRule]
    FOREIGN KEY ([StepTherapyRuleID])
    REFERENCES [dbo].[StepTherapyRules]
        ([StepTherapyRuleID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_StepTherapyStateOfPlanIssueExcluded_StepTherapyRule'
CREATE INDEX [IX_FK_StepTherapyStateOfPlanIssueExcluded_StepTherapyRule]
ON [dbo].[StepTherapyStateOfPlanIssueExcludeds]
    ([StepTherapyRuleID]);
GO

-- Creating foreign key on [UserID] in table 'User_MemberAssociation'
ALTER TABLE [dbo].[User_MemberAssociation]
ADD CONSTRAINT [FK_User_MemberAssociation_User]
    FOREIGN KEY ([UserID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_User_MemberAssociation_User'
CREATE INDEX [IX_FK_User_MemberAssociation_User]
ON [dbo].[User_MemberAssociation]
    ([UserID]);
GO

-- Creating foreign key on [UserID] in table 'User_SecurityGroup'
ALTER TABLE [dbo].[User_SecurityGroup]
ADD CONSTRAINT [FK_User_SecurityGroup_User]
    FOREIGN KEY ([UserID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_User_SecurityGroup_User'
CREATE INDEX [IX_FK_User_SecurityGroup_User]
ON [dbo].[User_SecurityGroup]
    ([UserID]);
GO

-- Creating foreign key on [UserID] in table 'UserAddresses'
ALTER TABLE [dbo].[UserAddresses]
ADD CONSTRAINT [FK_UserAddress_User]
    FOREIGN KEY ([UserID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserAddress_User'
CREATE INDEX [IX_FK_UserAddress_User]
ON [dbo].[UserAddresses]
    ([UserID]);
GO

-- Creating foreign key on [UserID] in table 'UserAreaCodes'
ALTER TABLE [dbo].[UserAreaCodes]
ADD CONSTRAINT [FK_UserAreaCode_User]
    FOREIGN KEY ([UserID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserAreaCode_User'
CREATE INDEX [IX_FK_UserAreaCode_User]
ON [dbo].[UserAreaCodes]
    ([UserID]);
GO

-- Creating foreign key on [UserID] in table 'UserCaseAcceptanceTimes'
ALTER TABLE [dbo].[UserCaseAcceptanceTimes]
ADD CONSTRAINT [FK_UserCaseAcceptanceTime_User]
    FOREIGN KEY ([UserID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserCaseAcceptanceTime_User'
CREATE INDEX [IX_FK_UserCaseAcceptanceTime_User]
ON [dbo].[UserCaseAcceptanceTimes]
    ([UserID]);
GO

-- Creating foreign key on [UserID] in table 'UserContacts'
ALTER TABLE [dbo].[UserContacts]
ADD CONSTRAINT [FK_UserContact_User]
    FOREIGN KEY ([UserID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserContact_User'
CREATE INDEX [IX_FK_UserContact_User]
ON [dbo].[UserContacts]
    ([UserID]);
GO

-- Creating foreign key on [UserID] in table 'UserLicenses'
ALTER TABLE [dbo].[UserLicenses]
ADD CONSTRAINT [FK_UserLicense_User_UserID]
    FOREIGN KEY ([UserID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserLicense_User_UserID'
CREATE INDEX [IX_FK_UserLicense_User_UserID]
ON [dbo].[UserLicenses]
    ([UserID]);
GO

-- Creating foreign key on [UserID] in table 'UserLoginActivities'
ALTER TABLE [dbo].[UserLoginActivities]
ADD CONSTRAINT [FK_UserLoginActivity_User]
    FOREIGN KEY ([UserID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserLoginActivity_User'
CREATE INDEX [IX_FK_UserLoginActivity_User]
ON [dbo].[UserLoginActivities]
    ([UserID]);
GO

-- Creating foreign key on [UserID] in table 'UserProfileSettings'
ALTER TABLE [dbo].[UserProfileSettings]
ADD CONSTRAINT [FK_UserProfileSetting_User]
    FOREIGN KEY ([UserID])
    REFERENCES [dbo].[Users]
        ([UserID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserProfileSetting_User'
CREATE INDEX [IX_FK_UserProfileSetting_User]
ON [dbo].[UserProfileSettings]
    ([UserID]);
GO

-- Creating foreign key on [UserAccessListID] in table 'UserAccessList_Provider'
ALTER TABLE [dbo].[UserAccessList_Provider]
ADD CONSTRAINT [FK_UserAccessList_ProviderID]
    FOREIGN KEY ([UserAccessListID])
    REFERENCES [dbo].[UserAccessLists]
        ([UserAccessListID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserAccessList_ProviderID'
CREATE INDEX [IX_FK_UserAccessList_ProviderID]
ON [dbo].[UserAccessList_Provider]
    ([UserAccessListID]);
GO

-- Creating foreign key on [WorkQueueID] in table 'WorkFlowQueueConfigurations'
ALTER TABLE [dbo].[WorkFlowQueueConfigurations]
ADD CONSTRAINT [FK_WorkFlowQueueConfiguration_WorkQueue]
    FOREIGN KEY ([WorkQueueID])
    REFERENCES [dbo].[WorkQueues]
        ([WorkQueueID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_WorkFlowQueueConfiguration_WorkQueue'
CREATE INDEX [IX_FK_WorkFlowQueueConfiguration_WorkQueue]
ON [dbo].[WorkFlowQueueConfigurations]
    ([WorkQueueID]);
GO

-- Creating foreign key on [WorkQueueID] in table 'WorkQueue_SecurityGroup'
ALTER TABLE [dbo].[WorkQueue_SecurityGroup]
ADD CONSTRAINT [FK_WorkQueue_SecurityGroup_WorkQueue]
    FOREIGN KEY ([WorkQueueID])
    REFERENCES [dbo].[WorkQueues]
        ([WorkQueueID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_WorkQueue_SecurityGroup_WorkQueue'
CREATE INDEX [IX_FK_WorkQueue_SecurityGroup_WorkQueue]
ON [dbo].[WorkQueue_SecurityGroup]
    ([WorkQueueID]);
GO

-- Creating foreign key on [PatientProtocolAssignmentID] in table 'PatientProtocolAssignment_VitalSign'
ALTER TABLE [dbo].[PatientProtocolAssignment_VitalSign]
ADD CONSTRAINT [FK_PatientProtocolAssignment_VitalSigns_PatientProtocolAssignment]
    FOREIGN KEY ([PatientProtocolAssignmentID])
    REFERENCES [dbo].[PatientProtocolAssignments]
        ([PatientProtocolAssignmentID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_PatientProtocolAssignment_VitalSigns_PatientProtocolAssignment'
CREATE INDEX [IX_FK_PatientProtocolAssignment_VitalSigns_PatientProtocolAssignment]
ON [dbo].[PatientProtocolAssignment_VitalSign]
    ([PatientProtocolAssignmentID]);
GO

-- Creating foreign key on [AppealLanguageID] in table 'DynamicFaxContents'
ALTER TABLE [dbo].[DynamicFaxContents]
ADD CONSTRAINT [FK_DynamicFaxContent_AppealLanguage]
    FOREIGN KEY ([AppealLanguageID])
    REFERENCES [dbo].[DocumentTextBlocks]
        ([DocumentTextBlockID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DynamicFaxContent_AppealLanguage'
CREATE INDEX [IX_FK_DynamicFaxContent_AppealLanguage]
ON [dbo].[DynamicFaxContents]
    ([AppealLanguageID]);
GO

-- Creating foreign key on [HelpInfoID] in table 'DynamicFaxContents'
ALTER TABLE [dbo].[DynamicFaxContents]
ADD CONSTRAINT [FK_DynamicFaxContent_DocumentTextBlock_HelpInfo]
    FOREIGN KEY ([HelpInfoID])
    REFERENCES [dbo].[DocumentTextBlocks]
        ([DocumentTextBlockID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DynamicFaxContent_DocumentTextBlock_HelpInfo'
CREATE INDEX [IX_FK_DynamicFaxContent_DocumentTextBlock_HelpInfo]
ON [dbo].[DynamicFaxContents]
    ([HelpInfoID]);
GO

-- Creating foreign key on [LogoImageID] in table 'DynamicFaxContents'
ALTER TABLE [dbo].[DynamicFaxContents]
ADD CONSTRAINT [FK_DynamicFaxContent_Image]
    FOREIGN KEY ([LogoImageID])
    REFERENCES [dbo].[Images]
        ([ImageID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DynamicFaxContent_Image'
CREATE INDEX [IX_FK_DynamicFaxContent_Image]
ON [dbo].[DynamicFaxContents]
    ([LogoImageID]);
GO

-- Creating foreign key on [ExternalAppealsApplicationID] in table 'DynamicFaxContents'
ALTER TABLE [dbo].[DynamicFaxContents]
ADD CONSTRAINT [FK_DynamicFaxContent_NotificationEnclosure_Application]
    FOREIGN KEY ([ExternalAppealsApplicationID])
    REFERENCES [dbo].[NotificationEnclosures]
        ([NotificationEnclosureID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DynamicFaxContent_NotificationEnclosure_Application'
CREATE INDEX [IX_FK_DynamicFaxContent_NotificationEnclosure_Application]
ON [dbo].[DynamicFaxContents]
    ([ExternalAppealsApplicationID]);
GO

-- Creating foreign key on [GuideToAppealingInsuranceDenialsID] in table 'DynamicFaxContents'
ALTER TABLE [dbo].[DynamicFaxContents]
ADD CONSTRAINT [FK_DynamicFaxContent_NotificationEnclosure_Guide]
    FOREIGN KEY ([GuideToAppealingInsuranceDenialsID])
    REFERENCES [dbo].[NotificationEnclosures]
        ([NotificationEnclosureID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DynamicFaxContent_NotificationEnclosure_Guide'
CREATE INDEX [IX_FK_DynamicFaxContent_NotificationEnclosure_Guide]
ON [dbo].[DynamicFaxContents]
    ([GuideToAppealingInsuranceDenialsID]);
GO

-- Creating foreign key on [InsuranceProviderID] in table 'ExcludedPCPs'
ALTER TABLE [dbo].[ExcludedPCPs]
ADD CONSTRAINT [FK_ExcludedPCP_InsuranceProvider]
    FOREIGN KEY ([InsuranceProviderID])
    REFERENCES [dbo].[InsuranceProviders]
        ([InsuranceProviderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ExcludedPCP_InsuranceProvider'
CREATE INDEX [IX_FK_ExcludedPCP_InsuranceProvider]
ON [dbo].[ExcludedPCPs]
    ([InsuranceProviderID]);
GO

-- Creating foreign key on [DimPayerID] in table 'SpecialtyDrugCodes'
ALTER TABLE [dbo].[SpecialtyDrugCodes]
ADD CONSTRAINT [FK_SpecialtyDrugCodes_DimPayer]
    FOREIGN KEY ([DimPayerID])
    REFERENCES [dbo].[DimPayers]
        ([DimPayerID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_SpecialtyDrugCodes_DimPayer'
CREATE INDEX [IX_FK_SpecialtyDrugCodes_DimPayer]
ON [dbo].[SpecialtyDrugCodes]
    ([DimPayerID]);
GO

-- Creating foreign key on [DrugCodeID] in table 'SpecialtyDrugCodes'
ALTER TABLE [dbo].[SpecialtyDrugCodes]
ADD CONSTRAINT [FK_SpecialtyDrugCodes_DrugCode]
    FOREIGN KEY ([DrugCodeID])
    REFERENCES [dbo].[DrugCodes]
        ([DrugCodeID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_SpecialtyDrugCodes_DrugCode'
CREATE INDEX [IX_FK_SpecialtyDrugCodes_DrugCode]
ON [dbo].[SpecialtyDrugCodes]
    ([DrugCodeID]);
GO

-- Creating foreign key on [DenialHealthcareAdvocateInfoID] in table 'DynamicFaxContents'
ALTER TABLE [dbo].[DynamicFaxContents]
ADD CONSTRAINT [FK_DynamicFaxContent_DocumentTextBlock_DenialHealthcareAdvocateInfo]
    FOREIGN KEY ([DenialHealthcareAdvocateInfoID])
    REFERENCES [dbo].[DocumentTextBlocks]
        ([DocumentTextBlockID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DynamicFaxContent_DocumentTextBlock_DenialHealthcareAdvocateInfo'
CREATE INDEX [IX_FK_DynamicFaxContent_DocumentTextBlock_DenialHealthcareAdvocateInfo]
ON [dbo].[DynamicFaxContents]
    ([DenialHealthcareAdvocateInfoID]);
GO

-- Creating foreign key on [LineOfBusinessId] in table 'LineOfBusiness_CAGSetting'
ALTER TABLE [dbo].[LineOfBusiness_CAGSetting]
ADD CONSTRAINT [FK_LobCagSetting_LineOfBusinessID]
    FOREIGN KEY ([LineOfBusinessId])
    REFERENCES [dbo].[LineofBusinesses]
        ([LineOfBusinessID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LobCagSetting_LineOfBusinessID'
CREATE INDEX [IX_FK_LobCagSetting_LineOfBusinessID]
ON [dbo].[LineOfBusiness_CAGSetting]
    ([LineOfBusinessId]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------