import re
import sys
import json

def parse_sql_file(sql_file):
    """Parse SQL file to extract table definitions and foreign keys."""
    with open(sql_file, 'r', encoding='utf-8') as f:
        content = f.read()

    tables = {}

    # Extract CREATE TABLE statements
    table_pattern = r'CREATE TABLE \[dbo\]\.\[(\w+)\]\s*\((.*?)\);'
    matches = re.finditer(table_pattern, content, re.DOTALL | re.IGNORECASE)

    for match in matches:
        table_name = match.group(1)
        table_def = match.group(2)

        # Extract columns
        columns = []
        column_pattern = r'\[(\w+)\]\s+(\[?\w+\]?(?:\(\d+(?:,\s*\d+)?\))?(?:\s+IDENTITY\(\d+,\s*\d+\))?)\s*(NOT NULL|NULL)?(?:\s+DEFAULT\s+[^,\n]+)?'
        for col_match in re.finditer(column_pattern, table_def):
            col_name = col_match.group(1)
            col_type = col_match.group(2)
            columns.append({'name': col_name, 'type': col_type})

        tables[table_name] = {
            'columns': columns,
            'foreign_keys': [],
            'primary_keys': []
        }

    # Extract PRIMARY KEYs from ALTER TABLE statements
    pk_pattern = r'ALTER TABLE \[dbo\]\.\[(\w+)\]\s+ADD CONSTRAINT \[PK_\w+\]\s+PRIMARY KEY[^(]*\(\[(\w+)\](?:\s+\w+)?(?:,\s*\[(\w+)\])?\)'
    for pk_match in re.finditer(pk_pattern, content, re.IGNORECASE):
        table_name = pk_match.group(1)
        if table_name in tables:
            tables[table_name]['primary_keys'].append(pk_match.group(2))
            if pk_match.group(3):
                tables[table_name]['primary_keys'].append(pk_match.group(3))

    # Extract FOREIGN KEYs from ALTER TABLE statements
    fk_pattern = r'ALTER TABLE \[dbo\]\.\[(\w+)\]\s+ADD CONSTRAINT \[FK_\w+\]\s+FOREIGN KEY\s*\(\[(\w+)\]\)\s+REFERENCES\s+\[dbo\]\.\[(\w+)\]\s*\(\[(\w+)\]\)'
    for fk_match in re.finditer(fk_pattern, content, re.IGNORECASE):
        table_name = fk_match.group(1)
        fk_column = fk_match.group(2)
        ref_table = fk_match.group(3)
        ref_column = fk_match.group(4)

        if table_name in tables:
            tables[table_name]['foreign_keys'].append({
                'column': fk_column,
                'ref_table': ref_table,
                'ref_column': ref_column
            })

    return tables

def find_referencing_tables(tables, target_table):
    """Find all tables that reference the target table."""
    referencing = []
    for table_name, table_info in tables.items():
        for fk in table_info['foreign_keys']:
            if fk['ref_table'] == target_table:
                referencing.append({
                    'table': table_name,
                    'fk_column': fk['column'],
                    'ref_column': fk['ref_column']
                })
    return referencing

def clean_column_type(col_type):
    """Clean SQL Server column type for dbdiagram.io compatibility."""
    # Remove IDENTITY syntax
    col_type = re.sub(r'\s*IDENTITY\(\d+,\s*\d+\)', '', col_type)
    # Remove brackets
    col_type = col_type.replace('[', '').replace(']', '')
    return col_type.strip()

def generate_dbdiagram(tables, target_table):
    """Generate dbdiagram.io format for a table and its one-level dependencies."""
    if target_table not in tables:
        return f"Error: Table '{target_table}' not found in the database schema."

    dbml = []

    # Set default layout algorithm to Snowflake
    dbml.append("Project {")
    dbml.append("  database_type: 'SQL Server'")
    dbml.append("  Note: '''")
    dbml.append(f"    One-level dependency diagram for {target_table}")
    dbml.append("  '''")
    dbml.append("}")
    dbml.append("")

    target_info = tables[target_table]
    related_tables = set()

    # Add the target table
    dbml.append(f"Table {target_table} {{")
    for col in target_info['columns']:
        clean_type = clean_column_type(col['type'])
        is_pk = col['name'] in target_info['primary_keys']

        marker_str = " [pk]" if is_pk else ""
        dbml.append(f"  {col['name']} {clean_type}{marker_str}")
    dbml.append("}")
    dbml.append("")

    # Add tables that target_table references (outgoing FKs)
    for fk in target_info['foreign_keys']:
        ref_table = fk['ref_table']
        related_tables.add(ref_table)

        if ref_table in tables:
            ref_info = tables[ref_table]
            dbml.append(f"Table {ref_table} {{")
            for col in ref_info['columns']:
                clean_type = clean_column_type(col['type'])
                pk_marker = " [pk]" if col['name'] in ref_info['primary_keys'] else ""
                dbml.append(f"  {col['name']} {clean_type}{pk_marker}")
            dbml.append("}")
            dbml.append("")

    # Add tables that reference target_table (incoming FKs)
    referencing = find_referencing_tables(tables, target_table)
    for ref in referencing:
        ref_table = ref['table']
        if ref_table not in related_tables:
            related_tables.add(ref_table)

            if ref_table in tables:
                ref_info = tables[ref_table]
                dbml.append(f"Table {ref_table} {{")
                for col in ref_info['columns']:
                    clean_type = clean_column_type(col['type'])
                    pk_marker = " [pk]" if col['name'] in ref_info['primary_keys'] else ""
                    dbml.append(f"  {col['name']} {clean_type}{pk_marker}")
                dbml.append("}")
                dbml.append("")

    # Add relationships
    dbml.append("// Relationships")

    # Outgoing relationships (target_table -> referenced tables)
    for fk in target_info['foreign_keys']:
        ref_table = fk['ref_table']
        dbml.append(f"Ref: {target_table}.{fk['column']} > {ref_table}.{fk['ref_column']}")

    # Incoming relationships (referencing tables -> target_table)
    for ref in referencing:
        dbml.append(f"Ref: {ref['table']}.{ref['fk_column']} > {target_table}.{ref['ref_column']}")

    return "\n".join(dbml)

def generate_json(tables, target_table):
    """Generate JSON representation of table dependencies."""
    if target_table not in tables:
        return json.dumps({"error": f"Table '{target_table}' not found in the database schema."}, indent=2)

    target_info = tables[target_table]

    # Build the dependency structure
    result = {
        "table": target_table,
        "summary": {
            "total_columns": len(target_info['columns']),
            "primary_key_count": len(target_info['primary_keys']),
            "foreign_key_count": len(target_info['foreign_keys']),
            "references_count": 0,  # Will be updated below
            "referenced_by_count": 0  # Will be updated below
        },
        "columns": target_info['columns'],
        "primary_keys": target_info['primary_keys'],
        "references": [],  # Tables this table references
        "referenced_by": []  # Tables that reference this table
    }

    # Add outgoing references (tables this table references)
    for fk in target_info['foreign_keys']:
        ref_table = fk['ref_table']
        if ref_table in tables:
            result['references'].append({
                "table": ref_table,
                "foreign_key": fk['column'],
                "references_column": fk['ref_column'],
                "columns": tables[ref_table]['columns'],
                "primary_keys": tables[ref_table]['primary_keys']
            })

    # Add incoming references (tables that reference this table)
    referencing = find_referencing_tables(tables, target_table)
    for ref in referencing:
        ref_table = ref['table']
        if ref_table in tables:
            result['referenced_by'].append({
                "table": ref_table,
                "foreign_key": ref['fk_column'],
                "references_column": ref['ref_column'],
                "columns": tables[ref_table]['columns'],
                "primary_keys": tables[ref_table]['primary_keys']
            })

    # Update summary counts
    result['summary']['references_count'] = len(result['references'])
    result['summary']['referenced_by_count'] = len(result['referenced_by'])
    result['summary']['total_related_tables'] = result['summary']['references_count'] + result['summary']['referenced_by_count']

    return json.dumps(result, indent=2)

def main():
    if len(sys.argv) != 2:
        print("Usage: python generate_table_dependencies.py <TableName>")
        print("Example: python generate_table_dependencies.py Patient")
        sys.exit(1)

    table_name = sys.argv[1]
    sql_file = r"src\Data\OncologyAnalytics.DB\ApplicationModel.edmx.sql"

    print(f"Parsing SQL file: {sql_file}")
    tables = parse_sql_file(sql_file)
    print(f"Found {len(tables)} tables")

    print(f"\nGenerating dependency diagram for table: {table_name}\n")
    diagram = generate_dbdiagram(tables, table_name)
    json_data = generate_json(tables, table_name)

    # Save DBML file
    dbml_output_file = f"{table_name}_dependencies.dbml"
    with open(dbml_output_file, 'w', encoding='utf-8') as f:
        f.write(diagram)

    # Save JSON file
    json_output_file = f"{table_name}_dependencies.json"
    with open(json_output_file, 'w', encoding='utf-8') as f:
        f.write(json_data)

    print(diagram)
    print(f"\n\nDiagram saved to: {dbml_output_file}")
    print(f"JSON data saved to: {json_output_file}")
    print("Copy the DBML contents and paste into https://dbdiagram.io/d")

if __name__ == "__main__":
    main()
